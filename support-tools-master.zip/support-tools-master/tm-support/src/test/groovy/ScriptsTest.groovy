import com.edifecs.support.Storage
import com.edifecs.support.Support
import com.edifecs.support.tm.TmConfig
import com.edifecs.support.tm.TmSupport
import spock.lang.Ignore
import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ScriptsTest extends Specification {

    @Ignore
    void 'verify all-logs script'() {
        def context = Support.info {
            include('/collect/all-logs.groovy')
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify tm-tomcat-logs script'() {
        def context = Support.info {
            include('/collect/tm-tomcat-logs')
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify tm-classic script'() {
        def context = Support.info {
            include('/collect/tm-classic-install.groovy')
        }
        expect:
        context
        context.values()
//        println context.values()
    }

    @Ignore
    void 'verify config-server script'() {
        def context = Support.info {
            include('/collect/config-server-repository.groovy')
        }
        expect:
        context
        context.values()
//        println context.values()
    }

    @Ignore
    void 'verify tm-start fixture'() {
        def context = Support.fixture {
            include('/fixture/tm-start')
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify tm-stop fixture'() {
        def context = Support.fixture {
            include('/fixture/tm-stop')
        }
        expect:
        context
        context.values()
        context.getErrorInfo()
    }

    @Ignore
    void 'verify several scripts'() {
        def context = Support.info {
            include('/collect/tm-classic-install.groovy')
            include('/collect/config-server-repository.groovy')
//            include('/collect/all-logs ServiceManager')
        }
        expect:
        context
        context.values()

        and:
        context.destination('${ECRootPath}/info-context/content.zip')
        Storage.toDisk(context)
    }

    @Ignore
    void 'verify validate-config-server script'() {
        def context = Support.info {
            include('/validate/validate-config-server.groovy')
        }
        expect:
        context
        context.values()
        context.getErrorInfo()
    }

    @Ignore
    void 'verify TM Service Manager jars against expected 9.2.4.0 snapshot'() {
        def context = Support.info {
            include('/validate/sm-jars-validate.groovy')
        }

        expect:
        context
        context.values()
        context.getErrorInfo()
        println context.getErrorInfo().getErrors().toString()

        and:
        context.destination('${ECRootPath}/info-context/jars.zip')
        Storage.toDisk(context)
    }

    @Ignore
    void 'verify forEachApplication closure'() {
        def context = TmSupport.fixture {
            forEachApplication { final String hostName, final Map<String, ?> applicationMap ->
                if (TmConfig.isService(applicationMap)) {
                    if (isLinux(hostName)) {
//                ssh(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'), 'start') // todo: add stop service on linux thru SSH
                    } else {
                        final key = hostName + TmSupport.toWindowsServiceName(applicationMap, 'TM') + ".txt"
                        add(key, key)
                    }
                } else if (TmConfig.isXes(applicationMap)) {
                    for (final Map<String, ?> profileMap : TmConfig.listProfiles(applicationMap)) {
                        if (isLinux(hostName)) {
//                    ssh(hostName, TmSupport.toWindowsServiceName(profileMap, ' XEServer ', '_'), 'start') // todo: add stop XES profile on linux thru SSH
                        } else {
                            final key = hostName + TmSupport.toWindowsServiceName(profileMap, ' XEServer ', '_') + ".txt"
                            add(key, key)
                        }
                    }
                } else if (TmConfig.isWebApp(applicationMap)) {
                    // todo: start tomcat?
                }
            }
        }

        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify db-selector-xml-validate'() {
        def context = TmSupport.info {
            include '/validate/db-selector-xml-validate.groovy ${ECRootPath}/TM/ServiceManager/tools/dbSelector-exporter/exported_DBSelector.xml ${ECRootPath}/TM/ServiceManager/tools/dbSelector-exporter/exported_DBSelector_copy.xml'
        }
        expect:
        context
        context.getErrorInfo()
    }
    @Ignore
    void 'verify validate-duplicate-jars'() {
        def context = TmSupport.info {
//            include '/validate/validate-duplicate-jars'
            include '/validate/validate-duplicate-jars ${ECRootPath}/TM/ServiceManager/lib'
        }
        expect:
        context
        context.getErrorInfo()
    }

    @Ignore
    void 'verify tm-db-diagnostic'() {
        def context = TmSupport.info {
            destination(protectionDomainPath())
            include '/collect/tm-db-diagnostic /tm-db-diagnostic.properties'
        }
        expect:
        context
        context.getErrorInfo()
    }

    static File protectionDomainFile() {
        new File(ScriptsTest.protectionDomain.codeSource.location.file)
    }

    static String protectionDomainPath() {
        return protectionDomainFile().absolutePath
    }
    static String getProtectionDomainPath() {
        return protectionDomainFile().absolutePath
    }

    static String protectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }
    static String getProtectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }
}
