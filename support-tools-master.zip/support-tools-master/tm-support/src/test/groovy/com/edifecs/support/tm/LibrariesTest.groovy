package com.edifecs.support.tm

import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class LibrariesTest extends Specification {

    void 'verify artifact name extraction'() {
        expect:
        'tm-im' == Libraries.toArtifactName('tm-im-9.2.7.0-SNAPSHOT.jar')
        '9.2.7.0-SNAPSHOT' == Libraries.toArtifactVersion('tm-im-9.2.7.0-SNAPSHOT.jar')

        'tm-config' == Libraries.toArtifactName('tm-config-9.2.7-SNAPSHOT.jar')
        'edifecs-commons' == Libraries.toArtifactName('edifecs-commons-9.2.7-SNAPSHOT.jar')

        'etools-commons-crypto' == Libraries.toArtifactName('etools-commons-crypto-9.3.0.0.jar')
        '9.3.0.0' == Libraries.toArtifactVersion('etools-commons-crypto-9.3.0.0.jar')

        'gbd-deploy' == Libraries.toArtifactName('gbd-deploy-9.2.7-SNAPSHOT.jar')
        'gbd-repository-install' == Libraries.toArtifactName('gbd-repository-install-9.2.7-SNAPSHOT.jar')
        'install' == Libraries.toArtifactName('install-1.0.3.6.jar')
        'reload4j' == Libraries.toArtifactName('reload4j-1.2.19.jar')

        'reload4j' == Libraries.toArtifactName('reload4j.jar')
        null == Libraries.toArtifactVersion('reload4j.jar')
    }
}
