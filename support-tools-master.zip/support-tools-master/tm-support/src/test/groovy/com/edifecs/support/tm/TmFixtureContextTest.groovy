package com.edifecs.support.tm

import spock.lang.Specification

import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class TmFixtureContextTest extends Specification {

    void 'verify parse config'() {
        given:
        final context = new TmFixtureContext(TmConfig.of(this.class.getResourceAsStream('/config.xml')))

        expect:
        context
        context.tmConfig
        context.appStream().collect(Collectors.toList())

        final tomcat = context.findTomcat()
        context.tomcatLocation(tomcat)
        context.findTomcatLocation()
    }
}
