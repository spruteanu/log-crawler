package com.edifecs.support.log

import com.edifecs.support.core.DatePredicate
import com.edifecs.support.core.ZipWalker
import spock.lang.Ignore
import spock.lang.Specification

import java.time.LocalDateTime
import java.time.ZoneId
import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class TmLogsTest extends Specification {

    void 'verify default creation has registered consumers'() {
        expect:
        TmLogs.defaultConfigBuilder().hasRegisteredConsumers()
    }

    void 'verify old logs consumption'() {
        final folder = new File(TmLogsTest.protectionDomain.codeSource.location.path, 'old')
        final Map<String, List<LogEntry>> exceptions = new LinkedHashMap<>(1024)
        expect:
        TmLogs.tmLoggerBuilder().source(folder).build().stream().collect(Collectors.toList())
        and: 'Verify filtering by date'
        TmLogs.tmLoggerBuilder().source(folder).build().logToDate().stream().filter(DateConsumer.logDatePredicate(DatePredicate.of(
                Date.from(LocalDateTime.of(2023, 4, 1, 0, 0).atZone(ZoneId.systemDefault()).toInstant()),
                Date.from(LocalDateTime.of(2023, 5, 1, 0, 0).atZone(ZoneId.systemDefault()).toInstant())
        ))).collect(Collectors.toList())
        and: 'Verify exceptions collection'
        TmLogs.tmLoggerBuilder().source(folder).collectExceptions(exceptions).build().stream().collect(Collectors.toList())
        exceptions.size() > 0
    }

    void 'verify new logs consumption'() {
        final folder = new File(TmLogsTest.protectionDomain.codeSource.location.path, 'new')
        expect:
        TmLogs.yamlLoggerBuilder().source(folder).build().stream().filter(ExceptionConsumer.&containsException).collect(Collectors.toList())
    }

    @Ignore
    void 'verify tm log categories'() {
        final file = new File(getClass().protectionDomain.codeSource.location.path, 'samples.zip')
        final dir = file.parentFile
        ZipWalker.of(file).extract(dir)
        expect:
        Logs.builder {
            log4jConfig('/TMLogger.old.cfg')
        }.source(dir).build().stream().filter(ExceptionConsumer.&containsException).collect(Collectors.toList())
    }
}
