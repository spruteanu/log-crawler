package com.edifecs.support.tm

import spock.lang.Specification

import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class TmConfigTest extends Specification {

    void 'verify parseXml config'() {
        given:
        final tmConfig = TmConfig.of(this.class.getResourceAsStream('/config.xml'))

        expect:
        tmConfig
        tmConfig.appStream().collect(Collectors.toList())

        final tomcat = tmConfig.findTomcat()
        tmConfig.tomcatLocation(tomcat) == 'C:\\\\Tomcat'

        and:
        tmConfig.dbMap('enablement')
        tmConfig.dbMap('active')

        tmConfig.enablementMap()
        tmConfig.enablementProperties()
        tmConfig.activeMap()
        tmConfig.activeProperties()
        tmConfig.gbdMap()
        tmConfig.gbdProperties()

        tmConfig.enablementProperties().get('password') == '{enc}U4Wi47iHluc='

        and: 'verify DB system properties load'
        tmConfig.usingDbProperties(this.class.getResourceAsStream('/DBProperties.conf'))
        tmConfig.dbSystemProperties()
    }
}
