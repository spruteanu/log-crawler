package collect

import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.edifecs.support.tm.TmSupport

@Description(
        name = "TM DB diagnostic",
        description = "Analyze TM database wellness",
        author = "Serge Pruteanu",
        usage = '''Usage: tm-db-diagnostic [dbProperties file] [TM config file [tm-db-name-from-config.xml]] [script1] [scriptN]
    Examples:
        tm-db-diagnostic enablement
        # will perform diagnostic over TM EcEnablement DB, with properties defined in '$ECRootPath/TM/install/config.xml'

        tm-db-diagnostic customLocation/config.xml enablement
        # will perform diagnostic over TM EcEnablement DB, with properties defined in 'customLocation/config.xml'

        tm-db-diagnostic enablement-db.properties
        # will perform diagnostic over DB with connectivity properties defined in 'enablement-db.properties'
'''
)
@Argument(name = "TM config XML file", description = "TM config XML file, where DB information is")
@Argument(name = "DB properties file", description = """Database properties file that will contain database connectivity details:

Microsoft SQL Server Example
# Basic connection properties
# JDBC Connection URL (required)
url=jdbc:sqlserver://localhost:1433;databaseName=mydb
# Database username (required)
username=sa
# Database password (required)
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
# JDBC driver class name (required)
driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver

# SQL Server specific properties
trustServerCertificate=true
encrypt=true
integratedSecurity=false
applicationName=MyApplication

# Connection pooling properties
initialSize=5
maxActive=10
maxIdle=5
# Query timeout settings
queryTimeout=30

Oracle Example
url=jdbc:oracle:thin:@localhost:1521:XE
username=system
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
driverClassName=oracle.jdbc.OracleDriver

# Example of db properties defined in EIM
#Supported database types:
#   MSSQL - SQL Server
#   MsSqlAzure - Azure SQL Server
#   Oracle12c - Oracle 12c
#   Oracle19c - Oracle 19c
#   PostgreSQL - Postgre 13.x
database.type=MSSQL
server=localhost
database=EcEnablement
username=CDWeb
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
port=1433
instance=MSSQLSERVER
trustservercertificate=true
encrypt=true
""")
@Argument(name = "SQL script", description = "Script with defined queries")
@Role("admin")
static def execute(String[] args) {
    return TmSupport.sqlInfo {
        final scripts = initialize(args)
        fetchSize(1000)
        if (!scripts) {
            csvQueryConsumer()
            if (isOracle()) {
                scriptDelimiter(";")
                scripts.add('/collect/db/oracle/db-diagnostic.sql')
            } else if (isMssql()) {
                scripts.add('/collect/db/mssql/db-diagnostic.sql')
            }
        }
        for (final script : scripts) {
            queryFrom(script)
        }
    }
}

execute(args)
