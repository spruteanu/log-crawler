select * from sys.databases
GO

select serverproperty('ServerName') ServerName
     , serverproperty('Edition') Edition
     , serverproperty('ProductVersion') Version
     , serverproperty('ProductLevel') ServicePack
     , serverproperty('IsClustered') IsClustered
     , serverproperty('MachineName') MachineName
     , i.*
from sys.dm_os_sys_info i
GO

select c.* from sys.configurations c
GO

select *
from sys.dm_os_memory_clerks
where pages_kb > 0
order by pages_kb desc
GO

select type, sum(pages_kb) / 1024 as size_mb
from sys.dm_os_memory_clerks
group by type
order by sum(pages_kb) desc
GO

select * from sys.dm_os_sys_memory
GO

select * from sys.dm_os_sys_info
GO

select *
from sys.dm_os_performance_counters
order by object_name, counter_name
GO

-- Sessions I/O
select r.reads, r.writes, r.logical_reads, r.row_count
     , r.sql_handle, r.plan_handle
     , s.*
from sys.dm_exec_sessions s
left join sys.dm_exec_requests r on s.session_id = r.session_id
order by r.reads desc
GO

--
select s.login_time, s.login_name, s.host_name, s.program_name
     , mem.*
from sys.dm_exec_sessions s
left join sys.dm_exec_query_memory_grants mem on s.session_id = mem.session_id
order by mem.granted_memory_kb desc
GO

select * from sys.dm_os_process_memory
GO

-- System level waits
with wait_stats as (
    select wait_type
         , waiting_tasks_count
         , wait_time_ms
         , max_wait_time_ms
         , signal_wait_time_ms
         , wait_time_ms - signal_wait_time_ms resource_wait_time_ms
    from sys.dm_os_wait_stats
    where wait_type not in (
        -- Filter out idle waits
        'CLR_SEMAPHORE', 'LAZYWRITER_SLEEP', 'RESOURCE_QUEUE', 'SLEEP_TASK',
        'SLEEP_SYSTEMTASK', 'SQLTRACE_BUFFER_FLUSH', 'WAITFOR', 'LOGMGR_QUEUE',
        'CHECKPOINT_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'XE_TIMER_EVENT',
        'BROKER_TO_FLUSH', 'BROKER_TASK_STOP', 'CLR_MANUAL_EVENT',
        'CLR_AUTO_EVENT', 'DISPATCHER_QUEUE_SEMAPHORE', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
        'XE_DISPATCHER_WAIT', 'XE_DISPATCHER_JOIN', 'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
        'ONDEMAND_TASK_QUEUE', 'BROKER_EVENTHANDLER', 'SLEEP_BPOOL_FLUSH',
        'DIRTY_PAGE_POLL', 'HADR_FILESTREAM_IOMGR_IOCOMPLETION', 'SP_SERVER_DIAGNOSTICS_SLEEP'
    )
)
select cast(round(100.0 * wait_time_ms / sum(wait_time_ms) over(), 1) as decimal(5,2)) time_waited_pct
     , cast(round(100.0 * waiting_tasks_count / sum(waiting_tasks_count) over(), 1) as decimal(5,2)) total_waits_pct
     , wait_type
     , waiting_tasks_count
     , wait_time_ms
     , wait_time_ms / 1000.0 wait_time_sec
     , max_wait_time_ms
     , signal_wait_time_ms
     , resource_wait_time_ms
     , case when waiting_tasks_count > 0
            then wait_time_ms / waiting_tasks_count
            else 0 end avg_wait_time_ms
from wait_stats
order by time_waited_pct desc
GO

-- Session level waits
with session_waits as (
    select session_id
         , wait_type
         , waiting_tasks_count
         , wait_time_ms
         , max_wait_time_ms
    from sys.dm_exec_session_wait_stats
    where wait_type not in (
        'CLR_SEMAPHORE', 'LAZYWRITER_SLEEP', 'RESOURCE_QUEUE', 'SLEEP_TASK',
        'SLEEP_SYSTEMTASK', 'SQLTRACE_BUFFER_FLUSH', 'WAITFOR', 'LOGMGR_QUEUE',
        'CHECKPOINT_QUEUE', 'REQUEST_FOR_DEADLOCK_SEARCH', 'XE_TIMER_EVENT',
        'BROKER_TO_FLUSH', 'BROKER_TASK_STOP', 'CLR_MANUAL_EVENT'
      )
)
select session_id
     , wait_type
     , cast(round(100.0 * wait_time_ms /
         nullif(sum(wait_time_ms) over(partition by session_id), 0), 1) as decimal(5,2)) time_waited_pct
     , cast(round(100.0 * waiting_tasks_count /
         nullif(sum(waiting_tasks_count) over(partition by session_id), 0), 1) as decimal(5,2)) total_waits_pct
     , waiting_tasks_count
     , wait_time_ms
     , max_wait_time_ms
     , case when waiting_tasks_count > 0
            then wait_time_ms / waiting_tasks_count
            else 0 end avg_wait_ms
from session_waits
order by session_id, time_waited_pct desc
GO

--- Top SQL by logical reads
select top 100
       qs.execution_count execs
     , qs.total_rows rowsp
     , qs.total_logical_reads logical_reads
     , case when qs.execution_count > 0
            then qs.total_logical_reads / qs.execution_count
            else 0 end reads_per_exec
     , qs.total_physical_reads physical_reads
     , case when qs.execution_count > 0
            then qs.total_physical_reads / qs.execution_count
            else 0 end physical_per_exec
     , case when qs.total_rows > 0
            then qs.total_logical_reads / qs.total_rows
            else -1 end reads_per_row
     , cast(qs.total_elapsed_time / 1000000.0 as decimal(18,3)) elapsed_sec
     , case when qs.execution_count > 0
            then cast(qs.total_elapsed_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end sec_per_exec
     , cast(qs.total_worker_time / 1000000.0 as decimal(18,3)) cpu_sec
     , case when qs.execution_count > 0
            then cast(qs.total_worker_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end cpu_sec_per_exec
     , substring(st.text, (qs.statement_start_offset/2) + 1,
         ((case qs.statement_end_offset
             when -1 then datalength(st.text)
             else qs.statement_end_offset
         end - qs.statement_start_offset)/2) + 1) query_text
     , qs.*
     , qp.query_plan
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
where qs.execution_count > 0
order by qs.total_logical_reads desc
GO

-- Top SQL by elapsed time
select top 100
       qs.execution_count execs
     , qs.total_rows rowsp
     , qs.total_logical_reads logical_reads
     , case when qs.execution_count > 0
            then qs.total_logical_reads / qs.execution_count
            else 0 end reads_per_exec
     , qs.total_physical_reads physical_reads
     , case when qs.execution_count > 0
            then qs.total_physical_reads / qs.execution_count
            else 0 end physical_per_exec
     , case when qs.total_rows > 0
            then qs.total_logical_reads / qs.total_rows
            else -1 end reads_per_row
     , cast(qs.total_elapsed_time / 1000000.0 as decimal(18,3)) elapsed_sec
     , case when qs.execution_count > 0
            then cast(qs.total_elapsed_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end sec_per_exec
     , cast(qs.total_worker_time / 1000000.0 as decimal(18,3)) cpu_sec
     , case when qs.execution_count > 0
            then cast(qs.total_worker_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end cpu_sec_per_exec
     , substring(st.text, (qs.statement_start_offset/2) + 1,
         ((case qs.statement_end_offset
             when -1 then datalength(st.text)
             else qs.statement_end_offset
         end - qs.statement_start_offset)/2) + 1) query_text
     , qs.*
     , qp.query_plan
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
where qs.execution_count > 0
order by qs.total_elapsed_time desc
GO

-- Top SQL by CPU Time
select top 100
       qs.execution_count execs
     , qs.total_rows rowsp
     , qs.total_logical_reads logical_reads
     , case when qs.execution_count > 0
            then qs.total_logical_reads / qs.execution_count
            else 0 end reads_per_exec
     , qs.total_physical_reads physical_reads
     , case when qs.execution_count > 0
            then qs.total_physical_reads / qs.execution_count
            else 0 end physical_per_exec
     , case when qs.total_rows > 0
            then qs.total_logical_reads / qs.total_rows
            else -1 end reads_per_row
     , cast(qs.total_elapsed_time / 1000000.0 as decimal(18,3)) elapsed_sec
     , case when qs.execution_count > 0
            then cast(qs.total_elapsed_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end sec_per_exec
     , cast(qs.total_worker_time / 1000000.0 as decimal(18,3)) cpu_sec
     , case when qs.execution_count > 0
            then cast(qs.total_worker_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end cpu_sec_per_exec
     , substring(st.text, (qs.statement_start_offset/2) + 1,
         ((case qs.statement_end_offset
             when -1 then datalength(st.text)
             else qs.statement_end_offset
         end - qs.statement_start_offset)/2) + 1) query_text
     , qs.*
     , qp.query_plan
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
where qs.execution_count > 0
order by qs.total_worker_time desc
GO

-- Top SQL by Physical Reads
select top 100
       qs.execution_count execs
     , qs.total_rows rowsp
     , qs.total_logical_reads logical_reads
     , case when qs.execution_count > 0
            then qs.total_logical_reads / qs.execution_count
            else 0 end reads_per_exec
     , qs.total_physical_reads physical_reads
     , case when qs.execution_count > 0
            then qs.total_physical_reads / qs.execution_count
            else 0 end physical_per_exec
     , case when qs.total_rows > 0
            then qs.total_logical_reads / qs.total_rows
            else -1 end reads_per_row
     , cast(qs.total_elapsed_time / 1000000.0 as decimal(18,3)) elapsed_sec
     , case when qs.execution_count > 0
            then cast(qs.total_elapsed_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end sec_per_exec
     , cast(qs.total_worker_time / 1000000.0 as decimal(18,3)) cpu_sec
     , case when qs.execution_count > 0
            then cast(qs.total_worker_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end cpu_sec_per_exec
     , substring(st.text, (qs.statement_start_offset/2) + 1,
         ((case qs.statement_end_offset
             when -1 then datalength(st.text)
             else qs.statement_end_offset
         end - qs.statement_start_offset)/2) + 1) query_text
     , qs.*
     , qp.query_plan
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
where qs.execution_count > 0
order by qs.total_physical_reads desc
GO

-- Top SQL by Executions
select top 100
       qs.execution_count execs
     , qs.total_rows rowsp
     , qs.total_logical_reads logical_reads
     , case when qs.execution_count > 0
            then qs.total_logical_reads / qs.execution_count
            else 0 end reads_per_exec
     , qs.total_physical_reads physical_reads
     , case when qs.execution_count > 0
            then qs.total_physical_reads / qs.execution_count
            else 0 end physical_per_exec
     , case when qs.total_rows > 0
            then qs.total_logical_reads / qs.total_rows
            else -1 end reads_per_row
     , cast(qs.total_elapsed_time / 1000000.0 as decimal(18,3)) elapsed_sec
     , case when qs.execution_count > 0
            then cast(qs.total_elapsed_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end sec_per_exec
     , cast(qs.total_worker_time / 1000000.0 as decimal(18,3)) cpu_sec
     , case when qs.execution_count > 0
            then cast(qs.total_worker_time / 1000000.0 / qs.execution_count as decimal(18,3))
            else 0 end cpu_sec_per_exec
     , substring(st.text, (qs.statement_start_offset/2) + 1,
         ((case qs.statement_end_offset
             when -1 then datalength(st.text)
             else qs.statement_end_offset
         end - qs.statement_start_offset)/2) + 1) query_text
     , qs.*
     , qp.query_plan
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
where qs.execution_count > 0
order by qs.execution_count desc
GO

with top_sql as (
    select plan_handle, sql_handle from (
        select top 100 plan_handle, sql_handle from sys.dm_exec_query_stats order by total_logical_reads desc ) t1 union
    select plan_handle, sql_handle from (
        select top 100 plan_handle, sql_handle from sys.dm_exec_query_stats order by total_physical_reads desc ) t2 union
    select plan_handle, sql_handle from (
        select top 100 plan_handle, sql_handle from sys.dm_exec_query_stats order by total_elapsed_time desc ) t3 union
    select plan_handle, sql_handle from (
        select top 100 plan_handle, sql_handle from sys.dm_exec_query_stats order by total_worker_time desc ) t4 union
    select plan_handle, sql_handle from (
        select top 100 plan_handle, sql_handle from sys.dm_exec_query_stats order by execution_count desc ) t5
)
select qs.*
     , st.text query_text
     , qp.query_plan
from sys.dm_exec_query_stats qs
inner join top_sql ts on qs.plan_handle = ts.plan_handle
    and qs.sql_handle = ts.sql_handle
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
cross apply sys.dm_exec_query_plan(qs.plan_handle) qp
order by qs.total_elapsed_time desc
GO

-- Historical queries if Query Store is enabled
-- Optionally, execution time range filter can be set
select qsq.query_id
     , qsqt.query_sql_text
     , qsp.plan_id
     , qsrs.avg_duration / 1000000.0 avg_duration_sec
     , qsrs.last_duration / 1000000.0 last_duration_sec
     , qsrs.min_duration / 1000000.0 min_duration_sec
     , qsrs.max_duration / 1000000.0 max_duration_sec
     , qsrs.avg_cpu_time / 1000000.0 avg_cpu_time_sec
     , qsrs.*
from sys.query_store_query qsq
inner join sys.query_store_query_text qsqt on qsq.query_text_id = qsqt.query_text_id
inner join sys.query_store_plan qsp on qsq.query_id = qsp.query_id
inner join sys.query_store_runtime_stats qsrs on qsp.plan_id = qsrs.plan_id
inner join sys.query_store_runtime_stats_interval qsrsi on qsrs.runtime_stats_interval_id = qsrsi.runtime_stats_interval_id
--where qsrsi.start_time >= '2025-02-13 09:00:00' and qsrsi.end_time <= '2025-02-13 11:00:00'
order by qsrs.avg_duration desc
GO

select qsq.query_id
     , qsqt.query_sql_text
     , sum(qsrs.count_executions) total_executions
     , sum(qsrs.count_executions * qsrs.avg_duration) / 1000000.0 total_duration_sec
     , max(qsrs.max_duration) / 1000000.0 max_duration_sec
     , sum(qsrs.count_executions * qsrs.avg_cpu_time) / 1000000.0 total_cpu_sec
     , sum(qsrs.count_executions * qsrs.avg_logical_io_reads) total_logical_reads
from sys.query_store_query qsq
inner join sys.query_store_query_text qsqt on qsq.query_text_id = qsqt.query_text_id
inner join sys.query_store_plan qsp on qsq.query_id = qsp.query_id
inner join sys.query_store_runtime_stats qsrs on qsp.plan_id = qsrs.plan_id
inner join sys.query_store_runtime_stats_interval qsrsi
    on qsrs.runtime_stats_interval_id = qsrsi.runtime_stats_interval_id
where qsq.object_id <> 0  -- Exclude system queries
  -- and qsrsi.start_time >= cast(getdate() as date)  -- Uncomment for today only
group by qsq.query_id
       , qsqt.query_sql_text
order by total_duration_sec desc
GO

-- Objects size
select object_schema_name(p.object_id) schema_name
     , object_name(p.object_id) object_name
     , i.name index_name
     , i.type_desc index_type
     , p.partition_number
     , p.rows row_count
     , au.type_desc allocation_type
     , au.total_pages * 8 / 1024 total_space_mb
     , au.used_pages * 8 / 1024 used_space_mb
     , au.data_pages * 8 / 1024 data_space_mb
     , (au.total_pages - au.used_pages) * 8 / 1024 unused_space_mb
from sys.partitions p
inner join sys.indexes i on p.object_id = i.object_id and p.index_id = i.index_id
inner join (
    select container_id
         , type_desc
         , sum(total_pages) total_pages
         , sum(used_pages) used_pages
         , sum(data_pages) data_pages
    from sys.allocation_units
    group by container_id, type_desc
) au on p.partition_id = au.container_id
where object_schema_name(p.object_id) not in ('sys')
order by au.total_pages desc
GO

-- Object statistics
select object_schema_name(ios.object_id) schema_name
     , object_name(ios.object_id) object_name
     , i.name index_name
     , ios.*
from sys.dm_db_index_operational_stats(db_id(), null, null, null) ios
left join sys.indexes i on ios.object_id = i.object_id and ios.index_id = i.index_id
where object_schema_name(ios.object_id) not in ('sys')
order by ios.range_scan_count + ios.singleton_lookup_count desc
GO

-- Physical stats
select object_schema_name(ips.object_id) schema_name
     , object_name(ips.object_id) object_name
     , i.name index_name
     , ips.*
from sys.dm_db_index_physical_stats(db_id(), null, null, null, 'DETAILED') ips
left join sys.indexes i on ips.object_id = i.object_id and ips.index_id = i.index_id
where object_schema_name(ips.object_id) not in ('sys')
order by ips.avg_fragmentation_in_percent desc
GO

-- Tables
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , t.object_id
     , t.create_date
     , t.modify_date
     , sum(p.rows) row_count
     , p.data_compression_desc
     , sum(au.total_pages) * 8 / 1024 total_space_mb
     , sum(au.used_pages) * 8 / 1024 used_space_mb
     , sum(au.data_pages) * 8 / 1024 data_space_mb
     , t.is_tracked_by_cdc
     , t.lock_escalation_desc
     , t.is_memory_optimized
     , t.durability_desc
     , t.temporal_type_desc
     , fg.name filegroup_name
from sys.tables t
inner join sys.indexes i on t.object_id = i.object_id and i.index_id < 2
inner join sys.partitions p on i.object_id = p.object_id and i.index_id = p.index_id
inner join sys.allocation_units au on p.partition_id = au.container_id
left join sys.filegroups fg on i.data_space_id = fg.data_space_id
where t.is_ms_shipped = 0
group by schema_name(t.schema_id), t.name, t.object_id, t.create_date, t.modify_date
       , p.data_compression_desc, t.is_tracked_by_cdc, t.lock_escalation_desc
       , t.is_memory_optimized, t.durability_desc, t.temporal_type_desc, fg.name
order by schema_name(t.schema_id), t.name
GO

-- Partitions
select schema_name(t.schema_id) schema_name
     , object_name(p.object_id) table_name
     , i.name index_name
     , p.partition_number
     , p.rows row_count
     , p.data_compression_desc
     , prv.value partition_boundary_value
     , fg.name filegroup_name
     , au.total_pages * 8 / 1024 total_space_mb
     , au.used_pages * 8 / 1024 used_space_mb
     , au.data_pages * 8 / 1024 data_space_mb
from sys.partitions p
inner join sys.tables t on p.object_id = t.object_id
inner join sys.indexes i on p.object_id = i.object_id and p.index_id = i.index_id
left join sys.partition_schemes ps on i.data_space_id = ps.data_space_id
left join sys.partition_functions pf on ps.function_id = pf.function_id
left join sys.partition_range_values prv
    on pf.function_id = prv.function_id
    and p.partition_number = prv.boundary_id
left join sys.destination_data_spaces dds
    on ps.data_space_id = dds.partition_scheme_id
    and p.partition_number = dds.destination_id
left join sys.filegroups fg on dds.data_space_id = fg.data_space_id
inner join (
    select container_id
         , sum(total_pages) total_pages
         , sum(used_pages) used_pages
         , sum(data_pages) data_pages
    from sys.allocation_units
    group by container_id
) au on p.partition_id = au.container_id
where t.is_ms_shipped = 0
  and ps.data_space_id is not null  -- Only partitioned tables
  and i.index_id < 2
order by schema_name(t.schema_id)
       , object_name(p.object_id)
       , i.name
       , p.partition_number
GO

-- Table columns
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , c.column_id
     , c.name column_name
     , type_name(c.user_type_id) data_type
     , c.max_length
     , c.precision
     , c.scale
     , c.is_nullable
     , c.is_identity
     , c.is_computed
     , cc.definition computed_definition
     , dc.definition default_definition
     , c.collation_name
     , c.is_sparse
     , c.is_column_set
     , ic.seed_value identity_seed
     , ic.increment_value identity_increment
     , isnull(ic.last_value, ic.seed_value) identity_current
from sys.tables t
inner join sys.columns c on t.object_id = c.object_id
left join sys.computed_columns cc on c.object_id = cc.object_id and c.column_id = cc.column_id
left join sys.default_constraints dc on c.default_object_id = dc.object_id
left join sys.identity_columns ic on c.object_id = ic.object_id and c.column_id = ic.column_id
where t.is_ms_shipped = 0
order by schema_name(t.schema_id)
       , t.name
       , c.column_id
GO

-- Indexes
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , i.name index_name
     , i.index_id
     , i.type_desc index_type
     , i.is_unique
     , i.is_primary_key
     , i.is_unique_constraint
     , i.fill_factor
     , i.is_padded
     , i.is_disabled
     , i.is_hypothetical
     , i.allow_row_locks
     , i.allow_page_locks
     , p.data_compression_desc
     , ps.name partition_scheme
     , fg.name filegroup_name
     , sum(p.rows) row_count
     , sum(au.total_pages) * 8 / 1024 total_space_mb
     , sum(au.used_pages) * 8 / 1024 used_space_mb
     , sum(au.data_pages) * 8 / 1024 data_space_mb
     , i.filter_definition
from sys.tables t
inner join sys.indexes i on t.object_id = i.object_id
inner join sys.partitions p on i.object_id = p.object_id and i.index_id = p.index_id
inner join sys.allocation_units au on p.partition_id = au.container_id
left join sys.partition_schemes ps on i.data_space_id = ps.data_space_id
left join sys.filegroups fg on i.data_space_id = fg.data_space_id
where t.is_ms_shipped = 0
group by schema_name(t.schema_id), t.name, i.name, i.index_id, i.type_desc
       , i.is_unique, i.is_primary_key, i.is_unique_constraint, i.fill_factor
       , i.is_padded, i.is_disabled, i.is_hypothetical, i.allow_row_locks
       , i.allow_page_locks, p.data_compression_desc, ps.name, fg.name
       , i.filter_definition
order by schema_name(t.schema_id)
       , t.name
       , i.name
GO

-- Index partitions
select schema_name(t.schema_id) schema_name
     , object_name(i.object_id) table_name
     , i.name index_name
     , p.partition_number partition_nr
     , p.rows row_count
     , p.data_compression_desc
     , prv.value partition_boundary_value
     , fg.name filegroup_name
     , au.total_pages * 8 / 1024 total_space_mb
     , au.used_pages * 8 / 1024 used_space_mb
     , p.*
from sys.indexes i
inner join sys.tables t on i.object_id = t.object_id
inner join sys.partitions p on i.object_id = p.object_id and i.index_id = p.index_id
left join sys.partition_schemes ps on i.data_space_id = ps.data_space_id
left join sys.partition_functions pf on ps.function_id = pf.function_id
left join sys.partition_range_values prv
    on pf.function_id = prv.function_id
    and p.partition_number = prv.boundary_id
left join sys.destination_data_spaces dds
    on ps.data_space_id = dds.partition_scheme_id
    and p.partition_number = dds.destination_id
left join sys.filegroups fg on dds.data_space_id = fg.data_space_id
inner join (
    select container_id
         , sum(total_pages) total_pages
         , sum(used_pages) used_pages
    from sys.allocation_units
    group by container_id
) au on p.partition_id = au.container_id
where t.is_ms_shipped = 0
  and ps.data_space_id is not null  -- Only partitioned indexes
order by schema_name(t.schema_id)
       , object_name(i.object_id)
       , i.name
       , p.partition_number
GO

-- Index columns
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , i.name index_name
     , i.type_desc index_type
     , ic.key_ordinal column_position
     , c.name column_name
     , ic.is_descending_key
     , ic.is_included_column
     , type_name(c.user_type_id) data_type
     , c.max_length
     , c.precision
     , c.scale
from sys.tables t
inner join sys.indexes i on t.object_id = i.object_id
inner join sys.index_columns ic on i.object_id = ic.object_id and i.index_id = ic.index_id
inner join sys.columns c on ic.object_id = c.object_id and ic.column_id = c.column_id
where t.is_ms_shipped = 0
  and i.type > 0  -- Exclude heaps
order by schema_name(t.schema_id)
       , t.name
       , i.name
       , ic.key_ordinal
       , ic.index_column_id
GO

-- Columns stats
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , s.*
     , sp.*
     , stuff((
         select ', ' + c.name
         from sys.stats_columns sc
         inner join sys.columns c on sc.object_id = c.object_id and sc.column_id = c.column_id
         where sc.object_id = s.object_id and sc.stats_id = s.stats_id
         order by sc.stats_column_id
         for xml path(''), type
     ).value('.', 'nvarchar(max)'), 1, 2, '') columns_in_stats
from sys.tables t
inner join sys.stats s on t.object_id = s.object_id
cross apply sys.dm_db_stats_properties(s.object_id, s.stats_id) sp
where t.is_ms_shipped = 0
order by schema_name(t.schema_id)
       , t.name
       , s.name
GO

-- Histograms
select schema_name(t.schema_id) schema_name
     , t.name table_name
     , s.name stats_name
     , c.name column_name
     , h.*
from sys.tables t
inner join sys.stats s on t.object_id = s.object_id
inner join sys.stats_columns sc on s.object_id = sc.object_id and s.stats_id = sc.stats_id
inner join sys.columns c on sc.object_id = c.object_id and sc.column_id = c.column_id
cross apply sys.dm_db_stats_histogram(s.object_id, s.stats_id) h
where t.is_ms_shipped = 0
  and sc.stats_column_id = 1  -- First column only
order by schema_name(t.schema_id)
       , t.name
       , s.name
       , c.name
       , h.step_number
GO