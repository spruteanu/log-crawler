select * from v$database
;

select * from v$instance
;

select * from v$parameter where isdefault = 'FALSE'
;

select * from v$sgastat order by bytes desc
;

select * from v$sgainfo
;

select * from v$pgastat
;

select * from v$osstat
;

-- Session IO
select i.*, s.osuser, s.program, s.* from v$sess_io i, v$session s where i.sid = s.sid order by 2 desc
;

-- Session/process memory usage
select s.sid, p.pid, s.username, s.osuser, p.pga_used_mem, p.pga_alloc_mem, p.pga_max_mem, p.pga_freeable_mem
from v$process p, v$session s
where p.addr = s.paddr
order by 5 desc
;

select round(ratio_to_report(time_waited) over(),3)*100 time_waited_pct
     , round(ratio_to_report(total_waits) over(),3)*100 total_waits_pct
     , t.*
from v$system_event t
where wait_class != 'Idle'
order by 1 desc
;

select round(ratio_to_report(time_waited) over(partition by sid),3)*100 time_waited_pct
     , round(ratio_to_report(total_waits) over(partition by sid),3)*100 total_waits_pct
     , t.*
from v$session_event t
where wait_class != 'Idle'
order by sid, time_waited_pct desc nulls last
;

-- Top SQL by logical reads
select  * from
(
  select executions execs, rows_processed rowsp
       , buffer_gets buff_gets, round(buffer_gets/executions) gets_per_exec
       , disk_reads disk_read_cnt, round(disk_reads/executions) disk_per_exec
       , round(decode(rows_processed, 0, -1, buffer_gets/rows_processed)) gets_per_row
       , round(elapsed_time/1e6,3) elapsed_sec
       , round(elapsed_time/1e6/executions,3) sec_per_exec
       , round(cpu_time/1e6,3) cpu_sec
       , round(cpu_time/1e6/executions,3) cpu_sec_per_exec
       , s.*
  from v$sqlarea s
  where executions > 0
  order by buffer_gets desc
)
where rownum <= 100
;

-- Top SQL by elapsed time
select  * from
(
  select executions execs, rows_processed rowsp
       , buffer_gets buff_gets, round(buffer_gets/executions) gets_per_exec
       , disk_reads disk_read_cnt, round(disk_reads/executions) disk_per_exec
       , round(decode(rows_processed, 0, -1, buffer_gets/rows_processed)) gets_per_row
       , round(elapsed_time/1e6,3) elapsed_sec
       , round(elapsed_time/1e6/executions,3) sec_per_exec
       , round(cpu_time/1e6,3) cpu_sec
       , round(cpu_time/1e6/executions,3) cpu_sec_per_exec
       , s.*
  from v$sqlarea s
  where executions > 0
  order by elapsed_time desc
)
where rownum <= 100
;

-- Top SQL by CPU time
select  * from
(
  select executions execs, rows_processed rowsp
       , buffer_gets buff_gets, round(buffer_gets/executions) gets_per_exec
       , disk_reads disk_read_cnt, round(disk_reads/executions) disk_per_exec
       , round(decode(rows_processed, 0, -1, buffer_gets/rows_processed)) gets_per_row
       , round(elapsed_time/1e6,3) elapsed_sec
       , round(elapsed_time/1e6/executions,3) sec_per_exec
       , round(cpu_time/1e6,3) cpu_sec
       , round(cpu_time/1e6/executions,3) cpu_sec_per_exec
       , s.*
  from v$sqlarea s
  where executions > 0
  order by cpu_time desc
)
where rownum <= 100
;

-- Top SQL by disk reads
select  * from
(
  select executions execs, rows_processed rowsp
       , buffer_gets buff_gets, round(buffer_gets/executions) gets_per_exec
       , disk_reads disk_read_cnt, round(disk_reads/executions) disk_per_exec
       , round(decode(rows_processed, 0, -1, buffer_gets/rows_processed)) gets_per_row
       , round(elapsed_time/1e6,3) elapsed_sec
       , round(elapsed_time/1e6/executions,3) sec_per_exec
       , round(cpu_time/1e6,3) cpu_sec
       , round(cpu_time/1e6/executions,3) cpu_sec_per_exec
       , s.*
  from v$sqlarea s
  where executions > 0
  order by disk_reads desc
)
where rownum <= 100
;

-- Top SQL by disk reads
select  * from
(
  select executions execs, rows_processed rowsp
       , buffer_gets buff_gets, round(buffer_gets/executions) gets_per_exec
       , disk_reads disk_read_cnt, round(disk_reads/executions) disk_per_exec
       , round(decode(rows_processed, 0, -1, buffer_gets/rows_processed)) gets_per_row
       , round(elapsed_time/1e6,3) elapsed_sec
       , round(elapsed_time/1e6/executions,3) sec_per_exec
       , round(cpu_time/1e6,3) cpu_sec
       , round(cpu_time/1e6/executions,3) cpu_sec_per_exec
       , s.*
  from v$sqlarea s
  where executions > 0
  order by executions desc
)
where rownum <= 100
;

with top_sql as
(
  select sql_id from (select sql_id from v$sqlarea order by buffer_gets desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by disk_reads desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by elapsed_time desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by cpu_time desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by executions desc) where rownum <= 100
)
select s.* from v$sql s, top_sql ts
where s.sql_id = ts.sql_id
order by elapsed_time desc
;

with top_sql as
(
  select sql_id from (select sql_id from v$sqlarea order by buffer_gets desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by disk_reads desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by elapsed_time desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by cpu_time desc) where rownum <= 100 union
  select sql_id from (select sql_id from v$sqlarea order by executions desc) where rownum <= 100
)
select sp.* from v$sql_plan sp, top_sql ts
where sp.sql_id = ts.sql_id
order by sp.sql_id, plan_hash_value, child_number, id
;

-- Active sessions history for 1-2 hours when UI slowness was observed
-- ! Uncomment the filter and set appropriate time range
select *
from v$active_session_history
--where sample_time between to_date('2025.02.13 09:00','yyyy.mm.dd hh24:mi') and  to_date('2025.02.13 11:00','yyyy.mm.dd hh24:mi')
order by sample_id, sample_time
;

select h.user_id, u.username, h.session_state , h.event
      , h.action
      , h.module
      , h.sql_id, h.session_id, h.session_serial#
      , sum(h.time_waited) time_waited -- approx.
      , max(h.time_waited) max_time_waited -- approx.
      , sum(h.wait_time) wait_time -- approx.
      , max(h.wait_time) max_wait_time -- approx.
      , count(*) cnt
      , h.plsql_entry_object_id obj, h.plsql_entry_subprogram_id sp
      ,(select object_name||'.'||procedure_name from all_procedures
        where object_id = plsql_entry_object_id and subprogram_id = plsql_entry_subprogram_id) pkg
from v$active_session_history h, dba_users u
where h.user_id = u.user_id
--  and h.event is not null
--  and h.action is not null
--  and h.sample_time > trunc(sysdate)
group by h.user_id, u.username, h.session_state, h.event, h.action
       , h.plsql_entry_object_id, h.plsql_entry_subprogram_id
       , h.module, h.sql_id, h.session_id, h.session_serial#
order by time_waited desc
;

-- list of timeout-candidates queries
select *
from v$sql
where end_of_fetch_count < executions
  and parsing_schema_name != 'SYS'
;

select *
from v$sql_monitor
where status = 'DONE (ERROR)'
;

-- segments, tables, indexes data
-- Can be filtered by owner to limit export size
-- where owner in ('') / where table_owner in ('') -- optional application schemas list filter for the following queries, add is necessary
select *
from dba_segments
order by bytes desc
;

select *
from v$segment_statistics
order by owner, object_name, statistic_name
;

select *
from dba_tables
order by owner, table_name
;

select *
from dba_tab_partitions
order by table_owner, table_name, partition_position
;

select *
from dba_tab_cols
order by owner, table_name, column_id
;

select *
from dba_indexes
order by owner, table_name, index_name
;

select *
from dba_ind_partitions
order by index_owner, index_name, partition_position
;

select *
from dba_ind_columns
order by index_owner, table_name, index_name, column_position
;

select *
from dba_histograms
order by owner, table_name, column_name, endpoint_number
;