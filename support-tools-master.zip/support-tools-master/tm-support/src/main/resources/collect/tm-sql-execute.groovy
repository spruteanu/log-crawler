import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.edifecs.support.tm.TmSupport

@Description(
        name = "TM SQL execute",
        description = "Execute SQL scripts over provided TM database",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/tm-sql-execute [dbProperties file] [TM config file [tm-db-name-from-config.xml]] [script1] [scriptN]
    Examples:
        script-runner /collect/tm-sql-execute "enablement users.sql partners.sql"
        # will execute users.sql, partners.sql over TM EcEnablement DB, with properties defined in '$ECRootPath/TM/install/config.xml'

        script-runner /collect/tm-sql-execute "customLocation/config.xml enablement users.sql partners.sql"
        # will execute users.sql, partners.sql over TM EcEnablement DB, with properties defined in 'customLocation/config.xml'

        script-runner /collect/tm-sql-execute "enablement-db.properties users.sql partners.sql"
        # will execute users.sql, partners.sql with properties defined in 'enablement-db.properties'
'''
)
@Argument(name = "TM config XML file", description = "TM config XML file, where DB information is")
@Argument(name = "DB properties file", description = 'Database properties file, same syntax like in /collect/sql-query')
@Argument(name = "SQL script", description = "Script with defined queries")
@Role("admin")
protected def execute(String[] args) {
    return TmSupport.sqlFixture {
        final scripts = initialize(args)
        for (final script : scripts) {
            executeFrom(script)
        }
    }
}

execute(args)
