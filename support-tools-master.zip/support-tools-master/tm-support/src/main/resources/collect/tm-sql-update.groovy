import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.edifecs.support.tm.TmSupport

@Description(
        name = "TM SQL update",
        description = "Execute SQL update scripts over provided TM database",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/tm-sql-update [dbProperties file] [TM config file [tm-db-name-from-config.xml]] [script1] [scriptN]
    Examples:
        script-runner /collect/tm-sql-update "enablement users.sql partners.sql"
        # will update users.sql, partners.sql over TM EcEnablement DB, with properties defined in '$ECRootPath/TM/install/config.xml'

        script-runner /collect/tm-sql-update "customLocation/config.xml enablement users.sql partners.sql"
        # will update users.sql, partners.sql over TM EcEnablement DB, with properties defined in 'customLocation/config.xml'

        script-runner /collect/tm-sql-update "enablement-db.properties users.sql partners.sql"
        # will update users.sql, partners.sql with properties defined in 'enablement-db.properties'
'''
)
@Argument(name = "TM config XML file", description = "TM config XML file, where DB information is")
@Argument(name = "DB properties file", description = 'Database properties file, same syntax like in /collect/sql-query')
@Argument(name = "SQL script", description = "Script with defined queries")
@Role("admin")
protected def execute(String[] args) {
    return TmSupport.sqlFixture {
        final scripts = initialize(args)
        for (final script : scripts) {
            updateFrom(script)
        }
    }
}

execute(args)
