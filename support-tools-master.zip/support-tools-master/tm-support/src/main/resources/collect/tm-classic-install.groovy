package collect

import com.edifecs.support.Support
import com.edifecs.support.scripts.Description

@Description(
        name = "Collect TM Classic Install Files",
        description = "Collects all files from the TM classic installation directory within the install folder.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/tm-classic-install
Examples:
    script-runner "/collect/tm-classic-install"
'''
)
static def execute() {
    Support.info {
        add findFiles('${ECRootPath}/TM/install', "*")
    }
}

execute()
