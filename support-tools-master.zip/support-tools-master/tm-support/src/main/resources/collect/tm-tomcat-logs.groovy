package collect

import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.tm.TmSupport
@Description(
        name = "Collect TM Tomcat logs",
        description = "Collects logs from the Tomcat.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/tm-tomcat-logs [Tomcat installation path] [Application context]
    Examples:
# Automatically detect and collect Tomcat logs
script-runner "/collect/tm-tomcat-logs"

# Specify Tomcat location manually
script-runner "/collect/tm-tomcat-logs /opt/tomcat"

# Specify both Tomcat location and web application context
script-runner "/collect/tm-tomcat-logs /opt/tomcat tm"
'''
)
@Argument(name = "Tomcat installation path", description = "Path to the Tomcat installation directory.")
@Argument(name = "Application context", description = "Name of the web application context")
static def execute() {
    TmSupport.info {
        final tomcat = findTomcat()
        if (tomcat) {
            final location = tomcatLocation(tomcat)
            if (location != null) {
                final context = tomcatContext(tomcat)
                include '/collect/tomcat-logs ' + location + (context ? ' ' + context : '')
            } else {
                error('tm-tomcat.location', 'TM Tomcat location not found')
            }
        }
    }
}
execute()
