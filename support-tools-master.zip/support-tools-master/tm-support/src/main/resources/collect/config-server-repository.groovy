package collect

import com.edifecs.support.Support
import com.edifecs.support.scripts.Description

@Description(
        name = "Collect Config Server Repository",
        description = "Collects all files from the TM Config Server config-repository.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/config-server-repository
    Examples:
        script-runner "/collect/config-server-repository"
'''
)
static def execute() {
    Support.info {
        add findFiles('${ECRootPath}/TM/ConfigServer/config-repository', "*")
    }
}

execute()
