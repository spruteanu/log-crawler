import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.edifecs.support.tm.TmConfig
import com.edifecs.support.tm.TmSupport

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "TM Stop",
        description = "Stops TM-related services, including Service Manager, XES profiles, Config Server, and Web Apps.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/tm-stop
# The script will iterate through all TM services and stop them accordingly. 
Examples:
# Stop TM services
script-runner /fixture/tm-stop
'''
)
@Role("admin")
static def execute() {
    TmSupport.fixture {
        forEachApplication { final String hostName, final Map<String, ?> applicationMap ->
            if (TmConfig.isService(applicationMap)) {
                if (isLinux(hostName)) {
                    final folderName = TmSupport.toWindowsServiceName(applicationMap, '')
                    final command = 'cd $ECRootPath/TM/' + folderName + '/classes && ./stop_task_manager.sh'
                    if (isLocalHost(hostName)) {
                        shell(command)
                    } else {
                        ssh("\${SSH_USER}@$hostName '$command'")
                    }
                } else {
                    windowsService(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'), 'stop')
                }
            } else if (TmConfig.isXes(applicationMap)) {
                for (final Map<String, ?> profileMap : TmConfig.listProfiles(applicationMap)) {
                    if (isLinux(hostName)) {
                        final profileFolderName = TmSupport.toWindowsServiceName(profileMap, '', '_')
                        final command = 'cd $ECRootPath/XEServer/' + profileFolderName + '/bin && ./stop.sh'
                        if (isLocalHost(hostName)) {
                            shell(command)
                        } else {
                            ssh("\${SSH_USER}@$hostName '$command'")
                        }
                    } else {
                        windowsService(hostName, TmSupport.toWindowsServiceName(profileMap, ' XEServer ', '_'), 'stop')
                    }
                }
            } else if (TmConfig.isConfigServer(applicationMap)) {
                if (isLinux(hostName)) {
                    final folderName = TmSupport.toWindowsServiceName(applicationMap, '')
                    final command = 'cd $ECRootPath/TM/' + folderName + ' && ./stop-config-server.sh'
                    if (isLocalHost(hostName)) {
                        shell(command)
                    } else {
                        ssh("\${SSH_USER}@$hostName '$command'")
                    }
                } else {
                    windowsService(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'), 'stop')
                }
            } else if (TmConfig.isWebApp(applicationMap)) {
                // todo: start tomcat?
            }
        }
    }
}
execute()
