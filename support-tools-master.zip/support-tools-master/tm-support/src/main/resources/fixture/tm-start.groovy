import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.edifecs.support.tm.TmConfig
import com.edifecs.support.tm.TmSupport

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "TM Start services",
        description = "Starts TM-related services, including Service Manager, XES profiles, Config Server, and Web Apps.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/tm-start
Examples:
# Start TM services
script-runner /fixture/tm-start
'''
)
@Role("admin")
static def execute() {
    TmSupport.fixture {
        forEachApplication { final String hostName, final Map<String, ?> applicationMap ->
            if (TmConfig.isService(applicationMap)) {
                if (isLinux(hostName)) {
                    final folderName = TmSupport.toWindowsServiceName(applicationMap, '')
                    final command = 'cd $ECRootPath/TM/' + folderName + '/classes && ./run_task_manager.sh'
                    if (isLocalHost(hostName)) {
                        shell(command)
                    } else {
                        ssh("\${SSH_USER}@$hostName '$command'")
                    }
                } else {
                    windowsService(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'), 'start')
                }
            } else if (TmConfig.isXes(applicationMap)) {
                for (final Map<String, ?> profileMap : TmConfig.listProfiles(applicationMap)) {
                    if (isLinux(hostName)) {
                        final profileFolderName = TmSupport.toWindowsServiceName(profileMap, '', '_')
                        final command = 'cd $ECRootPath/XEServer/' + profileFolderName + '/bin && ./start.sh'
                        if (isLocalHost(hostName)) {
                            shell(command)
                        } else {
                            ssh("\${SSH_USER}@$hostName '$command'")
                        }
                    } else {
                        windowsService(hostName, TmSupport.toWindowsServiceName(profileMap, ' XEServer ', '_'), 'start')
                    }
                }
            } else if (TmConfig.isConfigServer(applicationMap)) {
                if (isLinux(hostName)) {
                    final folderName = TmSupport.toWindowsServiceName(applicationMap, '')
                    final command = 'cd $ECRootPath/TM/' + folderName + ' && ./config-server.sh'
                    if (isLocalHost(hostName)) {
                        shell(command)
                    } else {
                        ssh("\${SSH_USER}@$hostName '$command'")
                    }
                } else {
                    windowsService(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'), 'start')
                }
            } else if (TmConfig.isWebApp(applicationMap)) {
                // todo: start tomcat?
            }
        }
    }
}

execute()
