package validate

import com.edifecs.support.Support
import com.edifecs.support.scripts.Description

@Description(
        name = "Validate Config Server",
        description = "Verifies if a Config Server Java process is running.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/config-server

     Examples:
     
# Check if ConfigServer process is running
script-runner "/validate/config-server"
'''
)

static def execute() {
    Support.info {
        final name = isLinux() ? 'lib/config-server' : 'lib\\config-server'
        def javaProcess = findJavaProcess(name)
        if (!javaProcess) {
            error(name, "No running '$name' java processes found")
        }
    }
}

execute()
