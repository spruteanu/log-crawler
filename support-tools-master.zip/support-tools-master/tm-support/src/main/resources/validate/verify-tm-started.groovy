import com.edifecs.support.scripts.Description
import com.edifecs.support.tm.TmConfig
import com.edifecs.support.tm.TmSupport

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */

@Description(
        name = "Verify TM Started",
        description = "Checks if Transaction Management services are running.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/verify-tm-started

    Examples:
# Verify if TM services are started
script-runner "/validate/verify-tm-started"
'''
)

static def execute() {
    TmSupport.info {
        forEachApplication { final String hostName, final Map<String, ?> applicationMap ->
            if (TmConfig.isService(applicationMap)) {
                if (isLinux(hostName)) {
//                    ... todo: implement service running check
                } else {
                    validateServiceRunning(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'))
                }
            } else if (TmConfig.isXes(applicationMap)) {
                for (final Map<String, ?> profileMap : TmConfig.listProfiles(applicationMap)) {
                    if (isLinux(hostName)) {
//                    ... todo: implement service running check
                    } else {
                        validateServiceRunning(hostName, TmSupport.toWindowsServiceName(profileMap, ' XEServer ', '_'))
                    }
                }
            } else if (TmConfig.isConfigServer(applicationMap)) {
                if (isLinux(hostName)) {
//                    ... todo: implement service running check
                } else {
                    if (isLocalHost(hostName)) {
                        include('/validate/validate-config-server')
                    } else {
                        validateServiceRunning(hostName, TmSupport.toWindowsServiceName(applicationMap, 'TM'))
                    }
                }
            } else if (TmConfig.isWebApp(applicationMap)) {
                // todo: is Tomcat started?
            }
        }
    }
}

execute()
