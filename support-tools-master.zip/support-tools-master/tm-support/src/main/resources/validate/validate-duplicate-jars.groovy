import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.tm.Libraries

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */

@Description(
        name = "Validate Duplicate JARs",
        description = "Checks for duplicate JAR files in specific directories.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/duplicate-jars [path1] [path2] ... [path n]
    Scans specified directories (or default TM library locations) for duplicate JAR files.

    Examples:
# Scan default TM library locations for duplicate JARs
script-runner /validate/duplicate-jars

# Scan a specific directory for duplicate JARs
script-runner /validate/duplicate-jars "/opt/app/lib"

# Scan multiple directories for duplicate JARs
script-runner /validate/duplicate-jars "/opt/app/lib" "/var/app/modules"
'''
)
@Argument(name = "path", description = "The directory or directories to scan for duplicate JAR files. If not provided, default TM library locations will be scanned.", required = false)

static def execute(String... args) {
    Support.info {
        final pathToScan = args ? Arrays.asList(args) : Libraries.tmLibLocations(resolveVariable('${ECRootPath}'))
        for (final path : pathToScan) {
            logger.debug("Verifying duplicate jars under: '{}'", path)
            final duplicates = Libraries.lookupDuplicates(resolveVariable(path))
            if (duplicates) {
                error(pathToKey(path) + '-duplicates.error', duplicates.toString())
            }
        }
    }
}

execute(args)
