import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.tm.TmSupport

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.stream.Collectors

@Description(
        name = "DB Selector XML Validator",
        description = "Compares two exported DB Selector XML files and reports differences in SIDs.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/db-selector-xml-validate [file1.xml] [file2.xml] 

    Example:

# Compare two DB Selector XML files
script-runner "/validate/db-selector-xml-validate file1.xml file2.xml"

'''
)

@Argument(name = "file1.xml", description = "First XML file to compare.")
@Argument(name = "file2.xml", description = "Second XML file to compare.")

static def execute(String... args) {
    TmSupport.fixture {
        validateArgs("Exported DB Selector XMLs file1 and file2 are expected", { it != null && it.length == 2 }, args)
        final file1 = Paths.get(args[0])
        final file2 = Paths.get(args[1])
        final file1SIDs = parseSIDs(file1)
        final file2SIDs = parseSIDs(file2)
        final file1MinusFile2 = diff(Collections.unmodifiableList(file1SIDs), Collections.unmodifiableList(file2SIDs))
        final file2MinusFile1 = diff(Collections.unmodifiableList(file2SIDs), Collections.unmodifiableList(file1SIDs))
        if (!file1MinusFile2.isEmpty()) {
            error(file1.fileName.toString() + ".error", String.format("file 1 has SIDs that are not present in file 2 %s", file1MinusFile2))
        }
        if (!file2MinusFile1.isEmpty()) {
            error(file2.fileName.toString() + ".error", String.format("file 2 has SIDs that are not present in file 1 %s", file2MinusFile1))
        }
    }
}
private static Integer extractProperty(final String line) {
    final String property = "TPM_TradeRelationshipSID="
    int startIndex = line.indexOf(property)
    if (startIndex == -1) {
        return null
    }
    startIndex += property.length()
    final int endIndex = line.indexOf("</property>")
    return Integer.parseInt(line.substring(startIndex, endIndex))
}

private static List<Integer> parseSIDs(Path file) throws IOException {
    return Files.lines(file)
            .map(this.&extractProperty)
            .filter(Objects.&nonNull)
            .collect(Collectors.toList())
}

private static Collection<Integer> diff(final Collection<Integer> list1, final Collection<Integer> list2) {
    final Set<Integer> copy = new HashSet<>(list1)
    copy.removeAll(list2)
    return copy
}
execute(args)
