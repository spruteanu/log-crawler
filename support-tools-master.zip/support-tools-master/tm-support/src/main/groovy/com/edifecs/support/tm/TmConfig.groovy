package com.edifecs.support.tm

import com.edifecs.support.collect.SqlContext
import com.edifecs.support.core.StringEncrypter
import com.edifecs.support.core.Utils
import org.apache.commons.lang.StringUtils

import java.util.stream.Stream

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings('unused')
class TmConfig {
    static final String NAME_PROPERTY = '@name'
    static final String TYPE_PROPERTY = '@type'
    protected static final String SERVICE_MANAGER_TYPE = 'servicemanager'
    static final String CONFIG_SERVER_TYPE = 'tm-config-server'
    static final String XES_TYPE = 'xes'
    static final String WEB_APP_TYPE = 'webapp'
    protected static final String APPLICATION_PROPERTY = 'application'
    static final String APP_SERVER_PROPERTY = 'appserver'
    static final String PROFILES_PROPERTY = 'profiles'

    static final String CONFIG_TAG = "config"
    static final String COMPUTER_TAG = "computer"
    static final String SERVICES_TAG = "services"
    static final String SERVICE_TAG = "service"
    static final String APPLICATION_TAG = "application"
    static final String APPSERVER_TAG = "appserver"
    static final String PROFILES_TAG = "profiles"
    static final String PROFILE_TAG = "profile"
    static final String CONFIGURATION_TAG = "configuration"
    static final String DATABASES_TAG = "databases"
    static final String EMAILS_TAG = "emails"
    static final String JMS_TAG = "jms"
    static final String JMSSERVER_TAG = "jmsserver"
    static final String PROPERTY_TAG = "property"
    static final String CLOUD_REPOSITORY_TAG = "cloud-repository"
    static final String TABLEAU_SERVER_TAG = "tableau-server"
    static final String GBD_REPLICATION_TAG = "gbdreplication"
    static final String KAFKA_TAG = "kafka"
    static final String KAFKA_SERVER_TAG = "kafkaserver"

    static final String CONFIGSERVER_ID = "configserver"
    static final String SERVICEMANAGER_ID = "servicemanager"
    static final String TOOLS_SERVICE = "tools-service"
    static final String WEBAPP_GENERIC_ID = "webapp__generic_id"

    public static final String DATABASE_TAG = "database"
    public static final String GBD_DATABASE_NAME = "gbd"
    public static final String ACTIVE_DATABASE_NAME = "active"
    public static final String ENABLEMENT_DATABASE_NAME = "enablement"
    public static final String DATASTORE_DATABASE_NAME = "TMDS"
    public static final String REPLICATION_DATABASE_NAME = "replica"
    public static final String CONNECTION_SETTINGS_NAME = "Connection Settings"
    public static final String NAME_PROPERTY = "@name"
    public static final String TAG_PROPERTY = "tag"
    public static final String TYPE_PROPERTY = "@type"
    public static final String REPORTING_DB_TYPE = "reporting"

    public static final String DATABASE_TYPE = "database.type"
    public static final String SERVER = "server"
    public static final String DATABASE = "database"
    public static final String PORT = "port"
    public static final String URL = "url"
    public static final String MASTER_URL = "master.url"
    public static final String INSTANCE = "instance"
    public static final String DRIVER = "driver"
    public static final String ENCRYPT = "encrypt"
    public static final String TRUST_SERVER_CERTIFICATE = "trustservercertificate"

    public static final String MSSQL_DEFAULT_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    public static final String ORACLE_DEFAULT_DRIVER = "oracle.jdbc.OracleDriver"
    public static final String POSTGRES_DEFAULT_DRIVER = "org.postgresql.Driver"

    private final Map<String, ?> tmConfig = [:]
    private final Map<String, ?> dbSystemProperties = [:]

    boolean isInitialized() {
        return tmConfig
    }

    protected void handleConfiguration(def configurationMap, String useConfiguration) {
        if (configurationMap instanceof Map) {
            tmConfig.putAll(configurationMap)
        } else if (configurationMap instanceof Collection) {
            for (def ccMap : configurationMap) {
                if (ccMap.'@name' == useConfiguration) {
                    tmConfig.putAll(ccMap)
                }
            }
        }
    }

    protected void parseXml(def obj) {
        if (!obj) {
            return
        }
        final configMap = obj.'config'
        if (!configMap) {
            return
        }
        final String useConfiguration = configMap.'use-configuration'
        final version = configMap.'@version'
        tmConfig.'version' = version

        final configurationMap = configMap.'configuration'
        if (configurationMap instanceof Map) {
            handleConfiguration(configurationMap, useConfiguration)
        } else if (configurationMap instanceof Collection) {
            for (def ccMap : configurationMap) {
                handleConfiguration(configurationMap, useConfiguration)
            }
        }
    }

    TmConfig parseXml(String file) {
        parseXml(new File(file))
        return this
    }

    TmConfig parseXml(File file) {
        if (file.exists()) {
            file.withInputStream {
                parseXml(it)
            }
        }
        return this
    }

    TmConfig parseXml(InputStream ios) {
        parseXml(Utils.xml2Map(ios))
        return this
    }

    protected String lookupDbName(String key) {
        String name = key
        int idx = key.indexOf('.')
        if (idx != -1) {
            name = key.substring(0, idx)
        }
        return name
    }
    protected static String toDbProperty(String name, String key) {
        def propName = key.substring(name.length())
        if (propName.startsWith('.')) {
            propName = propName.substring(1)
        }
        if (!propName) {
            propName = key
        }
        return propName
    }

    TmConfig usingDbProperties(InputStream ios) {
        def props = new Properties()
        props.load(ios)
        final map = new LinkedHashMap<>()
        props.each {
            String key = it.key
            final name = lookupDbName(key)
            def mMap = map.get(name) as Map
            if (!mMap) {
                mMap = [:]
                map.put(name, mMap)
            }
            mMap.put(toDbProperty(name, key), it.value)
        }
        dbSystemProperties.putAll(map)
        return this
    }

    TmConfig usingDbProperties(File file) {
        file.withInputStream {
            usingDbProperties(it)
        }
        return this
    }

    TmConfig usingDbProperties(String file) {
        usingDbProperties(new File(file))
        return this
    }

    String getVersion() {
        return tmConfig.get('version')
    }

    Map<String, ?> findTomcat() {
        return appStream()
                .filter { isTomcat(it) }
                .map { listAppServers(it)[0] }
                .findAny().orElse(Collections.emptyMap())
    }

    protected static Map<String, ?> toPropertyValueMap(Object props) {
        def p = props
        if (!(p instanceof Collection)) {
            p = Collections.singletonList(props)
        }
        return p.collect({
            final key = it.'@name'
            def value = it.'value'
            if ('encrypted' == it.'@type') {
                value = "{enc}$value"
            }
            return Map.entry(key, value)
        }).collectEntries()
    }

    static Map<String, ?> toPropertyValueMap(Map<String, ?> map) {
        if (!map) {
            return map
        }
        return toPropertyValueMap(map.property)
    }

    String tomcatLocation(Map<String, ?> tomcatApp) {
        def map = toPropertyValueMap(tomcatApp)
        return map.location
    }

    String tomcatLocation() {
        return tomcatLocation(findTomcat())
    }

    String tomcatContext(Map<String, ?> tomcatApp) {
        def map = toPropertyValueMap(tomcatApp)
        return map.webcontext
    }

    String tomcatContext() {
        return tomcatContext(findTomcat())
    }

    protected Collection<Map<String, ?>> applications() {
        return tmConfig.'computer'.'application'
    }

    Stream<Map<String, ?>> appStream() {
        return applications().stream()
    }

    void forEachApplication(def delegate, Closure closure) {
        for (final Map.Entry<String, ?> entry : tmConfig.entrySet()) {
            final value = entry.value
            if (!(value instanceof Map)) {
                continue
            }
            closure.setDelegate(delegate)
            closure.setResolveStrategy(Closure.DELEGATE_FIRST)
            final hostName = entry.key
            final Map cMap = value as Map
            if (cMap.containsKey(APPLICATION_PROPERTY)) {
                def applications = cMap.get(APPLICATION_PROPERTY) as Collection<Map>
                for (final ccMap : applications) {
                    closure.call(hostName, ccMap)
                }
            }
        }
    }

    protected Collection<Map<String, ?>> databases() {
        return tmConfig.databases.database
    }

    Map<String, Map<String, ?>> databaseMap() {
        return databases().collectEntries {[(it.'@name'): it]}
    }

    Stream<Map<String, ?>> dbStream() {
        return databases().stream()
    }

    Map<String, ?> dbMap(String dbName) {
        return databaseMap().get(dbName)
    }
    Map<String, ?> enablementMap() {
        return dbMap(ENABLEMENT_DATABASE_NAME)
    }
    Map<String, ?> activeMap() {
        return dbMap(ACTIVE_DATABASE_NAME)
    }
    Map<String, ?> gbdMap() {
        return dbMap(GBD_DATABASE_NAME)
    }

    Map<String, ?> dbProperties(String name) {
        final result = new LinkedHashMap(toPropertyValueMap(dbMap(name)))
        result.putAll(toPropertyValueMap(((Object)tmConfig.databases.property)))
        return result
    }
    Map<String, ?> enablementProperties() {
        return dbProperties(ENABLEMENT_DATABASE_NAME)
    }
    Map<String, ?> activeProperties() {
        return dbProperties(ACTIVE_DATABASE_NAME)
    }
    Map<String, ?> gbdProperties() {
        return dbProperties(GBD_DATABASE_NAME)
    }

    Map<String, ?> dbSystemProperties() {
        return dbSystemProperties
    }

    Map<String, ?> configXmlProperties() {
        return tmConfig
    }

    Properties dbConnectionProperties(String dbName) {
        final dbProps = new Properties()
        final dbPropertyValueMap = toPropertyValueMap(dbMap(dbName))
        if (dbPropertyValueMap) {
            dbProps.putAll(dbPropertyValueMap)
            if (!dbProps.hasProperty(SqlContext.URL)) {
                String url = SqlContext.generateUrl(SqlContext.lookupDatabaseType(dbPropertyValueMap, [:]), dbPropertyValueMap)
                if (url) {
                    dbProps.put(SqlContext.URL, url)
                }
            }
        }
        def password = dbProps.get(SqlContext.PASSWORD)
        if (StringEncrypter.isEncrypted(password)) {
            password = SqlContext.getDecrypter().resolveDecrypted(password)
            dbProps.put(SqlContext.PASSWORD, password)
        }
        return dbProps
    }

    Properties enablementConnectionProperties() {
        return dbConnectionProperties('enablement')
    }
    Properties activeConnectionProperties() {
        return dbConnectionProperties('active')
    }
    Properties gbdConnectionProperties() {
        return dbConnectionProperties('gbd')
    }

    static TmConfig of(String file) {
        return new TmConfig().parseXml(file)
    }

    static TmConfig of(File file) {
        return new TmConfig().parseXml(file)
    }

    static TmConfig of(InputStream ios) {
        return new TmConfig().parseXml(ios)
    }

    static String lookupServer(Map properties) {
        return StringUtils.defaultIfEmpty((String) properties.get(SERVER), "localhost")
    }

    static boolean isTomcat(Map<String, ?> applicationMap) {
        boolean result = false
        if (isWebApp(applicationMap)) {
            final appServers = listAppServers(applicationMap)
            result = appServers && 'tomcat'.equalsIgnoreCase(getType(appServers[0]))
        }
        return result
    }

    static String getName(Map<String, ?> applicationMap) {
        return applicationMap.get(NAME_PROPERTY)
    }

    static String getType(Map<String, ?> map) {
        return map.get(TYPE_PROPERTY)
    }

    static boolean isService(Map<String, ?> applicationMap) {
        return SERVICE_MANAGER_TYPE.equalsIgnoreCase(getType(applicationMap))
    }

    static boolean isConfigServer(Map<String, ?> applicationMap) {
        return CONFIG_SERVER_TYPE.equalsIgnoreCase(getType(applicationMap))
    }

    static boolean isXes(Map<String, ?> applicationMap) {
        return XES_TYPE.equalsIgnoreCase(getType(applicationMap))
    }

    static boolean isWebApp(Map<String, ?> applicationMap) {
        return WEB_APP_TYPE.equalsIgnoreCase(getType(applicationMap))
    }

    static Collection<Map<String, ?>> listAppServers(Map<String, ?> applicationMap) {
        final obj = applicationMap.(APP_SERVER_PROPERTY)
        return obj instanceof Collection ? obj : [obj]
    }

    static Collection<Map<String, ?>> listProfiles(Map<String, ?> applicationMap) {
        final obj = applicationMap.(PROFILES_PROPERTY)
        return obj instanceof Collection ? obj : [obj]
    }

    private static final Map<String, TmConfig> instanceMap = Collections.synchronizedMap(new LinkedHashMap<>())
    static TmConfig instance(String name) {
        if (!name) {
            return instanceMap.isEmpty() ? null : instanceMap.values().first()
        }
        return instanceMap.computeIfAbsent(name, TmConfig.&of)
    }
    static TmConfig instance() {
        return instance(null)
    }
}
