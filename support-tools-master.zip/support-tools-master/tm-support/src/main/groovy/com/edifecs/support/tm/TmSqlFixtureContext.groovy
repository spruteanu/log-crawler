package com.edifecs.support.tm

import com.edifecs.support.fixture.SqlFixtureContext
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class TmSqlFixtureContext extends SqlFixtureContext {

    List<String> initialize(String[] args) {
        return TmSqlContext.initialize(this, args)
    }

    static TmSqlFixtureContext of() {
        return new TmSqlFixtureContext();
    }
}
