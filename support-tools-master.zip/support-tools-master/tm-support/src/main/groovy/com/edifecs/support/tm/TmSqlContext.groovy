package com.edifecs.support.tm

import com.edifecs.support.collect.SqlContext
import com.edifecs.support.collect.SqlInfoContext
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class TmSqlContext extends SqlInfoContext {

    @SuppressWarnings('DuplicatedCode')
    static List<String> initialize(SqlContext context, String[] args) {
        String tmConfigXml = null
        String dbName = null
        String dbPropertiesFile = null
        List<String> scripts = new ArrayList<>()
        for (final arg : args) {
            final larg = arg.toLowerCase()
            if (larg.endsWith('.xml')) {
                tmConfigXml = arg
            } else if (larg.endsWith('.properties') || larg.endsWith('.conf')) {
                dbPropertiesFile = arg
            } else if (larg.endsWith('.sql')) {
                scripts.add(arg)
            } else {
                dbName = arg
            }
        }
        if (!tmConfigXml && !dbPropertiesFile) {
            tmConfigXml = '${ECRootPath}/TM/install/config.xml'
        }
        if (dbPropertiesFile) {
            context.dbProperties(dbPropertiesFile)
        } else if (tmConfigXml) {
            if (!dbName) {
                throw new IllegalArgumentException("TM configuration provided but no DB name specified: ${args.join(' ')}")
            }
            context.dbProperties(TmConfig.instance(context.resolveVariable(tmConfigXml)).dbConnectionProperties(dbName))
        }
        if (!context.isInitialized()) {
            throw new IllegalStateException("Sql context is not initialized; used arguments: ${args.join(' ')}")
        }
        return scripts
    }

    List<String> initialize(String[] args) {
        return initialize(this, args)
    }

    static TmSqlContext of() {
        return new TmSqlContext();
    }
}
