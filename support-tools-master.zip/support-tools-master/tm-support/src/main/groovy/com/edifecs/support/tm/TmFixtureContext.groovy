package com.edifecs.support.tm

import com.edifecs.support.fixture.FixtureContext
import groovy.transform.CompileStatic

import java.util.stream.Stream

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class TmFixtureContext extends FixtureContext {
    TmConfig tmConfig

    TmFixtureContext() {
    }

    TmFixtureContext(TmConfig tmConfig) {
        this.tmConfig = tmConfig
    }

    Stream<Map<String, ?>> appStream() {
        return tmConfig.appStream()
    }

    void forEachApplication(@DelegatesTo(TmFixtureContext.class) Closure closure) {
        tmConfig.forEachApplication(this, closure)
    }

    Map<String, ?> findTomcat() {
        return tmConfig.findTomcat()
    }
    String findTomcatLocation() {
        return tmConfig.tomcatLocation()
    }
    String tomcatLocation(Map<String, ?> tomcatApp) {
        return tmConfig.tomcatLocation(tomcatApp)
    }
    String tomcatContext(Map<String, ?> tomcatApp) {
        return tmConfig.tomcatContext(tomcatApp)
    }
    String tomcatContext() {
        return tmConfig.tomcatContext()
    }

    static TmFixtureContext of() {
        final context = new TmFixtureContext()
        context.defaultContext()
        context.tmConfig = TmConfig.instance(context.resolveVariable('${ECRootPath}/TM/install/config.xml'))
        return context
    }
}
