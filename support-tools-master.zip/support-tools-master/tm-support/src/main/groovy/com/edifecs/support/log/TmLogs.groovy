package com.edifecs.support.log

import com.edifecs.support.core.GroovyUtil
import com.edifecs.support.core.Validators
import groovy.transform.CompileStatic
import groovy.util.logging.Log4j2

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
@Log4j2
class TmLogs extends Logs {

    private static final String TM_YAML_LOGGING_VERSION = '9.2.3.2'
    static final String TM_LOGGER_LOG4J_CONFIG = '/TMLogger.old.cfg'
    static final String YAML_LOG4J_CONFIG = '/TMLogger.yaml.cfg'

    static LogsBuilder log4j(LogsBuilder builder, Closure closure) {
        builder.log4j(closure)
        return builder
    }

    protected static boolean isYamlLogConfig(String tmVersion) {
        return Validators.isVersionGreater(tmVersion, TM_YAML_LOGGING_VERSION) || Validators.matchesVersion(tmVersion, TM_YAML_LOGGING_VERSION)
    }

    protected static LogsBuilder defaultConfigBuilder(String... args) {
        final builder = Logs.builder(args)
        if (!builder.hasRegisteredConsumers()) {
            log.debug("No logging configuration found, using default '{}'", TM_LOGGER_LOG4J_CONFIG)
            builder.log4jConfig(TM_LOGGER_LOG4J_CONFIG)
        }
        return builder
    }

    protected static LogsBuilder builder(String... args) {
        return defaultConfigBuilder(args)
    }

    static LogsBuilder log4j(@DelegatesTo(Log4jConsumer.Builder) Closure closure, String... args) {
        final builder = defaultConfigBuilder(args)
        return log4j(builder, closure)
    }

    static LogsBuilder builder(@DelegatesTo(LogsBuilder) Closure closure, String... args) {
        return GroovyUtil.closureCall(closure, LogsBuilder.class, { defaultConfigBuilder(args) })
    }
    static LogsBuilder tmLoggerBuilder(String... args) {
        def options = [Tool.LOG4J_OPTION, TM_LOGGER_LOG4J_CONFIG]
        if (args) {
            options.addAll(args)
        }
        final array = options.toArray(new String[0])
        return defaultConfigBuilder(array as String[])
    }
    static LogsBuilder yamlLoggerBuilder(String... args) {
        def options = [Tool.LOG4J_OPTION, YAML_LOG4J_CONFIG]
        if (args) {
            options.addAll(args)
        }
        final array = options.toArray(new String[0])
        return defaultConfigBuilder(array as String[])
    }
}
