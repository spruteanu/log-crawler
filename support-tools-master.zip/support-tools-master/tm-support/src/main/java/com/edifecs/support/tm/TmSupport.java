package com.edifecs.support.tm;

import com.edifecs.support.Support;
import com.edifecs.support.collect.SqlInfoContext;
import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import com.edifecs.support.fixture.SqlFixtureContext;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

import java.util.Map;
import java.util.Properties;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"rawtypes", "squid:S1121"})
public class TmSupport extends Support {

    private TmSupport() {}

    public static String toWindowsServiceName(Map<String, ?> applicationMap, String servicePrefix, String separator) {
        return ("Edifecs" + servicePrefix + TmConfig.getName(applicationMap)).replaceAll("\\s", separator);
    }

    public static String toWindowsServiceName(Map<String, ?> applicationMap, String servicePrefix) {
        return toWindowsServiceName(applicationMap, servicePrefix, "");
    }

    public static Context info(@DelegatesTo(TmFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof TmFixtureContext) {
            return info(context, closure);
        }
        final Context ctx = context != null ? TmFixtureContext.of().clone(context) : TmFixtureContext.of();
        info(ctx, closure);
        return ctx;
    }

    public static Context info(Context context, @DelegatesTo(TmFixtureContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static Context fixture(@DelegatesTo(TmFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof TmFixtureContext) {
            return fixture(context, closure);
        }
        final Context ctx = context != null ? TmFixtureContext.of().clone(context) : TmFixtureContext.of();
        fixture(ctx, closure);
        return context;
    }

    @SuppressWarnings("squid:S4144")
    public static Context fixture(Context context, @DelegatesTo(TmFixtureContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static TmSqlContext sqlInfo(@DelegatesTo(TmSqlContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof TmSqlContext) {
            return sqlInfo((TmSqlContext) context, closure);
        }
        final TmSqlContext ctx = context != null ? (TmSqlContext) TmSqlContext.of().clone(context) : TmSqlContext.of();
        sqlInfo(ctx, closure);
        return ctx;
    }

    @SuppressWarnings("DuplicatedCode")
    public static TmSqlContext sqlInfo(String url, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final TmSqlContext ctx;
        if (context instanceof TmSqlContext) {
            ctx = (TmSqlContext) context;
        } else {
            ctx = context != null ? (TmSqlContext) TmSqlContext.of().clone(context) : TmSqlContext.of();
        }
        ctx.jdbcTemplate(url);
        return sqlInfo(ctx, closure);
    }

    @SuppressWarnings("DuplicatedCode")
    public static TmSqlContext sqlInfo(Properties properties, @DelegatesTo(TmSqlContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final TmSqlContext ctx;
        if (context instanceof TmSqlContext) {
            ctx = (TmSqlContext) context;
        } else {
            ctx = context != null ? (TmSqlContext) TmSqlContext.of().clone(context) : TmSqlContext.of();
        }
        ctx.jdbcTemplate(properties);
        return sqlInfo(ctx, closure);
    }

    public static TmSqlContext sqlInfo(TmSqlContext context, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static TmSqlFixtureContext sqlFixture(@DelegatesTo(TmSqlFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof TmSqlFixtureContext) {
            return sqlFixture((TmSqlFixtureContext) context, closure);
        }
        final TmSqlFixtureContext ctx = context != null ? (TmSqlFixtureContext) TmSqlFixtureContext.of().clone(context) : TmSqlFixtureContext.of();
        sqlFixture(ctx, closure);
        return ctx;
    }

    @SuppressWarnings("DuplicatedCode")
    public static TmSqlFixtureContext sqlFixture(String url, @DelegatesTo(TmSqlFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final TmSqlFixtureContext ctx;
        if (context instanceof SqlFixtureContext) {
            ctx = (TmSqlFixtureContext) context;
        } else {
            ctx = context != null ? (TmSqlFixtureContext) TmSqlFixtureContext.of().clone(context) : TmSqlFixtureContext.of();
        }
        ctx.jdbcTemplate(url);
        return sqlFixture(ctx, closure);
    }

    @SuppressWarnings("DuplicatedCode")
    public static TmSqlFixtureContext sqlFixture(Properties properties, @DelegatesTo(TmSqlFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final TmSqlFixtureContext ctx;
        if (context instanceof TmSqlFixtureContext) {
            ctx = (TmSqlFixtureContext) context;
        } else {
            ctx = context != null ? (TmSqlFixtureContext) SqlFixtureContext.of().clone(context) : TmSqlFixtureContext.of();
        }
        ctx.jdbcTemplate(properties);
        return sqlFixture(ctx, closure);
    }

    @SuppressWarnings("squid:S4144")
    public static TmSqlFixtureContext sqlFixture(TmSqlFixtureContext context, @DelegatesTo(TmSqlFixtureContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static TmConfig tmConfig() {
        return TmConfig.instance();
    }
}
