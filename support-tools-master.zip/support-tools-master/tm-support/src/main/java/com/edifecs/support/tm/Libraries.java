package com.edifecs.support.tm;

import com.edifecs.support.core.Directories;
import com.edifecs.support.core.Patterns;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by anastasiaz on 5/18/2016.
 */
public class Libraries {

    public static List<String> tmLibLocations(final String basePath) {
        return Arrays.asList(
                basePath + "/tmp/cp/gbd-deploy/lib",
                basePath + "/tmp/cp/gbd-deploy/cps",
                basePath + "/TM/ServiceManager/lib",
                basePath + "/TM/ServiceManager/task-management/activiti-service/WEB-INF/lib",
                basePath + "/TM/ServiceManager/tools",
                basePath + "/TM/ServiceManager/tpm-plugin/gbd-party-sync-plugin/lib",
                basePath + "/TM/sdk/archive-xes/archive/lib",
                basePath + "/TM/sdk/gbd-indexer-xes/gbd-indexer/lib",
                basePath + "/TM/sdk/guideline-loader-xes/guideline-loader/lib",
                basePath + "/TM/sdk/htr-indexer-xes/htr-indexer/lib",
                basePath + "/TM/sdk/job-xes/job/lib",
                basePath + "/TM/sdk/search-repo-xes/search-repo/lib",
                basePath + "/TM/sdk/tm-components-xes/tm/lib",
                basePath + "/TM/sdk/tm-components-xes/tm/trackinginfo-lib",
                basePath + "/TM/sdk/tools",
                basePath + "/TM/ConfigServer/lib",
                basePath + "/TM/archive/gbd-etl/lib",
                basePath + "/TM/archive/htr-etl/lib",
                basePath + "/TM/TmAgent/lib",
                basePath + "/tmp/tm/install/database/lib",
                basePath + "/tmp/tm/install/lib"
        );
    }

    /**
     * This method should match in this case :<br>
     * accesscontrol-api-1.4.jar
     * archival-etl-1.13-SNAPSHOT.jar
     * archive-client-5.2.0-20181214.160750-6.jar <<---- ONLY THIS
     * commons-lang3-3.8.1.jar
     * ojdbc6-11.2.0.4.0.jar
     *
     * @param name - jar file
     * @return - match description
     */
    static boolean isInvalidSnapshotName(String name) {
        return Patterns.of("^\\D+[\\d+.]+-\\d{3,}+.+").matcher(name).matches();
    }

    static Pattern artifactVersion() {
        return Patterns.of("((?:\\-*)([\\d\\.]*(?:\\-SNAPSHOT)*(?:\\.jar)))", Pattern.CASE_INSENSITIVE);
    }

    static String toArtifactName(String name) {
        final Matcher matcher = artifactVersion().matcher(name);
        if (matcher.find()) {
            final String versionWithJar = matcher.group(0);
            return name.substring(0, name.length() - versionWithJar.length());
        }
        return name;
    }

    static String toArtifactVersion(String name) {
        final Matcher matcher = artifactVersion().matcher(name);
        if (matcher.find()) {
            String versionWithJar = matcher.group(0);
            versionWithJar = versionWithJar.substring(0, versionWithJar.length() - 4);
            if (!versionWithJar.isEmpty()) {
                if (versionWithJar.charAt(0) == '-') {
                    versionWithJar = versionWithJar.substring(1);
                }
                return versionWithJar;
            }
        }
        return null;
    }

    static boolean isInvalidSnapshotName(File file) {
        return isInvalidSnapshotName(file.getName());
    }

    static boolean isInvalidSnapshotName(Path file) {
        return isInvalidSnapshotName(file.getFileName().toString());
    }

    static boolean isJarFileName(String name) {
        return name.endsWith("jar");
    }

    static boolean isInspectableJar(String name) {
        return isJarFileName(name)
                && !name.contains("TM_Codesets")
                && !(name.matches("config-server-.*-original.jar") || name.matches("config-server-.*-starter.jar"));
    }

    public static Map<String, List<Path>> lookupDuplicates(String basePath) throws IOException {
        final Path dir = Paths.get(basePath);
        if (!Files.exists(dir)) {
            return Collections.emptyMap();
        }
        try (final Stream<Path> stream = Directories.filesStream(dir, path -> {
            final String name = path.getFileName().toString().toLowerCase();
            return isInspectableJar(name);
        })) {
            final Map<String, List<Path>> artifactPathsMap = stream.collect(Collectors.groupingBy(path -> toArtifactName(path.toString())));
            return artifactPathsMap.entrySet().stream()
                    .filter(e -> e.getValue().size() > 1)
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        }
    }

    public static Set<String> lookupInvalidSnapshot(String basePath) throws IOException {
        try (final Stream<Path> stream = Directories.filesStream(Paths.get(basePath), path -> {
            final String name = path.getFileName().toString().toLowerCase();
            return isJarFileName(name) && isInvalidSnapshotName(name);
        })) {
            return stream.map(Path::toString).collect(Collectors.toSet());
        }
    }

}
