package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import org.apache.commons.compress.archivers.zip.UnixStat;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * ApacheZipWalker provides zipIt methods implemented using Apache Commons Compress
 * ZipArchiveOutputStream. This class does NOT replace existing ZipWalker usages.
 * It is an alternative for cases where we need precise control over Unix file permissions
 * (e.g., shell scripts) and want to rely on Apache Commons' ZipArchiveOutputStream end-to-end.
 */
public final class ApacheZipWalker {

    private ApacheZipWalker() {
        // utility class
    }

    public interface ZipArchiveOutputVisitor {
        void visit(ZipArchiveOutputStream zaos) throws IOException;
    }

    public static void zipIt(Path folder, Path zipFile) throws IOException {
        zipIt(folder, zipFile, Utils::acceptAll, null);
    }

    public static void zipIt(Path folder, Path zipFile, Predicate<Path> filter) throws IOException {
        zipIt(folder, zipFile, filter, null);
    }

    public static void zipIt(Path folder, Path zipFile, Predicate<Path> filter, ZipArchiveOutputVisitor visitor) throws IOException {
        try (final Stream<Path> stream = Files.walk(folder)) {
            final Predicate<Path> isFile = Files::isRegularFile;
            zipIt(folder, stream, zipFile, isFile.and(filter), visitor);
        }
    }

    public static void zipIt(Path sourcePath, Stream<Path> stream,
                             Path zipPath, Predicate<Path> filter,
                             ZipArchiveOutputVisitor visitor) throws IOException {
        if (!zipPath.toFile().exists()) {
            zipPath = Files.createFile(zipPath);
        }
        try (final ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(Files.newOutputStream(zipPath))) {
            stream.filter(filter).forEach(p -> zipIt(sourcePath, zaos, p));
            if (visitor != null) {
                visitor.visit(zaos);
            }
            zaos.finish();
        }
    }

    /**
     * Zip shell script files using Apache Commons Compress to properly set executable permissions.
     * This method ensures that shell scripts will be executable when extracted on Unix/Linux systems.
     */
    public static void shellZipIt(ZipArchiveOutputStream zaos, InputStream inputStream, String zeName) {
        final ZipArchiveEntry zipEntry = new ZipArchiveEntry(zeName);

        // Set executable permissions for shell scripts using Apache Compress
        if (zeName.toLowerCase().endsWith(".sh")) {
            // Set Unix file permissions: 0755 (owner: read/write/execute, group/others: read/execute)
            zipEntry.setUnixMode(UnixStat.FILE_FLAG | 0755);
        } else {
            // Set default file permissions for non-shell files
            zipEntry.setUnixMode(UnixStat.FILE_FLAG | 0644);
        }

        try {
            try {
                zaos.putArchiveEntry(zipEntry);

                // For shell scripts, ensure Linux line endings (LF only, not CRLF)
                if (zeName.toLowerCase().endsWith(".sh")) {
                    // Read the entire content and normalize line endings
                    byte[] content = IOUtils.toByteArray(inputStream);
                    String contentStr = new String(content, java.nio.charset.StandardCharsets.UTF_8);
                    // Replace CRLF with LF, then replace any remaining CR with LF
                    String normalizedContent = contentStr.replace("\r\n", "\n").replace("\r", "\n");
                    byte[] normalizedBytes = normalizedContent.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    zaos.write(normalizedBytes);
                } else {
                    IOUtils.copy(inputStream, zaos);
                }
            } finally {
                zaos.closeArchiveEntry();
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to zip entry for: '%s'", zeName), e);
        }
    }

    /**
     * Zip shell script files using Apache Commons Compress to properly set executable permissions.
     * This method ensures that shell scripts will be executable when extracted on Unix/Linux systems.
     */
    public static void shellZipIt(ZipArchiveOutputStream zaos, Path path, String zeName) {
        try (InputStream inputStream = Files.newInputStream(path)) {
            shellZipIt(zaos, inputStream, zeName);
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to zip entry for: '%s'", path), e);
        }
    }

    public static void zipIt(Path basePath, ZipArchiveOutputStream zaos, Path path) {
        final String zeName = FilenameUtils.separatorsToUnix(basePath.relativize(path).toString());
        zipIt(zaos, path, zeName);
    }

    public static void zipIt(ZipArchiveOutputStream zaos, Path path, String zeName) {
        // Delegate to the helper that ensures proper handling for shell files
        shellZipIt(zaos, path, zeName);
    }

    public static void zipIt(ZipArchiveOutputStream zaos, InputStream inputStream, String zeName) {
        // Delegate to the helper that ensures proper handling for shell files
        shellZipIt(zaos, inputStream, zeName);
    }

    public static void zipIt(Map<String, String> files, OutputStream outputStream) {
        try (final ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(outputStream)) {
            for (Map.Entry<String, String> e : files.entrySet()) {
                final String zeName = FilenameUtils.separatorsToUnix(e.getKey());
                final ZipArchiveEntry entry = new ZipArchiveEntry(zeName);
                // set sane defaults; .sh gets elevated perms in shellZipIt path, but here we have Strings
                if (zeName.toLowerCase().endsWith(".sh")) {
                    entry.setUnixMode(UnixStat.FILE_FLAG | 0755);
                } else {
                    entry.setUnixMode(UnixStat.FILE_FLAG | 0644);
                }
                try {
                    zaos.putArchiveEntry(entry);
                    if (zeName.toLowerCase().endsWith(".sh")) {
                        // normalize line endings to LF for shell scripts
                        String normalized = e.getValue().replace("\r\n", "\n").replace("\r", "\n");
                        IOUtils.write(normalized, zaos, Charset.defaultCharset());
                    } else {
                        IOUtils.write(e.getValue(), zaos, Charset.defaultCharset());
                    }
                } finally {
                    zaos.closeArchiveEntry();
                }
            }
            zaos.finish();
        } catch (IOException ex) {
            throw new SupportRuntimeException("Failed to zip multiple files (ApacheZipWalker)", ex);
        }
    }
}
