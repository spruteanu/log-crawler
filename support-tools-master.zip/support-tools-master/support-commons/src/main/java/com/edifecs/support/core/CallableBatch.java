package com.edifecs.support.core;

import com.edifecs.support.SupportException;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Utility class for performing and retrieval of asynchronously submitted callables
 *
 * @author Serge Pruteanu
 */
@SuppressWarnings({"squid:S112", "squid:S1166", "squid:S2221"})
public class CallableBatch<R> implements ExecutionObserver {
    private static final String RETRIES_COUNT_EXCEEDED_MSG = "Failed execute batch, retries count: %d exceeded, message: %s";

    private final Logger logger = LogManager.getLogger(this.getClass());

    protected final ExecutorCompletionService<R> completionService;
    protected final List<Future<R>> tasks = Collections.synchronizedList(new ArrayList<>());
    protected int maxRetriesCount = 3;
    protected long executionTimeout = 10L;

    protected long unresponsiveTimeout = 2;
    protected TimeUnit unresponsiveUnit = TimeUnit.MINUTES;

    protected boolean throwExceptions = true;
    protected volatile long retrievalStart;

    public CallableBatch(ExecutorService executorService) {
        this(new ExecutorCompletionService<>(executorService));
    }

    public CallableBatch(ExecutorCompletionService<R> completionService) {
        this.completionService = completionService;
    }

    public List<Future<R>> getTasks() {
        return tasks;
    }

    public boolean isThrowExceptions() {
        return throwExceptions;
    }

    public void setThrowExceptions(boolean throwExceptions) {
        this.throwExceptions = throwExceptions;
    }
    public CallableBatch<R> ignoreExceptions() {
        this.throwExceptions = false;
        return this;
    }

    public void setExecutionTimeout(long executionTimeout) {
        this.executionTimeout = executionTimeout;
    }

    public void setMaxRetriesCount(int maxRetriesCount) {
        this.maxRetriesCount = maxRetriesCount;
    }

    public CallableBatch<R> withExecutionTimeout(long timeOut) {
        this.executionTimeout = timeOut;
        return this;
    }
    public CallableBatch<R> retryAttemptsCount(int maxRetriesCount) {
        this.maxRetriesCount = maxRetriesCount;
        return this;
    }

    public CallableBatch<R> withUnresponsiveTimeout(long timeOut, TimeUnit timeUnit) {
        this.unresponsiveTimeout = timeOut;
        this.unresponsiveUnit = timeUnit;
        return this;
    }

    public CallableBatch<R> noUnresponsiveCheck() {
        this.unresponsiveTimeout = 0;
        return this;
    }

    public Future<R> submit(Callable<R> jobCallable) {
        final Future<R> future = completionService.submit(jobCallable);
        tasks.add(future);
        return future;
    }

    public void awaitTermination() throws Exception {
        retrieveResults(null);
    }

    boolean checkNotResponsiveState(Future<R> task, List<Exception> exceptions) {
        if (task == null) {
            final long timeout = System.currentTimeMillis() - retrievalStart;
            if (unresponsiveTimeout > 0 && timeout > unresponsiveUnit.toMillis(unresponsiveTimeout)) {
                exceptions.add(new TimeoutException(String.format("Submitted batch is not responsive for: '%s'", DurationFormatUtils.formatDurationWords(timeout, true, true))));
                return true;
            }
        }
        return false;
    }

    public R retrieveAny(long timeout, TimeUnit timeUnit) throws Exception {
        R result = null;
        Future<R> task = null;
        if (retrievalStart == 0L) {
            retrievalStart = System.currentTimeMillis();
        }
        try {
            task = completionService.poll(timeout, timeUnit);
            if (task != null) {
                result = task.get();
                retrievalStart = System.currentTimeMillis();
            }
            final List<Exception> exceptions = new ArrayList<>();
            if (checkNotResponsiveState(task, exceptions)) {
                throw exceptions.get(0);
            }
        } catch (ExecutionException e) {
            throw (Exception)e.getCause();
        } finally {
            if (task != null) {
                tasks.remove(task);
            }
        }
        return result;
    }

    public R retrieveAny() throws Exception {
        return retrieveAny(executionTimeout, TimeUnit.MILLISECONDS);
    }

    @SuppressWarnings("squid:S3776")
    public List<R> retrieveResults(List<R> results) throws Exception {
        final List<Exception> exceptions = new ArrayList<>();
        int retriesCount = 0;
        retrievalStart = System.currentTimeMillis();
        while (tasks.size() > 0) {
            Future<R> task = null;
            try {
                task = completionService.poll(executionTimeout, TimeUnit.MILLISECONDS);
                if (task != null) {
                    R result = task.get();
                    if (results != null || task.isDone()) {
                        if (results != null) {
                            results.add(result);
                        }
                    }
                    retrievalStart = System.currentTimeMillis();
                }
                if (checkNotResponsiveState(task, exceptions)) {
                    break;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                checkRetryAttempts("Job execution interrupted", e, retriesCount++);
            } catch (Exception e) {
                exceptions.add((Exception) e.getCause());
            }
            if (task != null) {
                tasks.remove(task);
            }
        }
        if (tasks.size() > 0) {
            cancel();
        }
        if (exceptions.size() > 0) {
            handleExceptions(exceptions);
        }
        return results;
    }

    public void cancel() {
        for (final Future<R> task : tasks) {
            task.cancel(true);
        }
    }

    public boolean hasTasks() {
        return !tasks.isEmpty();
    }

    @SuppressWarnings({"ThrowableResultOfMethodCallIgnored"})
    protected void handleExceptions(List<Exception> exceptions) throws SupportException {
        String message = "Asynchronous batch failed";
        if (exceptions.size() > 1) {
            message = ", first exception cause included";
        }
        if (throwExceptions) {
            throw new SupportException(message, exceptions.get(0));
        } else {
            for (Exception exception : exceptions) {
                logger.error(exception);
            }
        }
    }

    protected void checkRetryAttempts(String message, Exception cause, int retriesCount) throws Exception {
        if (retriesCount >= maxRetriesCount) {
            throw new SupportException(String.format(RETRIES_COUNT_EXCEEDED_MSG, maxRetriesCount, message), cause);
        }
    }

    @Override
    public void onFinished(String message, Map<String, String> properties) {
        retrievalStart = System.currentTimeMillis();
    }

    @Override
    public void onProgress(String message, Map<String, String> properties) {
        retrievalStart = System.currentTimeMillis();
    }

    @Override
    public void onError(String message, Map<String, String> properties) {
        retrievalStart = System.currentTimeMillis();
        if (!throwExceptions) {
            logger.error(message);
        }
    }

    @Override
    public void onError(String message, Exception e, Map<String, String> properties) {
        onError(message, properties);
        if (!throwExceptions) {
            logger.error(message, e);
        }
    }

    public long getRetrievalStart() {
        return retrievalStart;
    }
}
