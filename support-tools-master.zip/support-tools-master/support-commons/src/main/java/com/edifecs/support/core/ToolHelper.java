package com.edifecs.support.core;

import org.apache.commons.cli.*;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ToolHelper {
    public static final String DEBUG = "debug";
    public static final String VERBOSE = "verbose";
    public static final String HELP = "help";

    private final String name;
    private final List<Option> toolOptions;
    private final List<String> usageHeaderMessages;
    private final List<String> customArgumentUsageMessages;
    private final CommandLine commandLine;

    public ToolHelper(String name,
                      CommandLine commandLine,
                      List<Option> toolOptions,
                      List<String> usageHeaderMessages,
                      List<String> customArgumentUsageMessages) {
        this.name = name;
        this.commandLine = commandLine;
        this.toolOptions = toolOptions;
        this.usageHeaderMessages = usageHeaderMessages;
        this.customArgumentUsageMessages = customArgumentUsageMessages;
    }

    public String getName() {
        return name;
    }

    public CommandLine getCommandLine() {
        return commandLine;
    }

    public void logHeader() {
        for (final String message : usageHeaderMessages) {
            System.out.println(message);//NOSONAR
        }
    }

    public boolean isValid() {
        return commandLine != null && (commandLine.getArgs().length == 0 || commandLine.getOptions().length == 0);
    }

    public boolean shouldShowUsage() {
        return !isValid() || hasArgument(HELP);
    }

    public boolean hasArgument(String argumentName) {
        return commandLine != null && commandLine.hasOption(argumentName);
    }

    public String getOptionValue(String argumentName) {
        return commandLine != null ? commandLine.getOptionValue(argumentName) : null;
    }

    public List<String> getArguments() {
        return commandLine != null ? Arrays.asList(commandLine.getArgs()) : null;
    }

    public List<Option> getOptions() {
        return commandLine != null ? Arrays.asList(commandLine.getOptions()) : null;
    }

    public void logUsage() {
        if (!isValid()) {
            final List<String> unknownArgs = getUnknownArguments();
            if (!unknownArgs.isEmpty()) {
                System.out.println(String.format("Unknown arguments provided: %s %s", name, unknownArgs));//NOSONAR
            }
        }
        if (customArgumentUsageMessages.isEmpty()) {
            System.out.println(String.format("Usage: %s %s", name, getArgumentAsOptionList()));//NOSONAR
        }
        for (final String customArgumentUsageMessage : customArgumentUsageMessages) {
            System.out.println(customArgumentUsageMessage);//NOSONAR
        }
        int maxLength = 0;
        for (final Option toolOption : toolOptions) {
            final String optionKey = toolOption.getOpt();
            if (optionKey.length() > maxLength) {
                maxLength = optionKey.length();
            }
        }
        maxLength += 4;
        for (final Option toolOption : toolOptions) {
            final String optionKey = StringUtils.rightPad(toolOption.getOpt(), maxLength);
            final String optionDescription = toolOption.getDescription();
            System.out.println(String.format("   -%s%s", optionKey, optionDescription));//NOSONAR
        }
    }

    public List<String> getUnknownArguments() {
        return commandLine != null ? Arrays.asList(commandLine.getArgs()) : new ArrayList<>();
    }

    String getArgumentAsOptionList() {
        final List<String> arguments = new ArrayList<>(toolOptions.size() + customArgumentUsageMessages.size());
        arguments.addAll(customArgumentUsageMessages);
        for (final Option toolOption : toolOptions) {
            final String optionKey = "-" + toolOption.getOpt();
            if (toolOption.isRequired()) {
                arguments.add(optionKey);
            } else {
                arguments.add("[" + optionKey + "]");
            }
        }
        return StringUtils.join(arguments, " ");
    }

    public static String getVersion() {
        String version = null;
        ManifestBean manifestBean = ManifestBean.findManifestInClasspath("Extension-Name", "support-commons");
        String buildNumber = null;
        if (manifestBean != null) {
            version = manifestBean.getManifestProperty("Implementation-Version");
            buildNumber = manifestBean.getManifestProperty("Implementation-Build-Number");
        }
        String result = version != null ? ("v." + version) : "v.1.0";
        if (buildNumber != null && !"0".equals(buildNumber)) {
            result = result + " (" + buildNumber + ")";
        }
        return result;
    }

    public static class Builder {
        protected final String toolName;
        protected final List<Option> toolOptions;

        protected boolean useDefaultOptions = true;
        protected final List<String> usageHeaderMessages;
        protected final List<String> customArgumentUsageMessages;

        protected String consoleLoggerName;
        protected String consoleLoggingPath;
        protected String fileLoggingPath;
        protected String logFileName;

        public Builder(String toolName) {
            this.toolName = toolName;
            toolOptions = new LinkedList<>();
            usageHeaderMessages = new LinkedList<>();
            customArgumentUsageMessages = new LinkedList<>();
        }

        public ToolHelper build(String[] args) {
            return build(args, false);
        }

        public ToolHelper build(String[] args, boolean stopUnknown) {
            CommandLine commandLine = null;
            try {
                commandLine = parseCommandLine(args, stopUnknown);
            } catch (ParseException ignore) { }
            final ToolHelper helper = createHelper(commandLine);
            configureLogger(helper);
            return helper;
        }

        protected ToolHelper createHelper(CommandLine commandLine) {
            return new ToolHelper(
                    toolName, commandLine, toolOptions,
                    usageHeaderMessages, customArgumentUsageMessages
            );
        }

        CommandLine parseCommandLine(String[] args, boolean stopUnknown) throws ParseException {
            final CommandLineParser parser = new DefaultParser();
            if (useDefaultOptions) {
                addDefaultOptions();
            }
            final Options options = new Options();
            for (final Option toolOption : toolOptions) {
                options.addOption(toolOption);
            }
            return parser.parse(options, args, stopUnknown);
        }

        public static Builder of(String toolName) {
            return new Builder(toolName);
        }

        public Builder addOption(String option, String description, boolean hasOption) {
            toolOptions.add(new Option(option, hasOption, description));
            return this;
        }

        public Builder addOption(String option, String description, boolean hasOption, boolean argumentOptional) {
            final Option o = new Option(option, hasOption, description);
            o.setOptionalArg(argumentOptional);
            toolOptions.add(o);
            return this;
        }

        public Builder addOption(Option option) {
            toolOptions.add(option);
            return this;
        }

        Builder addDefaultOptions() {
            addVerboseOption();
            addDebugOption();
            addHelpOption();
            return this;
        }

        public Builder addHelpOption() {
            toolOptions.add(new Option(HELP, false, "print help message"));
            return this;
        }

        public Builder addDebugOption() {
            toolOptions.add(new Option(
                    DEBUG, false,
                    "create and log detailed information (including exception call stack) about tool's execution process")
            );
            return this;
        }

        public Builder addVerboseOption() {
            toolOptions.add(new Option(
                    VERBOSE, false,
                    "display detailed information about tool's execution steps on console screen")
            );
            return this;
        }

        Builder configureLogger(ToolHelper helper) {
            // todo: bellow lines are overriding log4j2.xml settings. Review when to use Log4jHelper
            return this;
        }

        public Builder usingConsoleLogger(String consoleLoggerName, String consoleLoggingPath) {
            this.consoleLoggerName = consoleLoggerName;
            this.consoleLoggingPath = consoleLoggingPath;
            return this;
        }

        public Builder usingFileLogger(String fileLoggingPath) {
            this.fileLoggingPath = fileLoggingPath;
            this.logFileName = String.format("%1$s_%2$tm-%2$td-%2$tY_%2$tH-%2$tM-%2$tS_%2$tL.log", toolName, new Date());
            return this;
        }

        public Builder usingFileLogger(String fileLoggingPath, String logFileName) {
            this.fileLoggingPath = fileLoggingPath;
            this.logFileName = logFileName;
            return this;
        }

        public Builder useDefaultOptions(boolean useDefaultOptions) {
            this.useDefaultOptions = useDefaultOptions;
            return this;
        }

        public Builder withHeader(List<String> usageHeaderMessages) {
            this.usageHeaderMessages.addAll(usageHeaderMessages);
            return this;
        }

        public Builder withUsage(List<String> customArgumentUsageMessages) {
            this.customArgumentUsageMessages.addAll(customArgumentUsageMessages);
            return this;
        }
    }
}
