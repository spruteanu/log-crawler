package com.edifecs.support.collect;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.DatePredicate;
import com.edifecs.support.core.Directories;
import com.edifecs.support.core.Patterns;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Pattern;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class InformationContext extends Context {
    static final String CURRENT_LOGS_WILDCARD = "log?[\\\\/]*\\.log*";
    private Set<String> logFilters = new LinkedHashSet<>(10);
    private String defaultLogFilter = CURRENT_LOGS_WILDCARD;

    public void setLogFilters(Set<String> logFilters) {
        this.logFilters = logFilters;
    }

    public InformationContext logFilters(Set<String> logFilters) {
        setLogFilters(logFilters);
        return this;
    }

    public Set<String> logFilters() {
        return logFilters;
    }

    public String getDefaultLogFilter() {
        return defaultLogFilter;
    }

    public void setDefaultLogFilter(String defaultLogFilter) {
        this.defaultLogFilter = defaultLogFilter;
    }

    public InformationContext defaultLogFilter(String logFilter) {
        setDefaultLogFilter(logFilter);
        return this;
    }

    public InformationContext logFilter(String logFilter) {
        for (String filter : logFilter.split(",")) {
            logFilters.add(filter.trim());
        }
        return this;
    }

    public InformationContext allLogsFilter() {
        defaultLogFilter = CURRENT_LOGS_WILDCARD;
        return this;
    }

    static String toLogFilterMessage(Collection<String> filters) {
        final List<String> pf = new ArrayList<>();
        final List<String> pdf = new ArrayList<>();
        final StringBuilder sb = new StringBuilder();
        for (final String filter : filters) {
            if (DatePredicate.isRange(filter)) {
                pdf.add(DatePredicate.of(filter).toString());
            } else {
                pf.add(filter);
            }
        }
        if (!pf.isEmpty()) {
            sb.append(" filtering by: ").append(String.join(",", pf));
        }
        if (!pdf.isEmpty()) {
            sb.append(" for range: ").append(String.join(",", pdf));
        }
        return sb.toString();
    }

    @SuppressWarnings("squid:S2629")
    static void logCollectionMessage(Path path, Collection<String> filters) {
        logger.warn("Collecting logs: '{}'{}", path,
                Optional.ofNullable(filters).map(InformationContext::toLogFilterMessage).orElse("")
        );
    }

    public void logs(Path path, Predicate<Path> pathPredicate) throws IOException {
        logCollectionMessage(path, logFilters);
        add(Directories.findAllFiles(path, 5, pathPredicate));
    }

    public void logs(String path, Predicate<Path> pathPredicate) throws IOException {
        logs(Paths.get(resolveVariable(path)), pathPredicate);
    }
    public void logs(Predicate<Path> pathPredicate) throws IOException {
        logs(Paths.get(resolveVariable(source)), pathPredicate);
    }

    public void logs(String path) throws IOException {
        logs(path, logPathPredicate(logFilters, defaultLogFilter));
    }

    @SuppressWarnings("squid:S3776")
    public PathFilters lookupPathFilters(String path, Collection<String> logFilters) {
        final Set<String> filters = new LinkedHashSet<>();
        if (logFilters != null) {
            final Pattern pattern = Patterns.of("\\/");
            for (String logFilter : logFilters) {
                final String[] split = pattern.split(logFilter);
                if (split != null && split.length > 0) {
                    if (split.length == 1) {
                        if (DatePredicate.isRange(logFilter) && logFilters.size() == 1) {
                            filters.add(defaultLogFilter);
                        }
                    } else {
                        final String lf = split[split.length - 1];
                        path = logFilter.substring(0, logFilter.length() - lf.length());
                        logFilter = lf;
                    }
                }
                filters.add(logFilter);
            }
        }
        if (filters.isEmpty()) {
            filters.add(defaultLogFilter);
        }
        return new PathFilters(path, filters);
    }

    public void logs() throws IOException {
        final PathFilters result = lookupPathFilters(source, logFilters);
        logs(result.path, logPathPredicate(result.filters, defaultLogFilter));
    }

    public static String checkAddDefaultFilter(String filter, String defaultLogFilter) {
        if (!filter.contains("log")) {
            filter += "[\\\\/]" + defaultLogFilter;
        }
        if (!filter.startsWith("*")) {
            filter = "*" + filter;
        }
        return filter;
    }

    public static Predicate<Path> logPathPredicate(Predicate<Path> predicate, String filter, String defaultLogFilter) {
        final Predicate<Path> pp = Directories.toPathWildcardPredicate(checkAddDefaultFilter(filter, defaultLogFilter));
        return predicate != null ? predicate.or(pp) : pp;
    }

    public static Predicate<Path> logPathPredicate(String filter) {
        return logPathPredicate(null, filter, CURRENT_LOGS_WILDCARD);
    }

    public static Predicate<Path> logPathPredicate(final Collection<String> filters, final String defaultLogFilter) {
        final Set<String> filterSet = new LinkedHashSet<>(filters);
        if (filterSet.isEmpty()) {
            filterSet.add(defaultLogFilter);
        }
        Predicate<Path> predicate = null;
        for (String filter : filterSet) {
            predicate = logPathPredicate(predicate, filter, defaultLogFilter);
        }
        return predicate;
    }

    public static Predicate<Path> logPathPredicate(final Collection<String> filters) {
        return logPathPredicate(filters, CURRENT_LOGS_WILDCARD);
    }

    public static InformationContext of() {
        final InformationContext context = new InformationContext();
        context.defaultContext();
        return context;
    }

    public static class PathFilters {
        private final String path;
        private final Set<String> filters;

        public PathFilters(String path, Set<String> filters) {
            this.path = path;
            this.filters = filters;
        }

        public String getPath() {
            return path;
        }

        public Set<String> getFilters() {
            return filters;
        }
    }
}
