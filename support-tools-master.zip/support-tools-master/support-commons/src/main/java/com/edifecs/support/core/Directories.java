package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"squid:S1192", "unused"})
public class Directories {
    private static final Pattern NORMALIZED_PATH_PATTERN = Patterns.of("\\\\");

    private String base;
    private Set<String> directories;//NOSONAR
    private Set<String> mandatory;

    public Directories(String base) {
        this(base, Collections.emptySet(), Collections.emptySet());
    }

    public Directories(String base, Set<String> directories) {
        this(base, directories, Collections.emptySet());
    }

    public Directories(String base, Set<String> directories, Set<String> mandatory) {
        this.base = base;
        this.directories = directories;
        this.mandatory = mandatory;
    }

    public void setMandatory(Set<String> mandatory) {
        this.mandatory = mandatory;
    }

    public Directories mandatory(Set<String> mandatory) {
        setMandatory(mandatory);
        return this;
    }

    public static long getAvailableSize(Path path) {
        try {
            return Files.getFileStore(path).getUsableSpace();
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to get available size for: %s", path), e);
        }
    }

    public static String toWildcardRegex(String entryMask) {
        // Examples: *.properties should match only root properties files
        // Examples: config/*.properties should match only 'config' folder properties files
        // Examples: **/*.yml should match ALL yml files
        return StringUtils.replaceEach(entryMask, new String[]{"?", "*"}, new String[]{".?", ".*"});
    }
    public static String toFileWildcardRegex(String entryMask) {
        if (!entryMask.contains("\\") && !entryMask.contains("/") && !entryMask.startsWith("*")) {
            entryMask = "*" + entryMask;
        }
        return toWildcardRegex(entryMask);
    }

    public static Pattern toWildcardPattern(String entryMask) {
        return Patterns.of(toWildcardRegex(entryMask), Pattern.CASE_INSENSITIVE);
    }
    public static Pattern toFileWildcardPattern(String entryMask) {
        return Patterns.of(toFileWildcardRegex(entryMask), Pattern.CASE_INSENSITIVE);
    }

    public static Predicate<Path> toPathWildcardPredicate(String wildcardPattern) {
        return new PathWildcardPredicate(wildcardPattern);
    }
    public static Predicate<Path> toFileWildcardPredicate(String wildcardPattern) {
        return new PathWildcardPredicate(toFileWildcardPattern(wildcardPattern));
    }

    public long getAvailableSize() {
        return getAvailableSize(Paths.get(base));
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public Set<String> getDirectories() {
        return directories;
    }

    public void setDirectories(Set<String> directories) {
        this.directories = directories;
    }

    Path getBasePath() {
        return base != null ? Paths.get(base) : Paths.get("").toAbsolutePath();
    }

    public boolean exists() {
        final Path basePath = getBasePath();
        boolean result = basePath.toFile().exists();
        if (directories != null) {
            for (final Iterator<String> iterator = directories.iterator(); result && iterator.hasNext(); ) {
                result = basePath.resolve(iterator.next()).toFile().exists();
            }
        }
        return result;
    }

    void addError(String directory, List<String> errors) {
        errors.add(String.format("Mandatory entry: '%s' doesn't exists", directory));
    }

    public List<String> validateMandatory() {
        final List<String> errors = new ArrayList<>();
        final Path basePath = getBasePath();
        if (!basePath.toFile().exists()) {
            addError(base, errors);
        } else if (mandatory != null) {
            for (final String directory : mandatory) {
                if (!basePath.resolve(directory).toFile().exists()) {
                    addError(directory, errors);
                }
            }
        }
        return errors;
    }

    void create(Path path) throws IOException {
        Files.createDirectories(path);
    }

    public void create() throws IOException {
        final Path basePath = getBasePath();
        create(basePath);
        for (final String directory : directories) {
            create(basePath.resolve(directory));
        }
    }

    public static void delete(String location, boolean logDeletion) throws IOException {
        delete(Paths.get(location), logDeletion);
    }
    public static void delete(String location) throws IOException {
        delete(Paths.get(location), false);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    public static void delete(final Stream<Path> stream, final Consumer<Path> deletionConsumer) {
        final Spliterator<Path> spliterator = stream.spliterator();
        while (spliterator.tryAdvance(deletionConsumer)) { /*nop*/ }
    }

    public static void delete(final Stream<Path> stream, boolean logDeletion) {
        delete(stream, new DeletionConsumer(logDeletion));
    }

    public static void safeDelete(final Stream<Path> stream, Consumer<IOException> exceptionConsumer) {
        delete(stream, new DeletionConsumer().withExceptionConsumer(exceptionConsumer));
    }

    public static boolean delete(Path path, boolean logDeletion) throws IOException {
        try (final Stream<Path> stream = Files.walk(path)) {
            delete(stream.sorted(Comparator.reverseOrder()), logDeletion);
            return true;
        }
    }
    public static boolean delete(Path path) throws IOException {
        return delete(path, false);
    }

    public static boolean delete(Path path, Predicate<Path> predicate, boolean logDeletion) throws IOException {
        try (final Stream<Path> stream = Files.walk(path).filter(predicate)) {
            delete(stream.sorted(Comparator.reverseOrder()), logDeletion);
            return true;
        }
    }
    public static boolean delete(Path path, Predicate<Path> predicate) throws IOException {
        return delete(path, predicate, false);
    }

    public static boolean safeDelete(Path path, String wildcard, Consumer<IOException> exceptionConsumer) throws IOException {
        try (final Stream<Path> stream = Files.walk(path).filter(toPathWildcardPredicate(wildcard))) {
            safeDelete(stream.sorted(Comparator.reverseOrder()), exceptionConsumer);
            return true;
        }
    }

    public static boolean delete(Path path, String wildcard, boolean logDeletion) throws IOException {
        return delete(path, toPathWildcardPredicate(wildcard), logDeletion);
    }
    public static boolean delete(Path path, String wildcard) throws IOException {
        return delete(path, toPathWildcardPredicate(wildcard), false);
    }

    public void delete() throws IOException {
        delete(Paths.get(base));
    }

    public void copy(InputStream inputStream, String relativePath) throws IOException {
        copy(inputStream, getBasePath().resolve(relativePath));
    }

    public void deleteRelative(String relativePath) throws IOException {
        Files.delete(getBasePath().resolve(relativePath));
    }

    public static void copy(Path source, Path target) throws IOException {
        Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
    }
    public static void copy(String source, String target) throws IOException {
        copy(Paths.get(source), Paths.get(target));
    }
    public static void copy(InputStream inputStream, Path target) throws IOException {
        Files.copy(inputStream, target, StandardCopyOption.REPLACE_EXISTING);
    }

    public static boolean forRegularFile(Path filePath, BasicFileAttributes fileAttr) {
        return fileAttr.isRegularFile();
    }

    public static boolean forDirectory(Path filePath, BasicFileAttributes fileAttr) {
        return fileAttr.isDirectory();
    }

    public static List<Path> findAllSubdirectory(Path path, final Predicate<Path> predicate) throws IOException {
        return forFilesDepth(path, 2, predicate, Function.identity());
    }

    public List<Path> findAllSubdirectory(final Predicate<Path> predicate) throws IOException {
        return findAllSubdirectory(getBasePath(), predicate);
    }

    public static List<Path> findAllFiles(final Path path, final String wildcardPattern) throws IOException {
        return forFilesDepth(path, Integer.MAX_VALUE, toPathWildcardPredicate(wildcardPattern), Function.identity());
    }

    public static List<Path> findAllFiles(final Path path, final Predicate<Path> predicate) throws IOException {
        return findAllFiles(path, Integer.MAX_VALUE, predicate);
    }
    public static List<Path> findAllFiles(final Path path, int depth, final Predicate<Path> predicate) throws IOException {
        return forFilesDepth(path, depth, predicate, Function.identity());
    }

    public List<Path> findAllFiles(final Predicate<Path> predicate) throws IOException {
        return findAllFiles(getBasePath(), predicate);
    }

    public <R> List<R> forAllDirectories(final Predicate<Path> predicate, final Function<Path, R> directoryFunction) throws IOException {
        return forAllDirectories(getBasePath(), predicate, directoryFunction);
    }

    public <R> List<R> forAllFiles(final Predicate<Path> predicate, final Function<Path, R> fileFunction) throws IOException {
        return forAllFiles(getBasePath(), predicate, fileFunction);
    }

    @SuppressWarnings("resource")
    public static Stream<Path> filesStream(final Path path, final Predicate<Path> predicate) throws IOException {
        return Files.find(path, Integer.MAX_VALUE, Directories::forRegularFile).filter(predicate);
    }
    public static void filesStream(final Path path, final Predicate<Path> predicate,
                                   final Consumer<Path> filesFunction) throws IOException {
        try (final Stream<Path> stream = Files.find(path, Integer.MAX_VALUE, Directories::forRegularFile)) {
            stream.filter(predicate).forEach(filesFunction);
        }
    }

    public static void filesStream(final Path path, final Consumer<Path> filesFunction) throws IOException {
        filesStream(path, Utils::acceptAll, filesFunction);
    }

    public static void filesStream(final Path path, final String wildcard, final Consumer<Path> filesFunction) throws IOException {
        filesStream(path, toPathWildcardPredicate(wildcard), filesFunction);
    }

    public static <R> List<R> forDirectoriesDepth(final Path path, int depth, final Predicate<Path> predicate,
                                                  final Function<Path, R> directoryFunction) throws IOException {
        try (final Stream<Path> stream = Files.find(path, depth, Directories::forDirectory)) {
            return stream.filter(predicate).map(directoryFunction).filter(Objects::nonNull).collect(Collectors.toList());
        }
    }

    public static <R> List<R> forAllDirectories(final Path path, final Predicate<Path> predicate,
                                                final Function<Path, R> directoryFunction) throws IOException {
        return forDirectoriesDepth(path, Integer.MAX_VALUE, predicate, directoryFunction);
    }

    public static <R> List<R> forFilesDepth(final Path path, int depth, final Predicate<Path> predicate,
                                            final Function<Path, R> directoryFunction) throws IOException {
        if (!Files.exists(path)) {
            return Collections.emptyList();
        }
        try (final Stream<Path> stream = Files.find(path, depth, Directories::forRegularFile)) {
            return stream.filter(predicate).map(directoryFunction).collect(Collectors.toList());
        }
    }

    public static <R> List<R> forAllFiles(final Path path, final Predicate<Path> predicate,
                                          final Function<Path, R> directoryFunction) throws IOException {
        return forFilesDepth(path, Integer.MAX_VALUE, predicate, directoryFunction);
    }

    public PathWatcher pathWatcher() {
        return pathWatcher(base);
    }

    public static PathWatcher pathWatcher(String location) {
        return new PathWatcher(Paths.get(location));
    }

    public static Directories of(String path, String... mandatoryChildren) {
        final Set<String> directories = mandatoryChildren != null ? new LinkedHashSet<>(Arrays.asList(mandatoryChildren)) : null;
        return new Directories(path, directories, directories);
    }

    public static Path currentDirectory() {
        return Paths.get(".").toAbsolutePath().normalize();
    }

    public static long count(Path path) throws IOException {
        try (final Stream<Path> stream = Files.list(path)) {
            return stream.count();
        }
    }

    @SuppressWarnings("UnusedReturnValue")
    public static class PathWatcher implements Runnable {
        static final int DEFAULT_SLEEP_TIME = 5;
        private final Logger logger = LogManager.getLogger(PathWatcher.class);

        private final Path path;
        private final Map<WatchEvent.Kind<?>, Consumer<File>> eventWatchers = new LinkedHashMap<>();

        private final AtomicBoolean perform = new AtomicBoolean(true);

        private int sleepTime = DEFAULT_SLEEP_TIME;
        private TimeUnit sleepUnit = TimeUnit.SECONDS;

        private WatchService watchService;

        public PathWatcher(Path path) {
            this.path = path;
        }

        synchronized void notifyWatchers() {
            notifyAll();
        }

        public int getSleepTime() {
            return sleepTime;
        }

        public void setSleepTime(int sleepTime) {
            this.sleepTime = sleepTime;
        }

        public TimeUnit getSleepUnit() {
            return sleepUnit;
        }

        public void setSleepUnit(TimeUnit sleepUnit) {
            this.sleepUnit = sleepUnit;
        }

        public PathWatcher withSleepTime(int sleepTime) {
            this.sleepTime = sleepTime;
            return this;
        }

        public PathWatcher withSleepTime(int sleepTime, TimeUnit sleepUnit) {
            this.sleepTime = sleepTime;
            this.sleepUnit = sleepUnit;
            return this;
        }

        public PathWatcher watchCreation(Consumer<File> watcher) {
            eventWatchers.put(StandardWatchEventKinds.ENTRY_CREATE, watcher);
            return this;
        }

        public PathWatcher watchCreation(Predicate<File> predicate, Consumer<File> watcher) {
            return watchCreation(new PredicateWatcher(predicate, watcher));
        }

        public PathWatcher watchDeletion(Consumer<File> watcher) {
            eventWatchers.put(StandardWatchEventKinds.ENTRY_DELETE, watcher);
            return this;
        }

        public PathWatcher watchDeletion(Predicate<File> predicate, Consumer<File> watcher) {
            return watchDeletion(new PredicateWatcher(predicate, watcher));
        }

        public PathWatcher watchModification(Consumer<File> watcher) {
            eventWatchers.put(StandardWatchEventKinds.ENTRY_MODIFY, watcher);
            return this;
        }

        public PathWatcher watchModification(Predicate<File> predicate, Consumer<File> watcher) {
            return watchModification(new PredicateWatcher(predicate, watcher));
        }

        public PathWatcher start(ExecutorService executorService) throws IOException {
            perform.set(true);
            watchService = FileSystems.getDefault().newWatchService();
            path.register(watchService, eventWatchers.keySet().toArray(new WatchEvent.Kind<?>[0]));
            executorService.submit(this);
            return this;
        }

        public void stop() {
            perform.set(false);
            notifyWatchers();
            try {
                watchService.close();
                watchService = null;
            } catch (IOException e) {
                logger.error("Failed to close watch service", e);
            }
        }

        public boolean isStarted() {
            return perform.get() && watchService != null;
        }

        public boolean isStopped() {
            return !perform.get() && watchService == null;
        }

        void handleEvent(WatchEvent<?> event) {
            final WatchEvent.Kind<?> eventType = event.kind();
            final File file = new File(path.toFile(), event.context().toString());
            logger.trace("Received file '{}' {} event.", file.getAbsolutePath(), eventType);

            final Consumer<File> watcher = eventWatchers.get(eventType);
            if (watcher != null) {
                watcher.accept(file);
            }
        }

        int decreaseSleepTime() {
            sleepTime = Math.max(sleepTime - DEFAULT_SLEEP_TIME, DEFAULT_SLEEP_TIME);
            return sleepTime;
        }

        int increaseSleepTime() {
            sleepTime = Math.min(sleepTime + DEFAULT_SLEEP_TIME, DEFAULT_SLEEP_TIME * 24);
            return sleepTime;
        }

        @Override
        public void run() {
            while (perform.get()) {
                final WatchKey key;
                try {
                    key = watchService.poll(sleepTime, sleepUnit);
                } catch (ClosedWatchServiceException e) {
                    logger.error("Path watcher have been closed for some reason.", e);
                    break;
                } catch (InterruptedException ignore) {
                    logger.info("Path watcher have been stopped.");
                    Thread.currentThread().interrupt();
                    break;
                }
                if (key != null) {
                    for (final WatchEvent<?> event : key.pollEvents()) {
                        handleEvent(event);
                    }
                    key.reset();
                    decreaseSleepTime();
                } else {
                    increaseSleepTime();
                }
            }
            perform.set(false);
        }
    }

    public static String normalizePath(String source) {
        return NORMALIZED_PATH_PATTERN.matcher(source).replaceAll("/");
    }

    public static class PredicateWatcher implements Consumer<File> {
        private final Predicate<File> predicate;
        private final Consumer<File> watcher;

        public PredicateWatcher(Predicate<File> predicate, Consumer<File> watcher) {
            this.predicate = predicate;
            this.watcher = watcher;
        }

        @Override
        public void accept(File file) {
            if (predicate.test(file)) {
                watcher.accept(file);
            }
        }
    }

    public static class PathWildcardPredicate implements Predicate<Path> {
        private final Pattern maskPattern;

        public PathWildcardPredicate(String wildcardPattern) {
            maskPattern = toWildcardPattern(wildcardPattern);
        }

        public PathWildcardPredicate(Pattern maskPattern) {
            this.maskPattern = maskPattern;
        }

        @Override
        public boolean test(Path p) {
            return maskPattern.matcher(p.toString()).matches();
        }
    }

    public static class DeletionConsumer implements Consumer<Path> {
        private Consumer<IOException> exceptionConsumer;
        private Logger logger;

        public DeletionConsumer() {
        }

        public DeletionConsumer(boolean bLog) {
            if (bLog) {
                logger = LogManager.getLogger(DeletionConsumer.class);
            }
        }

        public void setExceptionConsumer(Consumer<IOException> exceptionConsumer) {
            this.exceptionConsumer = exceptionConsumer;
        }

        public DeletionConsumer withExceptionConsumer(Consumer<IOException> exceptionConsumer) {
            setExceptionConsumer(exceptionConsumer);
            return this;
        }

        @Override
        public void accept(Path path) {
            try {
                if (logger != null) {
                    logger.warn("Deleting: '{}'", path);
                }
                Files.delete(path);
            } catch (IOException e) {
                if (logger != null) {
                    logger.error("Failed to delete: '{}'", path, e);
                }
                if (exceptionConsumer != null) {
                    exceptionConsumer.accept(e);
                } else {
                    throw new SupportRuntimeException(String.format("Failed to delete path: %s", path), e);
                }
            }
        }
    }
}
