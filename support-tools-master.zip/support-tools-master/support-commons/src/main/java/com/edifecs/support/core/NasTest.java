/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.core;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

@SuppressWarnings({"squid:S106", "squid:S2629"})
public class NasTest {
    static final Logger log = Logger.getLogger(NasTest.class.getName());
    private static final int BUFFER_SIZE = 1024 * 8;
    private static final AtomicInteger newFilesCount = new AtomicInteger();

    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Wrong args: " + Arrays.asList(args));
            System.out.println("Usage: tool [folder] [sourceFile] [repeats count] [number of threads]");
            System.out.println("Examples: java -jar tool-0.9.jar . source-file.txt 2000 50");
            System.exit(1);
            return;
        }
        execute(args);
    }

    public static void execute(File folder, File sourceFile, int nTimes, int nThreads) {
        if (nThreads == 1) {
            createNewFiles(folder, sourceFile, nTimes);
        } else {
            createNewFilesAsync(folder, sourceFile, nThreads, nTimes);
        }
    }

    public static void execute(String[] args) {
        File folder = new File(args[0]);
        File sourceFile = new File(args[1]);
        int nTimes = Integer.parseInt(args[2]);
        int nThreads = args.length == 4 ? Integer.parseInt(args[3]) : 1;
        execute(folder, sourceFile, nTimes, nThreads);
    }

    static void createNewFiles(File folder, File sourceFile, int nTimes) {
        while (newFilesCount.get() < nTimes) {
            try {
                createNewFile(folder, sourceFile);
            } catch (IOException e) {
                log.log(Level.SEVERE, "Failed to create file", e);
            }
        }
    }

    static void createNewFilesAsync(final File folder, final File sourceFile, int nThreads, int nTimes) {
        log.log(Level.INFO, "Creating asynchronous files");

        ExecutorService executorService = Executors.newFixedThreadPool(nThreads);
        ExecutorCompletionService<Void> ces = new ExecutorCompletionService<>(executorService);
        List<Future<Void>> jobs = new ArrayList<>(nTimes);

        for (int i = 0; i < nTimes; i++) {
            Future<Void> future = ces.submit(() -> {
                createNewFile(folder, sourceFile);
                return null;
            });
            try {
                future.get(5, TimeUnit.MICROSECONDS);
                jobs.add(future);
            } catch (TimeoutException | InterruptedException ignore) {
                jobs.add(future);
                Thread.currentThread().interrupt();
            } catch (ExecutionException e) {
                log.log(Level.SEVERE, "Failed to schedule asynchronous job", e);
            }
        }
        awaitTermination(jobs, ces);

        executorService.shutdown();
        executorService.shutdownNow();
        log.log(Level.INFO, "Finished creating asynchronous files");
    }

    static void awaitTermination(List<Future<Void>> jobs, ExecutorCompletionService<Void> ces) {
        log.log(Level.INFO, String.format("Awaiting '%d' asynchronous jobs", jobs.size()));

        final List<Exception> exceptions = new ArrayList<>(jobs.size());
        while (jobs.size() > 0) {
            Future<Void> task = null;
            try {
                task = ces.poll(5, TimeUnit.MILLISECONDS);
                if (task != null) {
                    task.get();
                }
            } catch (InterruptedException ignore) {
                /*noop*/
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                exceptions.add((Exception) e.getCause());
            }
            if (task != null) {
                jobs.remove(task);
            }
        }
        if (exceptions.size() > 0) {
            for (Exception e : exceptions) {
                log.log(Level.SEVERE, "Failed to create file asynchronously", e);
            }
        }
    }

    @SuppressWarnings("squid:S899")
    static void createNewFile(File folder, File sourceFile) throws IOException {
        long start = System.currentTimeMillis();
        int newId = newFilesCount.incrementAndGet();
        File newFile = new File(folder, String.format("newFile-%s-%s", newId, sourceFile.getName()));
        try {
            log.log(Level.INFO, String.format("Creating '%s' file", newFile.getName()));

            newFile.createNewFile();

            try (InputStream sis = new BufferedInputStream(new FileInputStream(sourceFile), BUFFER_SIZE);
                 FileOutputStream os = new FileOutputStream(newFile);) {
                copyStream(sis, os, new byte[BUFFER_SIZE]);
            }
        } finally {
            log.log(Level.INFO, String.format("Created '%s' file in '%s' ms", newFile.getName(), (System.currentTimeMillis() - start)));
        }
    }

    static void closeQuietly(InputStream sis) {
        if (sis != null) {
            try {
                sis.close();
            } catch (IOException ignore) { /*noop*/ }
        }
    }

    static void closeQuietly(OutputStream os) {
        if (os != null) {
            try {
                os.close();
            } catch (IOException ignore) { /*noop*/ }
        }
    }

    static long copyStream(InputStream input, OutputStream output, byte[] buffer) throws IOException {
        long count = 0;
        int n;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

}
