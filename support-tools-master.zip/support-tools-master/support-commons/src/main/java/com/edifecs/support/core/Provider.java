package com.edifecs.support.core;

import com.edifecs.support.SupportException;
import com.edifecs.support.SupportRuntimeException;
import org.apache.commons.lang.StringUtils;
import org.codehaus.groovy.runtime.DefaultGroovyMethods;
import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.type.filter.RegexPatternTypeFilter;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings("squid:S1192")
@Component
public class Provider {
    static final String PROFILES = "support.profiles";
    public static final String CLASSPATH_SCAN_INCLUDE = "support.provider.classpath.include";
    public static final String CLASSPATH_SCAN_EXCLUDE = "support.provider.classpath.exclude";
    private static final Pattern CLASS_PATTERN = Patterns.of("([a-zA-Z_$][a-zA-Z\\d_$]*\\.)*[a-zA-Z_$][a-zA-Z\\d_$]*");

    private ApplicationContext context;

    public <T> T autowire(T obj) {
        context.getAutowireCapableBeanFactory().autowireBean(obj);
        return obj;
    }

    public ApplicationContext getContext() {
        return context;
    }

    public <T> T get(Class<T> clazz, Object... args) {
        return args != null ? context.getBean(clazz, args) : context.getBean(clazz);
    }

    public <T> Collection<T> getAll(Class<T> clazz) {
        return context.getBeansOfType(clazz).values();
    }

    @SuppressWarnings("unchecked")
    <T> T newInstance(Class<?> aClass, Object... args) {
        try {
            final Object obj = args != null ? DefaultGroovyMethods.newInstance(aClass, args) : DefaultGroovyMethods.newInstance(aClass);
            return autowire((T) obj);// NOSONAR
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("No class found for: '%s'", aClass), e);
        }
    }

    @SuppressWarnings({"unchecked", "squid:S1452", "squid:S1166", "squid:S2221"})
    public <T> T get(String name, Object... args) {
        if (context.containsBean(name) || context.containsBeanDefinition(name)) {
            return args != null ? (T) context.getBean(name, args) : (T) context.getBean(name);
        } else {
            Class<?> aClass = null;
            try {
                aClass = Class.forName(name);
                return (T) get(aClass, args);
            } catch (NoSuchBeanDefinitionException e) {
                if (aClass != null) {
                    return newInstance(aClass);
                } else {
                    throw new SupportRuntimeException(String.format("No class found for: '%s'", name), e);
                }
            } catch (Exception e) {
                throw new SupportRuntimeException(String.format("No class found for: '%s'", name), e);
            }
        }
    }

    @SuppressWarnings({"squid:S1452", "squid:S1166", "squid:S2221"})
    public <T> T get(String name, Class<T> aClass) {
        try {
            return context.getBean(name, aClass);
        } catch (NoSuchBeanDefinitionException | BeanNotOfRequiredTypeException e) {
            return null;
        }
    }

    private static Provider instance;

    @Autowired
    public void setContext(ApplicationContext context) {
        this.context = context;
        synchronized (this) {
            instance = this;
        }
    }

    public static synchronized void register(Provider instance) {
        Provider.instance = instance;
    }

    public static Provider instance() {
        if (instance == null) {
            createInstance(null);
        }
        return instance;
    }

    public static void destroy() {
        if (instance != null) {
            if (instance.context instanceof ConfigurableApplicationContext) {
                ConfigurableApplicationContext ctx = (ConfigurableApplicationContext) instance.context;
                ctx.close();
            }
            instance = null;
        }
    }

    public static Provider instance(Properties properties) {
        if (instance == null) {
            createInstance(properties);
        }
        return instance;
    }

    public static void addEnvironmentProperties(Properties properties) {
        for (Map.Entry<Object, Object> entry : new LinkedHashMap<>(System.getProperties()).entrySet()) {
            final String key = entry.getKey().toString();
            if (key.startsWith("support.")) {
                properties.setProperty(key, entry.getValue().toString());
            }
        }
    }

    static void lookupProfiles(GenericApplicationContext genericApplicationContext, Properties properties) {
        final ConfigurableEnvironment environment = genericApplicationContext.getEnvironment();
        String profiles = properties.getProperty(PROFILES);
        if (profiles != null) {
            environment.setActiveProfiles(profiles.split(","));
        }
    }

    public static Provider createInstance(Properties properties) {
        if (properties == null) {
            properties = new Properties();
        }
        addEnvironmentProperties(properties);
        final GenericApplicationContext gac = new GenericApplicationContext();
        lookupProfiles(gac, properties);
        if (properties.size() > 0) {
            final PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
            ppc.setProperties(properties);
            ppc.setLocalOverride(true);
            ppc.setOrder(0);
            ppc.setIgnoreUnresolvablePlaceholders(true);
            gac.addBeanFactoryPostProcessor(ppc);
        }
        new AnnotatedBeanDefinitionReader(gac);
        final ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(gac);
        customizeClassPathScanner(scanner, properties);
        scanner.scan(SupportException.class.getPackage().getName());
        gac.refresh();
        if (instance == null) {
            throw new IllegalStateException("Provider instance is not created");
        }
        return instance;
    }

    public static Provider createInstance(Properties properties, String scanIncludeFilter, String scanExcludeFilter) {
        Properties providerProps = properties;
        if (scanIncludeFilter != null || scanExcludeFilter != null) {
            providerProps = new Properties();
            providerProps.putAll(properties);
            if (scanIncludeFilter != null) {
                providerProps.put(CLASSPATH_SCAN_INCLUDE, scanIncludeFilter);
            }
            if (scanExcludeFilter != null) {
                providerProps.put(CLASSPATH_SCAN_EXCLUDE, scanExcludeFilter);
            }
        }
        return createInstance(providerProps);
    }

    private static void customizeClassPathScanner(ClassPathBeanDefinitionScanner scanner, Properties properties) {
        Pattern includeFilter = createPatternFromString(properties.getProperty(CLASSPATH_SCAN_INCLUDE));
        Pattern excludeFilter = createPatternFromString(properties.getProperty(CLASSPATH_SCAN_EXCLUDE));
        if (includeFilter != null) {
            scanner.addIncludeFilter(new RegexPatternTypeFilter(includeFilter));
        }
        if (excludeFilter != null) {
            scanner.addExcludeFilter(new RegexPatternTypeFilter(excludeFilter));
        }
    }

    @SuppressWarnings({"squid:S1452", "squid:S1166", "squid:S2221"})
    private static Pattern createPatternFromString(String regex) {
        try {
            if (StringUtils.isNotBlank(regex)) {
                return Patterns.of(regex);
            }
        } catch (PatternSyntaxException pse) { /* ignore */ }
        return null;
    }

    public <T> List<T> getAll(List<String> types) {
        final List<T> result = new ArrayList<>();
        if (types != null) {
            for (final String type : types) {
                result.add(get(type));
            }
        }
        return result;
    }

    public String getProperty(String name) {
        return context != null ? context.getEnvironment().getProperty(name) : null;
    }

    public static boolean isProfileActive(ApplicationContext context, String profile) {
        return context != null && Arrays.stream(context.getEnvironment().getActiveProfiles()).anyMatch(profile::equalsIgnoreCase);
    }

    public boolean isProfileActive(String profile) {
        return isProfileActive(context, profile);
    }

    public static boolean isClassName(String className) {
        return CLASS_PATTERN.matcher(className).matches();
    }
}
