package com.edifecs.support.core;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class MacroSubstitutionContentResolver implements ContentResolver {
    private static final String MACRO_PREFIX = "${";

    private final StrSubstitutor substitutor;

    public MacroSubstitutionContentResolver(StrSubstitutor substitutor) {
        this.substitutor = substitutor;
    }

    public MacroSubstitutionContentResolver(Map<String, String> macroMap) {
        substitutor = new StrSubstitutor(filterEmptyValues(macroMap));
    }

    @Override
    public InputStream toStream(String relativePath) throws IOException {
        InputStream inputStream = FileResourceContentResolver.lookupStream(relativePath);
        if (inputStream == null) {
            return new ByteArrayInputStream(resolve(relativePath).getBytes());
        } else {
            return new ByteArrayInputStream(resolve(IOUtils.toString(inputStream, Charset.defaultCharset())).getBytes());
        }
    }

    @Override
    public String toString(String relativePath) throws IOException {
        final InputStream inputStream = FileResourceContentResolver.lookupStream(relativePath);
        if (inputStream != null) {
            try {
                return resolve(IOUtils.toString(inputStream, Charset.defaultCharset()));
            } finally {
                inputStream.close();
            }
        } else {
            return resolve(relativePath);
        }
    }

    public String resolve(String source) {
        return substitutor.replace(source);
    }

    public static MacroSubstitutionContentResolver of(Map<String, String> macroMap) {
        return new MacroSubstitutionContentResolver(macroMap);
    }

    public static MacroSubstitutionContentResolver of(Properties properties) {
        return new MacroSubstitutionContentResolver(Utils.fromProperties(properties));
    }

    public static MacroSubstitutionContentResolver ofMacros(Properties propertiesWithMacro) {
        final Map<String, String> macroMap = new LinkedHashMap<>();
        for (final String property : propertiesWithMacro.stringPropertyNames()) {
            final int idx = property.indexOf(MACRO_PREFIX);
            if (idx >= 0) {
                final int lIdx = property.lastIndexOf('}');
                if (lIdx > 0) {
                    macroMap.put(property.substring(idx + MACRO_PREFIX.length(), lIdx), propertiesWithMacro.getProperty(property));
                }
            }
        }
        return new MacroSubstitutionContentResolver(macroMap);
    }

    private static Map<String, String> filterEmptyValues(Map<String, String> input) {
        Map<String, String> output = new HashMap<>(input.size());
        for (Map.Entry<String, String> inputEntry : input.entrySet()) {
            if (StringUtils.isNotBlank(inputEntry.getValue())) {
                output.put(inputEntry.getKey(), inputEntry.getValue());
            }
        }
        return output;
    }
}
