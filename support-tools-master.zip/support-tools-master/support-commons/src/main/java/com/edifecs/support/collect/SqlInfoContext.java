package com.edifecs.support.collect;

import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class SqlInfoContext extends SqlContext {

    public static SqlInfoContext of() {
        return new SqlInfoContext();
    }

    public static SqlInfoContext of(String url) {
        final SqlInfoContext context = new SqlInfoContext();
        context.jdbcTemplate(newJdbcTemplate(url));
        return context;
    }

    public static SqlInfoContext of(Properties properties) {
        final SqlInfoContext context = new SqlInfoContext();
        context.jdbcTemplate(properties);
        return context;
    }

    public static SqlInfoContext of(DataSource dataSource) {
        final SqlInfoContext context = new SqlInfoContext();
        context.jdbcTemplate(new JdbcTemplate(dataSource));
        return context;
    }

    public static SqlInfoContext of(JdbcTemplate jdbcTemplate) {
        final SqlInfoContext context = new SqlInfoContext();
        context.jdbcTemplate(jdbcTemplate);
        return context;
    }

    public static SqlInfoContext ofProperties(String propertyFile) throws IOException {
        final SqlInfoContext context = new SqlInfoContext();
        context.dbProperties(propertyFile);
        return context;
    }
}
