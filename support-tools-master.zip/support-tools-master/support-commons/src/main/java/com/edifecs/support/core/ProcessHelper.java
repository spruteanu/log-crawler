package com.edifecs.support.core;

import com.edifecs.support.Storage;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings("squid:S1166")
public class ProcessHelper {
    private String workingDir;
    private String command;
    private LinkedList<String> args = new LinkedList<>();
    private final LinkedHashSet<String> sensibleArgs = new LinkedHashSet<>();
    private File directory;

    private boolean tokenized = true;
    private boolean wsl = false;
    private boolean bash = false;

    private int refreshDelay = 1000;
    private TimeUnit refreshTimeUnit = TimeUnit.MILLISECONDS;

    private Logger logger;
    private List<OutputObserver> observers;
    private Map<String, String> environment;

    public ProcessHelper() {
        logger = LogManager.getLogger(ProcessHelper.class);
    }

    public ProcessHelper(String command, String... args) {
        this();
        this.command = command;
        this.args.addFirst(command);
        this.args.addAll(Arrays.stream(args).filter(s -> Objects.nonNull(s) && StringUtils.isNotEmpty(s)).collect(Collectors.toList()));
    }

    public ProcessHelper(String workingDir, String command, String... args) {
        this(command, args);
        this.workingDir = workingDir;
    }

    public List<String> getFullCommand() {
        return args;
    }

    public void setArgs(List<String> args) {
        this.args = new LinkedList<>(args);
    }

    public int getRefreshDelay() {
        return refreshDelay;
    }

    public void setRefreshDelay(int refreshDelay) {
        this.refreshDelay = refreshDelay;
    }

    public TimeUnit getRefreshTimeUnit() {
        return refreshTimeUnit;
    }

    public void setRefreshTimeUnit(TimeUnit refreshTimeUnit) {
        this.refreshTimeUnit = refreshTimeUnit;
    }

    public ProcessHelper withRefreshDelay(int refreshDelay, TimeUnit refreshTimeUnit) {
        this.refreshDelay = refreshDelay;
        this.refreshTimeUnit = refreshTimeUnit;
        return this;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public ProcessHelper withLogger(Logger logger) {
        setLogger(logger);
        return this;
    }

    public void setObserver(OutputObserver observer) {
        if (Objects.isNull(observers)) {
            observers = new ArrayList<>();
        }
        observers.add(observer);
    }

    public void setObservers(List<OutputObserver> observers) {
        this.observers = observers;
    }

    public ProcessHelper withObserver(OutputObserver observer) {
        if (Objects.isNull(observers)) {
            observers = new ArrayList<>();
        }
        observers.add(observer);
        return this;
    }

    public ProcessHelper withLoggingObserver() {
        setObserver(new LoggingObserver());
        return this;
    }

    public ProcessHelper withArguments(String... arguments) {
        if (Objects.nonNull(arguments) && arguments.length > 0) {
            args.addAll(Arrays.stream(arguments).filter(StringUtils::isNotBlank).collect(Collectors.toList()));
        }
        return this;
    }
    public ProcessHelper withSensibleArguments(String... arguments) {
        withArguments(arguments);
        if (Objects.nonNull(arguments) && arguments.length > 0) {
            sensibleArgs.addAll(Arrays.asList(arguments));
        }
        return this;
    }

    public File getDirectory() {
        return directory;
    }

    public void setDirectory(File directory) {
        this.directory = directory;
    }

    public ProcessHelper withDirectory(File directory) {
        setDirectory(directory);
        return this;
    }

    public void setTokenized(boolean tokenized) {
        this.tokenized = tokenized;
    }

    public ProcessHelper single() {
        setTokenized(false);
        return this;
    }

    public boolean isWsl() {
        return wsl;
    }

    public boolean isBash() {
        return bash;
    }

    public void setWsl(boolean wsl) {
        this.wsl = wsl;
    }

    public ProcessHelper withWsl() {
        setWsl(true);
        return this;
    }

    public void setBash(boolean bash) {
        this.bash = bash;
    }

    public ProcessHelper withBash() {
        setBash(true);
        return this;
    }

    public ProcessHelper withEnvironment(Map<String, String> env) {
        if (env == null || env.isEmpty()) {
            return this;
        }
        if (this.environment == null) {
            this.environment = new LinkedHashMap<>();
        }
        this.environment.putAll(env);
        return this;
    }

    public Map<String, String> getEnvironment() {
        return environment == null ? null : new LinkedHashMap<>(environment);
    }

    void logDebugMessage(String line) {
        logger.trace(line);
        if (observers != null) {
            observers.stream().filter(Objects::nonNull).forEach(observer -> observer.onDebug(line));
        }
    }

    void logProgressMessage(String line) {
        logger.trace(line);
        if (observers != null) {
            observers.stream().filter(Objects::nonNull).forEach(observer -> observer.onProgress(line));
        }
    }

    void logFinishedMessage(String line) {
        logger.trace(line);
        if (observers != null) {
            observers.stream().filter(Objects::nonNull).forEach(observer -> observer.onFinished(line));
        }
    }

    void logErrorMessage(String line, Exception e) {
        logger.error(line);
        logger.debug(line, e);
        if (observers != null) {
            observers.stream().filter(Objects::nonNull).forEach(observer -> observer.onError(line));
        }
    }

    String getProcessMessage() {
        if (args != null) {
            List<String> pArgs = this.args;
            if (!sensibleArgs.isEmpty()) {
                pArgs = new LinkedList<>();
                for (final String arg : args) {
                    if (sensibleArgs.contains(arg)) {
                        pArgs.add("********");
                    } else {
                        pArgs.add(arg);
                    }
                }
            }
            return StringUtils.join(pArgs, " ");
        }
        return "";
    }

    String toFullCommandLine() {
        if (tokenized) {
            return getProcessMessage();
        }
        return command;
    }

    void readConsoleBuffer(BufferedReader reader) {
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                logProgressMessage(line);
            }
        } catch (IOException e) {
            logErrorMessage(String.format("Failed to read process: '%s' console message; exception message: %s",
                    toFullCommandLine(), e.getMessage()), e);
        }
    }

    public int execute() throws IOException {
        return submit().waitFor().getRc();
    }

    @SuppressWarnings("squid:S3776")
    public Execution submit() throws IOException {
        logDebugMessage(String.format("Executing '%s' process.", getProcessMessage()));
        final Process process;
        if (tokenized) {
            if (wsl && isWindows()) {
                args.addFirst("wsl");
            } else if (bash) {
                if (isWindows()) {
                    args.addFirst("\"");
                    args.addLast("\"");
                    args.addFirst("-c");
                    args.addFirst("bash");
                } else {
                    args.addFirst("-c");
                    args.addFirst("/bin/bash");
                }
            }
            if (isWindows() && !"cmd".equalsIgnoreCase(command)) {
                if (workingDir != null) {
                    args.addFirst("&&");
                    args.addFirst(workingDir);
                    args.addFirst("/d");
                    args.addFirst("cd");
                }
                args.addFirst("/c");
                args.addFirst("cmd");
            }
            final File d = directory != null ? directory : Storage.toolPath().toFile();

            ProcessBuilder pb = new ProcessBuilder(args).directory(d).redirectErrorStream(true);
            if (this.environment != null && !this.environment.isEmpty()) {
                Map<String, String> pbEnv = pb.environment();
                for (Map.Entry<String, String> e : this.environment.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        pbEnv.put(e.getKey(), e.getValue());
                    }
                }
            }
            process = pb.start();
        } else {
            process = Runtime.getRuntime().exec(command);
        }
        return new Execution(process);
    }

    public Result executeAndGetResult(OutputObserver consoleOutputObserver) throws IOException {
        return submit().waitFor(consoleOutputObserver);
    }

    public Result executeAndGetResult() throws IOException {
        ConsoleOutputObserver consoleOutputObserver = new ConsoleOutputObserver();
        return executeAndGetResult(consoleOutputObserver);
    }

    @Override
    public String toString() {
        return toFullCommandLine();
    }

    public static ProcessHelper of(String command, String... args) {
        return new ProcessHelper(command, args);
    }

    public static boolean isWindows() {
        final String osName = System.getProperty("os.name");
        return osName != null && osName.toLowerCase().contains("win");
    }

    public static boolean isLinux() {
        return SystemUtils.IS_OS_LINUX;
    }

    public static Stream<ProcessHandle> processesStream() {
        return ProcessHandle.allProcesses();
    }
    public static List<ProcessHandle> find(final Predicate<ProcessHandle> predicate) {
        return processesStream().filter(predicate).collect(Collectors.toList());
    }
    public static List<ProcessHandle> findBy(final Predicate<ProcessHandle.Info> predicate) {
        return processesStream().filter(ph -> predicate.test(ph.info())).collect(Collectors.toList());
    }
    public static ProcessHandle findBy(final long pid) {
        return processesStream().filter(ph -> pid == ph.pid()).findAny().orElse(null);
    }
    public static Stream<ProcessHandle> processesStream(final String processName) {
        return processesStream().filter(ph -> {
            final ProcessHandle.Info info = ph.info();
            Optional<String> opt = info.command();
            boolean result = false;
            if (opt.isPresent()) {
                result = opt.get().toLowerCase().contains(processName);
            }
            return result;
        });
    }
    public static List<ProcessHandle> findBy(final String processName) {
        return processesStream(processName).collect(Collectors.toList());
    }
    public static List<Long> findPids(final String processName) {
        return processesStream(processName).map(ProcessHandle::pid).collect(Collectors.toList());
    }
    public static List<ProcessHandle> findJava() {
        return processesStream("java").collect(Collectors.toList());
    }
    public static List<Long> findJavaPids() {
        return findPids("java");
    }

    public static class Result {
        private final int rc;
        private final String output;

        Result(int rc, String output) {
            this.rc = rc;
            this.output = output;
        }

        public int getRc() {
            return rc;
        }

        public String getOutput() {
            return output;
        }
    }

    public class Execution {
        private final Process process;
        private Result result;

        public Execution(Process process) {
            this.process = process;
        }

        public Process getProcess() {
            return process;
        }

        public Result getResult() {
            return result;
        }

        public Result waitFor() throws IOException {
            return waitFor(null);
        }

        @SuppressWarnings({"squid:S135", "squid:S1943"})
        public Result waitFor(OutputObserver observer) throws IOException {
            NullSafeOutputObserver nullSafeOutputObserver = new NullSafeOutputObserver(observer);
            withObserver(nullSafeOutputObserver);
            int exitCode = -1;
            try (final BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                while (true) {
                    try {
                        if (process.waitFor(refreshDelay, refreshTimeUnit)) {
                            exitCode = process.exitValue();
                            break;
                        }
                        readConsoleBuffer(reader);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        logDebugMessage(String.format("Process: '%s' interrupted; exception message: '%s'. Stopping the process.", toFullCommandLine(), e.getMessage()));
                        break;
                    }
                }
                try {
                    readConsoleBuffer(reader);
                    if (process.isAlive()) {
                        process.destroy();
                        exitCode = process.exitValue();
                    }
                    logFinishedMessage(String.format("Finished '%s' process; exit code: '%s'", getProcessMessage(), exitCode));
                } catch (Exception ignore) { /*noop*/ }
            }
            result = new Result(exitCode, nullSafeOutputObserver.getOutput());
            return result;
        }

        public void abort() {
            process.destroy();
        }

        public boolean isTerminated() {
            return process != null && !process.isAlive();
        }

        public boolean isAlive() {
            return process != null && process.isAlive();
        }
    }
}
