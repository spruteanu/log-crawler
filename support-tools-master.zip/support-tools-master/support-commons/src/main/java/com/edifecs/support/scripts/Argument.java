/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.scripts;

import java.lang.annotation.*;

/**
 * Annotation used for script arguments documentation.
 *
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(Arguments.class)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface Argument {
    String name();
    String description() default "";
    boolean required() default true;
}
