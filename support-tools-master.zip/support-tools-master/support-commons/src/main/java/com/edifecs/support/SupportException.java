package com.edifecs.support;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class SupportException extends Exception {
    protected boolean recoverable;

    public SupportException() {
        super();
    }

    public SupportException(String message) {
        super(message);
    }

    public SupportException(String message, Exception cause) {
        super(message, cause);
    }

    public SupportException(Exception cause) {
        super(cause);
    }

    public boolean isRecoverable() {
        return recoverable;
    }

    public void setRecoverable(boolean recoverable) {
        this.recoverable = recoverable;
    }
}
