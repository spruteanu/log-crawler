package com.edifecs.support.core;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public interface ExecutorCloseable {
    void close();
    void closeNow();
}
