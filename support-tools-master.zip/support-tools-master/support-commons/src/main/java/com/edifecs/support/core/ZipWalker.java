package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.NumberFormat;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ZipWalker implements Closeable {
    private static final Pattern WIN_PATH_REPLACE_PATTERN = Patterns.of("\\\\");
    public static final String NO_ENTRY_FOUND_ERROR = "No entry found: '%s'";
    public static final String DELIMITER = "!/";

    private final ZipFile zipFile;
    private final Pattern pattern;

    public ZipWalker(ZipFile zipFile, Pattern pattern) {
        this.zipFile = zipFile;
        this.pattern = pattern;
    }

    public void handleEntry(String entryName, ZipEntryVisitor visitor) {
        final ZipEntry entry = zipFile.getEntry(entryName);
        if (entry != null) {
            visitor.visit(new ZipWalkerEntry(zipFile, entry));
        }
    }

    public String getName() {
        return zipFile.getName();
    }

    ZipWalkerEntry lookupZipWalkerEntry(ZipFile zipFile, String entryName) {
        final ZipEntry entry = zipFile.getEntry(entryName);
        if (entry != null) {
            if (zipFile == this.zipFile) {
                return new ZipWalkerEntry(zipFile, entry);
            } else {
                return new InnerZipWalkerEntry(zipFile, entry);
            }
        } else {
            throw new IllegalArgumentException(String.format(NO_ENTRY_FOUND_ERROR, entryName));
        }
    }

    public ZipWalkerEntry getZipWalkerEntry(String entryName) throws IOException {
        final String[] split = entryName.split(DELIMITER);
        return lookupZipWalkerEntry(lookupZipFile(split), split[split.length - 1]);
    }

    File extractInnerZip(ZipFile zipFile, String zipEntryName) throws IOException {
        final File innerFile = new File(zipFile.getName());
        final Path innerZipPath = new File(innerFile.getParent(), (innerFile.getName()).replaceAll("[\\.]", "-") + "/" + zipEntryName).toPath().normalize();
        final File innerZipFile = innerZipPath.toFile();

        final File parentFile = innerZipFile.getParentFile();
        if (parentFile.exists() || parentFile.mkdirs()) {
            try (final InputStream zipEntryIs = zipFile.getInputStream(new ZipEntry(zipEntryName))) {
                if (zipEntryIs == null) {
                    throw new SupportRuntimeException(String.format("Could not get input stream of %s from zip file %s  ", zipEntryName, zipFile.getName()));
                }
                Files.copy(zipEntryIs, innerZipPath, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        return innerZipFile;
    }

    ZipFile lookupZipFile(String[] split) throws IOException {
        final int lastIndex = split.length - 1;
        ZipFile zf = zipFile;
        for (int i = 0; i < lastIndex; i++) {
            final File file = extractInnerZip(zf, split[i]);
            if (zf != zipFile) {
                zf.close();
            }
            zf = new ZipFile(file);
        }
        return zf;
    }

    public byte[] toBytes(String entryName) throws IOException {
        final String[] split = entryName.split(DELIMITER);
        entryName = split[split.length - 1];
        final ZipFile zf = lookupZipFile(split);
        try (final ZipWalkerEntry zipWalkerEntry = lookupZipWalkerEntry(zf, entryName)) {
            return zipWalkerEntry.readFully();
        } finally {
            if (zf != zipFile) {
                zf.close();
            }
        }
    }

    public String text(String entryName) throws IOException {
        return new String(toBytes(entryName));
    }

    public void walk(ZipEntryVisitor visitor) {
        final Enumeration<? extends ZipEntry> entries = zipFile.entries();
        while (entries.hasMoreElements()) {
            final ZipEntry zipEntry = entries.nextElement();
            final String zipEntryName = WIN_PATH_REPLACE_PATTERN.matcher(zipEntry.getName()).replaceAll("/");
            if (pattern == null) {
                visitor.visit(new ZipWalkerEntry(zipFile, zipEntry));
            } else {
                String strPattern = pattern.pattern();
                if (strPattern.contains(DELIMITER)) {
                    walkInnerZip(visitor, strPattern, zipEntryName);
                } else if (pattern.matcher(zipEntryName).matches()) {
                    visitor.visit(new ZipWalkerEntry(zipFile, zipEntry));
                }
            }
        }
    }

    public ExtractSummary extract(final String location) throws SupportRuntimeException {
        final ExtractSummary summary = new ExtractSummary();
        walk(new ZipEntryVisitorExtractor(location, summary));
        return summary;
    }

    public ExtractSummary extract(final String location, final Map<String, String> replacementMap) throws SupportRuntimeException {
        final ExtractSummary summary = new ExtractSummary();
        walk(new ZipEntryVisitorExtractor(new File(location), summary, replacementMap));
        return summary;
    }

    public ExtractSummary extract(final File file) throws SupportRuntimeException {
        final ExtractSummary summary = new ExtractSummary();
        walk(new ZipEntryVisitorExtractor(file, summary));
        return summary;
    }

    public ExtractSummary extract(final File file, final Map<String, String> replacementMap) throws SupportRuntimeException {
        final ExtractSummary summary = new ExtractSummary();
        walk(new ZipEntryVisitorExtractor(file, summary, replacementMap));
        return summary;
    }

    public ExtractSummary extract(final Path path) throws SupportRuntimeException {
        return extract(path.toFile());
    }

    static String resolveRelativePath(String absolutePath) {
        absolutePath = WIN_PATH_REPLACE_PATTERN.matcher(absolutePath).replaceAll("/");
        String[] resolveZipPaths = absolutePath.split(DELIMITER, 2);
        return resolveZipPaths[resolveZipPaths.length - 1];
    }
    public static String relativePath(String absolutePath, String relativePath) {
        return absolutePath + DELIMITER + relativePath;
    }

    static String resolveBaseZip(String absolutePath) {
        absolutePath = WIN_PATH_REPLACE_PATTERN.matcher(absolutePath).replaceAll("/");
        return absolutePath.split(DELIMITER)[0];
    }

    public static String resolveName(String entryName) {
        if (entryName == null) {
            return null;
        }
        int idx = entryName.lastIndexOf('/');
        if (idx != -1) {
            return entryName.substring(idx + 1);
        }
        idx = entryName.lastIndexOf('\\');
        if (idx != -1) {
            return entryName.substring(idx + 1);
        }
        return entryName;
    }

    @NotNull
    public static String zipEntryPath(Path jarFile, String entryName) {
        return String.format("%s%s%s", jarFile.toString(), DELIMITER, entryName);
    }

    @Override
    public void close() throws IOException {
        zipFile.close();
    }

    public boolean contains(String name) {
        final ZipEntry entry = zipFile.getEntry(name);
        return entry != null;
    }

    static void collectManifestProperties(Map<String, String> manifestProperties, Reader reader) throws IOException {
        for (final String line : IOUtils.readLines(reader)) {
            if (StringUtils.isNotEmpty(line.trim())) {
                final String[] split = StringUtils.split(line, ":", 2);
                if (split != null && split.length > 0) {
                    manifestProperties.put(split[0].trim(), split.length > 1 ? split[1].trim() : null);
                }
            }
        }
    }

    void walkInnerZip(ZipEntryVisitor visitor, String strPattern, String zipEntryName) {
        String outerPath = StringUtils.substringBefore(strPattern, DELIMITER);
        if (Patterns.of(outerPath).matcher(zipEntryName).matches()) {
            String innerPath = StringUtils.substringAfter(strPattern, DELIMITER);
            try (ZipFile innerZipFile = lookupZipFile(new String[]{zipEntryName, innerPath});
                 ZipWalker innerZipWalker = ZipWalker.of(innerZipFile, innerPath)) {
                innerZipWalker.walk(visitor);
            } catch (IOException ioe) {
                throw new SupportRuntimeException("Cannot process inner zip " + innerPath, ioe);
            }
        }
    }

    public Map<String, String> lookupManifestProperties() throws SupportRuntimeException {
        final Map<String, String> manifestProperties = new LinkedHashMap<>();
        try {
            final ZipWalkerEntry zwe = getZipWalkerEntry("META-INF/MANIFEST.MF");
            if (zwe != null) {
                try (final Reader reader = new InputStreamReader(zwe.getInputStream())) {
                    collectManifestProperties(manifestProperties, reader);
                }
            }
        } catch (IOException e) {
            throw new SupportRuntimeException("Failed to extract manifest file", e);
        }
        return manifestProperties;
    }

    public List<String> listAll() throws SupportRuntimeException {
        final List<String> entryNames = new ArrayList<>(512);
        for (final Enumeration<? extends ZipEntry> entries = zipFile.entries(); entries.hasMoreElements(); ) {
            entryNames.add(entries.nextElement().getName());
        }
        return entryNames;
    }

    public static class ZipWalkerEntry implements Closeable {
        protected final ZipFile zipFile;
        protected final ZipEntry zipEntry;

        private ZipWalkerEntry(ZipFile zipFile, ZipEntry zipEntry) {
            this.zipFile = zipFile;
            this.zipEntry = zipEntry;
        }

        public ZipFile getZipFile() {
            return zipFile;
        }

        public ZipEntry getZipEntry() {
            return zipEntry;
        }

        public InputStream getInputStream() throws IOException {
            return zipFile.getInputStream(zipEntry);
        }

        public byte[] readFully() throws IOException {
            try (final InputStream inputStream = getInputStream()) {
                return IOUtils.readFully(inputStream, (int) zipEntry.getSize());
            }
        }

        public ExtractSummary extract(String location) throws SupportRuntimeException {
            return extract(new File(location, zipEntry.getName()), new ExtractSummary());
        }

        public ExtractSummary extract(File file, ExtractSummary summary) throws SupportRuntimeException {
            final Path filePath = file.toPath();
            if (zipEntry.isDirectory()) {
                try {
                    Files.createDirectories(filePath);
                } catch (IOException e) {
                    throw new SupportRuntimeException(String.format("Failed to create directories: '%s'", filePath), e);
                }
                return summary;
            }
            if (!file.exists()) {
                try {
                    final Path ppath = filePath.getParent();
                    if (!ppath.toFile().exists()) {
                        Files.createDirectories(ppath);
                    }
                } catch (IOException e) {
                    throw new SupportRuntimeException(String.format("Failed to create file: '%s'.", filePath), e);
                }
            }
            try (final InputStream is = getInputStream()) {
                Files.copy(is, filePath, StandardCopyOption.REPLACE_EXISTING);
                summary.report(zipEntry);
            } catch (IOException e) {
                throw new SupportRuntimeException(String.format("Failed to extract: '%s' to: '%s'", zipEntry.getName(), file), e);
            }
            try {
                Files.setLastModifiedTime(filePath, zipEntry.getLastModifiedTime());
                Files.setAttribute(filePath, "creationTime", zipEntry.getCreationTime());
            } catch (IOException e) {
                throw new SupportRuntimeException(String.format("Failed to set file: '%s' time attributes", filePath), e);
            }
            return summary;
        }

        @Override
        public void close() throws IOException {
            // nothing to do
        }
    }

    public static class InnerZipWalkerEntry extends ZipWalkerEntry {
        public InnerZipWalkerEntry(ZipFile zipFile, ZipEntry zipEntry) {
            super(zipFile, zipEntry);
        }

        @Override
        public void close() throws IOException {
            zipFile.close();
        }
    }

    /**
     * @author Serge Pruteanu (sergep@edifecs.com)
     */
    public interface ZipEntryVisitor {
        void visit(ZipWalkerEntry entry);
    }

    public static ZipWalker of(String fileName, String entryMask) throws IOException {
        return of(fileName, Directories.toWildcardPattern(entryMask));
    }

    public static ZipWalker of(String fileName, Pattern entryMaskPattern) throws IOException {
        return new ZipWalker(new ZipFile(fileName), entryMaskPattern);
    }

    public static ZipWalker of(String fileName) throws IOException {
        final File file = new File(fileName);
        if (!file.exists()) {
            throw new IllegalArgumentException(String.format("Can't create walker as provided file: '%s' doesn't exists", fileName));
        }
        return new ZipWalker(new ZipFile(file), null);
    }

    public static ZipWalker of(File file) throws IOException {
        return new ZipWalker(new ZipFile(file), null);
    }

    public static ZipWalker of(ZipFile zipFile) {
        return new ZipWalker(zipFile, null);
    }

    public static ZipWalker of(File file, String entryMask) throws IOException {
        return of(file, Directories.toWildcardPattern(entryMask));
    }

    public static ZipWalker of(File file, Pattern entryMaskPattern) throws IOException {
        return new ZipWalker(new ZipFile(file), entryMaskPattern);
    }

    public static ZipWalker of(ZipFile zipFile, String entryMask) {
        return of(zipFile, Directories.toWildcardPattern(entryMask));
    }

    public static ZipWalker of(ZipFile zipFile, Pattern entryMaskPattern) {
        return new ZipWalker(zipFile, entryMaskPattern);
    }

    public static void zipIt(String folder, String zipFile) throws IOException {
        zipIt(folder, zipFile, Utils::acceptAll);
    }

    public static void zipIt(String folder, String zipFile, Predicate<Path> filter) throws IOException {
        zipIt(Paths.get(folder), Paths.get(zipFile), filter, null);
    }

    public static void zipIt(String folder, String zipFile, Predicate<Path> filter, ZipOutputVisitor visitor) throws IOException {
        zipIt(Paths.get(folder), Paths.get(zipFile), filter, visitor);
    }

    public static void zipIt(Path folder, Path zipFile) throws IOException {
        zipIt(folder, zipFile, Utils::acceptAll, null);
    }

    public static void zipIt(Path folder, Path zipFile, ZipOutputVisitor visitor) throws IOException {
        zipIt(folder, zipFile, Utils::acceptAll, visitor);
    }

    public static void zipIt(ZipOutputStream zos, Path path, String zeName) {
        final ZipEntry zipEntry = new ZipEntry(zeName);
        try {
            try {
                zos.putNextEntry(zipEntry);
                Files.copy(path, zos);
            } finally {
                zos.closeEntry();
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to zip entry for: '%s'", path), e);
        }
    }
    public static void zipIt(ZipOutputStream zos, InputStream inputStream, String zeName) {
        final ZipEntry zipEntry = new ZipEntry(zeName);
        
        // Set executable permissions for shell scripts
        if (zeName.toLowerCase().endsWith(".sh")) {
            // Set POSIX file permissions: 0755 (owner: read/write/execute, group/others: read/execute)
            // Use extra field to store Unix file attributes
            // Format: Unix Extra Field (0x000d) with file permissions
            byte[] extraField = new byte[] {
                0x0d, 0x00,  // Unix Extra Field ID (little-endian)
                0x08, 0x00,  // Data size (8 bytes, little-endian)
                (byte)0xed, 0x01, 0x00, 0x00,  // File permissions 0755 in little-endian
                0x00, 0x00, 0x00, 0x00   // Reserved
            };
            zipEntry.setExtra(extraField);
        }
        
        try {
            try {
                zos.putNextEntry(zipEntry);
                
                // For shell scripts, ensure Linux line endings (LF only, not CRLF)
                if (zeName.toLowerCase().endsWith(".sh")) {
                    // Read the entire content and normalize line endings
                    byte[] content = IOUtils.toByteArray(inputStream);
                    String contentStr = new String(content, java.nio.charset.StandardCharsets.UTF_8);
                    // Replace CRLF with LF, then replace any remaining CR with LF
                    String normalizedContent = contentStr.replace("\r\n", "\n").replace("\r", "\n");
                    byte[] normalizedBytes = normalizedContent.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    zos.write(normalizedBytes);
                } else {
                    IOUtils.copy(inputStream, zos);
                }
            } finally {
                zos.closeEntry();
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to zip entry for: '%s'", zeName), e);
        }
    }

    public static void zipIt(Path basePath, ZipOutputStream zos, Path path) {
        zipIt(zos, path, FilenameUtils.separatorsToUnix(basePath.relativize(path).toString()));
    }

    public static void zipIt(Path sourcePath, Stream<Path> stream,
                             Path zipPath, Predicate<Path> filter,
                             ZipOutputVisitor visitor) throws IOException {
        if (!zipPath.toFile().exists()) {
            zipPath = Files.createFile(zipPath);
        }
        try (final ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zipPath))) {
            stream.filter(filter).forEach(p -> zipIt(sourcePath, zos, p));
            if (visitor != null) {
                visitor.visit(zos);
            }
        }
    }

    public static void zipIt(Path sourcePath, Path zipPath, Predicate<Path> filter, ZipOutputVisitor visitor) throws IOException {
        try (final Stream<Path> stream = Files.walk(sourcePath)) {
            final Predicate<Path> predicate = Files::isDirectory;
            zipIt(sourcePath, stream, zipPath, predicate.negate().and(filter), visitor);
        }
    }

    public static void zipIt(Map<String, String> files, OutputStream outputStream) {
        try (final ZipOutputStream zos = new ZipOutputStream(outputStream)) {
            files.forEach((key, value) -> {
                final String zeName = FilenameUtils.separatorsToUnix(key);
                final ZipEntry zipEntry = new ZipEntry(zeName);
                try {
                    try {
                        zos.putNextEntry(zipEntry);
                        IOUtils.write(value, zos, Charset.defaultCharset());
                    } finally {
                        zos.closeEntry();
                    }
                } catch (IOException e) {
                    throw new SupportRuntimeException(String.format("Failed to zip entry for: '%s'", key), e);
                }
            });
        } catch (IOException e) {
            throw new SupportRuntimeException("Failed to zip multiple files", e);
        }
    }

    public static boolean isZip(String path) {
        return path.toLowerCase().endsWith(".zip");
    }
    public static boolean isZip(Path path) {
        return isZip(path.toString());
    }

    public static boolean isArchivedSource(String source) {
        String normalizedSource = Directories.normalizePath(source);
        return normalizedSource.contains(DELIMITER);
    }

    public interface ZipOutputVisitor {
        void visit(ZipOutputStream zos) throws IOException;
    }

    public static class ExtractSummary {
        private long startTime;
        private long size;
        private long count;

        public ExtractSummary() {
            startTime = System.currentTimeMillis();
        }

        void report(ZipEntry zipEntry) {
            size += zipEntry.getSize();
            count++;
        }

        public long getSize() {
            return size;
        }

        public long getCount() {
            return count;
        }

        public long getStartTime() {
            return startTime;
        }

        public String formatDuration() {
            return "duration: " + DurationFormatUtils.formatDurationWords(System.currentTimeMillis() - startTime, true, true);
        }

        public String formatBytesSize() {
            return "size: " + FileUtils.byteCountToDisplaySize(size);
        }

        public String formatCount() {
            return "count: " + NumberFormat.getInstance().format(count);
        }

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("Extraction Summary: ");
            sb.append(formatBytesSize());
            sb.append(", ").append(formatCount());
            sb.append(", ").append(formatDuration());
            return sb.toString();
        }
    }

    public static class ZipEntryVisitorExtractor implements ZipEntryVisitor {
        protected final File location;
        protected final ExtractSummary summary;
        protected final Map<String, String> replacementMap;

        public ZipEntryVisitorExtractor(String location) {
            this(new File(location), new ExtractSummary(), new LinkedHashMap<>());
        }

        public ZipEntryVisitorExtractor(String location, ExtractSummary summary) {
            this(new File(location), summary, new LinkedHashMap<>());
        }

        public ZipEntryVisitorExtractor(File location, ExtractSummary summary) {
            this(location, summary, new LinkedHashMap<>());
        }

        public ZipEntryVisitorExtractor(File location, ExtractSummary summary, Map<String, String> replacementMap) {
            this.location = location;
            this.summary = summary;
            this.replacementMap = replacementMap;
        }

        protected void extract(ZipWalkerEntry zve, String name) {
            zve.extract(new File(location, name), summary);
        }

        @Override
        public void visit(ZipWalkerEntry zve) {
            String zipEntryName = zve.zipEntry.getName();
            if (replacementMap.containsKey(zipEntryName.toLowerCase())) {
                zipEntryName = replacementMap.get(zipEntryName);
            }
            extract(zve, zipEntryName);
        }
    }

}
