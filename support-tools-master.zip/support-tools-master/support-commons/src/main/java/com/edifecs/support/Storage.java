package com.edifecs.support;

import com.edifecs.support.collect.ContextHistory;
import com.edifecs.support.core.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;
import java.util.zip.CRC32;
import java.util.zip.ZipOutputStream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings("UnusedReturnValue")
public class Storage {

    private static final Logger logger = LogManager.getLogger(Storage.class);
    private static final String HISTORY_FILE_EXTENSION = "context";
    private static final AtomicReference<Path> historyPath = new AtomicReference<>();
    private static final String DEFAULT_TOOL_NAME = "support-tools.zip";
    private static final String CRC_EXTENSION = ".crc";
    private static final String DEFAULT_IMAGE_PATH = "image";
    private static final String DEFAULT_TOOL_PATH = ".";

    private static String toolPath = DEFAULT_TOOL_PATH;
    private static String destinationDefault = toolPath + "/results";
    private static String imagePath = DEFAULT_IMAGE_PATH;

    private Storage() { }

    public static Path defaultDestinationPath() {
        return Paths.get(destinationDefault);
    }
    public static String supportToolImageFile() {
        return DEFAULT_TOOL_NAME;
    }

    public static synchronized void toolPath(String toolPath) {
        Storage.toolPath = toolPath;
    }
    public static Path toolPath() {
        return Paths.get(toolPath);
    }

    public static Path toDisk(String resultsPath, Context context) throws IOException {
        final String source = context.resolveVariable(context.getSource());
        final String destination = context.resolveVariable(context.getDestination());
        final Path rPath = resultsPath == null ? defaultDestinationPath() : Paths.get(resultsPath);
        final Path dPath = destination == null
                ? Utils.checkTimeSuffixedPath(rPath, Utils.defaultDestinationPrefix(context.getPrefix()) + "-", "zip")
                : Paths.get(destination);
        storeContextHistory(context, dPath.toString());
        if (ZipWalker.isZip(dPath)) {
            toZip(context, source, dPath);
        } else {
            toDirectory(context, source, dPath);
        }
        return dPath;
    }

    public static Path toDisk(Context context) throws IOException {
        return toDisk(null, context);
    }

    private static void toZip(Context context, String source, Path dPath) throws IOException {
        final Path parent = dPath.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        final Map<String, Object> objectMap = context.values();
        try (final OutputStream os = Files.newOutputStream(dPath);
             final ZipOutputStream zos = new ZipOutputStream(os)) {
            for (Map.Entry<String, Object> entry : objectMap.entrySet()) {
                final String key = entry.getKey();
                final Object value = entry.getValue();
                if (value instanceof Path) {
                    final Path sPath = (Path) value;
                    ZipWalker.zipIt(zos, sPath, Utils.removePath(key, source));
                } else if (value instanceof String) {
                    ZipWalker.zipIt(zos, new ByteArrayInputStream(value.toString().getBytes()), key);
                }
            }
            if (context.hasErrors()) {
                ZipWalker.zipIt(zos, new ByteArrayInputStream(context.getErrorInfo().getErrors().toString().getBytes()), "errors.map");
            }
        }
    }

    private static void toDirectory(Context context, String source, Path dPath) throws IOException {
        Files.createDirectories(dPath);
        final Map<String, Object> objectMap = context.values();
        for (Map.Entry<String, Object> entry : objectMap.entrySet()) {
            final String key = entry.getKey();
            final Object value = entry.getValue();
            if (value instanceof Path) {
                final Path sPath = (Path) value;
                final Path dsPath = dPath.resolve(Utils.removePath(key, source));
                Files.createDirectories(dsPath.getParent());
                Directories.copy(sPath, dsPath);
            } else if (value instanceof String) {
                Files.copy(new ByteArrayInputStream(value.toString().getBytes()), dPath.resolve(key), StandardCopyOption.REPLACE_EXISTING);
            }
        }
        if (context.hasErrors()) {
            Files.copy(new ByteArrayInputStream(context.getErrorInfo().getErrors().toString().getBytes()), dPath.resolve("errors.map"), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    static ContextHistory storeContextHistory(Path path, ContextHistory contextHistory) {
        try {
            contextHistory.source(path.toAbsolutePath().toString());
            Files.write(path, contextHistory.toContentString().getBytes(),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            logger.error("Failed to create script execution history file: {}", e.getMessage(), e);
            // Don't throw exception to avoid breaking the main storage operation
        }
        return contextHistory;
    }
    static ContextHistory storeContextHistory(ContextHistory contextHistory) {
        final Path ctxPath = contextHistoryPath();
        if (!Files.exists(ctxPath)) {
            ctxPath.toFile().mkdirs();
        }
        return storeContextHistory(
                ctxPath.resolve(Utils.timeSuffixedPath("execution", HISTORY_FILE_EXTENSION)),
                contextHistory
        );
    }

    static ContextHistory storeContextHistory(Context context, String destination) {
        final Collection<String> scripts = context.getScripts();
        if (scripts == null || scripts.isEmpty()) {
            logger.debug("No scripts found in context, skipping execution history creation");
            return null;
        }
        final Map<String, Object> values = filterValues(context, new LinkedHashMap<>());
        final ContextHistory ctx = new ContextHistory(scripts, destination, LocalDateTime.now())
                .results(values);
        if (values.containsKey("output")) {
            ctx.output(values.get("output").toString());
            values.remove("output");
        }
        // Populate server name from results map if present
        if (values.containsKey("server")) {
            final Object s = values.get("server");
            if (s != null) {
                ctx.server(s.toString());
            }
        }
        return storeContextHistory(ctx);
    }

    public static List<ContextHistory> lookupContextHistory(Path logHistoryDir) throws IOException {
        final List<ContextHistory> historyList = new ArrayList<>(128);
        if (!Files.exists(logHistoryDir)) {
            logger.debug("Log/history directory does not exist: {}", logHistoryDir);
            return historyList;
        }
        try (final Stream<Path> pathStream = Files.walk(logHistoryDir)) {
            pathStream.filter(Files::isRegularFile)
                    .filter(path -> path.toString().toLowerCase().endsWith(HISTORY_FILE_EXTENSION))
                    .forEach(file -> {
                        try {
                            historyList.add(ContextHistory.of(file));
                        } catch (Exception e) {
                            logger.warn("Failed to parse file {}: {}", file, e.getMessage());
                        }
                    });
        } catch (IOException e) {
            logger.error("Failed to read log/history directory: {}", e.getMessage(), e);
            throw e;
        }
        // Sort by creation date (newest first)
        historyList.sort((h1, h2) -> h2.getDateTime().compareTo(h1.getDateTime()));
        return historyList;
    }

    public static List<ContextHistory> lookupContextHistory() throws IOException {
        return lookupContextHistory(contextHistoryPath());
    }

    public static synchronized void contextHistoryPath(Path path) {
        historyPath.set(path);
    }
    public static Path contextHistoryPath() {
        if (historyPath.get() == null) {
            historyPath.set(Paths.get(destinationDefault, "history"));
        }
        return historyPath.get();
    }

    public static synchronized void destinationDefault(String destinationDefault) {
        Storage.destinationDefault = destinationDefault;
    }

    public static Path imagePath() {
        return Objects.equals(DEFAULT_IMAGE_PATH, imagePath) ? defaultDestinationPath().resolve(imagePath) : Paths.get(imagePath);
    }
    public static Path toolImagePath() {
        return imagePath().resolve(DEFAULT_TOOL_NAME);
    }

    public static synchronized void imagePath(String imagePath) {
        Storage.imagePath = imagePath;
    }

    private static CRC32 calculateCrc(Path file) throws IOException {
        logger.info("Calculating CRC32 checksum for {}", file);
        final CRC32 crc = new CRC32();

        // Use buffered reading to handle large files without loading everything into memory
        final int bufferSize = 8192; // 8KB buffer size for optimal memory usage
        final byte[] buffer = new byte[bufferSize];

        try (final java.io.FileInputStream fis = new java.io.FileInputStream(file.toFile());
             final java.io.BufferedInputStream bis = new java.io.BufferedInputStream(fis, bufferSize)) {

            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                crc.update(buffer, 0, bytesRead);
            }
        }
        return crc;
    }

    private static String toCrcString(long crcValue) {
        return String.format("%08X", crcValue);
    }

    private static void crcToFile(Path file) throws IOException {
        // Calculate CRC32 checksum of the created zip file using buffered reading for memory efficiency
        final CRC32 crc = calculateCrc(file);
        final long crcValue = crc.getValue();
        // Create .crc file with the checksum
        final Path crcFilePath = file.resolveSibling(file.getFileName().toString() + CRC_EXTENSION);
        Files.write(crcFilePath, toCrcString(crcValue).getBytes());
        logger.info("Successfully created CRC file at: {}", crcFilePath.toAbsolutePath());
    }

    private static String readCrcString(Path crcFilePath) throws IOException {
        return new String(Files.readAllBytes(crcFilePath)).trim();
    }

    /**
     * Compares the CRC32 checksum of a file against a value stored in a corresponding .crc file.
     * The .crc file should be located in the same directory as the target file with .crc extension.
     *
     * @param file the file to calculate CRC for and compare
     * @return true if the calculated CRC matches the stored CRC, false otherwise
     * @throws IOException if file reading fails or .crc file doesn't exist
     */
    public static boolean isCrcEqual(Path file) throws IOException {
        logger.info("Comparing CRC32 checksum for {} with stored value", file);

        // Calculate CRC32 checksum of the file
        final String calculatedCrcString = toCrcString(calculateCrc(file).getValue());

        // Read stored CRC from .crc file
        final Path crcFilePath = file.resolveSibling(file.getFileName().toString() + CRC_EXTENSION);
        if (!Files.exists(crcFilePath)) {
            return false;
        }

        // Compare the CRC values
        final boolean matches = calculatedCrcString.equals(readCrcString(crcFilePath));
        logger.info("CRC comparison result: matches={}", matches);

        return matches;
    }

    /**
     * Creates support-tools.zip containing all files and folders from application folder
     * except log and results folders. The zip file is saved to results/image folder.
     *
     * @throws IOException if archiving fails
     */
    public static void createSupportToolsZip() throws IOException {
        final Path applicationFolder = toolPath();

        // Create results/image directory if it doesn't exist
        final Path resultsImagePath = defaultDestinationPath().resolve(imagePath);
        Files.createDirectories(resultsImagePath);

        // Define the zip file path
        final Path zipFilePath = resultsImagePath.resolve(DEFAULT_TOOL_NAME);

        // Create a filter to exclude log and results folders
        final java.util.function.Predicate<Path> filter = path -> {
            String pathString = path.toString().toLowerCase();
            // Exclude log and results folders (case-insensitive)
            return pathString.endsWith("jar") || pathString.contains("conf") ||
                    !pathString.contains("log") && !pathString.contains("results");
        };

        logger.info("Creating support-tools.zip archive from application folder, excluding log and results folders");
        ApacheZipWalker.zipIt(applicationFolder, zipFilePath, filter, null);
        logger.info("Successfully created support-tools.zip at: {}", zipFilePath.toAbsolutePath());

        crcToFile(zipFilePath);
    }

    public static Map<String, Object> filterValues(Context context, final Map<String, Object> result) {
        final Map<String, Object> values = context.values();
        for (final Map.Entry<String, Object> entry : values.entrySet()) {
            if (!(entry.getValue() instanceof File || entry.getValue() instanceof Path)) {
                result.put(entry.getKey(), entry.getValue());
            }
        }
        return result;
    }
}
