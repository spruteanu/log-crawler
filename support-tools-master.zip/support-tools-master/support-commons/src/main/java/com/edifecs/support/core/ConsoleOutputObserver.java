package com.edifecs.support.core;

import java.util.Map;
import java.util.function.Function;
import java.util.function.UnaryOperator;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ConsoleOutputObserver implements OutputObserver {
    private boolean appendEol;
    private Function<String, String> lineFormatter;
    private StringBuilder output = new StringBuilder();

    public ConsoleOutputObserver() {
    }

    public ConsoleOutputObserver(boolean appendEol) {
        this.appendEol = appendEol;
    }

    public ConsoleOutputObserver(UnaryOperator<String> lineFormatter) {
        this.lineFormatter = lineFormatter;
    }

    @Override
    public void onFinished(String message, Map<String, String> properties) {
        /* do nothing to override default behavior*/
    }

    @Override
    public void onProgress(String message, Map<String, String> properties) {
        if (lineFormatter != null) {
            message = lineFormatter.apply(message);
        }
        output.append(message);
        if (appendEol) {
            output.append("\n");
        }
    }

    @Override
    public void onDebug(String message, String... keyValues) {
        /* do nothing to override default behavior*/
    }

    @Override
    public void onError(String message, Map<String, String> properties) {
        /* do nothing to override default behavior*/
    }

    @Override
    public void onError(String message, Exception e, Map<String, String> properties) {
        /* do nothing to override default behavior*/
    }

    public String getOutput() {
        return output.toString();
    }
}
