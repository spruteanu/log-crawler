package com.edifecs.support.validate;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.support.JmsUtils;

import jakarta.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class JmsValidate {
    private static Logger log = LogManager.getLogger(JmsValidate.class);
    private final Hashtable jndiProperties;
    private final String connectionFactoryName;
    private final String userName;
    private final String password;
    private final Set<String> jmsQueueNamesSet;
    private String errorMessage;


    public JmsValidate(Map<String, String> props, String connectionFactoryName,
                       String userName, String password, Set<String> jmsQueueNames) {
        jndiProperties = getHashtable(props);
        this.connectionFactoryName = connectionFactoryName;
        this.userName = userName;
        this.password = password;
        jmsQueueNamesSet = jmsQueueNames;
    }

    private static void validateJmsQueue(InitialContext initialContext, Session session, String queueName) throws NamingException {
        log.debug("Lookup JMS queue '{}'", queueName);
        try {
            Object dst = initialContext.lookup(queueName);
            if (dst == null) {
                throw new NamingException(String.format("Not found JMS queue by JNDI name '%s'.", queueName));
            }

            if (!(dst instanceof Destination)) {
                throw new NamingException(String.format("JNDI object '%s' is not a JMS destination.", queueName));
            }
        } catch (NamingException e) {
            try {
                session.createQueue(queueName);
            } catch (JMSException e2) {
                log.trace("Failed to create JMS queue '{}' using the Session.createQueue() method.", queueName, e2);
                throw e;
            }
        }
    }

    public static Hashtable getHashtable(Map<String, String> props) {
        return new Hashtable<>(props);
    }

    private static String getExceptionErrorMessage(Exception e) {
        String exMsg = e.getMessage();

        if (StringUtils.isBlank(exMsg)) { // some JMS exceptions have an empty message...
            exMsg = "exception " + e.getClass().getName();
        }

        return exMsg;
    }

    public boolean isJmsAvailable() {
        boolean result;
        try {
            connect();
            result = true;
        } catch (NamingException e) {
            result = false;
            errorMessage = getExceptionErrorMessage(e);
            log.debug("Failed to obtain a JMS connection - naming issue.", e);
        } catch (RuntimeException | JMSException e) {
            result = false;
            errorMessage = getExceptionErrorMessage(e);
            log.debug("Failed to obtain a JMS connection.", e);
        }

        return result;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    private synchronized void connect() throws NamingException, JMSException {
        ClassLoader originalClassLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());

        Connection jmsConnection = null;
        try {
            InitialContext initialContext = new InitialContext(jndiProperties);

            log.debug("Lookup JMS connection factory");
            Object object = initialContext.lookup(connectionFactoryName);
            if (object instanceof ConnectionFactory) {
                log.trace("Create JMS connection");
                ConnectionFactory connectionFactory = (ConnectionFactory) object;
                if (org.apache.commons.lang.StringUtils.isNotBlank(userName)) {
                    // XEServer comment: For active MQ Thread context class loader should not be XESClassLoader to avoid class cast exceptions
                    jmsConnection = connectionFactory.createConnection(userName, password);
                } else {
                    jmsConnection = connectionFactory.createConnection();
                }

                jmsConnection.setExceptionListener(new JmsExceptionListener());
                log.debug("Start JMS connection");
                jmsConnection.start();
                log.trace("Create JMS session");
                Session session = jmsConnection.createSession(true, Session.SESSION_TRANSACTED);
                validateJmsQueues(initialContext, session);
            } else {
                String sMessage = String.format("The object stored under the name '%s' cannot be casted to javax.jms.ConnectionFactory.", connectionFactoryName);
                throw new NamingException(sMessage);
            }
        } finally {
            JmsUtils.closeConnection(jmsConnection);
            Thread.currentThread().setContextClassLoader(originalClassLoader);
        }
    }

    private void validateJmsQueues(InitialContext initialContext, Session session) throws NamingException {
        for (String queueName : jmsQueueNamesSet) {
            validateJmsQueue(initialContext, session, queueName);
        }
    }

    static class JmsExceptionListener implements ExceptionListener {

        public void onException(JMSException e) {
            log.debug("Exception during connecting to JMS.", e);
        }
    }
}
