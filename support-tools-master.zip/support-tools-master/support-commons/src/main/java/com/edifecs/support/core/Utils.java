package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.odysseus.staxon.json.JsonXMLConfig;
import de.odysseus.staxon.json.JsonXMLConfigBuilder;
import de.odysseus.staxon.json.JsonXMLOutputFactory;
import groovy.lang.GString;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.jetbrains.annotations.NotNull;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import java.io.*;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * @author victtern
 * @author Serge Pruteanu (sergep@edifecs.com)
 * <p>
 * Created: 01 2023
 */
public final class Utils {

    @SuppressWarnings("squid:S2885")
    public static final SimpleDateFormat YYYY_MM_DD_HH_MM = new SimpleDateFormat("yyyy-MM-dd-HH-mm");

    private Utils() {
    }

    private static CommandLine parseArguments(String[] args, Options options) {
        try {
            return new DefaultParser().parse(options, args);
        } catch (Exception exp) {
            throw new IllegalArgumentException("Invalid arguments: " + Arrays.toString(args), exp);
        }
    }

    public static Optional<CommandLine> checkForValidArgumentsOrHelp(String[] args, Options options, Consumer<Void> usage) {
        if (args != null && args.length == 1 && "-help".equals(args[0])) {
            usage.accept(null);
            return Optional.empty();
        }
        final CommandLine cmd = parseArguments(args, options);
        if (cmd.getArgs().length == 0 && cmd.getOptions().length == 0) {
            usage.accept(null);
            return Optional.empty();
        }
        if (cmd.hasOption("help")) {
            usage.accept(null);
            return Optional.empty();
        }
        return Optional.of(cmd);
    }

    @SuppressWarnings("unused")
    public static <T> boolean acceptAll(T t) {
        return true;
    }

    public static Map<String, String> asMap(String... keyValues) {
        if (keyValues == null) {
            return null;
        }
        final Map<String, String> result = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) {
            final String key = keyValues[i];
            final String value = i < keyValues.length - 1 ? keyValues[i + 1] : null;
            result.put(key, value);
        }
        return result;
    }

    @SuppressWarnings({"unchecked", "squid:S3776"})
    public static Object stringify(Object obj) {
        if (obj instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) obj;
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (entry.getValue() instanceof Map || entry.getValue() instanceof List) {
                    stringify(entry.getValue());
                } else if (entry.getValue() instanceof GString) {
                    map.put(entry.getKey(), entry.getValue().toString());
                }
            }
        } else if (obj instanceof List) {
            List<Object> list = (List<Object>) obj;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element instanceof GString) {
                    list.set(i, element.toString());
                } else if (element instanceof Map || element instanceof List) {
                    stringify(element);
                }
            }
        } else if (obj instanceof GString) {
            return obj.toString();
        }
        return obj;
    }

    public static Map<String, Object> asMap(Map<String, Object> result, Object k1, Object v1, Object... kv) {
        result.put(k1.toString(), stringify(v1));
        if (kv != null) {
            for (int i = 0; (i + 1) < kv.length; i += 2) {
                result.put(kv[i].toString(), stringify(kv[i + 1]));
            }
        }
        return result;
    }

    public static Map<String, Object> asMap(Object k1, Object v1, Object... kv) {
        return asMap(new LinkedHashMap<>(), k1, v1, kv);
    }

    public static <T> Map<String, T> asMap(List<T> list, Function<T, String> keyFn) {
        Map<String, T> map = new HashMap<>();
        if (list != null) {
            list.forEach(cp -> map.put(keyFn.apply(cp), cp));
        }
        return map;
    }

    public static String lookupHostName(String defaultName) {
        try {
            final InetAddress localHost = InetAddress.getLocalHost();
            return localHost.getHostName();
        } catch (UnknownHostException e) {
            if (defaultName == null) {
                throw new SupportRuntimeException("Failed to resolve host name", e);
            } else {
                return defaultName;
            }
        }
    }

    public static String lookupHostName() {
        return lookupHostName(null);
    }

    public static String lookupLocalHostName() {
        return lookupHostName("localhost");
    }

    public static Map<String, String> fromProperties(Properties properties) {
        final Map<String, String> result = new LinkedHashMap<>();
        for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements(); ) {
            String key = (String) e.nextElement();
            result.put(key, properties.getProperty(key));
        }
        return result;
    }

    public static ManifestBean lookupManifest(String lookupProperty, String lookupValue) {
        return ManifestBean.findManifestInClasspath(lookupProperty, lookupValue);
    }

    public static String lookupManifestVersion(final String lookupProperty, final String lookupValue) {
        final ManifestBean manifestBean = lookupManifest(lookupProperty, lookupValue);
        String version = null;
        if (manifestBean != null) {
            version = manifestBean.getManifestProperty("Implementation-Version");
        }
        return version != null ? "v." + version : "v.1.0";
    }

    public static String timeSuffixedPath(String fileNamePrefix, String fileNameExtension) {
        if (fileNameExtension != null) {
            return String.format("%s-%s.%s", fileNamePrefix, YYYY_MM_DD_HH_MM.format(new Date()), fileNameExtension);
        } else {
            return String.format("%s-%s", fileNamePrefix, YYYY_MM_DD_HH_MM.format(new Date()));
        }
    }

    public static Path checkTimeSuffixedPath(Path zPath, String fileNamePrefix, String fileNameExtension) {
        if (Files.isDirectory(zPath)) {
            zPath = zPath.resolve(timeSuffixedPath(fileNamePrefix, fileNameExtension));
        }
        return zPath;
    }

    public static Path defaultDestination(Path zPath, final String prefix) {
        return Utils.checkTimeSuffixedPath(zPath, defaultDestinationPrefix(prefix), null);
    }

    public static String removePath(String key, String source) {
        String result = key.replace(source, "");
        if (result.startsWith("/")) {
            result = result.substring(1);
        }
        while (result.startsWith("\\")) {
            result = result.substring(1);
        }
        return result;
    }

    public static long fileSize(Path file) throws IOException {
        try (final FileChannel channel = FileChannel.open(file, StandardOpenOption.READ)) {
            return channel.size();
        }
    }

    @SuppressWarnings("squid:S106")
    public static void disableIllegalReflectiveAccessWarning() {
        System.err.close();
        System.setErr(System.out);
    }

    @NotNull
    public static String exceptionToString(Throwable e) {
        final StringBuilder sb = new StringBuilder();
        sb.append(e.getMessage()).append('\n');
        for (StackTraceElement element : e.getStackTrace()) {
            sb.append("\tat ").append(element.toString()).append('\n');
        }
        return sb.toString();
    }


    private static TransformerFactory createdTransformerFactory() {
        TransformerFactory factory = TransformerFactory.newInstance();
        try {
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        } catch (Exception ignore) {
            // Some TransformerFactory implementations may not support this feature
        }
        try {
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        } catch (IllegalArgumentException ignore) {
            // Attribute not supported by this implementation
        }
        try {
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        } catch (IllegalArgumentException ignore) {
            // Attribute not supported by this implementation
        }
        return factory;
    }

    public static void xml2Json(Reader reader, OutputStream outputStream, boolean prettyPrint) throws XMLStreamException, TransformerException {
        JsonXMLConfig config = new JsonXMLConfigBuilder()
                .autoArray(true)
                .autoPrimitive(true)
                .prettyPrint(prettyPrint)
                .build();
        XMLStreamWriter writer = new JsonXMLOutputFactory(config).createXMLStreamWriter(outputStream, "UTF-8");
        writer.writeDTD("config.dtd");
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        xmlInputFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
        xmlInputFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        // This disables DTDs entirely for that factory
        xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        // disable external entities
        xmlInputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", false);
        createdTransformerFactory().newTransformer().transform(
                new StAXSource(xmlInputFactory.createXMLStreamReader(reader)),
                new StAXResult(writer)
        );
    }

    public static Map<String, Object> json2Map(URL url) throws IOException {
        try (final Reader reader = new InputStreamReader(url.openStream())) {
            return json2Map(reader);
        }
    }

    public static Map<String, Object> json2Map(Reader reader) {
        return new Gson().fromJson(reader, new TypeToken<LinkedHashMap<String, Object>>() {
        }.getType());
    }

    public static String defaultDestinationPrefix(final String prefix) {
        return prefix + lookupHostName("localhost").toLowerCase();
    }

    public static String xml2Json(Reader reader) throws XMLStreamException, TransformerException, IOException {
        try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream(16 * 1024)) {
            xml2Json(reader, outputStream, false);
            return outputStream.toString();
        }
    }

    public static Map<String, Object> xml2Map(Reader reader) throws Exception {
        return json2Map(new StringReader(xml2Json(reader)));
    }

    @SuppressWarnings({"Duplicates", "squid:S2755"})
    public static void xml2Json(InputStream inputStream, OutputStream outputStream, boolean prettyPrint) throws XMLStreamException, TransformerException {
        JsonXMLConfig config = new JsonXMLConfigBuilder()
                .autoArray(true)
                .autoPrimitive(false)
                .prettyPrint(prettyPrint)
                .build();
        XMLStreamWriter writer = new JsonXMLOutputFactory(config).createXMLStreamWriter(outputStream, "UTF-8");
        createdTransformerFactory().newTransformer().transform(
                new StAXSource(XMLInputFactory.newInstance().createXMLStreamReader(inputStream)),
                new StAXResult(writer)
        );
    }

    public static String xml2Json(InputStream inputStream) throws XMLStreamException, TransformerException, IOException {
        try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream(16 * 1024)) {
            xml2Json(inputStream, outputStream, false);
            return outputStream.toString();
        }
    }

    public static Map<String, Object> xml2Map(InputStream inputStream) throws Exception {
        return json2Map(new StringReader(xml2Json(inputStream)));
    }
}
