package com.edifecs.support.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class Difference {
    private Object left;
    private Object right;
    private List<String> details;
    private List<Difference> differences;

    public Object getDifferences() {
        return differences;
    }

    public void setDifferences(List<Difference> differences) {
        this.differences = differences;
    }
    public Difference difference(Difference difference) {
        if (difference == null || this == difference || !difference.hasDifference()) {
            return this;
        }
        if (differences == null) {
            differences = new ArrayList<>();
        }
        differences.add(difference);
        return this;
    }

    public Object getLeft() {
        return left;
    }

    public void setLeft(Object left) {
        this.left = left;
    }
    public Difference left(Object left) {
        setLeft(left);
        return this;
    }

    public Object getRight() {
        return right;
    }

    public void setRight(Object right) {
        this.right = right;
    }
    public Difference right(Object right) {
        setRight(right);
        return this;
    }

    public List<String> getDetails() {
        return details;
    }

    public void setDetails(List<String> details) {
        this.details = details;
    }

    public boolean hasDifference() {
        return (details != null && !details.isEmpty()) || (differences != null && !differences.isEmpty());
    }

    public Difference noDifference() {
        differences = null;
        details = null;
        return this;
    }

    private void details(String details) {
        if (this.details == null) {
            this.details = new ArrayList<>();
        }
        this.details.add(details);
    }

    public Difference difference(String details) {
        details(details);
        return this;
    }

    List<Difference> listAll(List<Difference> list) {
        list.add(this);
        if (differences != null) {
            for (Difference difference : differences) {
                difference.listAll(list);
            }
        }
        return list;
    }

    public List<Difference> listAll() {
        return listAll(new ArrayList<>(1 + (differences != null ? differences.size() : 0)));
    }

    @SuppressWarnings("squid:S3358")
    List<Object[]> listTuples(List<Object[]> list) {
        list.add(new Object[] {left, right, details != null ? details : (differences != null ? differences.size() : null) });
        if (differences != null) {
            for (Difference difference : differences) {
                difference.listTuples(list);
            }
        }
        return list;
    }
    public List<Object[]> listTuples() {
        return listTuples(new ArrayList<>(1 + (differences != null ? differences.size() : 0)));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Difference)) return false;
        Difference that = (Difference) o;
        if (!Objects.equals(left, that.left)) return false;
        return Objects.equals(right, that.right);
    }

    @Override
    public int hashCode() {
        int result = left != null ? left.hashCode() : 0;
        result = 31 * result + (right != null ? right.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(Objects.requireNonNullElse(left, "missing"));
        sb.append(", ").append(Objects.requireNonNullElse(right, "missing"));
        sb.append(", ");
        if (details != null) {
            sb.append("\"");
            sb.append(details);
            sb.append("\"");
        }
        if (differences != null) {
            sb.append(" differences count: ").append(differences.size());
        }
        return sb.toString();
    }

    public static <T> Difference of(T left, T right) {
        return new Difference().left(left).right(right);
    }
}
