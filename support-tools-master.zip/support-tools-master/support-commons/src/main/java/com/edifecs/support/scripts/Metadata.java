package com.edifecs.support.scripts;

import com.edifecs.support.SupportRuntimeException;
import com.edifecs.support.core.*;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class Metadata {
    private static final String GROOVY_EXTENSION = ".groovy";

    public static final String LIB_FOLDER = "lib";
    public static final String SCRIPTS_FOLDER = "scripts";

    private String name = "Unnamed";
    private String type;
    private String content;
    private String description = "No description";
    private String usage;
    private String author = "Unknown";
    private String path;
    private String alias;
    private String group;

    private Set<String> roles = new LinkedHashSet<>(10);

    private List<Map<String, Object>> arguments;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Metadata name(String name) {
        setName(name);
        return this;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public Metadata type(String type) {
        setType(type);
        return this;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    public Metadata content(String content) {
        setContent(content);
        return this;
    }
    public boolean hasContent() {
        return StringUtils.isNotBlank(content);
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
    public Metadata path(String path) {
        setPath(path);
        defaultGroupFromPath();
        return this;
    }
    public boolean hasPath() {
        return StringUtils.isNotBlank(path);
    }

    public String getGroup() {
        if (StringUtils.isNotBlank(group)) {
            return group;
        }
        group = defaultGroupFromPath();
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public Metadata group(String group) {
        setGroup(group);
        return this;
    }

    Metadata alias(String alias) {
        if (StringUtils.isNotBlank(alias) && alias.toLowerCase().endsWith(GROOVY_EXTENSION)) {
            alias = alias.substring(0, alias.length() - 7);
        }
        this.alias = alias;
        return this;
    }
    void alias(String name, String type) {
        String a = name;
        if (StringUtils.isNotBlank(type)) {
            a = type + "/" + name;
        }
        alias(a);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public Metadata description(String description) {
        setDescription(description);
        return this;
    }
    public Metadata error(String error) {
        setDescription(error);
        return this;
    }

    public String getUsage() {
        return usage;
    }

    public void setUsage(String usage) {
        this.usage = usage;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
    public Metadata author(String author) {
        setAuthor(author);
        return this;
    }

    public List<Map<String, Object>> getArguments() {
        return arguments;
    }

    public void setArguments(List<Map<String, Object>> arguments) {
        this.arguments = arguments;
    }
    public Metadata arguments(List<Map<String, Object>> arguments) {
        setArguments(arguments);
        return this;
    }
    @SafeVarargs
    public final Metadata arguments(Map<String, Object>... arguments) {
        if (arguments == null || arguments.length == 0) {
            return this;
        }
        final List<Map<String, Object>> args = new ArrayList<>(Arrays.asList(arguments));
        if (this.arguments != null) {
            this.arguments.addAll(args);
            return this;
        }
        return arguments(args);
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }
    public Metadata filters(Set<String> filters) {
        setRoles(filters);
        return this;
    }
    public Metadata filters(String filter, String... filters) {
        final List<String> f = new ArrayList<>();
        f.add(filter);
        if (filters != null && filters.length > 0) {
            f.addAll(Arrays.asList(filters));
        }
        setRoles(new LinkedHashSet<>(f));
        return this;
    }
    public Metadata admin() {
        return filters("admin");
    }
    public Metadata on_premise() {
        return filters("on-premise");
    }

    public boolean isLibraryScript() {
        return path != null && ZipWalker.isArchivedSource(path);
    }
    public String toScript() {
        String result = path;
        if (result != null) {
            final int i = result.indexOf(ZipWalker.DELIMITER);
            if (i > 0 && result.length() > i + 1) {
                return result.substring(i + 1);
            }
        } else {
            result = content;
        }
        return Patterns.of("\\\\").matcher(result).replaceAll("/");
    }
    static String escapeArgument(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        String v = value;
        if (Patterns.of("\\s").matcher(v).find()) {
            v = "\"" + v + "\"";
        }
        return v;
    }
    public String toScript(String... args) {
        StringBuilder script = new StringBuilder(toScript());
        if (args != null) {
            for (final String arg : args) {
                final String vArg = escapeArgument(arg);
                if (vArg != null) {
                    script.append(" ").append(vArg);
                }
            }
        }
        return script.toString();
    }

    @SuppressWarnings({"squid:S3776", "squid:S5843", "squid:S5998"})
    private String defaultGroupFromPath() {
        if (StringUtils.isBlank(path)) {
            return null;
        }
        String outer = path;
        int i = path.indexOf(ZipWalker.DELIMITER);
        if (i > 0) {
            outer = path.substring(0, i);
        }
        String lower = outer.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".jar")) {
            String fileName = new File(outer).getName();
            String base = fileName.replaceFirst("(?i)\\.jar$", "");
            // Strip trailing version-like suffixes (e.g., -1.2.3, -1.0.0-SNAPSHOT, -20210101.123456-1)
            String stripped = base.replaceFirst("-(\\d+([._-]\\d+)*)(([._-](?i)(SNAPSHOT|RELEASE|FINAL|GA|RC\\d+|M\\d+|ALPHA\\d*|BETA\\d*)))?$", "");
            stripped = stripped.replaceFirst("-(\\d+([._-]\\d+)*)$", "");
            return stripped;
        } else {
            try {
                Path p = Paths.get(outer);
                Path parent = p.getParent();
                if (parent == null) {
                    return null;
                }
                Path dir = parent.getFileName();
                return dir != null ? dir.toString() : null;
            } catch (Exception ignore) {
                // Fallback: attempt simple splitting by file separators
                String normalized = outer.replace('\\', '/');
                int slash = normalized.lastIndexOf('/');
                if (slash > 0) {
                    int prev = normalized.lastIndexOf('/', slash - 1);
                    if (prev >= 0 && slash - prev > 1) {
                        return normalized.substring(prev + 1, slash);
                    }
                }
                return null;
            }
        }
    }

    @Override
    public String toString() {
        return "Metadata{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", content='" + content + '\'' +
                ", description='" + description + '\'' +
                ", usage='" + usage + '\'' +
                ", author='" + author + '\'' +
                ", path='" + path + '\'' +
                ", group='" + getGroup() + '\'' +
                ", arguments=" + arguments +
                '}';
    }

    static void populate(Metadata metadata, Description scriptDescription) {
        metadata.name = scriptDescription.name();
        metadata.description = scriptDescription.description();
        metadata.author = scriptDescription.author();
        metadata.usage = scriptDescription.usage();
    }
    static void populate(Metadata metadata, Argument argument) {
        final Map<String, Object> map = new LinkedHashMap<>();
        map.put("name", argument.name());
        map.put("description", argument.description());
        map.put("required", argument.required());
        metadata.arguments(map);
    }
    static void populate(Metadata metadata, Group group) {
        if (group != null && StringUtils.isNotBlank(group.value())) {
            metadata.group(group.value());
        }
    }
    static void populate(Metadata metadata, Role role) {
        if (role != null && StringUtils.isNotBlank(role.value())) {
            if (metadata.roles == null) {
                metadata.roles = new LinkedHashSet<>(4);
            }
            metadata.roles.add(role.value());
        }
    }
    static void checkPopulate(Metadata metadata, final Description d) {
        if (d != null) {
            populate(metadata, d);
        }
    }
    static void checkPopulate(Metadata metadata, final Argument a) {
        if (a != null) {
            populate(metadata, a);
        }
    }
    static void checkPopulate(Metadata metadata, final Group g) {
        if (g != null) {
            populate(metadata, g);
        }
    }
    static void checkPopulate(Metadata metadata, final Role f) {
        if (f != null) {
            populate(metadata, f);
        }
    }
    static void populate(Metadata metadata, Field[] fields) {
        if (fields == null) {
            return;
        }
        for (final Field field : fields) {
            checkPopulate(metadata, field.getAnnotation(Description.class));
            checkPopulate(metadata, field.getAnnotation(Argument.class));
            checkPopulate(metadata, field.getAnnotation(Group.class));
            final Role[] roles = field.getDeclaredAnnotationsByType(Role.class);
            if (roles != null) {
                for (final Role f : roles) {
                    populate(metadata, f);
                }
            }
        }
    }

    static void populate(Metadata metadata, Method[] methods) {
        if (methods == null) {
            return;
        }
        for (final Method method : methods) {
            checkPopulate(metadata, method.getAnnotation(Description.class));
            final Argument[] annotations = method.getDeclaredAnnotationsByType(Argument.class);
            for (final Argument annotation : annotations) {
                populate(metadata, annotation);
            }
            checkPopulate(metadata, method.getAnnotation(Group.class));
            final Role[] roles = method.getDeclaredAnnotationsByType(Role.class);
            if (roles != null) {
                for (final Role f : roles) {
                    populate(metadata, f);
                }
            }
        }
    }

    static Metadata parseMeta(Class<?> scriptClass, Metadata metadata) {
        checkPopulate(metadata, scriptClass.getAnnotation(Description.class));
        checkPopulate(metadata, scriptClass.getAnnotation(Group.class));
        final Role[] roles = scriptClass.getDeclaredAnnotationsByType(Role.class);
        if (roles != null) {
            for (final Role f : roles) {
                populate(metadata, f);
            }
        }
        populate(metadata, scriptClass.getDeclaredFields());
        populate(metadata, scriptClass.getDeclaredMethods());
        return metadata;
    }
    static Metadata parseMeta(Object obj, Metadata metadata) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof Class) {
            return parseMeta((Class<?>) obj, metadata);
        } else {
            return parseMeta(obj.getClass(), metadata);
        }
    }

    static Metadata parseMeta(Class<?> scriptClass) {
        return parseMeta(scriptClass, new Metadata());
    }

    static Metadata parseMeta(Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof Class) {
            return parseMeta((Class<?>) obj);
        } else {
            return parseMeta(obj.getClass());
        }
    }

    static String lookupType(Path p) {
        return Optional.ofNullable(p)
                .map(Path::getParent)
                .map(Path::getFileName)
                .map(Path::toString)
                .filter(type -> !type.isEmpty())
                .orElse("unknown");
    }

    public static Metadata parseMeta(Path p) {
        if (p == null) {
            return null;
        }
        final Metadata metadata = new Metadata();
        metadata.path(p.toString());
        metadata.setName(p.getFileName().toString());
        metadata.type(lookupType(p));
        metadata.alias(metadata.getName(), metadata.getType());
        try {
            parseMeta(GroovyUtil.compile(p.toFile()), metadata);
        } catch (IOException e) {
            metadata.error("Failed to parse metadata; Error: " + Utils.exceptionToString(e));
        }
        return metadata;
    }

    static Metadata readContent(Metadata metadata) {
        try {
            metadata.setContent(new String(Files.readAllBytes(Paths.get(metadata.getPath()))));
        } catch (IOException e) {
            metadata.error("Failed to read content; Error: " + Utils.exceptionToString(e));
        }
        return metadata;
    }

    public static List<Metadata> lookupScripts(Path scripts) throws IOException {
        final List<Metadata> result = new ArrayList<>(256);
        if (scripts != null) {
            try (final Stream<Path> stream = Files.find(scripts, Integer.MAX_VALUE, Directories::forRegularFile)) {
                result.addAll(stream
                        .filter(p -> p.getFileName().toString().endsWith(GROOVY_EXTENSION))
                        .map(Metadata::parseMeta)
                        .collect(Collectors.toList())
                );
            }
        }
        return result;
    }
    public static List<Metadata> lookupJarScripts(Path jarFile) {
        final List<Metadata> result = new ArrayList<>(256);
        try (final ZipWalker zipWalker = ZipWalker.of(jarFile.toFile())) {
            zipWalker.walk(entry -> {
                final String entryName = entry.getZipEntry().getName();
                if (entryName.toLowerCase().endsWith(GROOVY_EXTENSION)) {
                    final Metadata metadata = new Metadata();
                    metadata.path(ZipWalker.zipEntryPath(jarFile, entryName));
                    metadata.setName(entryName);
                    metadata.type(lookupType(Paths.get(entryName)));
                    metadata.alias(entryName);
                    try {
                        metadata.setContent(new String(zipWalker.toBytes(entryName)));
                        parseMeta(GroovyUtil.compileText(metadata.getContent()), metadata);
                        result.add(metadata);
                    } catch (IOException e) {
                        metadata.error("Failed to read content; Error: " + Utils.exceptionToString(e));
                    }
                }
            });
        } catch (IOException e) {
            throw new SupportRuntimeException("Failed to open jar file: " + jarFile, e);
        }
        return result;
    }

    private static List<Metadata> lookupLibScripts(Path scripts) throws IOException {
        final List<Metadata> result = new ArrayList<>(256);
        if (scripts != null) {
            try (final Stream<Path> stream = Files.find(scripts, 1, Directories::forRegularFile)) {
                result.addAll(stream
                        .filter(p -> p.getFileName().toString().toLowerCase().endsWith(".jar"))
                        .map(Metadata::lookupJarScripts).flatMap(List::stream)
                        .collect(Collectors.toList())
                );
            }
        }
        return result;
    }

    public static List<Metadata> lookup(Path libs, Path scripts) throws IOException {
        final List<Metadata> result = new ArrayList<>(256);
        result.addAll(lookupScripts(scripts));
        result.addAll(lookupLibScripts(libs));
        Holder.populate(result);
        return result;
    }

    public static List<Metadata> lookup(File libFolder, File scriptsFolder) throws IOException {
        return lookup(Optional.ofNullable(libFolder).map(File::toPath).orElse(null),
                Optional.ofNullable(scriptsFolder).map(File::toPath).orElse(null));
    }
    public static List<Metadata> lookup(String libFolder, String scriptsFolder) throws IOException {
        return lookup(Optional.ofNullable(libFolder).map(Paths::get).orElse(null),
                Optional.ofNullable(scriptsFolder).map(Paths::get).orElse(null));
    }
    public static List<Metadata> lookup(String supportToolsLocation) throws IOException {
        return lookup(new File(supportToolsLocation, LIB_FOLDER), new File(supportToolsLocation, SCRIPTS_FOLDER));
    }
    public static List<Metadata> lookup(Path cp) throws IOException {
        Path scripts = cp.resolve(SCRIPTS_FOLDER);
        if (!scripts.toFile().exists()) {
            scripts = cp.resolve("samples");
            if (!scripts.toFile().exists()) {
                scripts = null;
            }
        }
        return lookup(cp.resolve(LIB_FOLDER), scripts);
    }
    public static List<Metadata> lookup() throws IOException {
        return lookup(Directories.currentDirectory());
    }
    public static Metadata lookupScript(String groovyScript) {
        if (groovyScript == null) {
            return null;
        }
        final Metadata metadata = new Metadata();
        metadata.path(groovyScript);
        metadata.setName(groovyScript);
        parseMeta(GroovyUtil.compile(groovyScript), metadata);
        return metadata;
    }

    public static void toMarkdown(List<Metadata> list, Writer writer) throws IOException {
        // Write the header
        writer.write("# Scripts Documentation\n\n");
        // Write the table of contents
        writer.write("## Table of Contents\n");
        for (final Metadata metadata : list) {
            writer.write("- [" + metadata.getName() + "](#" + metadata.getName().toLowerCase().replace(" ", "-") + ")\n");
        }
        writer.write("\n");
        // Write the details for each metadata object
        for (final Metadata metadata : list) {
            writer.write("## " + metadata.getName() + "\n\n");
            writer.write("**Type:** " + metadata.getType() + "\n\n");
            if (StringUtils.isNotBlank(metadata.getDescription())) {
                writer.write("**Description:** " + metadata.getDescription() + "\n\n");
            }
            if (StringUtils.isNotBlank(metadata.getUsage())) {
                writer.write("**Usage:** " + metadata.getUsage() + "\n\n");
            }
            writer.write("**Author:** " + metadata.getAuthor() + "\n\n");
            writer.write("**Path:** " + metadata.getPath() + "\n\n");
            if (StringUtils.isNotBlank(metadata.getContent())) {
                writer.write("**Content:**\n```groovy\n" + metadata.getContent() + "\n```\n\n");
            }
        }
    }

    public static void toMarkdown(List<Metadata> list, String outputFilePath) throws IOException {
        try (FileWriter writer = new FileWriter(outputFilePath)) {
            toMarkdown(list, writer);
        }
    }

    public static String lookupScriptName(String script) {
        String result = script;
        final Metadata metadata = search(script);
        if (metadata != null) {
            result = metadata.getName();
            if (result == null) {
                result = script;
            }
        }
        return result;
    }

    public static Metadata get(String key) {
        return Holder.get(key);
    }

    public static Collection<Metadata> get() {
        return Holder.get();
    }

    public static Metadata search(String key, Predicate<Metadata> predicate) {
        return Holder.search(key, predicate);
    }
    public static boolean matchesAlias(Metadata metadata, String alias) {
        String ma = metadata.alias;
        if (ma == null) {
            return false;
        }
        return Patterns.of(".*" + ma + ".*", Pattern.CASE_INSENSITIVE).matcher(alias).matches();
    }
    public static Metadata search(final String key) {
        return Holder.search(key, metadata -> matchesAlias(metadata, key));
    }
    public static Metadata search(Predicate<Metadata> predicate) {
        return Holder.search(predicate);
    }
    public static Collection<Metadata> searchAll(String key, Predicate<Metadata> predicate) {
        return Holder.searchAll(key, predicate);
    }
    public static Collection<Metadata> searchAll(Predicate<Metadata> predicate) {
        return Holder.searchAll(predicate);
    }

    private static class Holder {
        private static final String ALL_KEY = "all";
        private static final Map<String, Object> cache = new ConcurrentHashMap<>(256);

        public static synchronized void populate(Collection<Metadata> metas) {
            cache.put(ALL_KEY, metas);
            for (final Metadata meta : metas) {
                cache.put(meta.alias, meta);
            }
        }
        public static void populate(Supplier<Collection<Metadata>> metas) {
            populate(metas.get());
        }

        public static Metadata get(String key) {
            return (Metadata) cache.get(key);
        }

        @SuppressWarnings("unchecked")
        public static Collection<Metadata> get() {
            if (!cache.containsKey(ALL_KEY)) {
                synchronized (cache) {
                    try {
                        populate(lookup());
                    } catch (IOException ignore) { /*noop*/ }
                }
            }
            return (Collection<Metadata>) cache.get(ALL_KEY);
        }

        public static Metadata search(String key, final Predicate<Metadata> predicate) {
            final Metadata metadata = get(key);
            if (metadata != null) {
                return metadata;
            }
            synchronized (cache) {
                Optional.ofNullable(get()).orElse(Collections.emptyList())
                        .stream().filter(predicate).findFirst().ifPresent(m -> cache.put(key, m));
            }
            return get(key);
        }
        public static Metadata search(Predicate<Metadata> predicate) {
            return search(predicate.getClass().getName(), predicate);
        }
        @SuppressWarnings("unchecked")
        public static Collection<Metadata> searchAll(String key, Predicate<Metadata> predicate) {
            Collection<Metadata> result = (Collection<Metadata>) cache.get(key);
            if (result != null) {
                return result;
            }
            synchronized (cache) {
                result = Optional.ofNullable(get()).orElse(Collections.emptyList())
                        .stream().filter(predicate).collect(Collectors.toList());
                if (!result.isEmpty()) {
                    cache.put(key, result);
                }
            }
            return result;
        }
        public static Collection<Metadata> searchAll(Predicate<Metadata> predicate) {
            return searchAll(predicate.getClass().getName(), predicate);
        }

        public static void clear() {
            cache.clear();
        }
    }
}
