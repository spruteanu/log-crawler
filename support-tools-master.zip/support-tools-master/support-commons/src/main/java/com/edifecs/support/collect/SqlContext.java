package com.edifecs.support.collect;

import com.edifecs.support.SupportRuntimeException;
import com.edifecs.support.core.*;
import org.intellij.lang.annotations.Language;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"rawtypes", "squid:S1192", "UnusedReturnValue", "unused"})
public abstract class SqlContext extends Context {
    static final String DRIVER_NAME = "DriverName";
    public static final String QUERY_RESULTS = "query";

    private static final String LINE_BREAK = "\n";

    public static final String MSSQL_DEFAULT_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static final String ORACLE_DEFAULT_DRIVER = "oracle.jdbc.OracleDriver";
    public static final String POSTGRES_DEFAULT_DRIVER = "org.postgresql.Driver";

    public static final String MSSQL_DELIMITER = "GO";
    public static final String ORACLE_DELIMITER = ";";
    public static final String DEFAULT_DELIMITER = ";";

    public static final String URL = "url";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String DRIVER_CLASS_NAME = "driverClassName";
    public static final String DRIVER = "driver";
    public static final String DATABASE_TYPE = "database.type";
    public static final String SERVER = "server";
    public static final String DATABASE = "database";
    public static final String PORT = "port";
    public static final String MASTER_URL = "master.url";
    public static final String INSTANCE = "instance";
    public static final String ENCRYPT = "encrypt";
    public static final String TRUST_SERVER_CERTIFICATE = "trustservercertificate";

    public static final String DB_ADMINISTRATOR_USER_NAME = "administrator.user.name";
    public static final String DB_ADMINISTRATOR_PASSWORD = "administrator.password";

    public static final String MSSQL_TYPE = "mssql";
    public static final String ORACLE_TYPE = "oracle";
    public static final String POSTGRES_TYPE = "postgres";
    public static final String MSSQL_AZURE_TYPE = "mssqlazure";

    private static final String JDBC_SQLSERVER_URL_PREFIX = "jdbc:sqlserver://";
    private static final String JDBC_ORACLE_URL_PREFIX = "jdbc:oracle:thin:@";
    private static final String JDBC_POSTGRESQL_URL_PREFIX = "jdbc:postgresql://";

    private static final Map<String, DataSource> cache = Collections.synchronizedMap(new LinkedHashMap<>(256));
    private static StringEncrypter stringEncrypter;

    protected JdbcTemplate jdbcTemplate;
    protected String scriptDelimiter = DEFAULT_DELIMITER;

    protected Consumer<List<Map<String, Object>>> queryConsumer;
    private int fetchSize;

    public boolean isInitialized() {
        return jdbcTemplate != null;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public static synchronized void dataSource(String url, DataSource dataSource) {
        cache.put(url, dataSource);
    }

    public static DataSource dataSource(String url) {
        return cache.get(url);
    }

    public static DataSource dataSource(Properties properties) {
        final String url = properties.getProperty(URL);
        DataSource dataSource = dataSource(url);
        if (dataSource == null) {
            final DriverManagerDataSource dds = new DriverManagerDataSource();
            dds.setUrl(url);
            dds.setUsername(properties.getProperty(USERNAME));
            dds.setPassword(properties.getProperty(PASSWORD));
            dds.setDriverClassName(properties.getProperty(DRIVER_CLASS_NAME));
            dds.setConnectionProperties(properties);
            dataSource = dds;
            dataSource(url, dataSource);
        }
        return dataSource;
    }

    public static JdbcTemplate newJdbcTemplate(Properties properties) {
        final DataSource dataSource = dataSource(properties);
        return new JdbcTemplate(dataSource);
    }

    public static JdbcTemplate newJdbcTemplate(String url) {
        final DataSource dataSource = dataSource(url);
        if (dataSource == null) {
            throw new IllegalStateException(String.format("No dataSource found for: '%s'", url));
        }
        return new JdbcTemplate(dataSource);
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public SqlContext jdbcTemplate(JdbcTemplate jdbcTemplate) {
        setJdbcTemplate(jdbcTemplate);
        return this;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }
    public SqlContext fetchSize(int fetchSize) {
        setFetchSize(fetchSize);
        return this;
    }

    String lookupDriver(Properties properties) {
        String driver = properties.getProperty(DRIVER_CLASS_NAME);
        if (driver == null) {
            driver = properties.getProperty(DRIVER);
        }
        if (driver != null) {
            properties.setProperty(DRIVER_CLASS_NAME, driver);
            return driver;
        }
        String property = properties.getProperty(DATABASE_TYPE);
        if (property != null) {
            if (property.equalsIgnoreCase("mssql")) {
                driver = MSSQL_DEFAULT_DRIVER;
            } else if (property.equalsIgnoreCase("oracle")) {
                driver = ORACLE_DEFAULT_DRIVER;
            } else if (property.equalsIgnoreCase("postgres")) {
                driver = POSTGRES_DEFAULT_DRIVER;
            }
        }
        if (driver != null) {
            properties.setProperty(DRIVER_CLASS_NAME, driver);
            return driver;
        }
        property = properties.getProperty(URL);
        if (property != null) {
            if (property.startsWith(JDBC_SQLSERVER_URL_PREFIX)) {
                driver = MSSQL_DEFAULT_DRIVER;
            } else if (property.startsWith(JDBC_ORACLE_URL_PREFIX)) {
                driver = ORACLE_DEFAULT_DRIVER;
            } else if (property.startsWith(JDBC_POSTGRESQL_URL_PREFIX)) {
                driver = POSTGRES_DEFAULT_DRIVER;
            }
        }
        if (driver != null) {
            properties.setProperty(DRIVER_CLASS_NAME, driver);
        }
        return driver;
    }

    public static synchronized StringEncrypter getDecrypter() throws EncryptionException {
        if (stringEncrypter == null) {
            stringEncrypter = new StringEncrypter();
        }
        return stringEncrypter;
    }

    public SqlContext jdbcTemplate(Properties properties) {
        String driver = lookupDriver(properties);
        if (isOracle(driver)) {
            oracleDelimiter();
        } else if (isAzure(driver) || isMsSql(driver)) {
            mssqlDelimiter();
        }
        try {
            String password = properties.getProperty(PASSWORD);
            password = getDecrypter().resolveDecrypted(password);
            properties.put(PASSWORD, password);
        } catch (EncryptionException e) {
            logger.debug("Failed to decrypt value", e);
        }
        String url = properties.getProperty(URL);
        if (url == null) {
            url = generateUrl(lookupDatabaseType(properties, Collections.emptyMap()), properties);
            properties.setProperty(URL, url);
        }
        setJdbcTemplate(newJdbcTemplate(properties));
        return this;
    }

    public SqlContext dbProperties(Properties properties) {
        jdbcTemplate(properties);
        return this;
    }
    public SqlContext dbProperties(String file) throws IOException {
        final Properties properties = new Properties();
        try (final InputStream ios = new FileResourceContentResolver().toStream(file)) {
            properties.load(ios);
        }
        jdbcTemplate(properties);
        return this;
    }

    public SqlContext jdbcTemplate(String url) {
        setJdbcTemplate(newJdbcTemplate(url));
        return this;
    }

    public String getScriptDelimiter() {
        return scriptDelimiter;
    }

    public void setScriptDelimiter(String scriptDelimiter) {
        this.scriptDelimiter = scriptDelimiter;
    }

    public SqlContext scriptDelimiter(String scriptDelimiter) {
        setScriptDelimiter(scriptDelimiter);
        return this;
    }

    public SqlContext oracleDelimiter() {
        setScriptDelimiter(ORACLE_DELIMITER);
        return this;
    }

    public SqlContext mssqlDelimiter() {
        setScriptDelimiter(MSSQL_DELIMITER);
        return this;
    }

    public Consumer<List<Map<String, Object>>> getQueryConsumer() {
        return queryConsumer;
    }

    public void setQueryConsumer(Consumer<List<Map<String, Object>>> queryConsumer) {
        this.queryConsumer = queryConsumer;
    }

    public SqlContext queryConsumer(Consumer<List<Map<String, Object>>> queryConsumer) {
        setQueryConsumer(queryConsumer);
        return this;
    }

    protected String stripComments(final List<String> list) {
        final StringBuilder builder = new StringBuilder();
        for (final String line : list) {
            if (!line.startsWith("//") && !line.startsWith("--")) {
                builder.append(line).append(LINE_BREAK);
            }
        }
        return builder.toString().stripTrailing();
    }

    protected List<Map<String, Object>> doQuery(String script) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        script = script.trim();
        List<Map<String, Object>> results = Collections.emptyList();
        if (StringUtils.hasText(script)) {
            logger.debug("SQL query: '{}'", script);
            checkWriteExecutedQuery(script);
            if (fetchSize > 0) {
                jdbcTemplate.setFetchSize(fetchSize);
            }
            results = jdbcTemplate.queryForList(script, (Object[])null);
            if (queryConsumer != null) {
                queryConsumer.accept(results);
            } else {
                addQueryResults(results);
            }
        }
        return results;
    }

    @SuppressWarnings("unchecked")
    public synchronized List<Map<String, Object>> queryResultsList() {
        final Object obj = values.get(QUERY_RESULTS);
        if (obj != null) {
            return (List<Map<String, Object>>) obj;
        } else {
            final List<Map<String, Object>> qr = new ArrayList<>();
            add(QUERY_RESULTS, qr);
            return qr;
        }
    }

    void addQueryResults(List<Map<String, Object>> results) {
        if (!results.isEmpty()) {
            final List<Map<String, Object>> queryResults = queryResultsList();
            queryResults.addAll(results);
        }
    }

    protected String[] toScripts(List<String> lines, String delimiter) {
        final String[] strings = StringUtils.delimitedListToStringArray(stripComments(lines), delimiter);
        final List<String> list = new ArrayList<>(lines.size());
        for (String string : strings) {
            string = string.stripTrailing().stripLeading();
            if (StringUtils.hasText(string)) {
                list.add(string);
            }
        }
        return list.toArray(new String[0]);
    }

    void checkWriteExecutedQuery(String script) {
        if (queryConsumer instanceof CsvWriterConsumer) {
            final CsvWriterConsumer writer = (CsvWriterConsumer) queryConsumer;
            writer.csvWriter.writeLine(
                    "# " + Patterns.of("\n").matcher(script).replaceAll(" ")
            );
            writer.csvWriter.columns(null);
        }
    }

    protected String[] toScripts(List<String> lines) {
        return toScripts(lines, scriptDelimiter);
    }

    public List<Map<String, Object>> query(final List<String> lines) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        final List<Map<String, Object>> results = new ArrayList<>(1024);
        final String[] scripts = toScripts(lines);
        for (String script : scripts) {
            results.addAll(doQuery(script));
        }
        return results;
    }

    public List<Map<String, Object>> query(final InputStream inputStream) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            return query(reader.lines().collect(Collectors.toList()));
        }
    }

    Path toCsvFileName(String fileName) {
        Path dPath = destinationPath();
        if (dPath == null) {
            final String pDestination = parentDestination();
            if (pDestination != null) {
                dPath = Paths.get(pDestination);
            } else {
                throw new IllegalArgumentException("Destination not defined for context");
            }
        }
        return Utils.checkTimeSuffixedPath(dPath,
                Patterns.of("[^\\w]").matcher(fileName).replaceAll("_"), "csv");
    }

    public void queryFrom(final String resource) throws Exception {
        final String fileName = resolveVariable(resource);
        if (queryConsumer == null) {
            csvQueryConsumer(toCsvFileName(fileName));
        }
        try (final BufferedReader reader = new BufferedReader(new InputStreamReader(new FileResourceContentResolver().toStream(fileName)))) {
            final String[] scripts = toScripts(reader.lines().collect(Collectors.toList()));
            for (String script : scripts) {
                doQuery(script);
            }
        } finally {
            if (queryConsumer instanceof AutoCloseable) {
                ((AutoCloseable) queryConsumer).close();
                queryConsumer = null;
            }
        }
    }

    public List<Map<String, Object>> query(@Language("SQL") String query) {
        return query(Arrays.asList(GroovyUtil.lookupText(query).split(LINE_BREAK)));
    }

    public SqlContext csvQueryConsumer(Path path, String... cols) throws IOException {
        queryConsumer = new CsvWriterConsumer(path, cols);
        add(path);
        return this;
    }

    public SqlContext csvQueryConsumer(String... cols) throws IOException {
        return csvQueryConsumer(toCsvFileName("query"), cols);
    }

    public SqlContext jsonQueryConsumer(Path path) {
        queryConsumer = list -> {
            if (!list.isEmpty()) {
                try (final JsonWriter writer = JsonWriter.of(Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.APPEND))) {
                    writer.write(list);
                } catch (IOException e) {
                    throw new SupportRuntimeException(String.format("Failed to write data to file: '%s'", path), e);
                }
            }
        };
        return this;
    }

    public SqlContext jsonQueryConsumer(String path) {
        return jsonQueryConsumer(Paths.get(path));
    }

    public SqlContext jsonQueryConsumer() {
        return jsonQueryConsumer(Utils.checkTimeSuffixedPath(destinationPath(), "query", "json"));
    }

    private Properties databaseInfo(Connection connection, Properties dProps) throws SQLException {
        final DatabaseMetaData metaData = connection.getMetaData();
        dProps.put("UserName", metaData.getUserName());
        dProps.put("URL", metaData.getURL());
        dProps.put("DatabaseProductName", metaData.getDatabaseProductName());
        dProps.put("DatabaseProductVersion", metaData.getDatabaseProductVersion());
        dProps.put(DRIVER_NAME, metaData.getDriverName());
        dProps.put("DriverVersion", metaData.getDriverVersion());
        dProps.put("DriverMinorVersion", metaData.getDriverMinorVersion());
        dProps.put("DriverMajorVersion", metaData.getDriverMajorVersion());
        dProps.put("DatabaseMinorVersion", metaData.getDatabaseMinorVersion());
        dProps.put("DatabaseMajorVersion", metaData.getDatabaseMajorVersion());
        return dProps;
    }

    public Properties databaseInfo() {
        final Properties dProps = new Properties();
        final DataSource dataSource = jdbcTemplate.getDataSource();
        if (dataSource == null) {
            return dProps;
        }
        try (final Connection connection = dataSource.getConnection()) {
            return databaseInfo(connection, dProps);
        } catch (Exception e) {
            throw new SupportRuntimeException("Failed to get database info", e);
        }
    }

    public List<String> initialize(String[] args) throws IOException {
        prefix("sql-");
        String dbPropertiesFile = null;
        List<String> scripts = new ArrayList<>();
        for (final String arg : args) {
            final String larg = arg.toLowerCase();
            if (larg.endsWith(".properties") || larg.endsWith(".conf")) {
                dbPropertiesFile = arg;
            } else if (larg.endsWith(".sql")) {
                scripts.add(arg);
            }
        }
        if (dbPropertiesFile != null) {
            dbProperties(dbPropertiesFile);
        }
        if (!isInitialized()) {
            throw new IllegalStateException("Sql context is not initialized");
        }
        return scripts;
    }

    private static boolean isDriverOfType(Properties dbProps, final String type) {
        boolean result = false;
        final Pattern pattern = Patterns.of(type, Pattern.CASE_INSENSITIVE);
        String driverName = dbProps.getProperty(DRIVER_NAME);
        if (driverName != null) {
            result = pattern.matcher(driverName).find();
        } else {
            driverName = dbProps.getProperty(DATABASE_TYPE);
            if (driverName != null) {
                result = pattern.matcher(driverName).find();
            }
        }
        return result;
    }

    public boolean isOracle() {
        return isDriverOfType(databaseInfo(), "oracle");
    }

    public boolean isMssql() {
        return isDriverOfType(databaseInfo(), "mssql|microsoft");
    }

    public static boolean isOracle(String value) {
        return value != null && value.toLowerCase().contains("oracle");
    }

    public static boolean isPostgres(String value) {
        return value != null && (value.toLowerCase().contains("postgres") || value.toLowerCase().contains("pgsql"));
    }

    public static boolean isAzure(String value) {
        if (value == null) {
            return false;
        }
        return value.toLowerCase().contains("azure");
    }

    @SuppressWarnings("squid:S1845")
    public static boolean isMsSql(String value) {
        if (value == null) {
            return false;
        }
        value = value.toLowerCase();
        return (value.contains("mssql") || value.contains("sqlserver"));
    }

    public static String lookupDatabaseType(Map properties, Map generalProperties) {
        String type = org.apache.commons.lang.StringUtils.defaultIfEmpty(
                (String) properties.get(DATABASE_TYPE),
                org.apache.commons.lang.StringUtils.defaultIfEmpty((String) generalProperties.get(DATABASE_TYPE), null)
        );
        if (type == null) {
            final String property = (String) properties.get(DRIVER);
            if (property != null) {
                if (property.equalsIgnoreCase(MSSQL_DEFAULT_DRIVER)) {
                    type = MSSQL_TYPE;
                } else if (property.equalsIgnoreCase(ORACLE_DEFAULT_DRIVER)) {
                    type = ORACLE_TYPE;
                } else if (property.equalsIgnoreCase(POSTGRES_DEFAULT_DRIVER)) {
                    type = POSTGRES_TYPE;
                }
            }
        }
        if (type == null) {
            type = MSSQL_TYPE;
        }
        return type;
    }

    public static String lookupDriver(Map properties, Map generalProperties) {
        String driver = (String) properties.get(DRIVER);
        if (driver == null) {
            driver = (String) generalProperties.get(DRIVER);
        }
        if (driver == null) {
            final String dbType = lookupDatabaseType(properties, generalProperties).toLowerCase();
            if (dbType.startsWith(ORACLE_TYPE)) {
                driver = ORACLE_DEFAULT_DRIVER;
            } else if (dbType.startsWith(MSSQL_TYPE)) {
                driver = MSSQL_DEFAULT_DRIVER;
            } else if (isPostgres(dbType)) {
                driver = POSTGRES_DEFAULT_DRIVER;
            } else {
                throw new IllegalArgumentException(String.format("Invalid value [%s] for database property '%s'.", dbType, DATABASE_TYPE));
            }
        }
        return driver;
    }

    public static String generatePostgresUrl(Properties properties) {
        return SqlContext.generatePostgresUrl((Map) properties);
    }

    public static String generateUrl(String dbType, Map properties) {
        final String dType = dbType.toLowerCase();
        if (dType.startsWith(ORACLE_TYPE)) {
            return generateOracleUrl(properties);
        } else if (dType.startsWith(MSSQL_TYPE)) {
            return generateSqlServerUrl(properties);
        } else if (isPostgres(dType)) {
            return generatePostgresUrl(properties);
        } else {
            return null;
        }
    }

    public static String generateSqlServerUrl(Properties properties) {
        return SqlContext.generateSqlServerUrl((Map) properties);
    }

    public static String generateOracleUrl(Properties properties) {
        return SqlContext.generateOracleUrl((Map) properties);
    }

    public static String getDbSuperuser(Properties properties) {
        return properties.getProperty(DB_ADMINISTRATOR_USER_NAME);
    }

    public static boolean isDbSuperuserProvided(Properties properties) {
        final String superUser = properties.getProperty(DB_ADMINISTRATOR_USER_NAME);
        return org.apache.commons.lang.StringUtils.isNotBlank(superUser);
    }

    public static String getDbSuperuserPass(Properties properties) {
        return properties.getProperty(DB_ADMINISTRATOR_PASSWORD);
    }

    public static boolean isDbSuperuserPassProvided(Properties properties) {
        final String superUserPass = properties.getProperty(DB_ADMINISTRATOR_PASSWORD);
        return org.apache.commons.lang.StringUtils.isNotBlank(superUserPass);
    }

    public static boolean isCaseInsensitive(Properties dbProperties) {
        boolean caseInsensitive = false;
        final String property = "case.insensitive.indexes";
        final String value = dbProperties.getProperty(property);
        if (value != null && value.equalsIgnoreCase("true")) {
            caseInsensitive = true;
        }
        return caseInsensitive;
    }

    public static boolean isPartitioned(Properties dbProperties) {
        boolean partitioned = false;
        final String property = "schema.partition";
        final String value = dbProperties.getProperty(property);
        if (value != null && value.equalsIgnoreCase("true")) {
            partitioned = true;
        }
        return partitioned;
    }

    public static void lookupDatabaseType(Properties connectionProperties) {
        connectionProperties.getProperty(DATABASE_TYPE);
    }

    static String lookupServer(Map properties) {
        return org.apache.commons.lang.StringUtils.defaultIfEmpty((String) properties.get(SERVER), "localhost");
    }
    public static String generateSqlServerUrl(Map properties) {
        final StringBuilder sb = new StringBuilder();
        sb.append(JDBC_SQLSERVER_URL_PREFIX);
        sb.append(lookupServer(properties));
        final String instanceName = (String) properties.get(INSTANCE);
        if (org.apache.commons.lang.StringUtils.isNotEmpty(instanceName)) {
            sb.append("\\").append(instanceName);
        }
        sb.append(":").append(org.apache.commons.lang.StringUtils.defaultIfEmpty((String) properties.get(PORT), "1433"));
        sb.append(";databaseName=").append(Objects.requireNonNull(properties.get(DATABASE), String.format("'%s' property is missing.", DATABASE)));
        sb.append(";sendStringParametersAsUnicode=false"); // bug 70601, crease the TM performance on SQL Server
        sb.append(";disableStatementPooling=").append("false");
        sb.append(";statementPoolingCacheSize=").append("999999");
        sb.append(";").append(ENCRYPT).append("=").append(org.apache.commons.lang.StringUtils.defaultIfEmpty((String) properties.get(ENCRYPT), "false"));
        sb.append(";").append(TRUST_SERVER_CERTIFICATE).append("=").append(org.apache.commons.lang.StringUtils.defaultIfEmpty((String) properties.get(TRUST_SERVER_CERTIFICATE), "true"));
        return sb.toString();
    }
    public static String generateOracleUrl(Map properties) {
        //jdbc:oracle:thin:@db.oracle.com:1521/mydb
        if (properties.containsKey(URL)) {
            return properties.get(URL).toString();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(JDBC_ORACLE_URL_PREFIX).append(lookupServer(properties));
        sb.append(":").append(org.apache.commons.lang.StringUtils.defaultIfEmpty((String) properties.get(PORT), "1521"));
        sb.append("/").append(Objects.requireNonNull(properties.get(INSTANCE), String.format("'%s' property is missing.", INSTANCE)));
        return sb.toString();
    }
    public static String generatePostgresUrl(Map properties) {
        //jdbc:postgresql://host:port/database
        final StringBuilder sb = new StringBuilder();
        sb.append(JDBC_POSTGRESQL_URL_PREFIX).append(lookupServer(properties));
        final String port = (String) properties.get(PORT);
        if (org.apache.commons.lang.StringUtils.isNotEmpty(port)) {
            sb.append(":").append(port);
        }
        sb.append("/").append(Objects.requireNonNull(properties.get(DATABASE), String.format("'%s' property is missing.", DATABASE)));
        return sb.toString();
    }

    static class CsvWriterConsumer implements Consumer<List<Map<String, Object>>>, AutoCloseable {
        private final CsvWriter csvWriter;

        public CsvWriterConsumer(Path path, String... cols) throws IOException {
            csvWriter = CsvWriter.of(new FileWriter(path.toFile()), cols);
        }

        public CsvWriterConsumer(CsvWriter csvWriter) {
            this.csvWriter = csvWriter;
        }

        @Override
        public void accept(List<Map<String, Object>> list) {
            if (list.isEmpty()) {
                return;
            }
            for (final Map<String, ?> map : list) {
                csvWriter.write(map);
            }
            csvWriter.columns(Collections.emptyList());
        }

        public void flush() {
            csvWriter.flush();
        }

        @Override
        public void close() throws Exception {
            csvWriter.close();
        }
    }
}
