package com.edifecs.support.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ZipContentResolver implements ContentResolver {
    private ZipWalker zipWalker;
    String absolutePath;

    public ZipContentResolver(String absolutePath) {
        this.absolutePath = absolutePath;
    }

    public ZipContentResolver(ZipWalker zipWalker) {
        this.zipWalker = zipWalker;
    }

    @Override
    public InputStream toStream(final String relativePath) throws IOException {
        return new ZipWalkerEntryInputStream(zipWalker.getZipWalkerEntry(relativePath));
    }

    public ZipWalkerInputStream toStream() throws IOException {
        return new ZipWalkerInputStream(ZipWalker.of(ZipWalker.resolveBaseZip(absolutePath)), ZipWalker.resolveRelativePath(absolutePath));
    }

    public byte[] toBytes(String relativePath) throws IOException {
        return zipWalker.toBytes(relativePath);
    }

    public byte[] toBytes() throws IOException {
        try (final ZipWalker walker = ZipWalker.of(ZipWalker.resolveBaseZip(absolutePath))) {
            return walker.toBytes(ZipWalker.resolveRelativePath(absolutePath));
        }
    }

    public Properties toProperties(String relativePath) throws IOException {
        Properties properties = new Properties();
        try (final ZipWalker.ZipWalkerEntry zipWalkerEntry = zipWalker.getZipWalkerEntry(relativePath);
             final InputStream inputStream = zipWalkerEntry.getInputStream()) {
            properties.load(inputStream);
        }
        return properties;
    }

    public Properties toProperties() throws IOException {
        Properties properties = new Properties();
        try (final InputStream inputStream = toStream()) {
            properties.load(inputStream);
        }
        return properties;
    }

    public static InputStream stream(String absolutePath) throws IOException {
        return new ZipContentResolver(absolutePath).toStream();
    }
    public static String text(String absolutePath) throws IOException {
        return new String(new ZipContentResolver(absolutePath).toBytes());
    }

    private static class ZipWalkerEntryInputStream extends InputStream {
        protected final ZipWalker.ZipWalkerEntry zipWalkerEntry;
        protected final InputStream inputStream;

        private ZipWalkerEntryInputStream(ZipWalker.ZipWalkerEntry zipWalkerEntry) throws IOException {
            this.zipWalkerEntry = zipWalkerEntry;
            this.inputStream = zipWalkerEntry.getInputStream();
        }

        @Override
        public int read() throws IOException {
            return inputStream.read();
        }

        @Override
        public int read(byte[] b) throws IOException {
            return inputStream.read(b);
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            return inputStream.read(b, off, len);
        }

        @Override
        public long skip(long n) throws IOException {
            return inputStream.skip(n);
        }

        @Override
        public int available() throws IOException {
            return inputStream.available();
        }

        @Override
        public synchronized void mark(int readlimit) {
            inputStream.mark(readlimit);
        }

        @Override
        public synchronized void reset() throws IOException {
            inputStream.reset();
        }

        @Override
        public boolean markSupported() {
            return inputStream.markSupported();
        }

        @Override
        public void close() throws IOException {
            try {
                inputStream.close();
            } finally {
                zipWalkerEntry.close();
            }
        }
    }

    private static class ZipWalkerInputStream extends ZipWalkerEntryInputStream {
        private final ZipWalker zipWalker;

        private ZipWalkerInputStream(ZipWalker zipWalker, String entryName) throws IOException {
            super(zipWalker.getZipWalkerEntry(entryName));
            this.zipWalker = zipWalker;
        }

        @Override
        public void close() throws IOException {
            try {
                super.close();
            } finally {
                zipWalker.close();
            }
        }
    }
}
