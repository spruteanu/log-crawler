package com.edifecs.support.core;

import org.apache.commons.io.IOUtils;

import java.io.*;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public interface ContentResolver {
    InputStream toStream(String relativePath) throws IOException;

    default String toString(String relativePath) throws IOException {
        try (StringWriter writer = new StringWriter()) {
            IOUtils.copy(toReader(relativePath), writer);
            return writer.toString();
        }
    }

    default Reader toReader(String relativePath) throws IOException {
        return new InputStreamReader(toStream(relativePath));
    }
}
