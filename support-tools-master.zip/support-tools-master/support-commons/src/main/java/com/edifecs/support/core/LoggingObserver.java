package com.edifecs.support.core;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author Serge Pruteanu
 */
@SuppressWarnings({"squid:S2629", "squid:S864", "squid:S3457"})
@Component
public class LoggingObserver implements OutputObserver {
    private final Logger logger;

    public LoggingObserver() {
        this(LogManager.getLogger(LoggingObserver.class));
    }

    public LoggingObserver(Logger logger) {
        this.logger = logger;
    }

    static String propertiesToString(Map<String, String> properties) {
        return properties != null && properties.size() > 0 ? " Details: " + properties : "";
    }

    void info(String message, Map<String, String> properties) {
        logger.debug(message + propertiesToString(properties));
    }

    @Override
    public void onFinished(String message, Map<String, String> properties) {
        info(message, properties);
    }

    @Override
    public void onProgress(String message, Map<String, String> properties) {
        info(message, properties);
    }

    void error(String message, Map<String, String> properties) {
        logger.debug(message + (propertiesToString(properties)));
    }

    @Override
    public void onError(String message, Map<String, String> properties) {
        error(message, properties);
    }

    @Override
    public void onError(String message, Exception e, Map<String, String> properties) {
        logger.debug(message + (propertiesToString(properties)), e);
    }

    @Override
    public String getOutput() {
        return null;
    }
}
