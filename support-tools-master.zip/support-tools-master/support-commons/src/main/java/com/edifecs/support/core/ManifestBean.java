package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.jar.JarInputStream;
import java.util.jar.Manifest;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ManifestBean {
    private final Manifest manifest;

    private ManifestBean(Manifest manifest) {
        this.manifest = manifest;
    }

    public static ManifestBean of(InputStream inputStream) {
        try (JarInputStream jarInputStream = new JarInputStream(inputStream)) {
            return new ManifestBean(jarInputStream.getManifest());
        } catch (Exception e) {
            throw new SupportRuntimeException("Couldn't read Manifest file", e);
        }
    }

    public String getManifestProperty(String property) {
        if (manifest != null) {
            return manifest.getMainAttributes().getValue(property);
        }
        return null;
    }

    public boolean propertyEquals(String propertyName, String propertyValue) {
        if (propertyValue != null && manifest != null) {
            return propertyValue.equals(manifest.getMainAttributes().getValue(propertyName));
        }
        return false;
    }

    @SuppressWarnings({"squid:S1452", "squid:S1166", "squid:S2221"})
    public static ManifestBean findManifestInClasspath(String propName, String propValue) {
        Enumeration<URL> resources;
        try {
            resources = ManifestBean.class.getClassLoader().getResources("META-INF/MANIFEST.MF");
        } catch (IOException e) {
            return null;
        }
        while (resources.hasMoreElements()) {
            try {
                ManifestBean manifestBean = of(resources.nextElement().openStream());
                if (manifestBean.propertyEquals(propName, propValue)) {
                    return manifestBean;
                }
            } catch (Exception e) {
                // ignore this exception
            }
        }
        return null;
    }

}
