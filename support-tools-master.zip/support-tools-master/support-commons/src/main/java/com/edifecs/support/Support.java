package com.edifecs.support;

import com.edifecs.support.collect.InformationContext;
import com.edifecs.support.collect.SqlInfoContext;
import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import com.edifecs.support.fixture.FixtureContext;
import com.edifecs.support.fixture.SqlFixtureContext;
import com.edifecs.support.scripts.Metadata;
import com.edifecs.support.tool.ScriptUsageRuntimeException;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"rawtypes", "squid:S1121"})
public class Support {
    private static final Logger logger = LogManager.getLogger(Support.class);

    protected Support() {}

    public static Context info(@DelegatesTo(InformationContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof InformationContext) {
            return info(context, closure);
        }
        final Context ctx = context != null ? InformationContext.of().clone(context) : InformationContext.of();
        info(ctx, closure);
        return ctx;
    }

    public static Context info(Context context, @DelegatesTo(InformationContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static Context fixture(@DelegatesTo(FixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof FixtureContext) {
            return fixture(context, closure);
        }
        final Context ctx = context != null ? FixtureContext.of().clone(context) : FixtureContext.of();
        fixture(ctx, closure);
        return context;
    }

    @SuppressWarnings("squid:S4144")
    public static Context fixture(Context context, @DelegatesTo(FixtureContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static SqlInfoContext sqlInfo(@DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof SqlInfoContext) {
            return sqlInfo((SqlInfoContext) context, closure);
        }
        final SqlInfoContext ctx = context != null ? (SqlInfoContext) SqlInfoContext.of().clone(context) : SqlInfoContext.of();
        sqlInfo(ctx, closure);
        return ctx;
    }

    @SuppressWarnings("DuplicatedCode")
    public static SqlInfoContext sqlInfo(String url, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final SqlInfoContext ctx;
        if (context instanceof SqlInfoContext) {
            ctx = (SqlInfoContext) context;
        } else {
            ctx = context != null ? (SqlInfoContext) SqlInfoContext.of().clone(context) : SqlInfoContext.of();
        }
        ctx.jdbcTemplate(url);
        return sqlInfo(ctx, closure);
    }

    @SuppressWarnings("DuplicatedCode")
    public static SqlInfoContext sqlInfo(Properties properties, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final SqlInfoContext ctx;
        if (context instanceof SqlInfoContext) {
            ctx = (SqlInfoContext) context;
        } else {
            ctx = context != null ? (SqlInfoContext) SqlInfoContext.of().clone(context) : SqlInfoContext.of();
        }
        ctx.jdbcTemplate(properties);
        return sqlInfo(ctx, closure);
    }

    public static SqlInfoContext sqlInfo(SqlInfoContext context, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static SqlFixtureContext sqlFixture(@DelegatesTo(SqlFixtureContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof SqlFixtureContext) {
            return sqlFixture((SqlFixtureContext) context, closure);
        }
        final SqlFixtureContext ctx = context != null ? (SqlFixtureContext) SqlFixtureContext.of().clone(context) : SqlFixtureContext.of();
        sqlFixture(ctx, closure);
        return ctx;
    }

    @SuppressWarnings("DuplicatedCode")
    public static SqlFixtureContext sqlFixture(String url, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final SqlFixtureContext ctx;
        if (context instanceof SqlFixtureContext) {
            ctx = (SqlFixtureContext) context;
        } else {
            ctx = context != null ? (SqlFixtureContext) SqlFixtureContext.of().clone(context) : SqlFixtureContext.of();
        }
        ctx.jdbcTemplate(url);
        return sqlFixture(ctx, closure);
    }

    @SuppressWarnings("DuplicatedCode")
    public static SqlFixtureContext sqlFixture(Properties properties, @DelegatesTo(SqlInfoContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        final SqlFixtureContext ctx;
        if (context instanceof SqlFixtureContext) {
            ctx = (SqlFixtureContext) context;
        } else {
            ctx = context != null ? (SqlFixtureContext) SqlFixtureContext.of().clone(context) : SqlFixtureContext.of();
        }
        ctx.jdbcTemplate(properties);
        return sqlFixture(ctx, closure);
    }

    @SuppressWarnings("squid:S4144")
    public static SqlFixtureContext sqlFixture(SqlFixtureContext context, @DelegatesTo(SqlFixtureContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static <C extends Context> C execute(C context, String... args) {
        context.resolveVariable(""); // make sure that context is initialized
        for (final String script : context.getScripts()) {
            if (script.toLowerCase().contains("-h")) {
                throw new ScriptUsageRuntimeException(script);
            }
            logger.debug("Executing '{}'\n", Metadata.lookupScriptName(script));
            GroovyUtil.parseScript(script, context, GroovyUtil.lookupBinder(args));
        }
        if (context.hasErrors()) {
            logger.error("There are error(s) while scripts execution. Please check errors.map for more details.\n");
        }
        logger.info("Done. Info collected to '{}'", Optional.ofNullable(context.getDestination()).orElse("."));
        return context;
    }
    public static Context execute(Collection<String> scripts) {
        return execute(new InformationContext().scripts(scripts));
    }
    public static Context execute(String... scripts) {
        return execute(Arrays.asList(scripts));
    }

    public static Context execute(Metadata metadata, String... args) {
        if (metadata.hasPath()) {
            return execute(metadata.toScript(args));
        } else {
            final Context context = new InformationContext().scripts(Collections.singletonList(metadata.toScript()));
            return execute(context, args);
        }
    }
}
