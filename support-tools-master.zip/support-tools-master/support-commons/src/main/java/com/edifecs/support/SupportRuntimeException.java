package com.edifecs.support;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class SupportRuntimeException extends RuntimeException {
    protected boolean recoverable;

    public SupportRuntimeException() {
        super();
    }

    public SupportRuntimeException(String message) {
        super(message);
    }

    public SupportRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public SupportRuntimeException(Throwable cause) {
        super(cause);
    }

    public boolean isRecoverable() {
        return recoverable;
    }

    public void setRecoverable(boolean recoverable) {
        this.recoverable = recoverable;
    }
}
