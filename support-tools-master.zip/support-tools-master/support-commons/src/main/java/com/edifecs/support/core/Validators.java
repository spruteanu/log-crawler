package com.edifecs.support.core;

import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class Validators {
    private static final Pattern DEPENDENCY_SPLIT_PATTERN = Patterns.of("[\\.a-zA-Z+-]");
    private static final Pattern NON_DIGITS_PATTERN = Patterns.of("\\D");

    private static String nextInteger(Iterator<String> vit, String defaultValue) {
        String result = defaultValue;
        while (vit.hasNext()) {
            final String val = vit.next();
            if (val != null && val.length() > 0 && Character.isDigit(val.charAt(0))) {
                result = val;
                break;
            }
        }
        return result;
    }

    @SuppressWarnings({"squid:S3776", "squid:S135"})
    public static boolean matchesVersion(String version, String dependencyVersion, boolean relaxed) {
        if (StringUtils.isEmpty(dependencyVersion)) {
            return true;
        }
        if (StringUtils.isEmpty(version)) {
            return false;
        }
        boolean result = true;
        final String defVer = "0";
        final boolean nonStrict = dependencyVersion.trim().endsWith("+") || dependencyVersion.trim().endsWith("-") || relaxed;
        final List<String> depVersions = Arrays.asList(DEPENDENCY_SPLIT_PATTERN.split(dependencyVersion.trim()));
        final List<String> versions = Arrays.asList(DEPENDENCY_SPLIT_PATTERN.split(version.trim()));
        for (final Iterator<String> dit = depVersions.iterator(), vit = versions.iterator(); result && (dit.hasNext() || vit.hasNext()); ) {
            final String dver = nextInteger(dit, defVer);
            final String ver = nextInteger(vit, defVer);
            if (nonStrict) {
                final int cv = Integer.valueOf(ver).compareTo(Integer.valueOf(dver));
                if (relaxed) {
                    result = cv >= 0;
                } else if (dependencyVersion.endsWith("+")) {
                    result = cv >= 0;
                    if (cv > 0) {
                        break;
                    }
                }
                else {
                    result = cv <= 0;
                    if (result && cv != 0) {
                        break;
                    }
                }
            } else {
                result = dver.equals(ver);
            }
        }
        return result;
    }

    public static boolean matchesVersion(String version, String dependencyVersion) {
        return matchesVersion(version, dependencyVersion, false);
    }

    static String replaceNonDigits(String importingVersion) {
        return NON_DIGITS_PATTERN.matcher(importingVersion).replaceAll("");
    }
    public static int compareVersion(String importingVersion, String importedVersion) {
        int result = 0;
        final String padValue = "0";
        final String[] left = StringUtils.split(importingVersion, '.');
        final String[] right = StringUtils.split(importedVersion, '.');
        final int maxCount = Math.max(left.length, right.length);
        for (int i = 0; i < maxCount && result == 0; i++) {
            final String lp = i < left.length ? replaceNonDigits(left[i]) : padValue;
            final String rp = i < right.length ? replaceNonDigits(right[i]) : padValue;
            result = Integer.valueOf(StringUtils.defaultIfEmpty(lp, "" + Integer.MAX_VALUE))
                    .compareTo(Integer.valueOf(StringUtils.defaultIfEmpty(rp, "" + Integer.MAX_VALUE)));
        }
        return result;
    }

    public static boolean isVersionGreater(String importingVersion, String importedVersion) {
        return compareVersion(importingVersion, importedVersion) > 0;
    }

    public static boolean isVersionLess(String importingVersion, String importedVersion) {
        return compareVersion(importingVersion, importedVersion) < 0;
    }

}
