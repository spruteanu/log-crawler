package com.edifecs.support.core;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public interface ZipPackageReader {
    Package read(ZipWalker zipWalker);
}
