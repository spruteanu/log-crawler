package com.edifecs.support.core;

import com.edifecs.support.Storage;
import com.edifecs.support.SupportRuntimeException;
import com.edifecs.support.collect.ErrorInfo;
import com.edifecs.support.collect.ProcessInfo;
import com.edifecs.support.scripts.Metadata;
import groovy.lang.Binding;
import groovy.lang.Closure;
import groovy.lang.Script;
import groovy.util.DelegatingScript;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.intellij.lang.annotations.Language;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"rawtypes", "squid:S1121", "unused", "UnusedReturnValue"})
public abstract class Context implements Cloneable {
    public static final String DEFAULT_PREFIX = "support-";
    private static final String DESTINATION_PROPERTY = "destination";
    protected static Logger logger = LogManager.getLogger(Context.class);

    public static final String EC_ROOT_PATH = "ECRootPath";
    protected static final String GROOVY_EXTENSION = "groovy";

    protected String hostName;
    protected String source;
    protected String destination;

    protected MacroSubstitutionContentResolver variableResolver;
    protected Map<String, String> variables;
    protected OutputObserver observer;
    protected ContentResolver contentResolver = new FileResourceContentResolver();
    protected String scriptsDir;

    private Binding binding;

    protected Map<String, Object> values = new LinkedHashMap<>(256);
    protected Collection<String> scripts = new LinkedHashSet<>(10);

    protected ErrorInfo errors = new ErrorInfo();
    protected String prefix = DEFAULT_PREFIX;

    // Thread-local stack to track parent contexts during script inclusion/execution
    private static final ThreadLocal<Deque<Context>> PARENT_CONTEXT_STACK = ThreadLocal.withInitial(ArrayDeque::new);

    /**
     * Returns the current parent context bound to this thread (top of the stack), or null if none.
     */
    public static Context parentContext() {
        final Deque<Context> stack = PARENT_CONTEXT_STACK.get();
        return stack.peekLast();
    }

    /**
     * Returns the root parent context (bottom of the stack) for this thread, or null if none.
     */
    public static Context rootContext() {
        final Deque<Context> stack = PARENT_CONTEXT_STACK.get();
        return stack.peekFirst();
    }

    /** Pushes the given context onto the thread-local parent context stack. */
    static void pushContext(Object ctx) {
        if (ctx instanceof Context) {
            PARENT_CONTEXT_STACK.get().addLast((Context) ctx);
        }
    }

    /** Pops the current parent context from the thread-local stack if present. */
    static void popContext() {
        final Deque<Context> stack = PARENT_CONTEXT_STACK.get();
        if (!stack.isEmpty()) {
            stack.removeLast();
        }
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Context source(String source) {
        setSource(source);
        return this;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public Context hostName(String hostName) {
        setHostName(hostName);
        return this;
    }

    public static boolean isLocalHost(String hostName) {
        return Objects.equals(
                Optional.ofNullable(Utils.lookupLocalHostName()).orElse("").toLowerCase(),
                Optional.ofNullable(hostName).orElse("").toLowerCase()
        );
    }
    public boolean isLocalHost() {
        return isLocalHost(hostName);
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Context destination(String destination) {
        setDestination(destination);
        return this;
    }

    public String resolveVariable(String path) {
        checkVariableResolverCreated();
        return variableResolver.resolve(path);
    }

    public Path destinationPath() {
        if (destination == null) {
            return null;
        }
        Path dPath = Paths.get(resolveVariable(destination));
        if (!dPath.toFile().exists()) {
            dPath.toFile().mkdirs();
        }
        return dPath;
    }

    /**
     * Returns the first non-null/non-blank destination from the current parent context chain.
     * Traverses from the current parent (top of the stack) towards the root and returns the
     * destination of the first context that has it defined. If none is found, returns null.
     * The returned value has variables resolved in the context where it was defined.
     */
    public String parentDestination() {
        final Deque<Context> stack = PARENT_CONTEXT_STACK.get();
        if (stack == null || stack.isEmpty()) {
            return null;
        }
        for (Iterator<Context> it = stack.descendingIterator(); it.hasNext(); ) {
            Context ctx = it.next();
            final String dest = ctx.getDestination();
            if (StringUtils.isNotBlank(dest)) {
                return ctx.resolveVariable(dest);
            }
        }
        return null;
    }

    public void setVariableResolver(MacroSubstitutionContentResolver variableResolver) {
        this.variableResolver = variableResolver;
    }

    public Context variableResolver(MacroSubstitutionContentResolver variableResolver) {
        setVariableResolver(variableResolver);
        return this;
    }

    public void setObserver(OutputObserver observer) {
        this.observer = observer;
    }

    public Context observer(OutputObserver observer) {
        setObserver(observer);
        return this;
    }

    public void setContentResolver(ContentResolver contentResolver) {
        this.contentResolver = contentResolver;
    }

    public Context contentResolver(ContentResolver contentResolver) {
        setContentResolver(contentResolver);
        return this;
    }

    public void setScriptsDir(String scriptsDir) {
        this.scriptsDir = scriptsDir;
    }

    public Context scriptsDir(String scriptsDir) {
        setScriptsDir(scriptsDir);
        return this;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
    public Context prefix(String prefix) {
        String prev = this.prefix;
        setPrefix(prefix);
        if (!Objects.equals(prev, prefix) && destination != null && destination.contains(prev)) {
            destination = destination.replace(prev, prefix);
            if (variables != null) {
                variables.put(DESTINATION_PROPERTY, destination);
            }
        }
        return this;
    }

    protected void checkSourceDefined(Map<String, String> vars) {
        if (source == null) {
            source = vars.get(EC_ROOT_PATH);
            vars.put("source", source);
        }
    }

    public void withVariables(Map<String, String> vars) {
        checkSourceDefined(vars);
        if (destination == null) {
            destination = Utils.defaultDestination(Storage.defaultDestinationPath(), prefix).toString();
            vars.put(DESTINATION_PROPERTY, destination);
        }
        this.variables = new LinkedHashMap<>(vars);
        logger.debug("Using resolver variables: {}", this.variables);
        variableResolver = MacroSubstitutionContentResolver.of(this.variables);
    }

    public static String envVar(String var) {
        return System.getenv(var);
    }

    public static String systemVar(String var) {
        return System.getProperty(var);
    }

    protected Context defaultContext() {
        final Map<String, String> vars = envSystemVariables();
        if (hostName == null) {
            hostName = Utils.lookupHostName();
            vars.put("HOST", hostName);
        }
        withVariables(vars);
        return this;
    }

    public static Logger getLogger() {
        return logger;
    }

    public static Map<String, String> envSystemVariables() {
        final Map<String, String> vars = new LinkedHashMap<>(System.getenv());
        vars.putAll(Utils.fromProperties(System.getProperties()));
        return vars;
    }

    public static MacroSubstitutionContentResolver envSystemMacroResolver() {
        return new MacroSubstitutionContentResolver(envSystemVariables());
    }

    protected synchronized void checkVariableResolverCreated() {
        if (variableResolver == null) {
            defaultContext();
        }
    }

    public List<Path> findFiles(final Path path, final String wildcardPattern) throws IOException {
        return Directories.findAllFiles(path, wildcardPattern);
    }

    public List<Path> findFiles(final String path, final String wildcardPattern) throws IOException {
        return findFiles(Paths.get(resolveVariable(path)), wildcardPattern);
    }
    public List<Path> findFiles(final String path) throws IOException {
        return findFiles(path, "*"); // todo: implement wildcard detection in the path variable
    }

    public List<Path> findFiles(final Path path, final Predicate<Path> predicate) throws IOException {
        return Directories.findAllFiles(path, predicate);
    }

    public List<Path> findFiles(final String path, final Predicate<Path> predicate) throws IOException {
        return findFiles(Paths.get(resolveVariable(path)), predicate);
    }

    public void findFiles(final Path path, final Predicate<Path> predicate,
                          final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(path, predicate, filesFunction);
    }

    public void findFiles(final String path, final Predicate<Path> predicate,
                          final Consumer<Path> filesFunction) throws IOException {
        findFiles(Paths.get(resolveVariable(path)), predicate, filesFunction);
    }

    Object parseScript(String groovyScript, Object context, Binding binding) {
        return parseScript(groovyScript, context, binding, contentResolver);
    }

    Object parseScript(String groovyScript, Object context, Binding binding, ContentResolver contentResolver) {
        logger.debug("Executing script: '{}'", Metadata.lookupScriptName(groovyScript));
        if (scriptsDir != null || contentResolver == null) {
            return GroovyUtil.parseScript(resolveVariable(groovyScript), context, binding, scriptsDir);
        } else {
            return GroovyUtil.parseScript(resolveVariable(groovyScript), context, binding, contentResolver);
        }
    }

    private static Context lookupInstance(DelegatingScript delegate) {
        return lookupInstance(delegate.getDelegate());
    }

    private static Context lookupContext(Object delegate) {
        Context context = null;
        if (delegate instanceof Context) {
            context = (Context) delegate;
        }
        return context;
    }

    public static Context lookupInstance(Closure closure) {
        Object delegate = closure.getDelegate();
        Context context = lookupContext(delegate);
        if (context == null && delegate instanceof DelegatingScript) {
            context = lookupInstance(((DelegatingScript) delegate));
        }
        return context;
    }

    private static Context lookupInstance(Object delegate) {
        Context context;
        if (delegate instanceof Closure) {
            context = lookupInstance((Closure) delegate);
        } else if (delegate instanceof DelegatingScript) {
            context = lookupInstance((DelegatingScript) delegate);
//        } else if (delegate instanceof Script) { // todo: investigate how to resolve it
//            lookupContext(delegate.getBinding())
//            context = lookupInstance((Script) delegate);
        } else {
            context = lookupContext(delegate);
        }
        return context;
    }

    @SuppressWarnings("unchecked")
    public <O> O include(String groovyScript) {
        Object result;
        try {
            result = lookupResult(parseScript(groovyScript, this, new Binding(new String[0])));
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to include script: '%s'", groovyScript), e);
        }
        return (O) result;
    }

    static Object lookupResult(Object result) {
//        if (result instanceof Builder) { // todo: check if builder approach is applied
//            final Builder builder = (Builder) result;
//            result = builder.build();
//        }
        return result;
    }

    @SuppressWarnings({"unchecked", "squid:S2221"})
    public <O> O include(String groovyScript, Object parent, Binding binding) {
        Object result;
        Context context;
        if (parent == null) {
            context = this;
        } else {
            context = lookupInstance(parent);
        }
        // Track parent context in a thread-local stack so nested includes can access it
        pushContext(context);
        try {
            result = lookupResult(parseScript(groovyScript, context, binding != null ? binding : this.binding, contentResolver));
        } catch (SupportRuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to include script: '%s'", groovyScript), e);
        } finally {
            popContext();
        }
        return (O) result;
    }

    public <O> O include(String groovyScript, Object parent, Map<String, Object> vars) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(vars));
    }

    public <O> O include(String groovyScript, Script parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args));
    }

    public <O> O include(String groovyScript, Closure parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args));
    }

    public <O> O include(String groovyScript, Object parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args));
    }

    public <O> O include(String groovyScript, Map<String, Object> vars) {
        return include(groovyScript, this, vars);
    }

    public <O> O include(String groovyScript, String... args) {
        return include(groovyScript, this, GroovyUtil.lookupBinder(args));
    }

    public <O> O include(String groovyScript, Script parent) {
        return include(groovyScript, parent, (Binding) null);
    }

    public <O> O include(String groovyScript, Closure parent) {
        return include(groovyScript, parent, (Binding) null);
    }

    public <O> O include(String groovyScript, Object parent) {
        return include(groovyScript, parent, (Binding) null);
    }

    <O> O includeScript(@Language("groovy") String groovyScript) {
        return include(groovyScript, null, (Binding) null);
    }

    <O> O includeScript(@Language("groovy") String groovyScript, Object parent, Map<String, Object> vars) {
        return include(groovyScript, parent, vars);
    }

    <O> O includeScript(@Language("groovy") String groovyScript, Object parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args));
    }

    <O> O includeScript(@Language("groovy") String groovyScript, Object parent) {
        return include(groovyScript, parent, (Binding) null);
    }

    String[] resolveArguments(String... arguments) {
        String[] results = arguments;
        if (arguments != null && arguments.length > 0) {
            results = new String[arguments.length];
            for (int i = 0, length = arguments.length; i < length; i++) {
                results[i] = resolveVariable(arguments[i]);
            }
        }
        return results;
    }

    protected ProcessHelper withObserver(ProcessHelper helper) {
        return helper.withObserver(Optional.ofNullable(observer).orElse(new LoggingObserver())).withWsl();
    }

    public String shellOutput(String command, String... arguments) {
        String rCommand = resolveVariable(command);
        String[] rArguments = resolveArguments(arguments);
        final ProcessHelper helper = ProcessHelper.of(rCommand, rArguments).withLoggingObserver();
        try {
            return helper.executeAndGetResult(new ConsoleOutputObserver(true)).getOutput();
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to execute command: '%s'. Check logs for details.", helper), e);
        }
    }

    int doShell(String command, String... arguments) {
        final ProcessHelper helper = ProcessHelper.of(command, arguments).withLoggingObserver();
        try {
            return withObserver(helper).execute();
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to execute command: '%s'. Check logs for details.", helper), e);
        }
    }

    public int shell(String command, String... arguments) {
        String rCommand = resolveVariable(command);
        String[] rArguments = resolveArguments(arguments);
        return doShell(rCommand, rArguments);
    }

    int doShell(String workingDir, String command, String... arguments) {
        final ProcessHelper helper = new ProcessHelper(workingDir, command, arguments);
        try {
            return withObserver(helper).withDirectory(new File(workingDir)).execute();
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to execute command: '%s'. Check logs for details.", helper), e);
        }
    }

    public int shell(String workingDir, String command, String... arguments) {
        String rCommand = resolveVariable(command);
        String[] rArguments = resolveArguments(arguments);
        return doShell(resolveVariable(workingDir), rCommand, rArguments);
    }

    public static boolean isLinux() {
        return ProcessHelper.isLinux();
    }

    public static boolean isLinux(String hostName) {
        return ProcessHelper.isLinux(); // todo: implement determine isLinux based on hostName
    }

    public List<ProcessHandle> findProcess(final String processName) {
        return ProcessHelper.findBy(processName);
    }

    public List<Long> findProcessPids(final String processName) {
        return ProcessHelper.findPids(processName);
    }

    public List<ProcessHandle> findJavaProcess() {
        return ProcessHelper.findJava();
    }

    public List<Long> findJavaPids() {
        return ProcessHelper.findJavaPids();
    }

    public Context jps() {
        final String output = shellOutput(resolveVariable("${JAVA_HOME}/bin/jps"), "-lvm");
        final int length = output.length();
        if (length == 0) {
            return this;
        }
        for (String line : output.split("\\n")) {
            int i = line.indexOf(' ');
            if (i > 0) {
                long pid = Long.parseLong(line.substring(0, i));
                final ProcessInfo pi = new ProcessInfo();
                pi.setName("java");
                pi.setPid(pid);
                pi.setCommand(line.substring(i).trim());
                pi.setHandle(ProcessHelper.findBy(pid));
                add(String.valueOf(pid), pi);
            }
        }
        return this;
    }

    Stream<ProcessInfo> javaProcessInfoStream(Collection<?> collection, Predicate<ProcessInfo> predicate) {
        Stream<ProcessInfo> stream = collection.stream().filter(ProcessInfo.class::isInstance)
                .map(o -> (ProcessInfo) o).filter(pi -> "java".equalsIgnoreCase((pi).getName()));
        if (predicate != null) {
            stream = stream.filter(predicate);
        }
        return stream;
    }

    Stream<ProcessInfo> javaProcessInfoStream(Predicate<ProcessInfo> predicate) {
        return javaProcessInfoStream(values().values(), predicate);
    }

    Stream<ProcessInfo> javaProcessInfoStream() {
        return javaProcessInfoStream(null);
    }

    List<ProcessInfo> listJavaProcessInfo() {
        return javaProcessInfoStream().collect(Collectors.toList());
    }

    public List<ProcessInfo> findJavaProcess(final String className) {
        List<ProcessInfo> list = listJavaProcessInfo();
        final Predicate<ProcessInfo> classNamePredicate = pi -> pi.getCommand().contains(className);
        if (list.isEmpty()) {
            jps();
            list = javaProcessInfoStream(classNamePredicate).collect(Collectors.toList());
        } else {
            list = javaProcessInfoStream(list, classNamePredicate).collect(Collectors.toList());
        }
        return list;
    }

    protected static void validateArgs(final String description, String... args) {
        if (args == null || args.length == 0) {
            throw new IllegalStateException(description + " list is expected");
        }
    }

    public static void validateArgs(final String message, Predicate<String[]> predicate, String... args) {
        if (predicate.test(args)) {
            throw new IllegalStateException(message);
        }
    }

    public String jStack(final long pid) {
        String result;
        add("jstack-" + pid + ".trace", (result = shellOutput(resolveVariable("${JAVA_HOME}/bin/jstack"), "-l", "-e", String.valueOf(pid))));
        return result;
    }

    String _lsof(String prefix, long pid) {
        String result;
        if (isLinux()) {
            add(prefix + pid + ".lsof", (result = shellOutput(resolveVariable("lsof"), "-p", String.valueOf(pid))));
        } else {
            if (envVar("SYS_INTERNALS") == null) {
                throw new IllegalStateException("Microsoft SYS_INTERNALS tools (handle, listdlls) should be installed and SYS_INTERNALS variable should be defined");
            }
            add(prefix + pid + ".lsof", (result = shellOutput(resolveVariable("${SYS_INTERNALS}/handle"), "-p", String.valueOf(pid)) + "\n\n"));
            add(prefix + pid + ".lsof", (result += shellOutput(resolveVariable("${SYS_INTERNALS}/listdlls"), String.valueOf(pid))));
        }
        return result;
    }

    public String lsof(final long pid) {
        return _lsof("", pid);
    }

    public void lsof(final String... args) {
        validateArgs("PID(s) or process name", args);
        for (final String arg : args) {
            for (final String sArg : arg.split(",")) {
                if (StringUtils.isNumeric(sArg)) {
                    lsof(Long.parseLong(sArg.trim()));
                } else {
                    final List<ProcessHandle> process = findProcess(sArg);
                    for (final ProcessHandle ph : process) {
                        _lsof(sArg, ph.pid());
                    }
                }
            }
        }
    }

    public void javaLsof(String... args) {
        if (args != null && args.length > 0) {
            for (String filter : args) {
                for (ProcessInfo ph : findJavaProcess(filter)) {
                    _lsof("java-", ph.getPid());
                }
            }
        } else {
            for (ProcessHandle ph : findJavaProcess()) {
                _lsof("java-", ph.pid());
            }
        }
    }

    public Collection<String> getScripts() {
        return scripts;
    }

    public void setScripts(Collection<String> scripts) {
        this.scripts = scripts;
    }

    public Context scripts(Collection<String> scripts) {
        setScripts(scripts);
        return this;
    }

    public Context add(Map<String, Object> values) {
        if (values != null && this.values != null) {
            this.values.putAll(values);
        }
        return this;
    }

    public Context script(String scripts) {
        for (String script : scripts.split(",")) {
            if (!script.toLowerCase().endsWith(GROOVY_EXTENSION)) {
                script += GROOVY_EXTENSION;
            }
            this.scripts.add(script.toLowerCase().trim());
        }
        return this;
    }

    public Context add(String name, Object val) {
        values.put(name, val);
        return this;
    }

    public Context add(Path path) {
        add(path.toString(), path);
        return this;
    }

    public Context add(Collection<Path> path) {
        for (Path p : path) {
            add(p);
        }
        return this;
    }

    public String pathToKey(String path) {
        String result = path.replace(resolveVariable("${ECRootPath}"), "");
        result = result.replaceAll("[/\\\\]", "_");
        return result;
    }

    public Context error(String key, String error, String... errors) {
        this.errors.error(key, error, errors);
        return this;
    }

    public Context error(String key, Collection<String> errors) {
        this.errors.error(key, errors);
        return this;
    }
    public Context error(String key, String message, Closure<Boolean> errorPredicate) {
        final Object result = GroovyUtil.closureCall(errorPredicate, this);
        if (result instanceof Boolean) {
            final boolean pResult = (Boolean) result;
            if (pResult) {
                error(key, message);
            }
        } else {
            error(key, String.format("Invalid error predicate return for: '%s'", errorPredicate));
        }
        return this;
    }
    public Context errors(ErrorInfo errors) {
        if (errors != null) {
            this.errors.add(errors);
        }
        return this;
    }

    public boolean hasErrors(String key) {
        return errors.hasErrors(key);
    }

    public boolean hasErrors() {
        return errors.hasErrors();
    }

    public ErrorInfo getErrorInfo() {
        return errors;
    }

    public void setErrors(ErrorInfo errors) {
        this.errors = errors;
    }

    public Context withErrors(ErrorInfo errors) {
        setErrors(errors);
        return this;
    }

    public void validateVariable(String... vars) {
        validateArgs("Variables", vars);
        final String key = "missing.variables";
        for (final String var : vars) {
            if (!variables.containsKey(var)) {
                error(key, String.format("Missing '%s' variable", var));
            }
        }
    }

    public Map<String, Object> values() {
        return values;
    }

    public Context withValues(Map<String, Object> values) {
        this.values = values;
        return this;
    }

    public Object value(String name) {
        return values.get(name);
    }
    public boolean hasValues() {
        return values != null && !values.isEmpty();
    }
    public Context clone(Context source) {
        if (source == null) {
            return this;
        }
        source(source.getSource()).destination(source.getDestination()).hostName(source.getHostName());
        observer = source.observer;
        contentResolver = source.contentResolver;
        variableResolver = source.variableResolver;
        binding = source.binding;
        values = source.values;
        errors = source.errors;
        return this;
    }

    @Override
    public Context clone() {// NOSONAR
        try {
            return (Context) super.clone();
        } catch (Exception e) {
            throw new IllegalStateException("Clone failed for some reason", e);
        }
    }
}
