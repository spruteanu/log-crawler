package com.edifecs.support.tool;

import com.edifecs.support.Storage;
import com.edifecs.support.Support;
import com.edifecs.support.SupportRuntimeException;
import com.edifecs.support.collect.InformationContext;
import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import com.edifecs.support.core.ToolHelper;
import com.edifecs.support.core.Utils;
import com.edifecs.support.scripts.Metadata;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"unused", "squid:S2629"})
public class Tool {
    private static final Logger logger = LogManager.getLogger(Tool.class);
    private static Logger clLogger;
    static final String FAILURE_MSG = "Internal error. Please see logs for more details...";
    static final String SOURCE_OPTION = "source";
    static final String DESTINATION_OPTION = "destination";

    static final String ALL_LOGS_OPTION = "allLogs";
    static final String LOGS_OPTION = "logs";

    protected static Collection<String> collectScripts(ToolHelper toolHelper, Context context) {
        return new LinkedHashSet<>(toolHelper.getUnknownArguments());
    }

    static int execute(ToolHelper helper) {
        final InformationContext context = new InformationContext();
        if (helper.hasArgument(ALL_LOGS_OPTION)) {
            context.allLogsFilter();
        }
        if (helper.hasArgument(LOGS_OPTION)) {
            context.logFilter(helper.getOptionValue(LOGS_OPTION));
        }
        if (helper.hasArgument(SOURCE_OPTION)) {
            context.source(helper.getOptionValue(SOURCE_OPTION));
        }
        if (helper.hasArgument(DESTINATION_OPTION)) {
            context.destination(helper.getOptionValue(DESTINATION_OPTION));
        }
        context.scripts(collectScripts(helper, context));
        try {
            Support.execute(context);
            Storage.toDisk(context);
        } catch (ScriptUsageRuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new SupportRuntimeException(e);
        }
        return 0;
    }

    static boolean shouldShowUsage(ToolHelper toolHelper) {
        return toolHelper.hasArgument(ToolHelper.HELP);
    }

    static ToolHelper parseToolArguments(String... args) {
        return ToolHelper.Builder.of("script-runner")
                .withHeader(Arrays.asList(
                        "Edifecs Support Tools Version " + ToolHelper.getVersion() + " (ST).",
                        "Copyright (c) Edifecs, Inc " + Calendar.getInstance().get(Calendar.YEAR),
                        "\n"
                )).withUsage(Arrays.asList(
                        "Usage:",
                        "       script-runner [-source <source folder>] [-destination <results destination>] [\"[script] [arg1 arg2 argN]\"] [\"[scriptN] [arg1 arg2 argN]\"] [-verbose] [-debug] [-help]"
                ))
                .usingConsoleLogger("ConsoleAppender", "com.edifecs")
                .usingFileLogger("com.edifecs")
                .addOption(SOURCE_OPTION, "source folder", true, true)
                .addOption(DESTINATION_OPTION, "results destination", true, true)
                .build(args);
    }

    static void showScriptUsage(Metadata metadata) {
        clLogger.info("Script '{}' usage:\n", metadata.getPath());
        clLogger.info("\tName\t'{}'\n", metadata.getName());
        clLogger.info("\tDescription:\t'{}'\n", metadata.getDescription());
        clLogger.info("\tUsage:\t'{}'\n", metadata.getUsage());
        clLogger.info("\tAuthor:\t'{}'\n", metadata.getAuthor());
        final List<Map<String, Object>> arguments = metadata.getArguments();
        if (arguments != null) {
            clLogger.info("\tArguments:\n");
            for (Map<String, Object> argumentMap : arguments) {
                clLogger.info("\t\tName\t\t'{}'\n", argumentMap.get("name"));
                final Object required = argumentMap.get("required\n");
                clLogger.info("\t\t{}\n", required != null && Boolean.parseBoolean(required.toString()) ? "required" : "optional");
                clLogger.info("\t\tDescription\t\t'{}'\n", argumentMap.get("description"));
            }
        }
    }

    static void handleScriptUsageException(ScriptUsageRuntimeException e) {
        final GroovyUtil.GroovyScriptArgument argument = GroovyUtil.toGroovyScriptArgument(e.getScript());
        final Metadata metadata = Metadata.lookupScript(argument.getScript());
        showScriptUsage(metadata);
    }

    @SuppressWarnings("squid:S2221")
    static int doMain(String... args) {
        clLogger = LogManager.getLogger("ConsoleLine");
        int errorCode = 0;
        try {
            System.setProperty("log4j.defaultInitOverride", "true");
            final ToolHelper toolHelper = parseToolArguments(args);
            toolHelper.logHeader();
            if (shouldShowUsage(toolHelper)) {
                errorCode = 2;
                toolHelper.logUsage();
            }
            if (errorCode == 0) {
                errorCode = execute(toolHelper);
            }
        } catch (ScriptUsageRuntimeException e) {
            handleScriptUsageException(e);
            errorCode = 2;
        } catch (SupportRuntimeException e) {
            logger.debug(FAILURE_MSG, e);
            errorCode = 1;
        } catch (Exception e) {
            logger.debug(FAILURE_MSG, e);
            errorCode = -1;
        }
        if (errorCode != 0 && errorCode != 2) {
            clLogger.error("\n");
            clLogger.error(FAILURE_MSG);
            clLogger.error("\n");
        }
        return errorCode;
    }

    public static void main(String... args) {
        Utils.disableIllegalReflectiveAccessWarning();
        System.exit(doMain(args));
    }
}
