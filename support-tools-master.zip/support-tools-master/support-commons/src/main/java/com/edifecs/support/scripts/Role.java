/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.scripts;

import java.lang.annotation.*;

/**
 * Annotation used to mark scripts with one or more filters (capabilities, environments, etc.).
 * Example: @Filter("admin") or multiple repeatable usages.
 *
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(Roles.class)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
public @interface Role {
    String value();
}
