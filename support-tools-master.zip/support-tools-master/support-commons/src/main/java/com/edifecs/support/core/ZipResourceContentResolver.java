package com.edifecs.support.core;

import com.edifecs.support.SupportException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.stream.Collectors;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ZipResourceContentResolver implements ContentResolver {
    private ZipContentResolver zipContentResolver;

    public ZipResourceContentResolver(ZipContentResolver zipContentResolver) {
        this.zipContentResolver = zipContentResolver;
    }

    public void setZipContentResolver(ZipContentResolver zipContentResolver) {
        this.zipContentResolver = zipContentResolver;
    }

    public ZipResourceContentResolver zipContentResolver(ZipContentResolver zipContentResolver) {
        this.zipContentResolver = zipContentResolver;
        return this;
    }

    public boolean resourceExists(String path) {
        return this.getClass().getResource(path) != null;
    }

    @Override
    public InputStream toStream(String relativePath) throws IOException {
        final URL resource = this.getClass().getResource(relativePath);
        if (resource != null) {
            return resource.openStream();
        } else {
            return zipContentResolver.toStream(relativePath);
        }
    }

    @Override
    public String toString(String relativePath) throws IOException {
        final URL resource = SupportException.class.getResource(relativePath);
        if (resource != null) {
            try (final BufferedReader buffer = new BufferedReader(new InputStreamReader(resource.openStream()))) {
                return buffer.lines().collect(Collectors.joining("\n"));
            }
        } else {
            return zipContentResolver.toString(relativePath);
        }
    }
}
