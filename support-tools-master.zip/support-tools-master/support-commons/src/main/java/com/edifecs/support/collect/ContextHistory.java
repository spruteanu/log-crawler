/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.collect;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Map;

/**
 * Bean class representing script execution history information.
 * Contains information about executed scripts, destination path, and execution timestamp.
 *
 * @author Junie
 */
public class ContextHistory {

    private Collection<String> scripts;
    private transient LocalDateTime dateTime;
    private String output;
    private Map<String, Object> results;
    private String destination;
    private String server; // server name
    private transient String source;

    public ContextHistory() {
    }

    public ContextHistory(Collection<String> scripts, String destinationPath, LocalDateTime dateTime) {
        this.scripts = scripts;
        this.destination = destinationPath;
        this.dateTime = dateTime;
    }

    public ContextHistory(Collection<String> scripts, String destinationPath) {
        this(scripts, destinationPath, LocalDateTime.now());
    }

    /**
     * Gets the list of executed scripts.
     *
     * @return list of script names/paths
     */
    public Collection<String> getScripts() {
        return scripts;
    }

    /**
     * Sets the list of executed scripts.
     *
     * @param scripts list of script names/paths
     */
    public void setScripts(Collection<String> scripts) {
        this.scripts = scripts;
    }

    public ContextHistory scripts(Collection<String> scripts) {
        setScripts(scripts);
        return this;
    }

    /**
     * Gets the destination path where scripts were executed.
     *
     * @return destination path
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination path where scripts were executed.
     *
     * @param destination destination path
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public ContextHistory destination(String destination) {
        setDestination(destination);
        return this;
    }

    /**
     * Gets the execution file creation date and time.
     *
     * @return creation date and time
     */
    public LocalDateTime getDateTime() {
        return dateTime;
    }

    /**
     * Sets the execution file creation date and time.
     *
     * @param dateTime creation date and time
     */
    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public ContextHistory dateTime(LocalDateTime createdDateTime) {
        setDateTime(createdDateTime);
        return this;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public ContextHistory source(String source) {
        setSource(source);
        return this;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public ContextHistory server(String server) {
        setServer(server);
        return this;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }
    public ContextHistory output(String output) {
        setOutput(output);
        return this;
    }

    public Map<String, Object> getResults() {
        return results;
    }

    public void setResults(Map<String, Object> results) {
        this.results = results;
    }
    public ContextHistory results(Map<String, Object> results) {
        setResults(results);
        return this;
    }

    public String toContentString() {
        Gson gson = createGson();
        return gson.toJson(this);
    }

    private static Gson createGson() {
        return new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
                .create();
    }

    private static class LocalDateTimeAdapter extends TypeAdapter<LocalDateTime> {
        @Override
        public void write(JsonWriter out, LocalDateTime value) throws IOException {
            if (value == null) {
                out.nullValue();
            } else {
                out.value(value.toString());
            }
        }

        @Override
        public LocalDateTime read(JsonReader in) throws IOException {
            if (in.peek() == com.google.gson.stream.JsonToken.NULL) {
                in.nextNull();
                return null;
            }
            return LocalDateTime.parse(in.nextString());
        }
    }

    @Override
    public String toString() {
        return "HistoryScript{" +
                "scripts=" + scripts +
                ", destinationPath='" + destination + '\'' +
                ", execFileCreationDateTime=" + dateTime +
                '}';
    }

    private void lookupRemoteProperties() {
        if (results != null) {
            final Object s = results.get("server");
            if (s != null) {
                server((String) s);
                final String d = (String) results.get("destination");
                if (d != null) {
                    destination(d);
                }
            }
        }
    }

    public static ContextHistory of(Path path) throws IOException {
        try {
            String content = Files.readString(path);
            Gson gson = createGson();
            ContextHistory contextHistory = gson.fromJson(content, ContextHistory.class);

            // Set the source path
            contextHistory.source(path.toAbsolutePath().toString());

            // If dateTime is null, set it from file's last modified time
            if (contextHistory.getDateTime() == null) {
                LocalDateTime creationTime = LocalDateTime.ofInstant(
                        Files.readAttributes(path, BasicFileAttributes.class).lastModifiedTime().toInstant(),
                        java.time.ZoneId.systemDefault());
                contextHistory.dateTime(creationTime);
            }
            contextHistory.lookupRemoteProperties();
            return contextHistory;
        } catch (JsonSyntaxException e) {
            throw new IOException("Failed to parse JSON from file: " + path, e);
        }
    }
}
