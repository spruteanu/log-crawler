package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang.StringUtils;
import org.intellij.lang.annotations.Language;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.regex.Pattern;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"squid:S1192", "unused"})
public class CommonsFileComparator implements BiFunction<Path, Path, Difference> {
    private Predicate<String> contentFilter;
    private Predicate<String> lineFilter;

    private BiFunction<Path, Path, Difference> pathComparator = this::compareBySize;
    private BiFunction<File, File, Difference> fileComparator = this::compareFileBySize;

    public CommonsFileComparator contentComparison() {
        pathComparator = this::compareContent;
        fileComparator = this::compareFileContent;
        return this;
    }

    public CommonsFileComparator sizeComparison() {
        pathComparator = this::compareBySize;
        fileComparator = this::compareFileBySize;
        return this;
    }
    public CommonsFileComparator crc32Comparison() {
        pathComparator = this::compareByChecksum32;
        fileComparator = this::compareFileByChecksum32;
        return this;
    }

    public void setContentFilter(Predicate<String> contentFilter) {
        this.contentFilter = contentFilter;
    }
    public CommonsFileComparator contentComparison(Predicate<String> contentFilter) {
        contentComparison();
        setContentFilter(contentFilter);
        return this;
    }

    public void setLineFilter(Predicate<String> lineFilter) {
        this.lineFilter = lineFilter;
    }
    public CommonsFileComparator lineFilter(Predicate<String> contentFilter) {
        contentComparison();
        setLineFilter(contentFilter);
        return this;
    }

    public CommonsFileComparator contentComparison(Predicate<String> contentFilter, Predicate<String> lineFilter) {
        contentComparison();
        if (contentFilter != null) {
            setContentFilter(contentFilter);
        }
        if (lineFilter != null) {
            setLineFilter(lineFilter);
        }
        return this;
    }
    public CommonsFileComparator contentComparison(Pattern contentFilter, Pattern lineFilter) {
        Predicate<String> cp = null;
        if (contentFilter != null) {
            cp = contentFilter.asMatchPredicate();
        }
        Predicate<String> lp = null;
        if (lineFilter != null) {
            lp = lineFilter.asMatchPredicate();
        }
        return contentComparison(cp, lp);
    }
    public CommonsFileComparator contentComparison(Pattern contentFilter) {
        return contentComparison(contentFilter, null);
    }
    public CommonsFileComparator contentComparisonRegEx(@Language("RegExp") String contentFilter,
                                                        @Language("RegExp") String lineFilter) {
        Pattern cf = null;
        Pattern lf = null;
        if (contentFilter != null) {
            cf = Patterns.of(contentFilter, Pattern.CASE_INSENSITIVE);
        }
        if (lineFilter != null) {
            lf = Patterns.of(lineFilter, Pattern.CASE_INSENSITIVE);
        }
        contentComparison(cf, lf);
        return this;
    }
    public CommonsFileComparator contentComparisonRegEx(@Language("RegExp") String contentFilter) {
        return contentComparisonRegEx(contentFilter, null);
    }
    private Predicate<String> toWildcardPredicate(String filter, String[] filters) {
        Predicate<String> predicate = Directories.toFileWildcardPattern(filter).asMatchPredicate();
        if (filters != null) {
            for (final String i : filters) {
                predicate = predicate.or(Directories.toFileWildcardPattern(i).asMatchPredicate());
            }
        }
        return predicate;
    }

    public CommonsFileComparator contentComparisonWildcard(String contentFilter, String... filters) {
        contentComparison(toWildcardPredicate(contentFilter, filters), this.lineFilter);
        return this;
    }

    public CommonsFileComparator lineComparisonWildcard(String contentFilter, String... filters) {
        contentComparison(this.contentFilter, toWildcardPredicate(contentFilter, filters));
        return this;
    }

    boolean shouldCompareContent(String fileName) {
        return contentFilter != null && contentFilter.test(fileName);
    }
    boolean shouldCompareLineContent(String fileName) {
        return lineFilter != null && lineFilter.test(fileName);
    }
    public Difference compareContent(Path left, Path right) {
        final Difference difference;
        final String fileName = left.getFileName().toString();
        if (shouldCompareContent(fileName)) {
            difference = compareByByte(left, right);
        } else if (shouldCompareLineContent(fileName)) {
            difference = compareByLine(left, right);
        } else {
            difference = compareBySize(left, right);
        }
        return difference;
    }
    Difference compareFileContent(File left, File right) {
        final Difference difference;
        if (shouldCompareContent(left.getName())) {
            difference = compareByByte(left, right);
        } else {
            difference = compareByLine(left, right);
        }
        return difference;
    }

    private Difference checkDifferenceCreated(Object left, Object right) {
        return new Difference().left(left).right(right);
    }

    @Override
    public Difference apply(Path left, Path right) {
        return pathComparator.apply(left, right);
    }

    public Difference apply(File left, File right) {
        return fileComparator.apply(left, right);
    }

    String lineComparisonDetails(String lLine, String rLine, int line) {
        return String.format("Line:%s%n\t%s%n%s%n\tDifference:%s", line,
                StringUtils.defaultString(lLine), StringUtils.defaultString(rLine),
                StringUtils.difference(lLine, rLine));
    }
    Difference compareByLine(File left, File right) {
        final Difference difference = checkDifferenceCreated(left, right);
        try (final LineIterator lLines = FileUtils.lineIterator(left);
             final LineIterator rLines = FileUtils.lineIterator(right)) {
            int line = 0;
            while (lLines.hasNext() || rLines.hasNext()) {
                line++;
                final String lLine = lLines.hasNext() ? lLines.next() : null;
                final String rLine = rLines.hasNext() ? rLines.next() : null;
                if (!Objects.equals(lLine, rLine)) {
                    difference.difference(lineComparisonDetails(lLine, rLine, line));
                }
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to compare '%s' with '%s'", left, right), e);
        }
        return difference;
    }
    Difference compareByLine(Path left, Path right) {
        return compareByLine(left.toFile(), right.toFile());
    }

    Difference compareByChecksum32(File left, File right) {
        final Difference difference = checkDifferenceCreated(left, right);
        try {
            final long lCrc32 = FileUtils.checksumCRC32(left);
            final long rCrc32 = FileUtils.checksumCRC32(right);
            final int result = Long.compare(lCrc32, rCrc32);
            if (result != 0) {
                difference.difference(String.format("CRC32 checksum doesn't match for '%s' with '%s'", left, right));
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to compare '%s' with '%s'", left, right), e);
        }
        return difference;
    }
    Difference compareByChecksum32(Path left, Path right) {
        return compareByChecksum32(left.toFile(), right.toFile());
    }
    Difference compareFileByChecksum32(File left, File right) {
        return compareByChecksum32(left, right);
    }
    Difference compareByByte(File left, File right) {
        final Difference difference = checkDifferenceCreated(left, right);
        try {
            if (!FileUtils.contentEquals(left, right)) {
                difference.difference(String.format("Content is different for '%s' with '%s'", left, right));
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to compare '%s' with '%s'", left, right), e);
        }
        return difference;
    }
    Difference compareByByte(Path left, Path right) {
        return compareByByte(left.toFile(), right.toFile());
    }
    Difference compareBySize(Path left, Path right) {
        final Difference difference = checkDifferenceCreated(left, right);
        try {
            final BasicFileAttributes lAtt = Files.readAttributes(left, BasicFileAttributes.class);
            final BasicFileAttributes rAtt = Files.readAttributes(right, BasicFileAttributes.class);
            if (lAtt.size() != rAtt.size()) {
                difference.difference(String.format("File size is different for '%s', '%s'", left, right));
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to compare '%s' with '%s'", left, right), e);
        }
        return difference;
    }
    Difference compareFileBySize(File left, File right) {
        final Difference difference = checkDifferenceCreated(left, right);
        if (left.length() != right.length()) {
            difference.difference(String.format("File size is different for '%s', '%s'", left, right));
        }
        return difference;
    }
}
