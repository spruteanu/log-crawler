package com.edifecs.support.core;

import com.edifecs.support.SupportException;
import org.apache.commons.io.FileUtils;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.stream.Collectors;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class FileResourceContentResolver implements ContentResolver {
    private String parentPath;

    public String getParentPath() {
        return parentPath;
    }

    public void setParentPath(String parentPath) {
        this.parentPath = parentPath;
    }

    public FileResourceContentResolver parentPath(String pathPrefix) {
        this.parentPath = pathPrefix;
        return this;
    }

    public File toFile(String relativePath) {
        return parentPath != null ? new File(parentPath, relativePath) : new File(relativePath);
    }

    public boolean fileExists(String path) {
        return toFile(path).exists();
    }

    public boolean resourceExists(String path) {
        return this.getClass().getResource(path) != null;
    }

    @Override
    public InputStream toStream(String relativePath) throws IOException {
        final File file = toFile(relativePath);
        if (file.exists()) {
            return new FileInputStream(file);
        } else {
            final URL resource = this.getClass().getResource(relativePath);
            if (resource != null) {
                return resource.openStream();
            }
        }
        return new ByteArrayInputStream(relativePath.getBytes());
    }

    @Override
    public String toString(String relativePath) throws IOException {
        String text = relativePath;
        final File file = toFile(relativePath);
        if (file.exists()) {
            text = FileUtils.readFileToString(file, Charset.defaultCharset());
        } else {
            final URL resource = SupportException.class.getResource(relativePath);
            if (resource != null) {
                try (final BufferedReader buffer = new BufferedReader(new InputStreamReader(resource.openStream()))) {
                    return buffer.lines().collect(Collectors.joining("\n"));
                }
            }
        }
        return text;
    }

    public static InputStream lookupStream(String relativePath) throws IOException {
        final File file = new File(relativePath);
        if (file.exists()) {
            return new FileInputStream(file);
        } else {
            final URL resource = FileResourceContentResolver.class.getResource(relativePath);
            if (resource != null) {
                return resource.openStream();
            }
        }
        return null;
    }

}
