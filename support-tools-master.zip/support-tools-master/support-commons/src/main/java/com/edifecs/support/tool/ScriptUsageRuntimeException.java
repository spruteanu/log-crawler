package com.edifecs.support.tool;

import com.edifecs.support.SupportRuntimeException;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class ScriptUsageRuntimeException extends SupportRuntimeException {
    private final String script;

    public ScriptUsageRuntimeException(String script) {
        this.script = script;
    }

    public String getScript() {
        return script;
    }
}
