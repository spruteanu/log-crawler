package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import groovy.lang.*;
import groovy.util.DelegatingScript;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.groovy.control.CompilerConfiguration;
import org.intellij.lang.annotations.Language;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Supplier;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings({"unchecked", "rawtypes", "squid:S1166", "squid:S2221"})
public class GroovyUtil {

    private GroovyUtil() {}

    private static final Logger logger = LogManager.getLogger(GroovyUtil.class);
    private static GroovyShell importingGroovyShell;
    private static GroovyShell bindingGroovyShell;

    private static ContentResolver contentResolver = new FileResourceContentResolver();

    public static void setContentResolver(ContentResolver contentResolver) {
        GroovyUtil.contentResolver = contentResolver;
    }

    public static void defaultContentResolver() {
        contentResolver = new FileResourceContentResolver();
    }

    static boolean isArgSeparator(char c) {
        return c == ' ' || c == '\'' || c == '"';
    }

    static List<String> lookupArgs(String argsString) {
        argsString = argsString.trim();
        final int length = argsString.length();
        final List<String> args = new ArrayList<>();
        int startIdx = 0;
        char c = 0;
        for (int i = 0; i < length; i++) {
            final char ch = argsString.charAt(i);
            if (isArgSeparator(ch)) {
                if ((ch == c || c == 0) && startIdx != i) {
                    args.add(argsString.substring(startIdx, i + 1).trim());
                    startIdx = i + 1;
                    c = 0;
                } else
                if (c == 0) {
                    c = ch;
                }
            }
        }
        if (startIdx < length) {
            args.add(argsString.substring(startIdx).trim());
        }
        return args;
    }

    public static GroovyScriptArgument toGroovyScriptArgument(String groovyScript) {
        String grScript = groovyScript;
        final int idx = grScript.indexOf(' ');
        if (idx >= 0) {
            grScript = groovyScript.substring(0, idx);
        }
        if (!grScript.toLowerCase().endsWith(Context.GROOVY_EXTENSION)) {
            grScript += "." + Context.GROOVY_EXTENSION;
        }
        return new GroovyScriptArgument(grScript, idx);
    }

    static String lookupText(String groovyScript, Binding binding, ContentResolver resolver) {
        logger.debug("include '{}'", groovyScript);
        final GroovyScriptArgument result = toGroovyScriptArgument(groovyScript);
        if (result.idx >= 0) {
            final String[] args = lookupArgs(groovyScript.substring(result.idx).trim()).toArray(new String[0]);
            if (args.length > 0 && binding != null) {
                binding.setVariable("args", checkQuotedArgs(args));
            }
        }
        try {
            return resolver.toString(result.script);
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to resolve content for: '%s'", groovyScript), e);
        }
    }

    public static String lookupText(String resource) {
        logger.debug("include '{}'", resource);
        try {
            return contentResolver.toString(resource);
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to resolve content for: '%s'", resource), e);
        }
    }

    private static GroovyShell createDelegatingGroovyShell(Binding binding) {
        final CompilerConfiguration compilerConfiguration = new CompilerConfiguration();
        compilerConfiguration.setScriptBaseClass(DelegatingScript.class.getName());
        return new GroovyShell(binding != null ? binding : new Binding(), compilerConfiguration);
    }

    private static synchronized GroovyShell checkCreateImportingShell(Binding binding) {
        if (importingGroovyShell == null) {
            importingGroovyShell = createDelegatingGroovyShell(binding);
        }
        return importingGroovyShell;
    }

    static DelegatingScript compile(String groovyScript, Binding binding, ContentResolver contentResolver) {
        return (DelegatingScript) checkCreateImportingShell(binding).parse(lookupText(groovyScript, binding, contentResolver));
    }
    public static DelegatingScript compile(String groovyScript, Binding binding) {
        return (DelegatingScript) checkCreateImportingShell(binding).parse(lookupText(groovyScript, binding, new FileResourceContentResolver()));
    }
    public static DelegatingScript compile(String groovyScript) {
        return compile(groovyScript, null);
    }
    public static DelegatingScript compileText(@Language("groovy") String groovyScript) throws IOException {
        return (DelegatingScript) checkCreateImportingShell(null).parse(new FileResourceContentResolver().toString(groovyScript));
    }
    public static DelegatingScript compile(URI uri, Binding binding) throws IOException {
        return (DelegatingScript) checkCreateImportingShell(binding).parse(uri);
    }
    public static DelegatingScript compile(URI uri) throws IOException {
        return compile(uri, null);
    }
    public static DelegatingScript compile(File file, Binding binding) throws IOException {
        return (DelegatingScript) checkCreateImportingShell(binding).parse(file);
    }
    public static DelegatingScript compile(File file) throws IOException {
        return compile(file, null);
    }

    private static Context checkAddContextResults(Context context, Object result) {
        if (context != null && context != result && result instanceof Context) {
            final Context cr = (Context) result;
            context.add(cr.values());
            context.errors(cr.getErrorInfo());
            context.prefix(cr.getPrefix());
        }
        return context;
    }
    private static Object runScriptContext(Object delegate, Object result) {
        if (delegate instanceof Context) {
            checkAddContextResults((Context) delegate, result);
        }
        return result;
    }

    public static Object parseScript(String groovyScript, Object delegate, Binding binding) {
        final DelegatingScript script = compile(groovyScript, binding, contentResolver);
        if (delegate != null) {
            script.setDelegate(delegate);
        }
        if (binding != null) {
            script.setBinding(binding);
        }
        return runScriptContext(delegate, script.run());
    }

    public static Object parseScript(String groovyScript, Object delegate) {
        return parseScript(groovyScript, delegate, new Binding(new String[0]));
    }

    public static Object parseScript(URI uri, Object delegate, Binding binding) {
        final DelegatingScript script;
        try {
            script = compile(uri, binding);
            if (delegate != null) {
                script.setDelegate(delegate);
            }
            if (binding != null) {
                script.setBinding(binding);
            }
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to parse script: '%s'", uri), e);
        }
        return runScriptContext(delegate, script.run());
    }
    public static Object parseScript(File file, Object delegate, Binding binding) {
        setContentResolver(new FileResourceContentResolver().parentPath(file.getParentFile().getAbsolutePath()));
        final DelegatingScript script;
        try {
            script = compile(file, binding);
            if (delegate != null) {
                script.setDelegate(delegate);
            }
            if (binding != null) {
                script.setBinding(binding);
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to parse script: '%s'", file), e);
        }
        return runScriptContext(delegate, script.run());
    }

    public static Object parseScript(String groovyScript, Object delegate, Binding binding, ContentResolver contentResolver) {
        final DelegatingScript script = compile(groovyScript, binding, contentResolver);
        if (binding != null) {
            script.setBinding(binding);
        }
        Context.pushContext(delegate);
        try {
            if (delegate != null) {
                script.setDelegate(delegate);
            }
            return runScriptContext(delegate, script.run());
        } finally {
            Context.popContext();
        }
    }

    public static Object parseScript(String groovyScript, Object delegate, Binding binding, String currentDir) {
        return parseScript(groovyScript, delegate, binding,
                currentDir != null ? new FileResourceContentResolver().parentPath(currentDir) : contentResolver);
    }
    public static Object parseScript(String groovyScript, Object delegate, Binding binding, File currentDir) {
        return parseScript(groovyScript, delegate, binding,
                currentDir != null ? new FileResourceContentResolver().parentPath(currentDir.getAbsolutePath()) : contentResolver);
    }

    public static GroovyShell createBindingGroovyShell() {
        return new GroovyShell(new Binding());
    }
    public static GroovyShell createBindingGroovyShell(Properties properties) {
        return new GroovyShell(new Binding(properties));
    }
    public static GroovyShell createBindingGroovyShell(String propertiesFile) {
        final Properties properties = new Properties();
        try (final InputStream inputStream = new FileInputStream(propertiesFile)) {
            properties.load(inputStream);
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to read binding properties: '%s'", propertiesFile), e);
        }
        return createBindingGroovyShell(properties);
    }

    public static synchronized GroovyShell checkCreateBindingShell() {
        if (bindingGroovyShell == null) {
            bindingGroovyShell = createBindingGroovyShell();
        }
        return bindingGroovyShell;
    }

    public static Object executeScript(String groovyScript) {
        return checkCreateBindingShell().evaluate(lookupText(groovyScript, null, contentResolver));
    }
    public static Object executeScript(String groovyScript, String propertiesFile) {
        return createBindingGroovyShell(propertiesFile).evaluate(lookupText(groovyScript, null, contentResolver));
    }

    public static Object closureCall(Closure<?> closure, Object delegate) {
        if (closure == null) {
            return delegate;
        }
        closure.setResolveStrategy(Closure.DELEGATE_FIRST);
        closure.setDelegate(delegate);
        return runScriptContext(delegate, closure.call());
    }

    public static <T> T getPropertyFromClosure(Closure closure, String propertyName, T defaultValue) {
        try {
            return (T) closure.getProperty(propertyName);
        } catch (MissingPropertyException e) {
            logger.warn("Couldn't find property '{}' in closure", propertyName);
        }
        return defaultValue;
    }

    public static <T> T getPropertyFromScript(Script script, String propertyName, T defaultValue) {
        try {
            return (T) script.getProperty(propertyName);
        } catch (MissingPropertyException e) {
            logger.warn("Couldn't find property '{}' in script", propertyName);
        }
        return defaultValue;
    }

    public static <T> T getPropertyFromClosure(Closure closure, String propertyName) {
        return getPropertyFromClosure(closure, propertyName, null);
    }

    public static <T> T getPropertyFromScript(Script script, String propertyName) {
        return getPropertyFromScript(script, propertyName, null);
    }

    public static void rehydrateCall(Object delegate, Object owner, Object thisObject, Closure closure) {
        final Closure cClosure = closure.rehydrate(delegate, owner, thisObject);
        cClosure.setResolveStrategy(Closure.DELEGATE_FIRST);
        runScriptContext(delegate, cClosure.call());
    }

    public static Binding lookupBinder(Map<String, Object> vars) {
        return vars != null ? new Binding(vars) : null;
    }

    public static Object includeScript(@Language("groovy") String groovyScript, Object delegate, Map<String, Object> vars) {
        return parseScript(groovyScript, delegate, lookupBinder(vars));
    }

    public static Object includeScript(@Language("groovy") String groovyScript, Object delegate) {
        return includeScript(groovyScript, delegate, null);
    }

    public static Object include(String groovyScript, Object delegate) {
        return parseScript(groovyScript, delegate, null);
    }
    public static Object include(String groovyScript, Object delegate, Map<String, Object> vars) {
        return parseScript(groovyScript, delegate, lookupBinder(vars));
    }

    @NotNull
    public static String[] checkQuotedArgs(String[] args) {
        boolean quoted = false;
        final List<String> lArgs = new ArrayList<>();
        for (String arg : args) {
            if (arg.startsWith("\"") && arg.endsWith("\"")) {
                arg = arg.substring(1, arg.length() - 1);
                quoted = true;
            }
            lArgs.add(arg);
        }
        return quoted ? lArgs.toArray(new String[0]) : args;
    }

    public static Binding lookupBinder(String... args) {
        if (args != null) {
            return new Binding(checkQuotedArgs(args));
        }
        return null;
    }

    public static Object include(String groovyScript, Object delegate, String... args) {
        return parseScript(groovyScript, delegate, lookupBinder(args));
    }
    public static Object include(String groovyScript, Object delegate, Map<String, Object> vars, File currentDir) {
        return parseScript(groovyScript, delegate, lookupBinder(vars), currentDir);
    }
    public static Object include(String groovyScript, Object delegate, File currentDir, String... args) {
        return parseScript(groovyScript, delegate, lookupBinder(args), currentDir);
    }

    public static Object include(File groovyScript, Object delegate, Map<String, Object> vars) {
        return parseScript(groovyScript, delegate, lookupBinder(vars));
    }
    public static Object include(File groovyScript, Object delegate) {
        return include(groovyScript, delegate, null);
    }

    public static Object include(URI groovyScript, Object delegate, Map<String, Object> vars) {
        return parseScript(groovyScript, delegate, lookupBinder(vars));
    }
    public static Object include(URI groovyScript, Object delegate) {
        return include(groovyScript, delegate, null);
    }

    public static Object include(Closure closure, Object delegate) {
        return closureCall(closure, delegate);
    }

    @SuppressWarnings("rawtypes")
    public static <O> O lookupDelegate(Closure closure, Class<O> type, Supplier<O> supplier) {
        if (closure == null) {
            return supplier.get();
        }
        Object delegate = closure.getDelegate();
        if (delegate instanceof Closure) {
            delegate = lookupDelegate((Closure) delegate, type, supplier);
        }
        if (delegate instanceof DelegatingScript) {
            delegate = ((DelegatingScript) delegate).getDelegate();
        }
        return type.isInstance(delegate) ? (O) delegate : supplier.get();
    }
    @SuppressWarnings("rawtypes")
    public static <O> O lookupDelegate(Object delegate, Class<O> type, Supplier<O> supplier) {
        if (delegate instanceof Closure) {
            delegate = lookupDelegate((Closure) delegate, type, supplier);
        }
        if (delegate instanceof DelegatingScript) {
            delegate = ((DelegatingScript) delegate).getDelegate();
        }
        return type.isInstance(delegate) ? (O) delegate : supplier.get();
    }
    public static <O> O closureCall(Closure closure, Class<O> type, Supplier<O> supplier) {
        final O delegate = lookupDelegate(closure, type, supplier);
        closureCall(closure, delegate);
        return delegate;
    }

    public static class GroovyScriptArgument {
        public final String script;
        public final int idx;

        public GroovyScriptArgument(String script, int idx) {
            this.script = script;
            this.idx = idx;
        }

        public String getScript() {
            return script;
        }
    }
}
