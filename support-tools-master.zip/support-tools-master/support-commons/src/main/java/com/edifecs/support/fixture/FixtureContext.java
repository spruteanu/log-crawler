package com.edifecs.support.fixture;

import com.edifecs.support.collect.ProcessInfo;
import com.edifecs.support.core.*;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class FixtureContext extends Context {

    public void copy(String source, String destination) throws IOException {
        Directories.copy(resolveVariable(source), resolveVariable(destination));
    }

    public void copy(Path source, Path destination) throws IOException {
        Directories.copy(source, destination);
    }

    public void copy(InputStream inputStream, Path target) throws IOException {
        Directories.copy(inputStream, target);
    }

    public void delete(String path) throws IOException {
        Directories.delete(resolveVariable(path), true);
    }

    public void delete(Path path) throws IOException {
        Directories.delete(path, true);
    }

    public boolean delete(Path path, Predicate<Path> predicate) throws IOException {
        return Directories.delete(path, predicate, true);
    }

    public boolean delete(Path path, String wildcard) throws IOException {
        return Directories.delete(path, resolveVariable(wildcard), true);
    }

    public void delete(final Stream<Path> stream) {
        Directories.delete(stream, true);
    }

    public void filesStream(final String path, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(Paths.get(resolveVariable(path)), Utils::acceptAll, filesFunction);
    }

    public void filesStream(final Path path, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(path, Utils::acceptAll, filesFunction);
    }

    public void filesStream(final String path, final Predicate<Path> predicate, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(Paths.get(resolveVariable(path)), predicate, filesFunction);
    }

    public void filesStream(final Path path, final Predicate<Path> predicate, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(path, predicate, filesFunction);
    }

    public void filesStream(final String path, final String wildcard, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(Paths.get(resolveVariable(path)), resolveVariable(wildcard), filesFunction);
    }

    public void filesStream(final Path path, final String wildcard, final Consumer<Path> filesFunction) throws IOException {
        Directories.filesStream(path, resolveVariable(wildcard), filesFunction);
    }

    public void extract(final String source, final String destination) throws IOException {
        try (ZipWalker zipWalker = ZipWalker.of(resolveVariable(source))) {
            zipWalker.extract(resolveVariable(destination));
        }
    }

    public void extract(final String source, final String entryMask, final String destination) throws IOException {
        try (ZipWalker zipWalker = ZipWalker.of(resolveVariable(source), resolveVariable(entryMask))) {
            zipWalker.extract(resolveVariable(destination));
        }
    }

    public void extract(final String source, final Pattern entryMaskPattern, final String destination) throws IOException {
        try (ZipWalker zipWalker = ZipWalker.of(resolveVariable(source), entryMaskPattern)) {
            zipWalker.extract(resolveVariable(destination));
        }
    }

    public void extract(final Path source, final Path destination) throws IOException {
        try (ZipWalker zipWalker = ZipWalker.of(source.toFile())) {
            zipWalker.extract(destination);
        }
    }

    String kill(String prefix, long pid) {
        final String output;
        if (isLinux()) {
            output = shellOutput("kill", "-9", String.valueOf(pid));
        } else {
            output = shellOutput("taskkill", "/F", "/PID", String.valueOf(pid));
        }
        add(prefix, output);
        return output;
    }

    public String kill(long pid) {
        return kill("kill-process-" + pid + ".output", pid);
    }

    public void kill(final String... args) {
        validateArgs("PID(s) or process name", args);
        for (final String arg : args) {
            for (final String sArg : arg.split(",")) {
                if (StringUtils.isNumeric(sArg)) {
                    kill(Long.parseLong(sArg.trim()));
                } else {
                    final List<ProcessHandle> process = findProcess(sArg);
                    for (final ProcessHandle ph : process) {
                        kill(sArg, ph.pid());
                    }
                }
            }
        }
    }

    public void killJava(final String... args) {
        validateArgs("PID(s) or process name", args);
        for (final String arg : args) {
            for (final String sArg : arg.split(",")) {
                if (StringUtils.isNumeric(sArg)) {
                    kill(Long.parseLong(sArg.trim()));
                } else {
                    for (ProcessInfo info : findJavaProcess(sArg)) {
                        kill(sArg, info.getPid());
                    }
                }
            }
        }
    }

    public void rmdir(final String... args) {
        validateArgs("Directory(ies)", args);
        for (final String arg : args) {
            for (final String sArg : arg.split(",")) {
                final String value = resolveVariable(sArg.trim());
                final String prefix = "rmdir-" + sArg + ".output";
                if (isLinux()) {
                    add(prefix, shellOutput("rm", "-rf", value));
                } else {
                    add(prefix, shellOutput("rd", "/s", "/q", value));
                }
            }
        }
    }

    public String windowsService(final String host, final String service, final String... args) {
        validateArgs("Service argument(s)", args);
        final List<String> sArgs = new ArrayList<>();
        sArgs.add("\\\\" + host);
        sArgs.addAll(Arrays.asList(args));
        sArgs.add(service);
        final String output = shellOutput("sc", sArgs.toArray(new String[0]));
        add("sc-" + host + "-" + service + ".output", output);
        return output;
    }
    public static boolean isServiceRunning(final String output) {
        return output != null  && Patterns.of("\\s*state\\s+:\\s+4\\s+running", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE).matcher(output).find();
    }
    public boolean validateServiceRunning(final String host, final String service) {
        final String output = windowsService(host, service, "query");
        final boolean serviceRunning = isServiceRunning(output);
        if (!serviceRunning) {
            error(service, "Service is not running; details: ", output);
        }
        return serviceRunning;
    }

    public String ssh(final String... args) {
//        todo: sshpass -p ubuntu ssh ostechnix@192.168.1.30 uname -a (https://ostechnix.com/execute-commands-on-remote-linux-systems-via-ssh/)
//        todo: 	ssh user@hostname < file (https://www.cyberciti.biz/faq/unix-linux-execute-command-using-ssh/)
        validateArgs("SSH argument(s)", args);
        final String output = shellOutput("ssh", args);
        add(Utils.timeSuffixedPath("ssh-", "output"), output);
        return output;
    }

    public static FixtureContext of() {
        final FixtureContext context = new FixtureContext();
        context.defaultContext();
        return context;
    }
}
