package com.edifecs.support.core;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public interface OutputObserver extends ExecutionObserver {
    String getOutput();
}
