package com.edifecs.support.core;

import org.intellij.lang.annotations.Language;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public final class Patterns {
    private static final Map<String, Pattern> cache = Collections.synchronizedMap(new LinkedHashMap<>(256));
    private Patterns() {}

    public static synchronized Pattern of(@Language("RegExp") final String regex, final int flags) {
        return cache.computeIfAbsent(regex + flags, s -> Pattern.compile(regex, flags));
    }
    public static Pattern of(@Language("RegExp") final String regex) {
        return of(regex, 0);
    }
}
