package com.edifecs.support.core;

import java.util.Map;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class NullSafeOutputObserver implements OutputObserver {
    private final OutputObserver outputObserver;

    public NullSafeOutputObserver(OutputObserver outputObserver) {
        this.outputObserver = outputObserver;
    }

    @Override
    public void onFinished(String message, Map<String, String> properties) {
        if (outputObserver != null) {
            outputObserver.onFinished(message, properties);
        }
    }

    @Override
    public void onProgress(String message, Map<String, String> properties) {
        if (outputObserver != null) {
            outputObserver.onProgress(message, properties);
        }
    }

    @Override
    public void onError(String message, Map<String, String> properties) {
        if (outputObserver != null) {
            outputObserver.onError(message, properties);
        }
    }

    @Override
    public void onError(String message, Exception e, Map<String, String> properties) {
        if (outputObserver != null) {
            outputObserver.onError(message, e, properties);
        }
    }

    @Override
    public String getOutput() {
        if (outputObserver != null) {
            return outputObserver.getOutput();
        }
        return null;
    }
}
