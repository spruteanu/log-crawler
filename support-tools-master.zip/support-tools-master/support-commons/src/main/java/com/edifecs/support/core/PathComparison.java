package com.edifecs.support.core;

import com.edifecs.support.SupportRuntimeException;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.intellij.lang.annotations.Language;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings("rawtypes")
public class PathComparison {
    private final Logger logger = LogManager.getLogger(this.getClass());

    private BiFunction<Path, Path, Difference> fileComparator;

    private Predicate<String> ignore = Predicate.not(Utils::acceptAll);

    public void setIgnore(Predicate<String> ignore) {
        this.ignore = ignore;
    }

    public PathComparison ignore(Predicate<String> ignore) {
        setIgnore(ignore);
        return this;
    }
    public PathComparison ignoreByRegEx(@Language("RegExp") String ignorePattern) {
        setIgnore(Patterns.of(ignorePattern, Pattern.CASE_INSENSITIVE).asMatchPredicate());
        return this;
    }
    public PathComparison ignoreByWildcard(String ignore, String... ignores) {
        Predicate<String> predicate = Directories.toFileWildcardPattern(ignore).asMatchPredicate();
        if (ignores != null) {
            for (final String i : ignores) {
                predicate = predicate.or(Directories.toFileWildcardPattern(i).asMatchPredicate());
            }
        }
        setIgnore(predicate);
        return this;
    }

    Difference missingDifference(Object left, Object right) {
        final Difference d = new Difference().left(left).right(right);
        String lName = "missing";
        if (left != null) {
            lName = left.toString();
            if (shouldIgnoreComparison(lName)) {
                return d;
            }
        }
        String rName = "missing";
        if (right != null) {
            rName = right.toString();
            if (shouldIgnoreComparison(rName)) {
                return d;
            }
        }
        return d.difference(String.format("'%s';'%s'", lName, rName));
    }

    public void setFileComparator(BiFunction<Path, Path, Difference> fileComparator) {
        this.fileComparator = fileComparator;
    }

    public PathComparison compareFilesBy(BiFunction<Path, Path, Difference> fileComparator) {
        setFileComparator(fileComparator);
        return this;
    }

    Difference checkDifferenceCreated(Difference difference, Object left, Object right) {
        if (difference == null) {
            difference = Difference.of(left, right);
        }
        return difference;
    }

    CommonsFileComparator commonsFileComparator() {
        return new CommonsFileComparator();
    }

    public PathComparison defaultFileComparator() {
        compareFilesBy(commonsFileComparator().sizeComparison());
        return this;
    }

    public PathComparison defaultFileComparator(@DelegatesTo(CommonsFileComparator.class) Closure closure) {
        fileComparator = commonsFileComparator();
        GroovyUtil.closureCall(closure, fileComparator);
        return this;
    }

    BiFunction<Path, Path, Difference> checkFileComparatorCreated() {
        BiFunction<Path, Path, Difference> fc = fileComparator;
        if (fc == null) {
            fc = commonsFileComparator();
        }
        return fc;
    }

    Difference fileComparison(Path left, Path right) {
        final BiFunction<Path, Path, Difference> fc = checkFileComparatorCreated();
        return fc.apply(left, right);
    }

    boolean shouldIgnoreComparison(String fileName) {
        return ignore.test(fileName);
    }
    boolean shouldIgnoreComparison(Path left) {
        return shouldIgnoreComparison(left.toString());
    }
    Difference directoryComparison(final Difference difference, final Path left, final Path right) {
        final Difference d = checkDifferenceCreated(difference, left, right);
        try {
            final Set<String> visited = new HashSet<>();
            try (final Stream<Path> stream = Files.walk(left, 1)) {
                stream.forEach(p -> {
                    if (!p.equals(left)) {
                        final String fileName = p.getFileName().toString();
                        final Path pr = right.resolve(fileName);
                        d.difference(compare(null, p, pr.toFile().exists() ? pr : null));
                        visited.add(fileName);
                    }
                });
            }
            try (final Stream<Path> stream = Files.walk(right, 1)) {
                stream.forEach(p -> {
                    if (!p.equals(right)) {
                        final String fileName = p.getFileName().toString();
                        if (!visited.contains(fileName)) {
                            d.difference(missingDifference(null, p));
                        }
                    }
                });
            }
        } catch (IOException e) {
            throw new SupportRuntimeException(String.format("Failed to walk thru directory: '%s'", left), e);
        }
        return d;
    }

    @SuppressWarnings("SameParameterValue")
    Difference compare(Difference difference, Path left, Path right) {
        if (left == null || right == null) {
            return missingDifference(left, right);
        }
        if (shouldIgnoreComparison(left)) {
            return difference;
        }
        logger.debug("Comparing: '{}' with '{}'", left, right);
        final Difference d;
        if (left.toFile().isDirectory()) {
            d = directoryComparison(difference, left, right);
        } else {
            d = fileComparison(left, right);
        }
        logger.debug("Compared: '{}' with '{}'; {}", left, right, (d.hasDifference() ? "differ" : "no changes found"));
        return d;
    }

    public Difference compare(Path left, Path right) {
        return compare(null, left, right);
    }
    public Difference compare(String left, String right) {
        return compare(null, Paths.get(left), Paths.get(right));
    }

    public static PathComparison of() {
        return new PathComparison();
    }

    public static Difference of(Path left, Path right) {
        return of().compare(left, right);
    }
    public static Difference of(String left, String right) {
        return of().compare(left, right);
    }

    public static Difference compare(Path left, Path right, @DelegatesTo(PathComparison.class) Closure closure) {
        final PathComparison pc = of();
        GroovyUtil.closureCall(closure, pc);
        return pc.compare(left, right);
    }
    public static Difference compare(String left, String right, @DelegatesTo(PathComparison.class) Closure closure) {
        final PathComparison pc = of();
        GroovyUtil.closureCall(closure, pc);
        return pc.compare(left, right);
    }
}
