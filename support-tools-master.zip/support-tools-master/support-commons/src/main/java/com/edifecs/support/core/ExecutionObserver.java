package com.edifecs.support.core;

import java.util.Map;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public interface ExecutionObserver {
    void onFinished(String message, Map<String, String> properties);

    void onProgress(String message, Map<String, String> properties);

    void onError(String message, Map<String, String> properties);

    void onError(String message, Exception e, Map<String, String> properties);

    default void onDebug(String message, Map<String, String> properties) {
        onProgress(message, properties);
    }

    default void onDebug(String message, String... keyValues) {
        onProgress(message, Utils.asMap(keyValues));
    }

    default void onFinished(String message, String... keyValues) {
        onFinished(message, Utils.asMap(keyValues));
    }

    default void onProgress(String message, String... keyValues) {
        onProgress(message, Utils.asMap(keyValues));
    }

    default void onError(String message, String... keyValues) {
        onError(message, Utils.asMap(keyValues));
    }

    default void onError(String message, Exception e, String... keyValues) {
        onError(message, e, Utils.asMap(keyValues));
    }
}
