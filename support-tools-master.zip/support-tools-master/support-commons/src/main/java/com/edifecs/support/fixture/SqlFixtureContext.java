package com.edifecs.support.fixture;

import com.edifecs.support.collect.SqlContext;
import com.edifecs.support.collect.SqlInfoContext;
import com.edifecs.support.core.FileResourceContentResolver;
import com.edifecs.support.core.GroovyUtil;
import org.intellij.lang.annotations.Language;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class SqlFixtureContext extends SqlContext {
    void doExecute(String script) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        script = script.trim();
        if (StringUtils.hasText(script)) {
            logger.debug("SQL execute: '{}'", script);
            jdbcTemplate.execute(script);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public void execute(final List<String> lines) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        new TransactionTemplate(new DataSourceTransactionManager(jdbcTemplate.getDataSource())).execute((TransactionCallback) status -> {
            final String[] scripts = toScripts(lines);
            for (String script : scripts) {
                doExecute(script);
            }
            return null;
        });
    }

    public void execute(final InputStream inputStream) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            execute(reader.lines().collect(Collectors.toList()));
        }
    }

    public void execute(@Language("SQL") String query) {
        execute(Arrays.asList(GroovyUtil.lookupText(query).split("\n")));
    }
    public void executeFrom(final String resource) throws IOException {
        execute(new FileResourceContentResolver().toStream(resolveVariable(resource)));
    }

    int doUpdate(String script, Object... params) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        script = script.trim();
        int results = 0;
        if (StringUtils.hasText(script)) {
            logger.debug("SQL execute: '{}'", script);
            results = jdbcTemplate.update(script, params);
        }
        return results;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public int update(final List<String> lines, Object... params) {
        Objects.requireNonNull(jdbcTemplate, "SQL context is not initialized");
        final AtomicInteger results = new AtomicInteger();
        new TransactionTemplate(new DataSourceTransactionManager(jdbcTemplate.getDataSource())).execute((TransactionCallback) status -> {
            final String[] scripts = toScripts(lines);
            for (String script : scripts) {
                results.addAndGet(doUpdate(script, params));
            }
            return null;
        });
        return results.get();
    }

    public int update(final InputStream inputStream, Object... params) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            return update(reader.lines().collect(Collectors.toList()), params);
        }
    }

    public int update(@Language("SQL") String query, Object... params) {
        return update(Arrays.asList(GroovyUtil.lookupText(query).split("\n")), params);
    }
    public int updateFrom(final String resource) throws IOException {
        return update(new FileResourceContentResolver().toStream(resolveVariable(resource)));
    }

    public static SqlFixtureContext of(Properties properties) {
        final SqlFixtureContext context = new SqlFixtureContext();
        if (properties.getProperty(DRIVER_CLASS_NAME).toLowerCase().contains("oracle")) {
            context.oracleDelimiter();
        }
        context.jdbcTemplate(newJdbcTemplate((properties)));
        return context;
    }

    public static SqlFixtureContext of() {
        return new SqlFixtureContext();
    }
    public static SqlFixtureContext of(DataSource dataSource) {
        final SqlFixtureContext context = new SqlFixtureContext();
        context.jdbcTemplate(new JdbcTemplate(dataSource));
        return context;
    }

    public static SqlFixtureContext of(JdbcTemplate jdbcTemplate) {
        final SqlFixtureContext context = new SqlFixtureContext();
        context.jdbcTemplate(jdbcTemplate);
        return context;
    }
    public static SqlFixtureContext ofProperties(String propertyFile) throws IOException {
        final SqlFixtureContext context = new SqlFixtureContext();
        context.dbProperties(propertyFile);
        return context;
    }
}
