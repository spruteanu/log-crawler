package com.edifecs.support.tool;

import com.edifecs.support.core.Directories;
import com.edifecs.support.core.ToolHelper;
import com.edifecs.support.core.Utils;
import com.edifecs.support.scripts.Metadata;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class ScriptsHelpTool {
    private static final String DEFAULT_NAME = "scripts-help.md";
    private static final String FAILURE_MSG = "Internal error. Please see logs for more details...";

    private static final Logger logger = LogManager.getLogger(ScriptsHelpTool.class);
    private static final String LIB_FOLDER = "lib";
    private static final String SCRIPTS_FOLDER = "samples";

    private static Logger clLogger;

    static boolean shouldShowUsage(ToolHelper toolHelper) {
        return toolHelper.hasArgument(ToolHelper.HELP);
    }

    static ToolHelper parseToolArguments(String... args) {
        return ToolHelper.Builder.of("scripts-help")
                .withHeader(Arrays.asList(
                        "Edifecs Support Tools Version " + ToolHelper.getVersion() + " (ST).",
                        "Copyright (c) Edifecs, Inc " + Calendar.getInstance().get(Calendar.YEAR),
                        "\n"
                )).withUsage(Arrays.asList(
                        "Usage:",
                        "       scripts-help [help file name] [scripts folder name] [-help]"
                ))
                .usingConsoleLogger("ConsoleAppender", "com.edifecs")
                .usingFileLogger("com.edifecs")
                .build(args);
    }

    private static Path resolveLibDirectory(Path currentDirectory) {
        Path libDirectory = currentDirectory.resolve(LIB_FOLDER);
        if (!libDirectory.toFile().exists()) {
            libDirectory = currentDirectory.toFile().getParentFile().toPath().resolve(LIB_FOLDER);
        }
        return libDirectory;
    }

    private static Path resolveScriptsDirectory(Path currentDirectory, Path scriptsDirectory) {
        if (scriptsDirectory != null) {
            return scriptsDirectory;
        }
        scriptsDirectory = currentDirectory.resolve(SCRIPTS_FOLDER);
        if (!scriptsDirectory.toFile().exists()) {
            scriptsDirectory = currentDirectory.toFile().getParentFile().toPath().resolve(SCRIPTS_FOLDER);
        }
        return scriptsDirectory;
    }

    private static void execute(String[] args) throws IOException {
        Path output;
        Path scripts = null;
        final Path currentDirectory = Directories.currentDirectory();
        if (args.length > 0) {
            final String path = args[0];
            output = Paths.get(path).toAbsolutePath().normalize();
            if (path.toLowerCase().endsWith(".md")) {
                Files.createDirectories(output.getParent());
            } else {
                Files.createDirectories(output);
                output = output.resolve(DEFAULT_NAME);
            }
            if (args.length > 1) {
                scripts = currentDirectory.resolve(args[1]);
            }
        } else {
            output = Paths.get(".").resolve(DEFAULT_NAME).toAbsolutePath().normalize();
        }
        clLogger.info("Generating script help: '{}'...", output);
        final List<Metadata> metadataList = Metadata.lookup(
                resolveLibDirectory(currentDirectory),
                resolveScriptsDirectory(currentDirectory, scripts)
        );
        Metadata.toMarkdown(metadataList, output.resolve(output).toString());
    }

    @SuppressWarnings("squid:S2221")
    static int doMain(String... args) {
        clLogger = LogManager.getLogger("ConsoleLine");
        int errorCode = 0;
        try {
            System.setProperty("log4j.defaultInitOverride", "true");
            final ToolHelper toolHelper = parseToolArguments(args);
            toolHelper.logHeader();
            if (shouldShowUsage(toolHelper)) {
                errorCode = 2;
                toolHelper.logUsage();
            }
            if (errorCode == 0) {
                execute(args);
            }
        } catch (Exception e) {
            logger.debug(FAILURE_MSG, e);
            errorCode = 1;
        }
        if (errorCode != 0 && errorCode != 2) {
            clLogger.error("\n");
            clLogger.error(FAILURE_MSG);
            clLogger.error("\n");
        }
        return errorCode;
    }

    public static void main(String... args) {
        Utils.disableIllegalReflectiveAccessWarning();
        System.exit(doMain(args));
    }
}
