package com.edifecs.support.core

import groovy.json.JsonGenerator
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class JsonWriter implements Closeable {
    private static final String LINE_BREAK = System.lineSeparator()
    protected Writer writer
    protected int flushAt
    protected JsonGenerator jsonGenerator
    protected int nOutput

    JsonWriter() {
    }

    JsonWriter(Writer writer) {
        this.writer = writer
    }

    Writer getWriter() {
        return writer
    }

    void setWriter(Writer writer) {
        this.writer = writer
    }

    int getFlushAt() {
        return flushAt
    }

    void setFlushAt(int flushAt) {
        this.flushAt = flushAt
    }

    JsonWriter flushAt(int flushAt = 100) {
        this.flushAt = flushAt
        return this
    }

    JsonGenerator getJsonGenerator() {
        return jsonGenerator
    }

    void setJsonGenerator(JsonGenerator jsonGenerator) {
        this.jsonGenerator = jsonGenerator
    }
    JsonWriter withJsonGenerator(JsonGenerator jsonGenerator) {
        setJsonGenerator(jsonGenerator)
        return this
    }
    JsonGenerator defaultJsonGenerator() {
        final jsonGenerator = new JsonGenerator.Options().excludeNulls().build()
        withJsonGenerator(jsonGenerator)
        return jsonGenerator
    }

    synchronized void write(Collection<?> values) {
        for (final obj : values) {
            writer.write(jsonGenerator.toJson(obj))
            writer.write(LINE_BREAK)
            nOutput++
            if (flushAt && (nOutput % flushAt) == 0) {
                writer.flush()
            }
        }
    }
    synchronized void write(def values) {
        write(Collections.singleton(values))
    }

    @Override
    void close() throws IOException {
        if (writer != null) {
            try {
                writer.flush()
            } catch (Exception ignore) { /*noop*/ }
            try {
                writer.close()
            } catch (Exception ignore) { /*noop*/ }
        }
    }

    static JsonWriter of(Writer writer) {
        return new JsonWriter(writer: writer)
    }

    static JsonWriter of(File file) {
        return new JsonWriter(writer: new BufferedWriter(new FileWriter(file)))
    }

    static JsonWriter of(String filePath) {
        return of(new File(filePath))
    }
}
