package com.edifecs.support.collect

import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class ErrorInfo {
    final Map<String, List<String>> errors = new LinkedHashMap<>(256)

    List<String> getError(String key) {
        return this.errors.get(key) ?: new ArrayList<String>()
    }

    synchronized ErrorInfo error(String key, String error, String... errors) {
        final List<String> list = getError(key)
        list.add(error)
        if (errors) {
            list.addAll(Arrays.asList(errors))
        }
        this.errors.put(key, list)
        return this
    }
    synchronized ErrorInfo error(String key, Collection<String> errors) {
        if (errors) {
            final List<String> list = getError(key)
            list.addAll(errors)
            this.errors.put(key, list)
        }
        return this
    }

    synchronized ErrorInfo add(ErrorInfo errorInfo) {
        this.errors.putAll(errorInfo.errors)
        return this
    }

    boolean hasErrors(String key) {
        return !getError(key).isEmpty()
    }
    boolean hasErrors() {
        return errors.values().any {!it.isEmpty()}
    }
}
