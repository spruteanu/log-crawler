package com.edifecs.support.core

import groovy.transform.CompileStatic
import org.apache.commons.lang.StringUtils

import java.util.regex.Pattern

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class CsvWriter implements AutoCloseable {
    static final String LINE_BREAK = System.getProperty('line.separator')
    static final String EMPTY_STRING = ''

    protected Writer writer
    protected List<String> columns

    protected int flushAt
    protected int nOutput

    protected boolean allValues
    protected String separator = ','
    protected String fieldSeparator = '"'

    CsvWriter() {
    }

    CsvWriter(Writer writer, List<String> columns) {
        this.writer = writer
        this.columns = columns
    }

    CsvWriter(Writer writer) {
        this(writer, null)
    }

    Writer getWriter() {
        return writer
    }

    void setWriter(Writer writer) {
        this.writer = writer
    }

    List<String> getColumns() {
        return columns
    }

    void setColumns(List<String> columns) {
        this.columns = columns
    }
    void columns(List<String> columns) {
        setColumns(columns)
        nOutput = 0
    }

    int getFlushAt() {
        return flushAt
    }

    void setFlushAt(int flushAt) {
        this.flushAt = flushAt
    }

    boolean getAllValues() {
        return allValues
    }

    void setAllValues(boolean allValues) {
        this.allValues = allValues
    }

    String getSeparator() {
        return separator
    }

    void setSeparator(String separator) {
        this.separator = separator
    }

    String getFieldSeparator() {
        return fieldSeparator
    }

    void setFieldSeparator(String fieldSeparator) {
        this.fieldSeparator = fieldSeparator
    }

    CsvWriter withSeparators(String separator, String fieldSeparator = EMPTY_STRING) {
        this.separator = separator
        setFieldSeparator(fieldSeparator)
        return this
    }

    CsvWriter flushAt(int flushAt = 100) {
        this.flushAt = flushAt
        return this
    }

    void writeLine(String line) {
        writer.write(line)
        writer.write(LINE_BREAK)
    }

    protected String buildLine(List<String> values) {
        List<String> result = values
        if (fieldSeparator) {
            result = new ArrayList<String>(values.size())
            for (String value : values) {
                if (value.contains(separator)) {
                    value = fieldSeparator + value + fieldSeparator
                } else if (value.contains(fieldSeparator)) {
                    value = StringUtils.replaceChars(value, fieldSeparator, fieldSeparator + fieldSeparator)
                }
                result.add(value)
            }
        }
        return result.join(separator)
    }

    void flush() {
        writer.flush()
    }

    protected synchronized void doWrite(List<String> values) {
        if (!nOutput) {
            writeLine(buildLine(columns))
        }
        writeLine(buildLine(values))
        nOutput++
        if (flushAt && (nOutput % flushAt) == 0) {
            flush()
        }
    }

    synchronized void write(String... values) {
        Objects.requireNonNull(values, 'Values to be saved must not be null')
        doWrite(Arrays.asList(values))
    }

    synchronized void write(List<String> values) {
        doWrite(values)
    }

    static String escapeCsv(def value) {
        if (value == null) {
            return ""
        }
        String v = value.toString()
        if (Patterns.of('[,"\r\n]').matcher(v).find()) {
            String escapedValue = v.replace('"', '""')
            return '"' + escapedValue + '"'
        }
        return v
    }

    synchronized void write(Map<String, ?> values) {
        if (values.isEmpty()) {
            return
        }
        if (columns == null || columns.isEmpty()) {
            setColumns(new ArrayList<>(values.keySet()))
        }
        final List<String> vals = new ArrayList<>(columns.size())
        for (final column : columns) {
            def value = values.get(column)
            vals.add(escapeCsv(value))
        }
        doWrite(vals)
    }

    @Override
    void close() throws IOException {
        if (writer != null) {
            try {
                writer.close()
            } catch (Exception ignore) { /*noop*/ }
        }
    }

    static CsvWriter of(Writer writer, String... columns) {
        return new CsvWriter(writer: writer, columns: columns ? Arrays.asList(columns) : null)
    }

    static CsvWriter of(File file, String... columns) {
        return new CsvWriter(writer: new BufferedWriter(new FileWriter(file)), columns: columns ? Arrays.asList(columns) : null)
    }

    static CsvWriter of(String filePath, String... columns) {
        return of(new File(filePath), columns)
    }
}
