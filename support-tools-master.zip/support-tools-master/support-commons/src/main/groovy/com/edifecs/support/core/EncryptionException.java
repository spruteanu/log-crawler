package com.edifecs.support.core;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class EncryptionException extends Exception {
    public EncryptionException(Throwable cause) {
        super(cause);
    }
}
