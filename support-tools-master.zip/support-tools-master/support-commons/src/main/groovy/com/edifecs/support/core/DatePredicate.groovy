package com.edifecs.support.core

import groovy.transform.CompileStatic

import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.function.Predicate
import java.util.regex.Pattern

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class DatePredicate implements Predicate<Date> {
    static final String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm"
    private static final SimpleDateFormat DEFAULT_DATE_FORMATTER = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT)
    static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd"
    static final String RANGE_REGEX = "\\.\\.\\."

    private Date from
    private Date to

    DatePredicate() {
    }

    DatePredicate(Date from, Date to) {
        this.from = from
        this.to = to
    }

    DatePredicate(LocalDateTime from, LocalDateTime to) {
        this.from = from ? Date.from(from.atZone(ZoneId.systemDefault()).toInstant()) : null
        this.to = to ? Date.from(to.atZone(ZoneId.systemDefault()).toInstant()) : null
    }

    DatePredicate(LocalDateTime[] range) {
        this(range[0], range[1]);
    }

    void setFrom(Date from) {
        this.from = from
    }

    DatePredicate from(Date from) {
        setFrom(from)
        return this
    }

    DatePredicate from(String from, String format) {
        setFrom(new SimpleDateFormat(format).parse(from))
        return this
    }

    void setTo(Date to) {
        this.to = to
    }

    DatePredicate to(Date to) {
        setTo(to)
        return this
    }

    DatePredicate to(String to, String format) {
        setTo(new SimpleDateFormat(format).parse(to))
        return this
    }

    DatePredicate toCurrent() {
        setTo(new Date())
        return this
    }

    DatePredicate today() {
        from(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()))
        return this
    }

    DatePredicate yesterday() {
        from(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusDays(1).toInstant()))
        return this
    }

    DatePredicate week(int count = 1) {
        from(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusWeeks(count).toInstant()))
        return this
    }

    DatePredicate month(int count = 1) {
        from(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusMonths(count).toInstant()))
        return this
    }

    DatePredicate day(int count = 1) {
        from(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusDays(count).toInstant()))
        return this
    }

    @Override
    boolean test(Date date) {
        if (!date) {
            return false
        }
        boolean result = true
        if (from) {
            result = date.after(from)
        }
        if (result && to) {
            result = date.before(to)
        }
        return result
    }

    @Override
    String toString() {
        final StringBuilder sb = new StringBuilder()
        if (from != null) {
            sb.append(DEFAULT_DATE_FORMATTER.format(from))
        }
        sb.append("...")
        if (to != null) {
            sb.append(DEFAULT_DATE_FORMATTER.format(to))
        } else {
            sb.append(DEFAULT_DATE_FORMATTER.format(new Date()))
        }
        return sb.toString()
    }

    protected static Pattern relativePeriodPattern() {
        return Patterns.of("(\\d+)?\\s*(yesterday|day|week|month|year|[dwmy])s*")
    }

    static boolean isRange(String dateTimePeriod) {
        return dateTimePeriod != null && (
                Patterns.of(RANGE_REGEX).matcher(dateTimePeriod).find() ||
                        relativePeriodPattern().matcher(dateTimePeriod).find()
        )
    }

    protected static LocalDateTime parsePeriodValue(String dateTime, DateTimeFormatter dateTimeFormatter, DateTimeFormatter dateFormatter) {
        try {
            return LocalDateTime.parse(dateTime, dateTimeFormatter)
        } catch (DateTimeParseException e) {
            if (dateFormatter != null) {
                return LocalDate.parse(dateTime, dateFormatter).atStartOfDay()
            }
            throw e
        }
    }

    @SuppressWarnings('GroovyFallthrough')
    protected static DatePredicate ofPeriod(String periodString, String dateTimePattern = null, String datePattern = null) {
        if (periodString == null) {
            throw new IllegalArgumentException("Date time period cannot be null")
        }

        final datePredicate = new DatePredicate()
        final matcher = relativePeriodPattern().matcher(periodString.toLowerCase())
        if (matcher.find()) {
            final int count = matcher.group(1) != null ? Integer.parseInt(matcher.group(1)) : 1
            final String unit = matcher.group(2)
            switch (unit) {
                case "yesterday":
                    datePredicate.yesterday()
                    break
                case "day":
                case "d":
                    datePredicate.day(count)
                    break
                case "week":
                case "w":
                    datePredicate.week(count)
                    break
                case "month":
                case "m":
                    datePredicate.month(count)
                    break
                case "year":
                case "y":
                    datePredicate.month(12 * count)
                    break
                default:
                    throw new IllegalArgumentException("Unsupported time unit: $unit")
            }
        } else {
            if (isRange(periodString)) {
                return new DatePredicate(parseDateTimePeriod(periodString, dateTimePattern, datePattern))
            } else {
                throw new IllegalArgumentException("Invalid period format: $periodString")
            }
        }
        return datePredicate
    }

    /**
     * Parses a date-time period string into start and end LocalDateTime objects.
     *
     * @param dateTimePeriod The date-time period string (e.g., "2023-01-01...2023-12-31 23:59").
     * @param dateTimePattern The pattern to use for parsing (e.g., "yyyy-MM-dd HH:mm").
     * @param datePattern The pattern to use for parsing dates (e.g., "yyyy-MM-dd").
     * @return An array of LocalDateTime objects representing the start and end of the period.
     * @throws IllegalArgumentException If the date-time period is invalid or cannot be parsed.
     */
    protected static LocalDateTime[] parseDateTimePeriod(String dateTimePeriod, String dateTimePattern, String datePattern) {
        if (dateTimePeriod == null) {
            throw new IllegalArgumentException("Date time period cannot be null")
        }
        final Pattern pattern = Patterns.of(RANGE_REGEX)
        final String[] parts = pattern.split(dateTimePeriod)
        final DateTimeFormatter dateTimeFormatter = Optional.ofNullable(dateTimePattern)
                .map(DateTimeFormatter.&ofPattern)
                .orElse(DateTimeFormatter.ofPattern(DEFAULT_DATE_TIME_FORMAT))
        final DateTimeFormatter dateFormatter = Optional.ofNullable(datePattern)
                .map(DateTimeFormatter.&ofPattern)
                .orElse(DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT))

        LocalDateTime start = null
        LocalDateTime end = null
        if (parts.length > 0 && !parts[0].isEmpty()) {
            start = parsePeriodValue(parts[0], dateTimeFormatter, dateFormatter)
        }
        if (parts.length > 1 && !parts[1].isEmpty()) {
            end = parsePeriodValue(parts[1], dateTimeFormatter, dateFormatter)
        }
        if (start == null && end == null) {
            throw new IllegalArgumentException(String.format("Invalid date range provided: '%s'. Format: [start]...[end]", dateTimePeriod))
        }
        return [start, end] as LocalDateTime[]
    }

    static DatePredicate of(Date from = null, Date to = null) {
        return new DatePredicate().from(from).to(to)
    }

    static DatePredicate of(String dateTimePeriod, String dateTimePattern, String datePattern) {
        return ofPeriod(dateTimePeriod, dateTimePattern, datePattern)
    }

    static DatePredicate of(String dateTimePeriod, String dateTimePattern) {
        return ofPeriod(dateTimePeriod, dateTimePattern, null)
    }

    static DatePredicate of(String dateTimePeriod) {
        return of(dateTimePeriod, DEFAULT_DATE_TIME_FORMAT, DEFAULT_DATE_FORMAT)
    }
}
