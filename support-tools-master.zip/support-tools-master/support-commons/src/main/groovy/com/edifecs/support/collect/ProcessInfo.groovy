package com.edifecs.support.collect

import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class ProcessInfo {
    long pid
    String name
    String command
    ProcessHandle handle
}
