package com.edifecs.support.core

import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class RafLineReader implements AutoCloseable {
    private static final char LINE_FEED_CHAR = '\n'
    private static final char CARRIAGE_RETURN_CHAR = '\r'
    private static final byte FILE_END_BYTE = (byte) 0xFF

    private final RandomAccessFile raf
    private long currentPosition
    private long length

    RafLineReader(String filePath, String mode) throws FileNotFoundException {
        raf = new RandomAccessFile(filePath, mode)
    }

    RafLineReader(String filePath) throws FileNotFoundException {
        this(filePath, 'r')
    }

    RafLineReader(File file) throws FileNotFoundException {
        this(file, 'r')
    }

    RafLineReader(File file, String mode) throws FileNotFoundException {
        raf = new RandomAccessFile(file, mode)
    }

    RafLineReader(RandomAccessFile raf) throws FileNotFoundException {
        this.raf = raf
    }

    long currentPosition() {
        return currentPosition
    }

    long length() {
        if (length == 0) {
            length = raf.length()
        }
        return this.length
    }

    long positionStart() {
        // Start from the beginning of the file
        raf.seek(0)
        currentPosition = 0
        return 0
    }

    long positionEnd() {
        // Start searching from the end of the file
        long position = length - 1
        raf.seek(position)
        return position
    }

    static boolean isLineEndChar(char c) {
        return c == LINE_FEED_CHAR || c == CARRIAGE_RETURN_CHAR
    }

    protected byte readByte() {
        try {
            return raf.readByte()
        } catch (EOFException ignore) {
            return FILE_END_BYTE
        }
    }

    protected static boolean isFileEnd(byte b) {
        return b == FILE_END_BYTE
    }

    // Read the next line from the current position
    String next() throws IOException {
        final StringBuilder line = new StringBuilder()
        while (true) {
            byte b = readByte()
            if (isFileEnd(b)) {
                break // End of file
            }
            char c = (char) b
            if (isLineEndChar(c)) {
                // Handle Windows-style line endings (\r\n)
                if (c == CARRIAGE_RETURN_CHAR && readByte() != LINE_FEED_CHAR) {
                    raf.seek(raf.getFilePointer() - 1) // Move back if it's not \r\n
                }
                break // End of line
            }
            line.append(c)
        }
        currentPosition = raf.getFilePointer() // Update the current position
        return line.length() == 0 ? null : line.toString()
    }

    // Jump to the first line
    String first() throws IOException {
        positionStart()
        return next()
    }

    long toPosition(long position) {
        final p = position + 1
        raf.seek(p)
        currentPosition = p
        return p
    }

    long positionLineStart(long position) {
        boolean charRead = false;
        while (position >= 0) {
            raf.seek(position)
            final c = (char) readByte()
            if (isLineEndChar(c)) {
                if (charRead) {
                    break
                }
            } else {
                charRead = true
            }
            position--
        }
        return toPosition(position)
    }

    long positionLineStart(boolean endFile) {
        long position = endFile ? positionEnd() : currentPosition()
        return positionLineStart(position)
    }

    long positionLineEnd(boolean endFile) {
        long position = endFile ? positionEnd() : currentPosition()
        while (position >= 0) {
            raf.seek(position)
            if (isLineEndChar((char) readByte())) {
                while (position >= 0) {
                    raf.seek(position)
                    if (!isLineEndChar((char) readByte())) {
                        break
                    }
                    position--
                }
                break
            }
            position--
        }
        return toPosition(position)
    }

    String last() throws IOException {
        length()
        if (length == 0) {
            return null // File is empty
        }
        positionLineStart(true)
        return next()
    }

    // Jump to the last line
    long toMiddlePosition() {
        length()
        return toPosition(length >> 1)
    }

    String middle() {
        toMiddlePosition()
        positionLineStart(currentPosition)
        return next()
    }

    // Jump to a specific line (1-based index)
    String line(int lineNumber) throws IOException {
        if (lineNumber < 1) {
            throw new IllegalArgumentException("Line number must be at least 1")
        }
        positionStart()
        // Read lines until the desired line is reached
        int currentLine = 1
        String line
        while ((line = next()) != null) {
            if (currentLine == lineNumber) {
                return line
            }
            currentLine++
        }
        throw new IllegalArgumentException("Line number $lineNumber is out of bounds")
    }

    List<String> readLines() {
        final lines = new ArrayList<String>(256)
        positionStart()
        String line
        while ((line = next()) != null) {
            lines.add(line)
        }
        return lines
    }

    String readContent() throws IOException {
        positionStart()
        final StringBuilder sb = new StringBuilder()
        while (true) {
            byte b = readByte()
            if (isFileEnd(b)) {
                break // End of file
            }
            sb.append((char) b)
        }
        return sb.toString()
    }

    void close() throws IOException {
        raf.close()
    }
}
