package com.edifecs.support.core;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.*;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("unused")
public class StringEncrypter {
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    public static final String DES_ENCRYPTION_SCHEME = "DES";
    public static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";
    public static final int STREAM_DEFAULT_ENCRIPTION_CHUNK_SIZE = 1024;
    private static final String UNICODE_FORMAT = "UTF8";
    private final KeySpec keySpec;
    private final SecretKeyFactory keyFactory;
    private final Cipher cipher;

    public StringEncrypter() throws EncryptionException {
        this(StringEncrypter.DES_ENCRYPTION_SCHEME, DEFAULT_ENCRYPTION_KEY);
    }

    public StringEncrypter(String encryptionScheme) throws EncryptionException {
        this(encryptionScheme, DEFAULT_ENCRYPTION_KEY);
    }

    public StringEncrypter(String encryptionScheme, String encryptionKey) throws EncryptionException {
        if (!(encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME) || encryptionScheme.equals(DES_ENCRYPTION_SCHEME))) {
            throw new IllegalArgumentException("Encryption scheme not supported: " + encryptionScheme);
        }
        if (encryptionKey == null) {
            throw new IllegalArgumentException("encryption key was null");
        }
        if (encryptionKey.trim().length() < 24) {
            throw new IllegalArgumentException("encryption key was less than 24 characters");
        }
        try {
            byte[] keyAsBytes = encryptionKey.getBytes(StandardCharsets.UTF_8);
            if (encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME)) {
                keySpec = new DESedeKeySpec(keyAsBytes);
            } else { //encryptionScheme.equals(DES_ENCRYPTION_SCHEME)
                keySpec = new DESKeySpec(keyAsBytes);
            }
            keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
            cipher = Cipher.getInstance(encryptionScheme);
        } catch (Exception e) {
            throw new EncryptionException(e);
        }
    }

    private static String bytes2String(byte[] bytes) {
        StringBuilder stringBuilder = new StringBuilder();
        for (byte aByte : bytes) {
            stringBuilder.append((char) aByte);
        }
        return stringBuilder.toString();
    }

    public synchronized String encrypt(String unencryptedString) throws EncryptionException {
        if (unencryptedString == null || unencryptedString.trim().length() == 0) {
            throw new IllegalArgumentException("the string to be encrypted cannot be empty");
        }
        try {
            SecretKey key = keyFactory.generateSecret(keySpec);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] cleartext = unencryptedString.getBytes(StandardCharsets.UTF_8);
            byte[] ciphertext = cipher.doFinal(cleartext);
            return new String(Base64.encodeBase64(ciphertext));
        } catch (Exception e) {
            throw new EncryptionException(e);
        }
    }

    public void encrypt(InputStream unencryptedStream, OutputStream encryptedStream, int chunkSize) throws EncryptionException {
        transformStream(unencryptedStream, encryptedStream, chunkSize, Cipher.ENCRYPT_MODE);
    }

    public void decrypt(InputStream encryptedStream, OutputStream unencryptedStream, int chunkSize) throws EncryptionException {
        transformStream(encryptedStream, unencryptedStream, chunkSize, Cipher.DECRYPT_MODE);
    }

    public void decrypt(InputStream encryptedStream, OutputStream unencryptedStream) throws EncryptionException {
        transformStream(encryptedStream, unencryptedStream, STREAM_DEFAULT_ENCRIPTION_CHUNK_SIZE, Cipher.DECRYPT_MODE);
    }

    public void encrypt(InputStream unencryptedStream, OutputStream encryptedStream) throws EncryptionException {
        transformStream(unencryptedStream, encryptedStream, STREAM_DEFAULT_ENCRIPTION_CHUNK_SIZE, Cipher.ENCRYPT_MODE);
    }

    private synchronized void transformStream(InputStream input, OutputStream result, int chunkSize, int mode) throws EncryptionException {
        if (chunkSize <= 0) {
            throw new IllegalArgumentException("Invalid chunkSize " + chunkSize);
        }
        try {
            SecretKey key = keyFactory.generateSecret(keySpec);
            cipher.init(mode, key);
            try (InputStream inputStream = (mode == Cipher.DECRYPT_MODE) ? new CipherInputStream(input, cipher) : input;
                 OutputStream outputStream = (mode == Cipher.ENCRYPT_MODE) ? new CipherOutputStream(result, cipher) : result) {
                byte[] chunk = new byte[chunkSize];
                int read = inputStream.read(chunk);
                while (read > 0) {
                    outputStream.write(chunk, 0, read);
                    read = inputStream.read(chunk);
                }
            }
        } catch (Exception e) {
            throw new EncryptionException(e);
        }
    }

    public synchronized String decrypt(String encryptedString) throws EncryptionException {
        if (encryptedString == null || encryptedString.trim().length() <= 0) {
            throw new IllegalArgumentException("encrypted string was null or empty");
        }
        try {
            SecretKey key = keyFactory.generateSecret(keySpec);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] cleartext = Base64.decodeBase64(encryptedString);
            byte[] ciphertext = cipher.doFinal(cleartext);
            return bytes2String(ciphertext);
        } catch (Exception e) {
            throw new EncryptionException(e);
        }
    }

    public static String resolvePrefixed(String value) {
        String result = value;
        final Matcher matcher = encryptionPrefixPattern().matcher(result);
        if (matcher.matches()) {
            result = matcher.group(1);
            if (result == null) {
                result = matcher.group(2);
            }
        }
        return result;
    }
    public String resolveDecrypted(String value) throws EncryptionException {
        if (isEncrypted(value)) {
            return decrypt(resolvePrefixed(value));
        } else {
            return decrypt(value);
        }
    }
    public static Pattern encryptionPrefixPattern() {
        return Patterns.of("\\{enc\\}(.+)|\\$Dec\\{(.+)\\}");
    }

    public static boolean isEncrypted(String value) {
        return value != null && encryptionPrefixPattern().matcher(value).matches();
    }

}
