import com.edifecs.support.Support

Support.info {
    println "mumu_args=$args"
    include('/cucu.groovy ServiceManager')
}
