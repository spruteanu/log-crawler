import com.edifecs.support.Support
import com.edifecs.support.core.Context
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

collectLogs(args)

@Description(
        name = "Cucu collects logs",
        description = "Collects logs",
        author = "Serge Pruteanu"
)
@Argument(name = "logging arguments", description = "Logging folders to be collected")
Context collectLogs(String[] args) {
    return Support.info {
        println "cucu_args=$args"
        if (args) {
            for (String filter : args) {
                logFilter(filter)
            }
        } else {
            allLogsFilter()
        }
    }
}
