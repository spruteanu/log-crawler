import com.edifecs.support.Support

Support.info {
    println "cucu_args=$args"
    if (args) {
        for (String filter : args) {
            logFilter(filter)
        }
    } else {
        allLogsFilter()
    }
}
