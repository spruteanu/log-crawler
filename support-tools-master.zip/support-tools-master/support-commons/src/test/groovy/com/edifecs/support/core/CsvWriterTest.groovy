package com.edifecs.support.core

import spock.lang.Specification
import spock.lang.Unroll

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class CsvWriterTest extends Specification {

    @Unroll
    def "escapeCsv should properly escape '#input' to '#expected'"() {
        given:
        def csvWriter = new CsvWriter()

        expect:
        csvWriter.escapeCsv(input) == expected

        where:
        input                  | expected
        null                   | ""
        ""                     | ""
        "simple"               | "simple"
        "with,comma"           | "\"with,comma\""
        "with\"quote"          | "\"with\"\"quote\""
        "with\nnewline"        | "\"with\nnewline\""
        "with\rcarriage"       | "\"with\rcarriage\""
        "with\r\nboth"         | "\"with\r\nboth\""
        "\"already quoted\""   | "\"\"\"already quoted\"\"\""
        "multiple,\"commas,\n" | "\"multiple,\"\"commas,\n\""
        "normal text"          | "normal text"
        "123"                  | "123"
        "  spaces  "           | "  spaces  "
    }

    def "escapeCsv should handle complex cases"() {
        given:
        def csvWriter = new CsvWriter()
        def complexString = "First line\r\nSecond \"quoted\" line,with comma"

        when:
        def result = csvWriter.escapeCsv(complexString)

        then:
        result == "\"First line\r\nSecond \"\"quoted\"\" line,with comma\""
    }

    def "escapeCsv should handle empty strings"() {
        given:
        def csvWriter = new CsvWriter()

        expect:
        csvWriter.escapeCsv("") == ""
    }

    def "escapeCsv should handle strings with only special characters"() {
        given:
        def csvWriter = new CsvWriter()

        expect:
        csvWriter.escapeCsv(",") == "\",\""
        csvWriter.escapeCsv("\"") == "\"\"\"\""
        csvWriter.escapeCsv("\n") == "\"\n\""
        csvWriter.escapeCsv("\r") == "\"\r\""
    }
}
