package com.edifecs.support.core

import com.edifecs.support.Util
import spock.lang.Ignore
import spock.lang.Specification

import java.util.regex.Pattern

/**
 * @author Timofei Pavlov(c-timofei.pavlov@edifecs.com)
 * @author Serge Pruteanu(sergep@edifecs.com)
 */
class DirectoriesTest extends Specification {
    static private String basePath

    String setupSpec() {
        basePath = Util.getProtectionDomainPath(DirectoriesTest)
    }

    void 'verify get available size'() {
        final ds = Directories.of(new File(basePath).getAbsolutePath())
        expect:
        0 < ds.getAvailableSize()
    }

//    @Ignore // todo: implement me
    void 'verify mask methods'() {
        given:
        Pattern pattern

        expect: 'verify toMaskRegex'
        '.*.properties' == Directories.toWildcardRegex('*.properties')
        './.*' == Directories.toWildcardRegex('./*')
        'log.*.log.*' == Directories.toWildcardRegex('log*.log*')
        'packages/.*.*descriptor.yml' == Directories.toWildcardRegex('packages/**descriptor.yml')

        and: 'verify matching'
        null != (pattern = Directories.toWildcardPattern('*.properties'))
        '1.properties' ==~ pattern
        'test/1.properties' ==~ pattern

        null != (pattern = Directories.toWildcardPattern('packages/*.yml'))
        'packages/1.yml' ==~ pattern
        'packages/tm/1.yml' ==~ pattern
    }

    @Ignore // todo: implement me
    void 'verify find all of a type'() {
        final rds = Directories.ofRoot(new File(basePath).absolutePath)

        expect: 'verify find all'
        rds.findAllFiles({ p -> p.toFile().getName().endsWith('class') }).size() > 0

        and: 'verify for all files function'
        rds.forAllFiles(
                { p -> p.toFile().getName().endsWith('class') },
                { it.toFile().name }
        ).size() > 0
        def files = []
        def function = { p -> files.add(p) }
        Directories.filesStream(new File(basePath).toPath(), '*.class', function)
        files.size() > 0

        files.clear()
        Directories.filesStream(new File(basePath).toPath(), function)
        files.size() > 0

        Directories.findAllFiles(new File(basePath).toPath(), '*.class').size() > 0

        and: 'verify for all directories function'
        rds.forAllDirectories(
                { true },
                { it.toFile().name }
        ).size() > 0

        and: 'verify find any'
        rds.findAllSubdirectory({ p -> p.toFile().getName().endsWith('application.properties') }).size() == 1
    }

}
