package com.edifecs.support.collect

import com.edifecs.support.core.CsvWriter
import com.edifecs.support.fixture.SqlFixtureContext
import org.apache.commons.lang.exception.ExceptionUtils
import org.h2.tools.Server
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification

import javax.sql.DataSource

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class SqlContextTest extends Specification {
    private static Server server
    private static DataSource dataSource
    private static JdbcTemplate jdbcTemplate

    void setupSpec() {
        start('-tcp', '-tcpAllowOthers')
        final dbProperties = [
                'driverClassName': 'org.h2.Driver',
                'url'            : 'jdbc:h2:mem:repository;DB_CLOSE_DELAY=-1;TRACE_LEVEL_FILE=3;MODE=MSSQLServer;DB_CLOSE_ON_EXIT=FALSE',
                'username'       : 'sa',
                'password'       : '',
        ] as Properties
        dataSource = SqlContext.dataSource(dbProperties)
        jdbcTemplate = SqlContext.newJdbcTemplate(dbProperties)
    }

    void cleanupSpec() {
        stop()
    }

    void 'verify sql context'() {
        def context = SqlFixtureContext.of(jdbcTemplate)
        context.scriptDelimiter('/')
        final writer = new StringWriter()
        final csvWriter = new CsvWriter(writer)
        context.queryConsumer new SqlContext.CsvWriterConsumer(csvWriter)

        expect:
        SqlContext.dataSource('jdbc:h2:mem:repository;DB_CLOSE_DELAY=-1;TRACE_LEVEL_FILE=3;MODE=MSSQLServer;DB_CLOSE_ON_EXIT=FALSE')
        context.execute('/repository-schema.sql')

        and: 'do query'
        !context.query('SELECT * FROM Claim WHERE ClaimSid=-1')
        writer.toString()

        and: 'do update'
        !context.update('UPDATE Claim SET ClaimHeaderSID=-1 WHERE ClaimSid=-1')
    }

    static void start(String... arguments) throws Exception {
        if (server == null) {
            server = Server.createTcpServer(arguments)
        }
        if (!server.isRunning(true)) {
            try {
                server.start()
                if (!server.isRunning(true)) {
                    throw new IllegalStateException("Failed to start H2 server")
                }
            } catch (Exception e) {
                if (!BindException.class.isInstance(ExceptionUtils.getRootCause(e))) {
                    throw e
                }
            }
        }
    }

    static void stop() throws Exception {
        if (server.isRunning(true)) {
            server.stop()
        }
    }
}
