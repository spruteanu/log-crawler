package com.edifecs.support

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class Util {

    static File protectionDomainFile() {
        new File(Util.protectionDomain.codeSource.location.file)
    }

    static String getProtectionDomainPath() {
        return protectionDomainFile().absolutePath
    }

    static String getProtectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }

}
