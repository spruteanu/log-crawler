package com.edifecs.support.core

import com.edifecs.support.Util
import org.apache.commons.io.FileUtils
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import junit.framework.Assert
import spock.lang.Ignore
import spock.lang.Specification

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ZipWalkerTest extends Specification {

    void 'verify walker'() {
        final domainFolder = new File(Util.getProtectionDomainPath(this.class))
        final zipFile = new File(domainFolder, '../test-classes.zip')
        zipFile.delete()
        zipIt(domainFolder.absolutePath, zipFile.absolutePath)
        String entryName = null
        ZipWalker walker

        expect:
        zipFile.exists()
        null != (walker = ZipWalker.of(zipFile, '*Test.class'))
        walker.walk({ entry ->
            entryName = entry.zipEntry.getName()
            final length = entry.readFully().length
            Assert.assertTrue(length > 0)
        })
        walker.listAll()

        and: 'verify ZipContentResolver'
        0 < IOUtils.readFully(new ZipContentResolver(walker).toStream(entryName), 1).length
        0 < new ZipContentResolver(walker).toBytes(entryName).length

        and: 'verify match folder'
        null != (walker = ZipWalker.of(zipFile,
                this.class.getPackage().getName().replaceAll('\\.', '/') + '/*.class'))
        walker.walk({
            final entry = it.zipEntry
            println "folder file: ${entry.name} size: ${entry.size}"
            Assert.assertTrue(entry.size > 0)
        })
        null != (walker = ZipWalker.of(zipFile, 'com/**.class'))
        final zipPath = zipFile.toPath()
        walker.walk({
            final entry = it.zipEntry
            println "folder file: ${entry.name} size: ${entry.size}"
            Assert.assertTrue(entry.size > 0)
            final zep = ZipWalker.zipEntryPath(zipPath, entryName)
            Assert.assertEquals(zep, "" + zipPath + ZipWalker.DELIMITER + entryName)
            final zEntryName = ZipWalker.resolveRelativePath(zep)
            Assert.assertEquals(entryName, zEntryName)
            Assert.assertNotNull(ZipWalker.resolveName(entryName))
        })

        and: 'verify extract all'
        final extractedFolder = new File(domainFolder.getParent(), 'extracted-' + System.currentTimeMillis())
        extractedFolder.mkdirs()
        null != (walker = ZipWalker.of(zipFile))
        ZipWalker.ExtractSummary summary
        null != (summary = walker.extract(extractedFolder.getAbsolutePath()))
        0L < summary.size
        0L < summary.count

        and: 'verify folder deletion'
        Directories.of(extractedFolder.absolutePath).delete()
        !extractedFolder.exists()
    }

    void 'test zipping of strings'() {
        final domainFolder = new File(Util.getProtectionDomainPath(this.class))
        def files = ['test1.txt':'the value of text1', 'test2.txt':'value2']
        ZipWalker.zipIt(files, new FileOutputStream(new File(domainFolder, "test1234.zip")))
        expect:
        new File(domainFolder, "test1234.zip").exists()
    }

    // todo: implement me
    @Ignore
    void 'test extract from inner zips'() {
        final domainFolder = new File(Util.getProtectionDomainPath(this.class))
        File innerZipTestsDir = new File(domainFolder.getParentFile(),"inner-zip-tests")
        innerZipTestsDir.delete()
        FileUtils.copyDirectory(domainFolder, innerZipTestsDir)

        final innerFile = new File(domainFolder, '../inner.zip')
        innerFile.delete()
        zipIt(domainFolder.absolutePath, innerFile.absolutePath)

        FileUtils.copyFile(innerFile, new File(innerZipTestsDir, "inventories/inner.zip"))
        final outerZip = new File(innerZipTestsDir, '../outer.zip')
        outerZip.delete()
        zipIt(innerZipTestsDir.absolutePath, outerZip.absolutePath)

        def zipWalker = ZipWalker.of(outerZip.absolutePath)

        when:
        byte[] bytes = new ZipContentResolver(zipWalker).toBytes("inventories/inner.zip!/application.properties")
        then:
        bytes.length > 0

        when:
        Properties innerProperties = new ZipContentResolver(zipWalker).toProperties("inventories/inner.zip!/application.properties")
        Properties innerPropertiesFromAbsPath = new ZipContentResolver(outerZip.absolutePath + "!\\inventories\\inner.zip!\\application.properties").toProperties()
        Properties outerProperties = new ZipContentResolver(zipWalker).toProperties("application.properties")
        then:
        innerProperties.getProperty("test") == "true"
        innerProperties.getProperty("im.keys.location") == "target"
        innerProperties.getProperty("im.current-environment") == ""
        and:
        innerPropertiesFromAbsPath.getProperty("test") == "true"
        innerPropertiesFromAbsPath.getProperty("im.keys.location") == "target"
        innerPropertiesFromAbsPath.getProperty("im.current-environment") == ""
        and:
        outerProperties.getProperty("test") == "true"
        outerProperties.getProperty("im.keys.location") == "target"
        outerProperties.getProperty("im.current-environment") == ""

        when:
        new ZipContentResolver(zipWalker).toStream("inventories/inner.zip!/application.properties").withCloseable { is -> innerProperties.load(is)}
        then:
        innerProperties.getProperty("test") == "true"
        innerProperties.getProperty("im.keys.location") == "target"
        innerProperties.getProperty("im.current-environment") == ""

        when:
        new ZipContentResolver(outerZip.absolutePath + "!\\inventories\\inner.zip!\\application.properties").toStream().withCloseable { is -> innerProperties.load(is)}
        then:
        innerProperties.getProperty("test") == "true"
        innerProperties.getProperty("im.keys.location") == "target"
        innerProperties.getProperty("im.current-environment") == ""

        when:
        new ZipContentResolver(outerZip.absolutePath + "!\\application.properties").toStream().withCloseable { is -> outerProperties.load(is)}
        then:
        outerProperties.getProperty("test") == "true"
        outerProperties.getProperty("im.keys.location") == "target"
        outerProperties.getProperty("im.current-environment") == ""

        when:
        def innerFiles = ['deployments/include-vars.groovy',
                          'deployments/script-deployments-main.groovy',
                          'deployments/script2-inc.groovy',
                          'deployments/testdir/script1-inc.groovy',
                          'deployments/verify-inclusion.groovy']
        def zw = ZipWalker.of(outerZip.absolutePath, 'inventories/inner.zip!/deployments/*.groovy')
        then:
        zw.walk({zwe ->
            Assert.assertTrue(innerFiles.contains(zwe.zipEntry.name))
        })
    }

    void 'test shell script posix attributes'() {
        given: 'shell script content and regular file content'
        final domainFolder = new File(Util.getProtectionDomainPath(this.class))
        def shellScriptContent = "#!/bin/bash\necho \"Hello World\"\n"
        def regularFileContent = "This is a regular text file."
        def tempZip = Files.createTempFile(domainFolder.toPath(), "test-posix", ".zip")

        when: 'creating zip with shell script and regular file using ZipWalker.zipIt'
        try (def zos = new ZipOutputStream(Files.newOutputStream(tempZip))) {
            try (def scriptStream = new ByteArrayInputStream(shellScriptContent.getBytes())) {
                ZipWalker.zipIt(zos, scriptStream, "test-script.sh")
            }
            try (def textStream = new ByteArrayInputStream(regularFileContent.getBytes())) {
                ZipWalker.zipIt(zos, textStream, "test.txt")
            }
        }

        then: 'shell script should have Unix extra field with executable permissions'
        def zipFile = new ZipFile(tempZip.toFile())
        def shellEntry = zipFile.getEntry("test-script.sh")
        shellEntry != null
        
        def extra = shellEntry.getExtra()
        extra != null
        extra.length >= 12
        
        // Check Unix Extra Field ID (0x000d in little-endian)
        extra[0] == (byte)0x0d
        extra[1] == (byte)0x00
        
        // Extract permissions (little-endian format) - bytes 4-7 contain the permissions
        def permissions = (extra[4] & 0xFF) | 
                         ((extra[5] & 0xFF) << 8) | 
                         ((extra[6] & 0xFF) << 16) | 
                         ((extra[7] & 0xFF) << 24)
        permissions == 0755

        and: 'regular file should not have Unix extra field'
        def textEntry = zipFile.getEntry("test.txt")
        textEntry != null
        textEntry.getExtra() == null

        cleanup:
        zipFile?.close()
        Files.deleteIfExists(tempZip)
    }

    void 'test shell script linux line endings'() {
        given: 'shell script content with Windows line endings (CRLF)'
        final domainFolder = new File(Util.getProtectionDomainPath(this.class))
        def shellScriptWithCRLF = "#!/bin/bash\r\necho \"Hello World\"\r\necho \"Line 2\"\r\n"
        def regularFileWithCRLF = "This is a regular text file.\r\nWith CRLF line endings.\r\n"
        def tempZip = Files.createTempFile(domainFolder.toPath(), "test-lineends", ".zip")

        when: 'creating zip with shell script and regular file using ZipWalker.zipIt'
        try (def zos = new ZipOutputStream(Files.newOutputStream(tempZip))) {
            try (def scriptStream = new ByteArrayInputStream(shellScriptWithCRLF.getBytes())) {
                ZipWalker.zipIt(zos, scriptStream, "test-script.sh")
            }
            try (def textStream = new ByteArrayInputStream(regularFileWithCRLF.getBytes())) {
                ZipWalker.zipIt(zos, textStream, "test.txt")
            }
        }

        then: 'shell script should have Linux line endings (LF only)'
        def zipFile = new ZipFile(tempZip.toFile())
        def shellEntry = zipFile.getEntry("test-script.sh")
        shellEntry != null
        
        // Read the shell script content from ZIP
        def shellInputStream = zipFile.getInputStream(shellEntry)
        def shellContent = IOUtils.toString(shellInputStream, "UTF-8")
        shellInputStream.close()
        
        // Verify no CRLF sequences remain, only LF
        !shellContent.contains("\r\n")
        shellContent.contains("\n")
        shellContent == "#!/bin/bash\necho \"Hello World\"\necho \"Line 2\"\n"

        and: 'regular file should preserve original line endings (not processed)'
        def textEntry = zipFile.getEntry("test.txt")
        textEntry != null
        
        // Read the regular file content from ZIP
        def textInputStream = zipFile.getInputStream(textEntry)
        def textContent = IOUtils.toString(textInputStream, "UTF-8")
        textInputStream.close()
        
        // Regular file should still have CRLF since it's not a shell script
        textContent.contains("\r\n")
        textContent == regularFileWithCRLF

        cleanup:
        zipFile?.close()
        Files.deleteIfExists(tempZip)
    }

    static void zipIt(String folder, String zipFile) {
        final Path zipPath = Files.createFile(Paths.get(zipFile))
        final ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(zipPath))
        try {
            final Path sourcePath = Paths.get(folder)
            Files.walk(sourcePath)
                    .filter({ path -> !Files.isDirectory(path) })
                    .forEach({ path ->
                        final String zePath = FilenameUtils.separatorsToUnix(sourcePath.relativize(path).toString())
                        final ZipEntry zipEntry = new ZipEntry(zePath)
                        zs.putNextEntry(zipEntry)
                        Files.copy(path, zs)
                        zs.closeEntry()
                    })
        } finally {
            zs.close()
        }
    }

    static void zipIt(String zipFile, String folder, String... files) {
        final Path sourcePath = Paths.get(folder)
        final Path zipPath = Files.createFile(Paths.get(zipFile))
        final ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(zipPath))
        try {
            files.each { source ->
                final path = sourcePath.resolve(source)
                final String zePath = FilenameUtils.separatorsToUnix(sourcePath.relativize(path).toString())
                final ZipEntry zipEntry = new ZipEntry(zePath)
                zs.putNextEntry(zipEntry)
                Files.copy(path, zs)
                zs.closeEntry()
            }
        } finally {
            zs.close()
        }
    }
}
