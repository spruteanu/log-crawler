/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support

import com.edifecs.support.collect.ContextHistory
import com.edifecs.support.collect.InformationContext
import com.edifecs.support.core.Context
import spock.lang.Specification

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths

/**
 * Spock tests for Storage class context history functionality
 *
 * @author Junie
 */
class StorageTest extends Specification {

    private static Path lookupHistoryDir() {
        final folder = new File(Util.protectionDomainFile(), 'log/history')
        if (!folder.exists()) {
            folder.mkdirs()
        }
        final path = folder.toPath()
        Storage.contextHistoryPath(path)
        return path
    }

    def "test storeContextHistory through toDisk - creates history file with scripts"() {
        given: "a mock context with scripts"
        def logHistoryDir = lookupHistoryDir()
        final destinationPath = logHistoryDir.resolve("test-destination").toAbsolutePath().toString()
        def context = createMockContext(["script1.groovy", "script2.groovy", "test.groovy"],
                destinationPath)

        when: "toDisk is called"
        Storage.toDisk(context)

        then: "history file should be created in log/history directory"
        Files.exists(logHistoryDir)

        and: "history file should contain correct JSON content"
        ContextHistory historyFile = Storage.lookupContextHistory(logHistoryDir).get(0)
        def content = Files.readString(Paths.get(historyFile.source))
        content.contains("\"destination\"")
        content.contains("\"scripts\"")
        content.contains("script1.groovy")
        content.contains("script2.groovy")
        content.contains("test.groovy")
        // JSON escapes backslashes, so we need to check for the escaped version
        content.contains(destinationPath.replace("\\", "\\\\"))
    }

    def "test lookupContextHistory - multiple history files sorted by date"() {
        given: "multiple history files are created"
        def logHistoryDir = lookupHistoryDir()

        expect:
        def path = logHistoryDir.resolve("old.context")
        Storage.storeContextHistory(path, new ContextHistory(["old-script.groovy"], "/old/destination"))
        def history = ContextHistory.of(path)
        history.scripts == ["old-script.groovy"]
        history.destination == "/old/destination"
        history.dateTime != null

        null != (path = logHistoryDir.resolve("new.context"))
        Storage.storeContextHistory(path, new ContextHistory(["new-script.groovy"], "/new/destination"))
        null != (history = ContextHistory.of(path))
        history.scripts == ["new-script.groovy"]
        history.destination == "/new/destination"
        history.dateTime != null

        and: "lookupContextHistory is called"
        !Storage.lookupContextHistory().isEmpty()
    }

    private static Context createMockContext(List<String> scripts, String destination) {
        return new InformationContext(scripts: scripts, destination: destination)
    }
}
