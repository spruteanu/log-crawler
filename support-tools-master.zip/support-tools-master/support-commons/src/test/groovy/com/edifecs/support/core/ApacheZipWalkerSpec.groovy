package com.edifecs.support.core

import com.edifecs.support.Util
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.io.FileUtils
import spock.lang.Specification

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path

class ApacheZipWalkerSpec extends Specification {

    def "zipIt(Map, OutputStream) creates zip with proper perms and LF for .sh"() {
        given:
        def baos = new ByteArrayOutputStream()
        def map = [
                'bin/script.sh'  : '#!/bin/bash\r\necho "Hello"\r\n',
                'conf/readme.txt': 'Some text with CRLF\r\nnext line\r\n'
        ]
        final targetFolder = Util.protectionDomainFile()

        when:
        ApacheZipWalker.zipIt(map, baos)
        byte[] zipBytes = baos.toByteArray()
        File tmpZip = File.createTempFile("apache-zipwalker-map", ".zip", targetFolder)
        FileUtils.writeByteArrayToFile(tmpZip, zipBytes)

        then:
        tmpZip.exists()

        and: "verify entries"
        try (ZipFile zf = new ZipFile(tmpZip)) {
            ZipArchiveEntry shEntry = zf.getEntry('bin/script.sh')
            ZipArchiveEntry txtEntry = zf.getEntry('conf/readme.txt')
            assert shEntry != null
            assert txtEntry != null

            // 0755 and 0644 respectively (mask lower 9 bits)
            assert (shEntry.unixMode & 0x1FF) == 0x1ED // 0755
            assert (txtEntry.unixMode & 0x1FF) == 0x1A4 // 0644

            // content of .sh must be LF-only
            def shContent = zf.getInputStream(shEntry).text
            assert !shContent.contains('\r')
            assert shContent.contains('\n')
        }

        cleanup:
        tmpZip?.delete()
    }

    def "zipIt(Path folder, Path zipFile) sets 0755 for .sh and normalizes LF"() {
        given:
        final targetFolder = Util.protectionDomainFile()
        Path tempDir = Files.createDirectories(targetFolder.toPath().resolve("apache-zipwalker-spec"))
        Path binDir = tempDir.resolve("bin")
        Files.createDirectories(binDir)
        Path scriptPath = binDir.resolve("start.sh")
        Path textPath = tempDir.resolve("readme.txt")

        // Write CRLF to script to ensure normalization happens
        Files.write(scriptPath, "#!/usr/bin/env bash\r\necho start\r\n".getBytes(StandardCharsets.UTF_8))
        Files.write(textPath, "hello world\r\n".getBytes(StandardCharsets.UTF_8))

        File outZip = File.createTempFile("apache-zipwalker-folder", ".zip", targetFolder)
        outZip.delete()

        when:
        ApacheZipWalker.zipIt(tempDir, outZip.toPath())

        then:
        outZip.exists()

        and:
        try (ZipFile zf = new ZipFile(outZip)) {
            ZipArchiveEntry shEntry = zf.getEntry('bin/start.sh')
            ZipArchiveEntry txtEntry = zf.getEntry('readme.txt')
            assert shEntry != null
            assert txtEntry != null

            assert (shEntry.unixMode & 0x1FF) == 0x1ED // 0755
            assert (txtEntry.unixMode & 0x1FF) == 0x1A4 // 0644

            def shText = zf.getInputStream(shEntry).text
            assert !shText.contains('\r')
            assert shText.contains('\n')
        }

        cleanup:
        FileUtils.deleteQuietly(outZip)
        FileUtils.deleteDirectory(tempDir.toFile())
    }
}
