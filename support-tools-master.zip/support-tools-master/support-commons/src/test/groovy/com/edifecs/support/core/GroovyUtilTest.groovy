package com.edifecs.support.core

import com.edifecs.support.Support
import com.edifecs.support.collect.InformationContext
import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class GroovyUtilTest extends Specification {

    void 'verify arguments lookup'() {
        expect:
        GroovyUtil.lookupArgs('a b c') == ['a', 'b', 'c']
        GroovyUtil.lookupArgs('a "b c"') == ['a', '"b c"']
        GroovyUtil.lookupArgs('\'a b\' c') == ['\'a b\'', 'c']
        GroovyUtil.lookupArgs('Adevarat ca "Vasilica este un mirlan"') == ['Adevarat', 'ca', '"Vasilica este un mirlan"']
//        GroovyUtil.lookupArgs('\'Adevarat ca\' "Vasilica este un mirlan"') == ['\'Adevarat ca\'', '"Vasilica este un mirlan"']
        GroovyUtil.lookupArgs('Administrator@plt-tmbc-eim \'cd \\$IM_DATA && ls\'') == ['Administrator@plt-tmbc-eim', '\'cd \\$IM_DATA && ls\'']
    }

    void 'verify arguments passing'() {
        final context = new InformationContext()
        expect:
        Support.info(context, {
            include("/mumu.groovy MumuManager")
        })
        context.logFilters == ['ServiceManager'] as Set
    }
}
