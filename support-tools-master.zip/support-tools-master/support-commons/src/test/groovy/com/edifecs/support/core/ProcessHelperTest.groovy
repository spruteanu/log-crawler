package com.edifecs.support.core

import junit.framework.Assert
import spock.lang.Ignore
import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ProcessHelperTest extends Specification {

    void 'verify process helper'() {
        expect:
        null != "" + ProcessHelper.isWindows()
        if (ProcessHelper.isWindows()) {
            ProcessHelper processHelper = ProcessHelper.of("dir").withLoggingObserver()
            Assert.assertEquals(0, processHelper.execute())
            Assert.assertEquals("cmd /c dir", processHelper.toFullCommandLine())
        }
    }

    void 'verify output'() {
        def obs = new ConsoleOutputObserver()
        String command = ProcessHelper.isWindows() ? "dir" : "ls"
        int rc = ProcessHelper.of(command)
                .withLoggingObserver()
                .withObserver(obs)
                .execute()
        expect:
        rc >= 0
        obs.getOutput() != null
        !obs.getOutput().contains("Executing")
        println obs.getOutput()
    }

    @Ignore // todo: gitlabPipeline docker OS doesn't have sleep command
    void 'verify abort'() {
        def obs = new ConsoleOutputObserver()
        String command = ProcessHelper.isWindows() ? "timeout 10" : "sleep 10"
        def execution = ProcessHelper.of(command)
                .withLoggingObserver()
                .withObserver(obs)
                .submit()
        sleep(100)
        expect:
//        execution.getProcess().isAlive()
        execution.abort()
        !execution.getProcess().isAlive()
    }

    void 'verify empty args'() {
        def obs = new ConsoleOutputObserver()
        String command = ProcessHelper.isWindows() ? "dir" : "ls"
        def ph = ProcessHelper.of(command, "x", "", "y", " ", "z")
                .withLoggingObserver()
                .withObserver(obs)
        expect:
        ph.args.size() > 0
        ph.args.size() == 5
    }

    void 'verify process list'() {
        expect:
        ProcessHelper.findJava()
    }
}
