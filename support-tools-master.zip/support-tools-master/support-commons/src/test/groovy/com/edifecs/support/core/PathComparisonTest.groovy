package com.edifecs.support.core

import com.edifecs.support.Util
import org.apache.commons.io.FileUtils
import spock.lang.Specification

import java.nio.charset.Charset
import java.nio.file.Paths

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class PathComparisonTest extends Specification {

    void 'verify path comparison'() {
        final path = Paths.get(Util.getProtectionDomainPath())
        final pc = PathComparison.of()
        final targetCmp = new File(path.toFile().getParentFile(), Utils.timeSuffixedPath('pc', null))
        targetCmp.mkdir()
        final files = [] as List<File>
        FileUtils.copyDirectory(path.toFile(), targetCmp, {
            final bf = it.isFile()
            if (bf) {
                files.add(it)
            }
            return bf
        })
        File modifiedLineFile = null
        if (files) {
            modifiedLineFile = new File(targetCmp, files.first().getName())
            FileUtils.writeStringToFile(modifiedLineFile, "print('Path file comparison line')", Charset.defaultCharset(), true)
        }

        expect:
        !pc.compare(path, path).hasDifference()
        !pc.compare(path, path).listAll().isEmpty()

        pc.compare(path, null).listAll().size() == 1
        pc.compare(null, path).listAll().size() == 1
        pc.compare(null, null).listAll().size() == 1

        pc.compare(path, targetCmp.toPath()).hasDifference()
        pc.ignoreByRegEx(".*\\.zip").compare(path, targetCmp.toPath()).hasDifference()
        pc.ignoreByWildcard("*.zip").compare(path, targetCmp.toPath()).hasDifference()
        pc.defaultFileComparator {
            contentComparison()
        }.compare(path, targetCmp.toPath()).hasDifference()
        pc.defaultFileComparator {
            crc32Comparison()
        }.compare(path, targetCmp.toPath()).hasDifference()
        if (files) {
            and:
            pc.defaultFileComparator{
                contentComparisonWildcard('*.zip')
                lineComparisonWildcard('*.groovy')
//                contentComparisonRegEx(null, '.+\\.groovy')
            }.compare(files.first().toPath(), modifiedLineFile.toPath())?.hasDifference()
        }

//
//        and:
//        pc.defaultFileComparator().compare('\\\\plt-tmj-slw-18\\TMCompareModel\\CleanInstall\\463', '\\\\plt-tmj-slw-18\\TMCompareModel\\Upgraded\\463').hasDifference()
    }
}
