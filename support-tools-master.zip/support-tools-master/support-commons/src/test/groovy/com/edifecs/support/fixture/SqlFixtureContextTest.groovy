package com.edifecs.support.fixture

import spock.lang.Specification
import spock.lang.Unroll

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class SqlFixtureContextTest extends Specification {

    def "toScripts should use default delimiter"() {
        given: "a list of SQL statements with default delimiter"
        def sqlContext = new SqlFixtureContext()
        def lines = [
                "SELECT * FROM table1;",
                "SELECT * FROM table2;",
                "SELECT * FROM table3;"
        ]

        when: "toScripts is called"
        def result = sqlContext.toScripts(lines)

        then: "statements should be split correctly"
        result.length == 3
        result[0].trim() == "SELECT * FROM table1"
        result[1].trim() == "SELECT * FROM table2"
        result[2].trim() == "SELECT * FROM table3"
    }

    def "toScripts should use custom delimiter"() {
        given: "a custom delimiter is set"
        def sqlContext = new SqlFixtureContext()
        sqlContext.mssqlDelimiter()

        and: "a list of SQL statements with custom delimiter"
        def lines = [
                "SELECT * FROM table1 GO",
                "SELECT * FROM table2 GO",
                "SELECT * FROM table3 GO"
        ]

        when: "toScripts is called"
        def result = sqlContext.toScripts(lines)

        then: "statements should be split correctly"
        result.length == 3
        result[0].trim() == "SELECT * FROM table1"
        result[1].trim() == "SELECT * FROM table2"
        result[2].trim() == "SELECT * FROM table3"
    }

    def "toScripts should handle comments"() {
        given: "SQL statements with comments"
        def sqlContext = new SqlFixtureContext()
        def lines = [
                "-- This is a comment",
                "SELECT * FROM table1;",
                "// Another comment",
                "SELECT * FROM table2;"
        ]

        when: "toScripts is called"
        def result = sqlContext.toScripts(lines)

        then: "comments should be handled correctly"
        result.length == 2
        result[0].trim() == "SELECT * FROM table1"
        result[1].trim() == "SELECT * FROM table2"
    }

    def "toScripts should handle multiline scripts"() {
        given: "multiline SQL statements"
        def sqlContext = new SqlFixtureContext()
        def lines = [
                "SELECT *",
                "FROM table1",
                "WHERE id = 1;",
                "SELECT *",
                "FROM table2",
                "WHERE id = 2;"
        ]

        when: "toScripts is called"
        def result = sqlContext.toScripts(lines)

        then: "multiline statements should be preserved"
        result.length == 2
        result[0].contains("SELECT *")
        result[0].contains("FROM table1")
        result[0].contains("WHERE id = 1")
        result[1].contains("SELECT *")
        result[1].contains("FROM table2")
        result[1].contains("WHERE id = 2")
    }

    def "toScripts should throw exception for null input"() {
        def sqlContext = new SqlFixtureContext()
        when: "toScripts is called with null"
        sqlContext.toScripts(null)

        then: "NullPointerException should be thrown"
        thrown(NullPointerException)
    }

    @Unroll
    def "toScripts should handle different delimiters: #delimiter"() {
        given: "a custom delimiter is set"
        def sqlContext = new SqlFixtureContext()
        sqlContext.scriptDelimiter = delimiter

        and: "SQL statements with the delimiter"
        def lines = ["SELECT * FROM table1 $delimiter" as String, "SELECT * FROM table2 $delimiter" as String]

        when: "toScripts is called"
        def result = sqlContext.toScripts(lines)

        then: "statements should be split correctly"
        result.length == 2
        result[0].trim() == "SELECT * FROM table1"
        result[1].trim() == "SELECT * FROM table2"

        where:
        delimiter << [";", "GO", "//", "@@", "--END--"]
    }

    void 'verify more complex scripts parsing'() {
        final context = new SqlFixtureContext()
        context.oracleDelimiter()
        expect:
        context.toScripts(new StringReader('''
-- Active sessions history for 1-2 hours when UI slowness was observed
-- ! Uncomment the filter and set appropriate time range
select *
from v$active_session_history
--where sample_time between to_date('2025.02.13 09:00','yyyy.mm.dd hh24:mi') and  to_date('2025.02.13 11:00','yyyy.mm.dd hh24:mi')
order by sample_id, sample_time
/

-- list of SQL queries related to Claim table, execution plans for claim-related queries
select *
from v$sql
where lower(sql_fulltext) like '%from%claim %\'
order by buffer_gets desc
/

select *
from v$sql_plan
where sql_id in (select sql_id from v$sql where lower(sql_fulltext) like '%from%claim %')
order by plan_hash_value, child_number, id
/

select *
from v$sql_plan_statistics
where sql_id in (select sql_id from v$sql where lower(sql_fulltext) like '%from%claim %')
order by plan_hash_value, child_number, operation_id
/

-- list of timeout-candidates queries
select *
from v$sql
where end_of_fetch_count < executions
  and parsing_schema_name != 'SYS\'
/

select *
from v$sql_monitor
where status = 'DONE (ERROR)\'
/

-- segments, tables, indexes data
-- Can be filtered by owner to limit export size
-- where owner in ('') / where table_owner in ('') -- optional application schemas list filter for the following queries, add is necessary
select *
from dba_segments
order by bytes desc
/

select *
from v$segment_statistics
order by owner, object_name, statistic_name
/
''').readLines())
    }
}
