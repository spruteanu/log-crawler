package com.edifecs.support.core

import com.edifecs.support.Util
import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class RafLineReaderTest extends Specification {

    static File resolveTestDir() {
        return Util.protectionDomainFile()
    }

    def "should create RafLineReader with different constructors"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "test content"

        expect:
        new RafLineReader(testFile.path)
        new RafLineReader(testFile.path, "r")
        new RafLineReader(testFile)
        new RafLineReader(testFile, "r")
        new RafLineReader(new RandomAccessFile(testFile, "r"))
    }

    def "should read file content line by line"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\nline2\nline3"
        def reader = new RafLineReader(testFile)

        expect:
        reader.next() == "line1"
        reader.next() == "line2"
        reader.next() == "line3"
        reader.next() == null
        reader.readContent() == "line1\nline2\nline3"

        cleanup:
        reader.close()
    }

    def "should handle different line endings"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\r\nline2\rline3\nline4"
        def reader = new RafLineReader(testFile)

        expect:
        reader.next() == "line1"
        reader.next() == "line2"
        reader.next() == "line3"
        reader.next() == "line4"
        reader.next() == null

        and: 'verify middle line'
        reader.middle() == "line3"

        cleanup:
        reader.close()
    }

    def "should read first and last lines"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\nline2\nline3\n"
        def reader = new RafLineReader(testFile)

        expect:
        reader.first() == "line1"
        reader.first() == "line1"
        reader.last() == "line3"
        reader.last() == "line3"

        reader.middle() == "line2"
        reader.middle() == "line2"

        cleanup:
        reader.close()
    }

    def "should read specific line by number"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\nline2\nline3"
        def reader = new RafLineReader(testFile)

        expect:
        reader.line(1) == "line1"
        reader.line(2) == "line2"
        reader.line(3) == "line3"

        when:
        reader.line(0)

        then:
        thrown(IllegalArgumentException)

        when:
        reader.line(4)

        then:
        thrown(IllegalArgumentException)

        cleanup:
        reader.close()
    }

    def "should read all lines at once"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\nline2\nline3"
        def reader = new RafLineReader(testFile)

        when:
        def lines = reader.readLines()

        then:
        lines == ["line1", "line2", "line3"]

        cleanup:
        reader.close()
    }

    def "should handle empty file"() {
        given:
        def testFile = new File(resolveTestDir(), "empty.txt")
        testFile.createNewFile()
        def reader = new RafLineReader(testFile)

        expect:
        reader.next() == null
        reader.first() == null
        reader.last() == null
        reader.middle() == null
        reader.readLines() == []

        cleanup:
        reader.close()
    }

    def "should track current position"() {
        given:
        def testFile = new File(resolveTestDir(), "test.txt")
        testFile.text = "line1\nline2"
        def reader = new RafLineReader(testFile)

        expect:
        reader.currentPosition() == 0
        reader.next()
        reader.currentPosition() > 0

        cleanup:
        reader.close()
    }

    def "should throw FileNotFoundException for non-existent file"() {
        when:
        new RafLineReader("non-existent-file.txt")

        then:
        thrown(FileNotFoundException)
    }
}
