package com.edifecs.support.core

import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class DatePredicateTest extends Specification {
    private static final dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm")

    void 'verify date predicate creation'() {
        DatePredicate datePredicate

        expect:
        null != (datePredicate = DatePredicate.of()).toCurrent()
        datePredicate.to != null
        datePredicate.from == null
        !datePredicate.test(new Date())
        datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(1).toInstant()))

        and:
        null != (datePredicate = DatePredicate.of()).from(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(1).toInstant()))
        datePredicate.from != null
        datePredicate.to == null
        datePredicate.test(new Date())
        !datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(2).toInstant()))

        and:
        null != (datePredicate = DatePredicate.of()).yesterday()
        datePredicate.from != null
        datePredicate.to == null
        datePredicate.test(new Date())
        !datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(2).toInstant()))

        and:
        null != (datePredicate = DatePredicate.of()).today()
        datePredicate.from != null
        datePredicate.to == null
        datePredicate.test(new Date())
        !datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(1).toInstant()))
        !datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(2).toInstant()))

        and:
        null != (datePredicate = DatePredicate.of()).week()
        datePredicate.from != null
        datePredicate.to == null

        and:
        null != (datePredicate = DatePredicate.of()).month()
        datePredicate.from != null
        datePredicate.to == null

        and:
        null != (datePredicate = DatePredicate.of())
                .from(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(3).toInstant()))
                .to(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(1).toInstant()))
        datePredicate.from != null
        datePredicate.to != null
        datePredicate.test(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).minusDays(2).toInstant()))
        !datePredicate.test(new Date())

        and:
        null != (datePredicate = DatePredicate.of())
                .from('2023-04-20 09:34:35,950', 'yyyy-MM-dd HH:mm:ss,SSS')
                .to('2023-05-20 09:34:35,950', 'yyyy-MM-dd HH:mm:ss,SSS')
        datePredicate.from != null
        datePredicate.to != null
        datePredicate.test(Date.from(LocalDateTime.of(2023, 4, 22, 12, 31).atZone(ZoneId.systemDefault()).toInstant()))
        !datePredicate.test(Date.from(LocalDateTime.of(2023, 5, 22, 6, 12).atZone(ZoneId.systemDefault()).toInstant()))
        !datePredicate.test(Date.from(LocalDateTime.of(2023, 4, 19, 6, 12).atZone(ZoneId.systemDefault()).toInstant()))
        !datePredicate.test(new Date())
    }

    @Unroll
    def "should create predicate for date range: #dateTimePeriod"() {
        when:
        def predicate = DatePredicate.of(dateTimePeriod)

        then:
        predicate.test(dateFormat.parse(testDate)) == expected

        where:
        dateTimePeriod                        | testDate           | expected
        "2023-01-01 00:00...2023-12-31 23:59" | "2023-06-15 12:00" | true
        "2023-01-01 00:00...2023-12-31 23:59" | "2022-12-31 23:59" | false
        "2023-01-01 00:00...2023-12-31 23:59" | "2024-01-01 00:00" | false
        "...2023-12-31 23:59"                 | "2023-06-15 12:00" | true
        "...2023-12-31 23:59"                 | "2024-01-01 00:00" | false
        "2023-01-01 00:00..."                 | "2023-06-15 12:00" | true
        "2023-01-01 00:00..."                 | "2022-12-31 23:59" | false

        "2023-01-01 00:00...2023-12-31"       | "2023-06-15 12:00" | true
        "2023-01-01...2023-12-31 23:59"       | "2023-06-15 12:00" | true
        "2023-01-01...2023-12-31"             | "2023-06-15 12:00" | true
    }

    @Unroll
    def "isRange should return #expected for input '#input'"() {
        expect:
        DatePredicate.isRange(input) == expected

        where:
        input                        | expected
        "2023-01-01...2023-12-31"    | true
        "...2023-12-31"              | true
        "2023-01-01..."              | true
        "2023-01-01"                 | false
        "plain text"                 | false
        "2023-01-01..2023-12-31"     | false
        ""                           | false
        null                         | false
        "2023-01-01...2023-12-31..." | true
    }

    def "should throw IllegalArgumentException for null input"() {
        when:
        DatePredicate.of((String) null)

        then:
        thrown(IllegalArgumentException)
    }

    def "should throw IllegalArgumentException for empty range"() {
        when:
        DatePredicate.of("...")

        then:
        thrown(IllegalArgumentException)
    }

    def "should throw exception for invalid date format"() {
        when:
        DatePredicate.of("2023/01/01 00:00:00...2023/12/31 23:59:59")
        then:
        thrown(Exception)
    }

    @Unroll
    def "DateTimePredicate with #scenario"() {
        given: "a DateTimePredicate with the given start and end dates a date to test"
        Date date = Date.from(LocalDateTime.of(2023, 6, 15, 12, 0).atZone(ZoneId.systemDefault()).toInstant())

        when:
        DatePredicate predicate = new DatePredicate(
                expectedStart ? Date.from(expectedStart.atZone(ZoneId.systemDefault()).toInstant()) : null,
                expectedEnd ? Date.from(expectedEnd.atZone(ZoneId.systemDefault()).toInstant()) : null
        )

        then: "the test method should return the expected result"
        predicate.test(date) == expectedResult

        where:
        scenario                 | expectedStart                      | expectedEnd                          | expectedResult
        "date within range"      | LocalDateTime.of(2023, 1, 1, 0, 0) | LocalDateTime.of(2023, 12, 31, 0, 0) | true
        "date before start"      | LocalDateTime.of(2023, 7, 1, 0, 0) | LocalDateTime.of(2023, 12, 31, 0, 0) | false
        "date after end"         | LocalDateTime.of(2023, 1, 1, 0, 0) | LocalDateTime.of(2023, 6, 1, 0, 0)   | false
        "only start, date after" | LocalDateTime.of(2023, 1, 1, 0, 0) | null                                 | true
        "only end, date before"  | null                               | LocalDateTime.of(2023, 12, 31, 0, 0) | true
    }

    @Unroll
    def "parseDateTimePeriod with #scenario"() {
        when: "parseDateTimePeriod is called"
        LocalDateTime[] result = DatePredicate.parseDateTimePeriod(dateTimePeriod, dateTimePattern, datePattern)

        then: "the result should match the expected start and end dates"
        result[0] == expectedStart
        result[1] == expectedEnd

        where:
        scenario                        | dateTimePeriod                        | dateTimePattern    | datePattern  | expectedStart                      | expectedEnd
        "valid start and end"           | "2023-01-01...2023-12-31"             | "yyyy-MM-dd"       | "yyyy-MM-dd" | LocalDateTime.of(2023, 1, 1, 0, 0) | LocalDateTime.of(2023, 12, 31, 0, 0)
        "valid start and end with time" | "2023-01-01 00:00...2023-12-31 23:59" | "yyyy-MM-dd HH:mm" | "yyyy-MM-dd" | LocalDateTime.of(2023, 1, 1, 0, 0) | LocalDateTime.of(2023, 12, 31, 23, 59)
        "only start"                    | "2023-01-01..."                       | "yyyy-MM-dd"       | "yyyy-MM-dd" | LocalDateTime.of(2023, 1, 1, 0, 0) | null
        "only end"                      | "...2023-12-31"                       | "yyyy-MM-dd"       | "yyyy-MM-dd" | null                               | LocalDateTime.of(2023, 12, 31, 0, 0)
        "default pattern"               | "2023-01-01 00:00...2023-12-31 23:59" | null               | null         | LocalDateTime.of(2023, 1, 1, 0, 0) | LocalDateTime.of(2023, 12, 31, 23, 59)
    }

    @Unroll
    def "parsePeriod should handle #scenario"() {
        when:
        def result = DatePredicate.ofPeriod(input)

        then:
        result != null
        if (expectedFrom) {
            result.from.time >= expectedFrom.time - 1000 // allowing 1 second difference
            result.from.time <= expectedFrom.time + 1000
        }
        if (expectedTo) {
            result.to.time >= expectedTo.time - 1000
            result.to.time <= expectedTo.time + 1000
        }

        where:
        scenario           | input       | expectedFrom  | expectedTo
        "yesterday"        | "yesterday" | yesterday()   | null
        "single day"       | "1day"      | daysAgo(1)    | null
        "multiple days"    | "5days"     | daysAgo(5)    | null
        "single week"      | "1w"        | weeksAgo(1)   | null
        "multiple weeks"   | "3weeks"    | weeksAgo(3)   | null
        "single month"     | "1month"    | monthsAgo(1)  | null
        "multiple months"  | "6months"   | monthsAgo(6)  | null
        "single year"      | "1year"     | monthsAgo(12) | null
        "multiple years"   | "2years"    | monthsAgo(24) | null
        "short form day"   | "3d"        | daysAgo(3)    | null
        "short form week"  | "2w"        | weeksAgo(2)   | null
        "short form month" | "4m"        | monthsAgo(4)  | null
        "short form year"  | "1y"        | monthsAgo(12) | null
    }

    def "parsePeriod should throw exception for invalid unit"() {
        when:
        DatePredicate.ofPeriod("1x")

        then:
        thrown(IllegalArgumentException)
    }

    def "parsePeriod should handle date range format"() {
        given:
        def dateRange = "2023-01-01 00:00...2023-12-31 23:59"

        when:
        def result = DatePredicate.ofPeriod(dateRange)

        then:
        result != null
        result.from != null
        result.to != null
    }

    // Helper methods to calculate expected dates
    private static Date yesterday() {
        return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusDays(1).toInstant())
    }

    private static Date daysAgo(int days) {
        return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusDays(days).toInstant())
    }

    private static Date weeksAgo(int weeks) {
        return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusWeeks(weeks).toInstant())
    }

    private static Date monthsAgo(int months) {
        return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).minusMonths(months).toInstant())
    }
}
