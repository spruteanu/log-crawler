package com.edifecs.support.core

import junit.framework.Assert
import spock.lang.Specification

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class CallableBatchTest extends Specification {
    ExecutorService threadPool

    void setup() {
        threadPool = Executors.newFixedThreadPool(2)
    }
    void cleanup() {
        threadPool.shutdown()
    }

    void 'verify callable batch'() {
        def callableBatch = new CallableBatch<>(threadPool)
        callableBatch.submit({Thread.sleep(20); return 20})
        callableBatch.submit({Thread.sleep(60); return 60})

        expect: 'verify retrieve results'
        [20, 60] == callableBatch.retrieveResults([])
        callableBatch.tasks.isEmpty()

        and: 'verify await termination'
        callableBatch.submit({Thread.sleep(20); return 20})
        callableBatch.submit({Thread.sleep(60); return 60})
        callableBatch.awaitTermination()
        callableBatch.tasks.isEmpty()

        and: 'verify failing'
        try {
            callableBatch.submit({Thread.sleep(20); return 20})
            callableBatch.submit({Thread.sleep(60); throw new RuntimeException('Failed thread')})
            callableBatch.awaitTermination()
            Assert.fail('An exception should be thrown')
        } catch (Exception e) {
            Assert.assertEquals('Failed thread', e.getCause().getMessage())
        }
        callableBatch.tasks.isEmpty()

        and: 'verify not responsive'
        try {
            callableBatch.withUnresponsiveTimeout(70, TimeUnit.MILLISECONDS)
            callableBatch.submit({ Thread.sleep(60); return 20 })
            callableBatch.submit({ Thread.sleep(20); while (true); })
            callableBatch.awaitTermination()
            Assert.fail('An exception should be thrown')
        } catch (Exception e) {
            Assert.assertTrue(e.getCause().getMessage().startsWith('Submitted batch is not responsive for'))
        }

        and: 'verify observer'
        callableBatch.onProgress('progress')
        0 < callableBatch.retrievalStart

        callableBatch.onFinished('finished')
        0 < callableBatch.retrievalStart

        callableBatch.onError('error')
        0 < callableBatch.retrievalStart
    }

}
