package com.edifecs.support.core


import spock.lang.Specification
import spock.lang.Unroll

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class StringEncrypterTest extends Specification {

    def "should encrypt and decrypt string correctly"() {
        given: "a StringEncrypter instance with default settings"
        def encrypter = new StringEncrypter()
        def originalText = "This is a test string to encrypt"

        when: "encrypting the original text"
        def encryptedText = encrypter.encrypt(originalText)

        then: "encrypted text should be different from original"
        encryptedText != originalText
        encryptedText != null
        !encryptedText.isEmpty()

        when: "decrypting the encrypted text"
        def decryptedText = encrypter.decrypt(encryptedText)

        then: "decrypted text should match the original"
        decryptedText == originalText
    }

    @Unroll
    def "should encrypt and decrypt strings of different lengths: #originalText"() {
        given: "a StringEncrypter instance"
        def encrypter = new StringEncrypter()

        when: "encrypting and decrypting text of different length"
        def encryptedText = encrypter.encrypt(originalText)
        def decryptedText = encrypter.decrypt(encryptedText)

        then: "the original text should be recovered"
        decryptedText == originalText

        where:
        originalText << [
                "a",
                "ab",
                "abc",
                "abcd",
                "abcde",
                "a" * 100,
                "a" * 1000
        ]
    }

    def 'verify tm encryption'() {
        def encrypter = new StringEncrypter()
        expect:
        encrypter.decrypt("U4Wi47iHluc=")

        and: 'verify is encrypted'
        StringEncrypter.isEncrypted('$Dec{U4Wi47iHluc=}')

        StringEncrypter.resolvePrefixed('{enc}U4Wi47iHluc=')
        StringEncrypter.resolvePrefixed('$Dec{U4Wi47iHluc=}')
    }
}
