package com.edifecs.support.core

import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ValidatorsTest extends Specification {

    void "verify version matching"() {
        expect: 'verify strict matching'
        Validators.matchesVersion('9.0', '9.0')
        Validators.matchesVersion('9.0', '9.0.0.0')
        Validators.matchesVersion('9.0.0.0', '9.0')
        Validators.matchesVersion('v9.0', '9.0.0.0')

        and: 'verify version+ cases'
        Validators.matchesVersion('9.0', '9.0+')
        Validators.matchesVersion('19.0', '9.0+')
        Validators.matchesVersion('19.0', '9.4+')
        Validators.matchesVersion('19.0.1', '9.4+')
        Validators.matchesVersion('9.0.1', '9.0+')
        Validators.matchesVersion('9.1', '9.0.0+')
        Validators.matchesVersion('9.1-SNAPSHOT', '9.0.0+')
        Validators.matchesVersion('9.0.0.2', '9.0+')
        Validators.matchesVersion('v9.0.0.2', '9.0.0.0+')

        Validators.matchesVersion('9.0-SNAPSHOT', '9.0-SNAPSHOT+')
        Validators.matchesVersion('9.1', '9.0-SNAPSHOT+')
        Validators.matchesVersion('9.1-SNAPSHOT', '9.0-SNAPSHOT+')

        !Validators.matchesVersion('8.8.1', '9.0+')
        !Validators.matchesVersion('8.1', '9.0.0+')
        !Validators.matchesVersion('8.1-SNAPSHOT', '9.0.0+')
        !Validators.matchesVersion('v8.3.0.2', '9.0.0.0+')
        !Validators.matchesVersion('8.4.0.5', '9.0+')
        !Validators.matchesVersion('8.4.2.5', '8.4.2.6+')

        !Validators.matchesVersion('9.0.2', '9.1+')
        !Validators.matchesVersion('9.0.2', '19.1+')
        !Validators.matchesVersion('9.0.0.2', '9.2+')
        !Validators.matchesVersion('9.0.9', '9.1+')

        !Validators.matchesVersion('9.1', '9.2-SNAPSHOT+')
        !Validators.matchesVersion('9.1-SNAPSHOT', '9.2-SNAPSHOT+')

        and: 'verify version- cases'
        !Validators.matchesVersion('9.0.1', '9.0-')
        !Validators.matchesVersion('9.1', '9.0.0-')
        !Validators.matchesVersion('9.1-SNAPSHOT', '9.0.0-')
        !Validators.matchesVersion('v9.0.0.2', '9.0.0.0-')
        !Validators.matchesVersion('9.0.0.2', '9.0-')

        !Validators.matchesVersion('9.0.1', '9.0-')
        !Validators.matchesVersion('9.0.2', '9.0-')
        !Validators.matchesVersion('9.0.0.2', '9.0-')

        !Validators.matchesVersion('9.1', '9.0-SNAPSHOT-')
        !Validators.matchesVersion('9.1-SNAPSHOT', '9.0-SNAPSHOT-')
        !Validators.matchesVersion('19.0', '9.0-')

        Validators.matchesVersion('8.8.1', '9.0-')
        Validators.matchesVersion('8.1', '9.0.0-')
        Validators.matchesVersion('8.1-SNAPSHOT', '9.0.0-')
        Validators.matchesVersion('v8.3.0.2', '9.0.0.0-')
        Validators.matchesVersion('8.4.0.5', '9.0-')
        Validators.matchesVersion('8.4.2.5', '8.4.2.6-')

        Validators.matchesVersion('9.0', '9.0-')
        Validators.matchesVersion('9.0.2', '9.1-')
        Validators.matchesVersion('9.0.0.2', '9.2-')
        Validators.matchesVersion('9.0.9', '9.1-')

        Validators.matchesVersion('9.0-SNAPSHOT', '9.0-SNAPSHOT-')
        Validators.matchesVersion('9.1', '9.2-SNAPSHOT-')
        Validators.matchesVersion('9.1-SNAPSHOT', '9.2-SNAPSHOT-')

        and: 'verify empty use cases'
        Validators.matchesVersion('9.0', null)
        Validators.matchesVersion('9.0+', '')
        Validators.matchesVersion('9.0-', null)

        // if version is not defined, it doesn't match
        !Validators.matchesVersion(null, '9.0')
        !Validators.matchesVersion('', '9.0+')
        !Validators.matchesVersion(null, '9.0-')

        and: 'verify Content Packs versions check'
        Validators.matchesVersion('1.19.4', '1.19', true)
        !Validators.matchesVersion('1.19.4', '1.20', true)
        Validators.matchesVersion('1.20', '1.19', true)
        Validators.matchesVersion('1.21.7', '1.19', true)
        !Validators.matchesVersion('1.3.0', '1.19', true)
        !Validators.matchesVersion('2.0.0', '1.19', true)

    }

    void "verify version comparison"() {
        expect: 'verify strict matching'
        !Validators.isVersionGreater('9.0', '9.0')
        !Validators.isVersionGreater('9.0', '9.0.0.0')
        !Validators.isVersionGreater('9.0.0.0', '9.0')
        !Validators.isVersionGreater('v9.0', '9.0.0.0')

        !Validators.isVersionLess('9.0', '9.0')
        !Validators.isVersionLess('9.0', '9.0.0.0')
        !Validators.isVersionLess('9.0.0.0', '9.0')
        !Validators.isVersionLess('v9.0', '9.0.0.0')

        Validators.isVersionGreater('9.1', '9.0')
        Validators.isVersionGreater('9.1', '9.0.0.0')
        Validators.isVersionGreater('v9.1', '9.0.0.0')
        Validators.isVersionGreater('9.0.1', '9.0')
        Validators.isVersionGreater('9.0.1', '9.0.0.0')
        Validators.isVersionGreater('v9.0.0.1', '9.0.0.0')
        Validators.isVersionGreater('9.2-SNAPSHOT', '9.0.0.0')

        Validators.isVersionGreater('9.2.0.10', '9.2.0.9')
        Validators.isVersionGreater('9.2.0.10-SNAPSHOT', '9.2.0.9')
        Validators.isVersionGreater('9.2.1', '9.2.0.9')
        Validators.isVersionGreater('9.2.1', '9.2.0.9-SNAPSHOT')
        Validators.isVersionGreater('9.2.1.0-SNAPSHOT', '9.2.0-SNAPSHOT')
        Validators.isVersionGreater('9.2.0.1', '9.2-SNAPSHOT')

        !Validators.isVersionLess('9.1', '9.0')
        !Validators.isVersionLess('9.1', '9.0.0.0')
        !Validators.isVersionLess('v9.1', '9.0.0.0')
        !Validators.isVersionLess('9.0.1', '9.0')
        !Validators.isVersionLess('9.0.1', '9.0.0.0')
        !Validators.isVersionLess('v9.0.0.1', '9.0.0.0')
        !Validators.isVersionLess('9.2-SNAPSHOT', '9.0.0.0')

        Validators.isVersionLess('9.0', '9.1')
        Validators.isVersionLess('9.0.0.0', '9.1')
        Validators.isVersionLess('9.0.0.0', 'v9.1')
        Validators.isVersionLess('9.0', '9.0.1',)
        Validators.isVersionLess('9.0.0.0', '9.0.1',)
        Validators.isVersionLess('9.0.0.0', 'v9.0.0.1')
        Validators.isVersionLess('9.0.0.0', '9.2-SNAPSHOT')

        Validators.isVersionGreater('9.2.3.55', '9.2.3.4')
        Validators.isVersionGreater('9.2.3.55', '9.2.3.4.11')
        Validators.isVersionGreater('9.2.3.55-SNAPSHOT', '9.2.3.4.11-SNAPSHOT')

        Validators.isVersionLess('9.2.3.4', '9.2.3.55')
        Validators.isVersionLess('9.2.3.4.11', '9.2.3.55')
        Validators.isVersionLess('9.2.3.4.11-SNAPSHOT', '9.2.3.55-SNAPSHOT')
    }

}
