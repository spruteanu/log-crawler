package com.edifecs.support.core

import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class MacroSubstitutionContentResolverTest extends Specification {

    void 'verify macro replacement'() {
        expect:
        MacroSubstitutionContentResolver.of(['data.tablespace': 'mumu', 'test.empty': '']).toString('''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE ${data.tablespace}
TEST_EMPTY_MACROS ${test.empty}
/
''') == '''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE mumu
TEST_EMPTY_MACROS ${test.empty}
/
'''

        and:
        MacroSubstitutionContentResolver.of(['data.tablespace': 'mumu', 'mumu': 'cucu', 'mumu-macro': 'mumu-macro'] as Properties).toString('''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE ${data.tablespace}
CREATE INDEX IDXACCOUNTINFORMATION000 ON ACCOUNTINFORMATION(TRANSMISSIONSID) TABLESPACE ${mumu-macro};
/
''') == '''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE mumu
CREATE INDEX IDXACCOUNTINFORMATION000 ON ACCOUNTINFORMATION(TRANSMISSIONSID) TABLESPACE mumu-macro;
/
'''

        and:
        MacroSubstitutionContentResolver.ofMacros(['${data.tablespace}': 'mumu', 'mumu': 'cucu', '${mumu-macro}': 'mumu-macro'] as Properties).toString('''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE ${data.tablespace}
CREATE INDEX IDXACCOUNTINFORMATION000 ON ACCOUNTINFORMATION(TRANSMISSIONSID) TABLESPACE ${mumu-macro};
/
''') == '''CREATE TABLE Agreement(
    AgreementSID            NUMBER(19, 0)     NOT NULL,
    TpmTransactionSID       NUMBER(19, 0)     NOT NULL,
    Name                    VARCHAR2(100)     NOT NULL,
    Description             VARCHAR2(3000),
    Category                VARCHAR2(50),
    CreatedBySID            NUMBER(10, 0)     NOT NULL,
    ModifiedBySID           NUMBER(10, 0)     NOT NULL,
    CreatedDateTime         TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL,
    LastModifiedDateTime    TIMESTAMP(6)      DEFAULT SYSDATE NOT NULL
)
TABLESPACE mumu
CREATE INDEX IDXACCOUNTINFORMATION000 ON ACCOUNTINFORMATION(TRANSMISSIONSID) TABLESPACE mumu-macro;
/
'''

        and:
        !MacroSubstitutionContentResolver.ofMacros(['${data.tablespace}': 'mumu', 'mumu': 'cucu', '${mumu-macro}': 'mumu-macro'] as Properties).toString('/macro-replace-test.txt').contains('${')
    }

}
