package com.edifecs.support.scripts

import com.edifecs.support.Util
import com.edifecs.support.core.Directories
import com.edifecs.support.core.GroovyUtil
import com.edifecs.support.core.ZipWalkerTest
import junit.framework.Assert
import spock.lang.Specification

import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class MetadataTest extends Specification {

    @Group("explicit-class-group")
    @Description(name = "GroupedClass", description = "Has explicit group", author = "Test Author")
    class GroupedClass {}

    def "default group from jar internal path should strip version"() {
        given:
        def meta = new Metadata().path("/opt/libs/my-artifact-1.2.3.jar!/scripts/tool.groovy")
        expect:
        meta.group == 'my-artifact'
    }

    def "default group from jar with SNAPSHOT should strip version"() {
        given:
        def meta = new Metadata().path("C:/repo/lib/awesome-utility-1.0.0-SNAPSHOT.jar!/anything.groovy")
        expect:
        meta.group == 'awesome-utility'
    }

    def "default group for regular file should be parent directory"() {
        given:
        def meta = new Metadata().path("/home/user/tools/scripts/myScript.groovy")
        expect:
        meta.group == 'scripts'
    }

    @Description(name = "TestClass", description = "Test Description", author = "Test Author")
    class TestClass {}

    class NonAnnotatedClass {}

    def "parseMeta should handle group annotation on class"() {
        when:
        def metadata = Metadata.parseMeta(GroupedClass)
        then:
        metadata.group == "explicit-class-group"
    }

    def "parseMeta should handle Class object"() {
        when:
        def metadata = Metadata.parseMeta(TestClass)
        then:
        metadata.name == "TestClass"
        metadata.description == "Test Description"
        metadata.author == "Test Author"
    }

    def "parseMeta should handle instance object"() {
        given:
        def testInstance = new TestClass()

        when:
        def metadata = Metadata.parseMeta(testInstance)

        then:
        metadata.name == "TestClass"
        metadata.description == "Test Description"
        metadata.author == "Test Author"
    }

    def "parseMeta should use default values for non-annotated class"() {
        given:
        def nonAnnotatedInstance = new NonAnnotatedClass()

        when:
        def metadata = Metadata.parseMeta(nonAnnotatedInstance)

        then:
        metadata.name == "Unnamed"
        metadata.description == "No description"
        metadata.author == "Unknown"
    }

    void 'parse metadata from groovy script'() {
        when:
        def meta = Metadata.parseMeta(GroovyUtil.compileText("""
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.Support
import com.edifecs.support.core.NasTest

@Description(
        name = "File system speed test",
        description = "Verifies file system how fast a file can be copied synchronously or asynchronously",
        author = "Serge Pruteanu",
        usage = '''Usage: tool [folder] [sourceFile] [repeats count] [number of threads]
    Examples: "/collect/nas-test source-file.txt 2000 50"'''
)
@Argument(name = "folder", description = "Folder name where nas test will be performed")
@Argument(name = "sourceFile", description = "Used source file to be cloned/copied")
@Argument(name = "repeats count", description = "Number of repeats")
@Argument(name = "number of threads", description = "Number of used threads to perform the test, default value one, which means test will run synchronously", required = false)
static void execute(String[] args) {
    NasTest.execute(args)
}

Support.info {
    execute(args)
}
"""))
        then:
        meta != null
        meta.name == 'File system speed test'
        meta.description == 'Verifies file system how fast a file can be copied synchronously or asynchronously'
        meta.author == 'Serge Pruteanu'
        meta.usage == 'Usage: tool [folder] [sourceFile] [repeats count] [number of threads]\n' +
                '    Examples: "/collect/nas-test source-file.txt 2000 50"'
        meta.arguments == [
                [name: 'folder', description: 'Folder name where nas test will be performed', required: true],
                [name: 'sourceFile', description: 'Used source file to be cloned/copied', required: true],
                [name: 'repeats count', description: 'Number of repeats', required: true],
                [name: 'number of threads', description: "Number of used threads to perform the test, default value one, which means test will run synchronously", required: false],
        ]
    }

    void 'verify scripts lookup'() {
        def scriptsFolder = Util.protectionDomainFile()
        def scripts = Metadata.lookup(null, scriptsFolder)
        def libFolder = new File(scriptsFolder, 'lib')
        if (libFolder.exists()) {
            Directories.delete(libFolder.toPath())
        }
        libFolder.mkdirs()

        expect: 'verify scripts lookup from folder'
        scripts
        for (final meta : scripts) {
            Assert.assertFalse(meta.isLibraryScript())
        }

        and: 'verify scripts lookup from jar'
        ZipWalkerTest.zipIt(new File(libFolder, 'scripts.jar').absolutePath, scriptsFolder.absolutePath,
                scripts.stream().map { new File(it.path).getName() }.collect(Collectors.toList()).toArray([] as String[])
        )
        null != (scripts = Metadata.lookup(libFolder, null))
        scripts
        for (final meta : scripts) {
            Assert.assertTrue(meta.isLibraryScript())
        }
    }
}
