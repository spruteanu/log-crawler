# support-tools
<img src="docs/support-tools-overview.svg" alt="">

> For automated changes by Junie, see: [docs/junie-guidelines.md](docs/junie-guidelines.md)

## Support scripts tool
```powershell
script-runner samples/collect-info-sample
script-runner samples/collect-info-sample samples/verify-sample
script-runner -destination logs-dups.zip "/collect/all-logs ServiceManager" /validate/validate-duplicate-jars.groovy
```

### API
<img src="docs/support-tools-API.svg" alt="">

### Collect info scripts
```groovy
Support.info {
    add findFiles('${ECRootPath}/TM/install/config.xml')
//    add findFiles('${ECRootPath}/TM/install')
//    include('/collect/tm-classic-install')

    include('/collect/config-server-repository')

    include('/collect/all-logs TM*')
//    include('/collect/all-logs')

    include('/collect/environment-vars')
    include('/collect/processes')
    include('/collect/jstack config-server')
    include('/collect/java-lsof config-server')
}
```
[Collect info sample](dist/src/main/samples/collect-info-sample.groovy)


### Validate scripts
```groovy
Support.info {
   include('/validate/validate-vars ECRootPath XERoot XESRoot XEUSER')

   error('directories.structure', 'Incorrect directory structure', {
      boolean result
      def file = new File(resolveVariable('${ECRootPath}'))
      result = file.exists()
      if (!result) {
         error('directories.structure', "Directory: '$file' doesn't exists")
      }
      return !result
   })

   include('/validate/validate-duplicate-jars')
}
```
[Validate sample](dist/src/main/samples/validate-sample.groovy)

## Fixture scripts
```groovy
Support.fixture {
    include('samples/validate-sample')
    if (!hasErrors()) {
        include('/fixture/tm-start')
    }
}
```
[Fixture sample](dist/src/main/samples/fixture-sample.groovy)


### Logs analysis
<img src="docs/support-tools-logs-analysis.png" alt="">

### AWS transport helper
For programmatic connectivity to AWS EC2 using AWS SDK v2, use AwsTransport (module support-ide):

- Default credentials chain (env vars, profile, instance role):
  - Ec2Client ec2 = AwsTransport.ec2Default("us-west-2");
  - boolean ok = AwsTransport.pingEc2(ec2);

- Explicit profile:
  - Ec2Client ec2 = AwsTransport.ec2FromProfile("myprofile", "us-east-1");

- Static credentials:
  - Ec2Client ec2 = AwsTransport.ec2FromStatic("AKIA...","SECRET","SESSION","us-east-1");

You can also verify identity with STS using AwsTransport.pingSts(provider, region).
<img src="docs/support-tools-logs-analysis.png" alt="">

# Support scenario example
1. read EcRoot
2. collect envVariables 
3. collect TM/install/config.xml
4. collect ConfigServer
5. collect application logs
6. collect running processes
7. collect java process stack
8. zip it

> To Review

# Ideas
1. Help Service running on customer end, a small window GUI buttons:
    - send result zip to centralized edifecs server/email, group results by client
    - contact edifecs support button that opens email to technical support person from Edifecs
2. Tool collector can change log level programmatically to debug/trace

- LSOF script (done)
- SQL script that fix broken TRs in TPM 

# QA Scenarios
   stop/start services
      executed commands (shell) (done)

   Engage ServiceManager in debug mode and collect logs

   Script that will read TM config.xml and will start/stop services (done)
   - tool that will collect performance for each ETL or Tracking info component (Similar what XES team have in ssh []Edifecs\XEServer\bin\ssh-client\ssh.bat)

# Tool implementation scenarios
1. For distributed env:
    - result snapshot for each machine, group and merge into a centralized location
    - check if config.xml files are the same
2. For Releases/Service Pack/Hot fixes, compare client's image jars with a snapshot of expected jars. HTML Integrity report like EAM, for ex.
    - Missing files
    - Extra files
    - Different files (check MD5?)
3. Compatible Content Pack Addons and TM versions checker
