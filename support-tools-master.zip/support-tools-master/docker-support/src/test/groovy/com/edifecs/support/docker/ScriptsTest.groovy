package com.edifecs.support.docker

import com.edifecs.support.Support
import spock.lang.Ignore
import spock.lang.Specification

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ScriptsTest extends Specification {

    @Ignore
    void 'verify info script'() {
        def context = Support.info {
            include('/collect/docker-info.groovy')
        }
        expect:
        context
        context.values()
    }
}
