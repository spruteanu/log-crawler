package com.edifecs.support.docker;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import com.github.dockerjava.api.DockerClient;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

/**
 * DockerSupport provides helpers to create and validate Docker client connections
 * using docker-java. It centralizes common connection scenarios: from environment,
 * default local socket, explicit host/port with optional TLS, and custom unix socket.
 */
@SuppressWarnings({"squid:S2095", "squid:S3740"})
public class DockerSupport implements AutoCloseable {
    private DockerClient client;

    public DockerClient getClient() {
        return client;
    }

    public void setClient(DockerClient client) {
        this.client = client;
    }

    public DockerSupport withClient(DockerClient client) {
        setClient(client);
        return this;
    }

    @Override
    public void close() throws Exception {
        if (client != null) {
            HttpTransport.tryClose(client);
            client = null;
        }
    }

    static DockerSupport of() {
        final DockerSupport support = new DockerSupport();
        support.withClient(HttpTransport.connectDefault());
        return support;
    }
    static DockerSupport of(DockerClient client) {
        return new DockerSupport().withClient(client);
    }

    public static DockerContext info(DockerContext context, @DelegatesTo(DockerContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static Context info(@DelegatesTo(DockerContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof DockerContext) {
            return info((DockerContext) context, closure);
        }
        final DockerContext ctx = context != null ? (DockerContext) new DockerContext().clone(context) : new DockerContext();
        info(ctx, closure);
        return ctx;
    }

}
