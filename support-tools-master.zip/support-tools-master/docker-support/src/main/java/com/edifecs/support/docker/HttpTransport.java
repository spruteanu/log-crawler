package com.edifecs.support.docker;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.exception.DockerClientException;
import com.github.dockerjava.api.model.Info;
import com.github.dockerjava.core.DefaultDockerClientConfig;
import com.github.dockerjava.core.DockerClientImpl;
import com.github.dockerjava.httpclient5.ApacheDockerHttpClient;
import com.github.dockerjava.transport.DockerHttpClient;

import java.io.Closeable;
import java.io.IOException;
import java.time.Duration;
import java.util.Objects;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class HttpTransport {
    private static DockerHttpClient defaultHttpClient(DefaultDockerClientConfig config) {
        ApacheDockerHttpClient.Builder builder = new ApacheDockerHttpClient.Builder()
                .dockerHost(config.getDockerHost())
                .sslConfig(config.getSSLConfig())
                .connectionTimeout(Duration.ofSeconds(30))
                .responseTimeout(Duration.ofSeconds(45));
        return builder.build();
    }

    /**
     * Build a DockerClient using DOCKER_* environment variables (like Docker CLI).
     * Equivalent to DefaultDockerClientConfig.createDefaultConfigBuilder().build().
     */
    public static DockerClient connectFromEnv() {
        DefaultDockerClientConfig config = DefaultDockerClientConfig.createDefaultConfigBuilder().build();
        DockerHttpClient httpClient = defaultHttpClient(config);
        return DockerClientImpl.getInstance(config, httpClient);
    }

    private static String defaultLocalDockerHost() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            return "npipe:////./pipe/docker_engine";
        }
        // For Linux/macOS default to Unix socket
        return "unix:///var/run/docker.sock";
    }

    /**
     * Build a DockerClient to the default local Docker daemon.
     * Tries DOCKER_* env, and if DOCKER_HOST is not defined falls back to unix:///var/run/docker.sock (Linux/Mac)
     * or npipe:////./pipe/docker_engine (Windows). No network calls are performed here.
     */
    public static DockerClient connectDefault() {
        String dockerHost = System.getenv("DOCKER_HOST");
        if (dockerHost == null || dockerHost.isBlank()) {
            // Fallback to well-known defaults by OS
            dockerHost = defaultLocalDockerHost();
        }
        DefaultDockerClientConfig config = DefaultDockerClientConfig.createDefaultConfigBuilder()
                .withDockerHost(dockerHost)
                .build();
        DockerHttpClient httpClient = defaultHttpClient(config);
        return DockerClientImpl.getInstance(config, httpClient);
    }

    /**
     * Build a DockerClient for a specific TCP host.
     * Example host: tcp://127.0.0.1:2375
     * If tlsVerify is true, provide certPath (folder containing certs) and optionally apiVersion.
     */
    public static DockerClient connect(String host, Integer port, boolean tlsVerify, String certPath, String apiVersion) {
        Objects.requireNonNull(host, "host");
        String scheme = tlsVerify ? "https" : "http";
        String authority = port == null ? host : host + ":" + port;
        String dockerHost = scheme + "://" + authority;

        DefaultDockerClientConfig.Builder builder = DefaultDockerClientConfig.createDefaultConfigBuilder()
                .withDockerHost(dockerHost)
                .withDockerTlsVerify(tlsVerify);

        if (tlsVerify && certPath != null && !certPath.isBlank()) {
            builder.withDockerCertPath(certPath);
        }
        if (apiVersion != null && !apiVersion.isBlank()) {
            builder.withApiVersion(apiVersion);
        }

        DefaultDockerClientConfig config = builder.build();
        DockerHttpClient httpClient = defaultHttpClient(config);
        return DockerClientImpl.getInstance(config, httpClient);
    }

    /**
     * Connect using a unix domain socket path, e.g. /var/run/docker.sock
     */
    public static DockerClient connectUnixSocket(String socketPath) {
        Objects.requireNonNull(socketPath, "socketPath");
        String dockerHost = "unix://" + socketPath;
        DefaultDockerClientConfig config = DefaultDockerClientConfig.createDefaultConfigBuilder()
                .withDockerHost(dockerHost)
                .build();
        DockerHttpClient httpClient = defaultHttpClient(config);
        return DockerClientImpl.getInstance(config, httpClient);
    }

    /**
     * Checks connectivity by calling Docker ping endpoint.
     * Returns true if successful, false otherwise.
     */
    public static boolean ping(DockerClient client) {
        try {
            client.pingCmd().exec();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    static void tryClose(Object obj) throws IOException {
        if (obj instanceof Closeable) {
            ((Closeable) obj).close();
        }
    }

    /**
     * Safely closes a DockerClient and its underlying HTTP client when possible.
     */
    public static void closeQuietly(DockerClient client) {
        if (client == null) return;
        try {
            tryClose(client);
        } catch (IOException ignore) { /*noop*/ }
    }

    /**
     * Returns Docker daemon Info. Throws DockerClientException if request fails.
     */
    public static Info info(DockerClient client) {
        try {
            return client.infoCmd().exec();
        } catch (Exception e) {
            throw new DockerClientException("Failed to retrieve Docker info: " + e.getMessage(), e);
        }
    }
}
