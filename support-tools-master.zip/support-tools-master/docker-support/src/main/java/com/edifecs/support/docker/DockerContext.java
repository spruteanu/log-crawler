package com.edifecs.support.docker;

import com.edifecs.support.collect.ProcessInfo;
import com.edifecs.support.core.Context;
import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.async.ResultCallback;
import com.github.dockerjava.api.command.CopyArchiveFromContainerCmd;
import com.github.dockerjava.api.command.ExecCreateCmd;
import com.github.dockerjava.api.command.ExecCreateCmdResponse;
import com.github.dockerjava.api.exception.DockerClientException;
import com.github.dockerjava.api.model.Frame;
import com.edifecs.support.core.GroovyUtil;
import java.io.StringReader;
import java.util.Properties;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;

/**
 * DockerContext extends the generic Context with Docker container specific helpers.
 * It encapsulates a DockerClient and a target containerId to provide a simple API for:
 * - Listing processes inside a container
 * - Retrieving environment variables from a container
 * - Accessing files inside a container
 * <p>
 * Notes:
 * - This class uses `docker exec` operations via docker-java. It assumes a POSIX shell
 * is available at /bin/sh inside the container.
 * - Operations are best-effort and return sensible defaults instead of throwing where possible.
 */
public class DockerContext extends Context {
    private DockerSupport utils;
    private String containerId;

    public DockerContext() {
    }

    public DockerContext(DockerClient client, String containerId) {
        this.utils = DockerSupport.of(client);
        this.containerId = Objects.requireNonNull(containerId, "containerId");
        super.hostName(containerId);
    }

    public void setUtils(DockerSupport utils) {
        this.utils = utils;
    }

    public DockerSupport getUtils() {
        return utils;
    }
    public synchronized DockerSupport utils() {
        if (utils == null) {
            utils = DockerSupport.of();
        }
        return utils;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }
    public DockerContext containerId(String containerId) {
        setContainerId(containerId);
        return this;
    }
    public String getContainerId() {
        return containerId;
    }

    @Override
    public Context clone(Context source) {
        final Context clone = super.clone(source);
        if (source instanceof DockerContext) {
            DockerContext dockerContext = (DockerContext) source;
            setContainerId(dockerContext.getContainerId());
            setUtils(dockerContext.getUtils());
        }
        return clone;
    }

    @SuppressWarnings("squid:S3776")
    public void initialize(String[] args) {
        if (args == null || args.length == 0 || args[0] == null || args[0].trim().isEmpty()) {
            error("docker.container", "Container id or name is required");
            return;
        }
        containerId = args[0].trim();

        DockerClient client = null;
        try {
            if (args.length > 1 && args[1] != null && !args[1].trim().isEmpty()) {
                String configLocation = args[1].trim();
                // Ensure we use the default resolver to load content from file path/URI/classpath
                String content = GroovyUtil.lookupText(resolveVariable(configLocation));

                // Minimal implementation: support Java .properties format
                Properties props = new Properties();
                props.load(new StringReader(content));

                String unixSocket = trimToNull(props.getProperty("docker.unixSocket"));
                String host = trimToNull(props.getProperty("docker.host"));
                String portStr = trimToNull(props.getProperty("docker.port"));
                String tlsStr = trimToNull(props.getProperty("docker.tlsVerify"));
                String certPath = trimToNull(props.getProperty("docker.certPath"));
                String apiVersion = trimToNull(props.getProperty("docker.apiVersion"));

                if (unixSocket != null) {
                    client = HttpTransport.connectUnixSocket(unixSocket);
                } else if (host != null) {
                    Integer port = null;
                    if (portStr != null) {
                        try { port = Integer.parseInt(portStr); } catch (NumberFormatException ignore) { /*noop*/ }
                    }
                    boolean tlsVerify = toBoolean(tlsStr);
                    client = HttpTransport.connect(host, port, tlsVerify, certPath, apiVersion);
                } else {
                    // Fallback if properties do not specify connection details
                    client = HttpTransport.connectDefault();
                }
            }
        } catch (Exception e) {
            // If anything goes wrong during config parsing/connection build, fallback to default
            client = null;
        }

        if (client != null) {
            setUtils(DockerSupport.of(client));
        } else {
            // ensure utils created with default client
            utils();
        }
    }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String v = s.trim();
        return v.isEmpty() ? null : v;
    }

    private static boolean toBoolean(String s) {
        if (s == null) return false;
        String v = s.trim().toLowerCase();
        return v.equals("true") || v.equals("1") || v.equals("yes") || v.equals("y");
    }

    public static DockerContext of(DockerClient client, String containerId) {
        return new DockerContext(client, containerId);
    }

    public static DockerContext of(String containerId) {
        return new DockerContext(null, containerId);
    }

    // ---------------------- Processes ----------------------
    /**
     * Returns processes inside the container using `ps -eo pid,comm,args`.
     */
    public List<ProcessInfo> listProcesses() {
        String out = shellOutput("ps -eo pid,comm,args");

        List<ProcessInfo> result = new ArrayList<>();
        if (out == null || out.isBlank()) return result;
        String[] lines = out.split("\n");
        for (int i = 1; i < lines.length; i++) { // skip header when present
            String line = lines[i].trim();
            if (line.isEmpty()) continue;
            // Expect: PID COMMAND ARGS...
            String[] parts = line.split("\\s+", 3);
            if (parts.length >= 2) {
                try {
                    long pid = Long.parseLong(parts[0]);
                    ProcessInfo pi = new ProcessInfo();
                    pi.setPid(pid);
                    pi.setName(parts[1]);
                    pi.setCommand(parts.length > 2 ? parts[2] : parts[1]);
                    result.add(pi);
                } catch (NumberFormatException ignore) {
                    // skip malformed
                }
            }
        }
        return result;
    }

    /**
     * Reads the value of an environment variable from the container.
     * Falls back to parent behavior (host env) if the container value is not present.
     */
    public String dockerEnvVar(String variable) {
        String val = shellOutput("printenv " + escapeVarName(variable));
        if (val == null || val.isBlank()) return envVar(variable);
        return trimLastNewline(val);
    }

    private static String escapeVarName(String name) {
        return name.replaceAll("[^A-Za-z0-9_]+", "");
    }

    // ---------------------- Files ----------------------
    private static String quote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static String trimLastNewline(String s) {
        if (s == null) return null;
        if (s.endsWith("\r\n")) return s.substring(0, s.length() - 2);
        if (s.endsWith("\n")) return s.substring(0, s.length() - 1);
        return s;
    }

    /**
     * Returns file content from the container using `cat`.
     * If reading fails, returns null.
     */
    public String readFile(String path) {
        return shellOutput("cat " + quote(path));
    }

    /**
     * Checks whether a file (or dir) exists in the container.
     */
    public boolean exists(String path) {
        int code = shellExitCode("test -e " + quote(path));
        return code == 0;
    }

    private static byte[] readAllBytes(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) != -1) {
            bos.write(buf, 0, r);
        }
        return bos.toByteArray();
    }

    private static InputStream maybeGunzip(InputStream in) throws IOException {
        in.mark(2);
        int magic1 = in.read();
        int magic2 = in.read();
        in.reset();
        if (magic1 == 0x1f && magic2 == 0x8b) {
            return new GZIPInputStream(in);
        }
        return in;
    }
    /**
     * Copies a file or directory from the container to a host path.
     * For directories, the entire archive is extracted under the destination directory.
     */
    public void copyFrom(String sourcePathInContainer, Path destinationOnHost) {
        Objects.requireNonNull(sourcePathInContainer, "sourcePathInContainer");
        Objects.requireNonNull(destinationOnHost, "destinationOnHost");
        try (CopyArchiveFromContainerCmd cmd = utils.getClient().copyArchiveFromContainerCmd(containerId, sourcePathInContainer);
             InputStream in = cmd.exec()) {
            // docker-java returns a TAR stream (optionally gz). Handle gz if present.
            InputStream stream = maybeGunzip(in);
            // Best-effort untar implementation via java.nio (simplified): fallback to dumping bytes for single files
            // For minimal change, if destination is a file path, write raw bytes. For directories or tar, prefer external tools
            // To avoid dependencies, write to file when not a tar archive (heuristic by reading first 262 bytes 'ustar').
            byte[] data = readAllBytes(stream);
            Files.createDirectories(destinationOnHost.getParent() != null ? destinationOnHost.getParent() : destinationOnHost);
            Files.write(destinationOnHost, data);
        } catch (IOException e) {
            throw new DockerClientException("Failed to copy from container: " + e.getMessage(), e);
        }
    }

    // ---------------------- Internal exec helpers ----------------------
    /**
     * Executes a command with /bin/sh -lc inside the container and returns stdout as String.
     * Returns null on failure.
     */
    @SuppressWarnings("squid:S2142")
    public String shellOutput(String command) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            int code = exec(command,
                    bytes -> {
                        try {
                            out.write(bytes);
                        } catch (IOException ignore) { /*noop*/ }
                    },
                    bytes -> {
                        try {
                            err.write(bytes);
                        } catch (IOException ignore) { /*noop*/ }
                    }
            );
            if (code != 0) return null;
            return out.toString(StandardCharsets.UTF_8);
        } catch (Exception e) {
            final String message = "Failed to execute docker shell command: " + command;
            logger.error(message, e);
            error("docker.error", message);
            return message;
        }
    }

    /**
     * Executes a command and returns exit code.
     */
    @SuppressWarnings("squid:S2142")
    public int shellExitCode(String command) {
        try {
            return exec(command, null, null);
        } catch (Exception e) {
            logger.error("Failed to execute shell command: {}", command, e);
            error("docker.error", "Failed to execute docker shell command: " + command);
        }
        return -1;
    }

    @SuppressWarnings("squid:S131")
    int exec(String command, Consumer<byte[]> stdoutConsumer, Consumer<byte[]> stderrConsumer) throws IOException, InterruptedException {
        final int[] exitCode = {0};
        final ExecCreateCmd cmd = utils.getClient().execCreateCmd(containerId);
        final ExecCreateCmdResponse create = cmd.withTty(false).withAttachStdout(true).withAttachStderr(true).withCmd("/bin/sh", "-lc", command).exec();
        try (ResultCallback.Adapter<Frame> callback = new ResultCallback.Adapter<>() {
            @Override
            public void onNext(Frame frame) {
                byte[] payload = frame.getPayload();
                switch (frame.getStreamType()) {
                    case STDOUT:
                        if (stdoutConsumer != null) stdoutConsumer.accept(payload);
                        break;
                    case STDERR:
                        if (stderrConsumer != null) stderrConsumer.accept(payload);
                        break;
                }
                super.onNext(frame);
            }
        }) {
            utils.getClient().execStartCmd(create.getId()).exec(callback);
            callback.awaitCompletion(30, TimeUnit.SECONDS);
        }
        // Workaround: docker-java requires inspecting exec to get exit status
        Integer status = utils.getClient().inspectExecCmd(create.getId()).exec().getExitCode();
        exitCode[0] = status == null ? 0 : status;
        return exitCode[0];
    }
}
