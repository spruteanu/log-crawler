import com.edifecs.support.docker.DockerSupport
import com.edifecs.support.docker.HttpTransport
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role
import com.github.dockerjava.api.model.Info

@Description(
        name = "Docker Daemon Info",
        description = "Returns information from the current Docker client as a Map.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/docker-info [config file]
Examples:
    script-runner "/collect/docker-info"
    # with explicit Docker client config (Java .properties):
    script-runner "/collect/docker-info /path/to/docker.properties"

Supported config properties (Java .properties):
    docker.unixSocket=/var/run/docker.sock
    docker.host=127.0.0.1
    docker.port=2375
    docker.tlsVerify=false
    docker.certPath=/path/to/certs
    docker.apiVersion=1.43'''
)
@Argument(name = "Config file (optional)", description = "Path/URI/classpath to a .properties file used to construct DockerClient; see Supported config properties in usage")
@Role("docker")
static def execute(String... args) {
    DockerSupport.info {
        initialize(args)

        def client = utils().getClient()
        Map<String, Object> map = new LinkedHashMap<>()
        Info info = HttpTransport.info(client)
        // Populate a stable subset of Info into a Map. Null-safe accessors are used.
        map.serverVersion = info?.serverVersion
        map.id = info?.id
        map.name = info?.name
        map.operatingSystem = info?.operatingSystem
        map.osType = info?.osType
        map.kernelVersion = info?.kernelVersion
        map.architecture = info?.architecture
        map.nCPU = info?.nCPU
        map.memTotal = info?.memTotal
        map.swapTotal = info?.swapTotal
        map.dockerRootDir = info?.dockerRootDir
        map.httpProxy = info?.httpProxy
        map.httpsProxy = info?.httpsProxy
        map.noProxy = info?.noProxy
        map.indexServerAddress = info?.indexServerAddress
        map.initBinary = info?.initBinary
        map.initCommit = info?.initCommit?.id
        map.productLicense = info?.productLicense
        map.loggingDriver = info?.loggingDriver
        map.cgroupDriver = info?.cgroupDriver
        map.cgroupVersion = info?.cgroupVersion
        map.seccompProfile = info?.securityOptions
        map.containerdCommit = info?.containerdCommit?.id
        map.runcCommit = info?.runcCommit?.id
        map.runcCommitExpected = info?.runcCommit?.expected
        map.gitCommit = info?.gitCommit
        map.registryConfig = info?.registryConfig?.indexConfigs?.keySet()?.toArray(new String[0])
        map.driver = info?.driver
        map.driverStatus = info?.driverStatus
        map.plugins = [
                volume       : info?.plugins?.volumes,
                network      : info?.plugins?.network,
                authorization: info?.plugins?.authorization
        ]
        map.experimentalBuild = info?.experimentalBuild
        map.defaultRuntime = info?.defaultRuntime
        map.runtimes = info?.runtimes?.keySet()?.toArray(new String[0])
        map.liveRestoreEnabled = info?.liveRestoreEnabled
        map.isolation = info?.isolation
        map.containerCount = info?.containers
        map.containerRunning = info?.containersRunning
        map.containerPaused = info?.containersPaused
        map.containerStopped = info?.containersStopped
        map.imageCount = info?.images
        add('docker.info', map)
    }
}

execute(args)
