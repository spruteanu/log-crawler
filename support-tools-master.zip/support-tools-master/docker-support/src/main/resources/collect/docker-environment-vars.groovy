import com.edifecs.support.docker.DockerSupport
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "List Environment Variables (Docker)",
        description = "Retrieves environment variables from inside a Docker container.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/docker-environment-vars <container id|name> [config file]
Examples:
    script-runner "/collect/docker-environment-vars my-container"
    script-runner "/collect/docker-environment-vars 3f1c2a..."
    # with explicit Docker client config (Java .properties):
    script-runner "/collect/docker-environment-vars my-container /path/to/docker.properties"

Supported config properties (Java .properties):
    docker.unixSocket=/var/run/docker.sock
    docker.host=127.0.0.1
    docker.port=2375
    docker.tlsVerify=false
    docker.certPath=/path/to/certs
    docker.apiVersion=1.43'''
)
@Argument(name = "Container", description = "Docker container ID or name to exec into")
@Argument(name = "Config file (optional)", description = "Path/URI/classpath to a .properties file used to construct DockerClient; see Supported config properties in usage")
@Role("docker")
static def execute(String... args) {
    DockerSupport.info {
        initialize(args)
        add('environment.vars', shellOutput('printenv'))
    }
}
execute(args)
