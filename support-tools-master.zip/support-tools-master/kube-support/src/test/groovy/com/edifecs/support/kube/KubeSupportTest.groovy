package com.edifecs.support.kube

import spock.lang.Ignore
import spock.lang.Specification

class KubeSupportTest extends Specification {

    @Ignore
    void 'verify helper methods'() {
        given:
        def ks = KubeSupport.of()
        def res;
        expect:
        null != (res = ks.nodesProperties())
        null != (res = ks.containers())
        res
    }

    @Ignore
    void 'retrieve process list from a node (requires cluster)'() {
        given:
        def ks = KubeSupport.of()

        when:
        def list = ks.nodeProcessList(System.getProperty("kube.test.node", "minikube"))

        then:
        list != null
    }
}
