package com.edifecs.support.kube

import com.edifecs.support.Support
import spock.lang.Ignore
import spock.lang.Specification

/**
 * Validates that the kube-info script can be included and executed within the Support script framework.
 * The test is ignored by default because it requires access to a Kubernetes cluster.
 */
class ScriptsTest extends Specification {

    @Ignore
    void 'verify kube-info script'() {
        def context = Support.info {
            include('/collect/kube-info.groovy')
        }
        expect:
        context
        context.values()
    }
}
