package com.edifecs.support.kube;

import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.util.ClientBuilder;
import io.kubernetes.client.util.Config;

/**
 * Connection helpers for Kubernetes Java client.
 */
public final class KubeTransport {
    private KubeTransport() {}

    private static ApiClient tune(ApiClient client) {
        // Be forward-compatible with clusters that add extra fields (e.g., volumeMounts in status)
        // by allowing unknown JSON properties during deserialization.
        try {
            client.setLenientOnJson(true);
        } catch (NoSuchMethodError | Exception ignored) {
            // Older/newer clients may not support this flag; fail leniently.
        }
        // Optionally adjust timeouts
        client.setReadTimeout(60_000);
        client.setConnectTimeout(30_000);
        io.kubernetes.client.openapi.Configuration.setDefaultApiClient(client);
        return client;
    }

    public static ApiClient connectDefault() {
        try {
            io.kubernetes.client.openapi.JSON.setLenientOnJson(true);
            // Will try: KUBECONFIG, ~/.kube/config, or in-cluster if available
            ApiClient client = Config.defaultClient();
            return tune(client);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to initialize Kubernetes client", e);
        }
    }

    public static ApiClient connectFromKubeconfig(String kubeconfigYaml) {
        try {
            ApiClient client = ClientBuilder.kubeconfig(io.kubernetes.client.util.KubeConfig.loadKubeConfig(new java.io.StringReader(kubeconfigYaml))).build();
            return tune(client);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid kubeconfig provided", e);
        }
    }

    public static CoreV1Api core(ApiClient client) {
        if (client == null) client = connectDefault();
        return new CoreV1Api(client);
    }
}
