package com.edifecs.support.kube;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.apis.VersionApi;
import io.kubernetes.client.openapi.models.V1Namespace;
import io.kubernetes.client.openapi.models.V1Node;
import io.kubernetes.client.openapi.models.V1Pod;

import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Context for Kubernetes operations in scripts.
 */
public class KubeContext extends Context {
    private KubeSupport utils;

    public KubeContext() {
        super();
    }

    public KubeContext(ApiClient client) {
        this();
        setUtils(KubeSupport.of(client));
    }

    public void setUtils(KubeSupport utils) {
        this.utils = utils;
    }

    public KubeSupport getUtils() {
        return utils;
    }

    public synchronized KubeSupport utils() {
        if (utils == null) {
            utils = KubeSupport.of();
        }
        return utils;
    }

    @Override
    public Context clone(Context source) {
        final Context clone = super.clone(source);
        if (source instanceof KubeContext) {
            KubeContext kubeContext = (KubeContext) source;
            setUtils(kubeContext.getUtils());
        }
        return clone;
    }

    /**
     * Initializes this context using optional args.
     * Args:
     * [0] optional config location (path/URI/classpath) to kubeconfig YAML or properties.
     * If a .properties file is provided, supported keys:
     * kube.kubeconfig: path/URI/classpath to kubeconfig YAML content
     */
    public void initialize(String[] args) {
        ApiClient client = null;
        try {
            if (args != null && args.length > 0 && args[0] != null && !args[0].trim().isEmpty()) {
                String configLocation = args[0].trim();
                String content = GroovyUtil.lookupText(resolveVariable(configLocation));
                if (configLocation.endsWith(".properties")) {
                    Properties props = new Properties();
                    props.load(new StringReader(content));
                    String kubeconfigPath = trimToNull(props.getProperty("kube.kubeconfig"));
                    if (kubeconfigPath != null) {
                        String kubeconfigYaml = GroovyUtil.lookupText(resolveVariable(kubeconfigPath));
                        client = KubeTransport.connectFromKubeconfig(kubeconfigYaml);
                    }
                } else {
                    // assume kubeconfig yaml
                    client = KubeTransport.connectFromKubeconfig(content);
                }
            }
        } catch (Exception e) {
            client = null; // fall back
        }
        if (client != null) {
            setUtils(KubeSupport.of(client));
        } else {
            utils();
        }
    }

    private static String trimToNull(String s) {
        if (s == null) return null;
        String v = s.trim();
        return v.isEmpty() ? null : v;
    }

    public ApiClient client() {
        return utils().getClient();
    }

    public CoreV1Api core() {
        return KubeTransport.core(client());
    }

    // ---------------------- Info helpers ----------------------

    public Map<String, Object> clusterVersion() {
        Map<String, Object> map = new LinkedHashMap<>();
        try {
            VersionApi v = new VersionApi(client());
            Object version = v.getCode();
            map.put("raw", String.valueOf(version));
        } catch (Exception e) {
            error("kube.version", e.getMessage());
        }
        return map;
    }

    public List<V1Node> listNodes() throws ApiException {
        return core().listNode().execute().getItems();
    }

    public List<V1Namespace> listNamespaces() throws ApiException {
        return core().listNamespace().execute().getItems();
    }

    public List<V1Pod> listPods(String namespace) throws ApiException {
        if (namespace == null || namespace.isBlank()) namespace = ""; // all namespaces
        if (namespace.isEmpty()) {
            return core().listPodForAllNamespaces().execute().getItems();
        }
        return core().listNamespacedPod(namespace).execute().getItems();
    }

    public Map<String, Object> basicStats() {
        Map<String, Object> m = new LinkedHashMap<>();
        try {
            List<V1Node> nodes = listNodes();
            List<V1Namespace> namespaces = listNamespaces();
            List<V1Pod> pods = listPods("");
            m.put("nodeCount", nodes.size());
            m.put("namespaceCount", namespaces.size());
            m.put("podCount", pods.size());
            m.put("namespaces", namespaces.stream().map(ns -> ns.getMetadata().getName()).collect(Collectors.toList()));
        } catch (Exception e) {
            error("kube.stats", e.getMessage());
        }
        return m;
    }
}
