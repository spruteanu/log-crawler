package com.edifecs.support.kube;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.models.*;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * KubeSupport provides helpers to create and validate Kubernetes client connections
 * using the official Kubernetes Java client. It centralizes common connection scenarios:
 * from in-cluster config, KUBECONFIG, or default local config.
 */
@SuppressWarnings({"squid:S2095", "squid:S3776", "squid:S1141", "squid:S3740"})
public class KubeSupport implements AutoCloseable {
    private ApiClient client;

    public ApiClient getClient() {
        return client;
    }

    public void setClient(ApiClient client) {
        this.client = client;
    }

    public KubeSupport withClient(ApiClient client) {
        setClient(client);
        return this;
    }

    @Override
    public void close() {
        // ApiClient does not require explicit close, but keep method for symmetry
        client = null;
    }

    static KubeSupport of() {
        final KubeSupport support = new KubeSupport();
        support.withClient(KubeTransport.connectDefault());
        return support;
    }

    static KubeSupport of(ApiClient client) {
        return new KubeSupport().withClient(client);
    }

    public static KubeContext info(KubeContext context, @DelegatesTo(KubeContext.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static Context info(@DelegatesTo(KubeContext.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof KubeContext) {
            return info((KubeContext) context, closure);
        }
        final KubeContext ctx = context != null ? (KubeContext) new KubeContext().clone(context) : new KubeContext();
        info(ctx, closure);
        return ctx;
    }

    /**
     * Returns Kubernetes Nodes information as a map of properties per node.
     * Key: node name; Value: map of node properties (labels, annotations, capacity, allocatable, addresses, versions, etc).
     * This method avoids throwing and returns an empty map on errors.
     */
    public List<Map<String, Object>> nodesProperties() throws ApiException {
        final List<Map<String, Object>> result = new ArrayList<>();
        CoreV1Api api = KubeTransport.core(getClient());
        List<V1Node> nodes = api.listNode().execute().getItems();
        for (V1Node n : nodes) {
            String name = n.getMetadata() != null ? n.getMetadata().getName() : null;
            if (name == null || name.isBlank()) {
                name = "<unknown>";
            }
            Map<String, Object> props = new LinkedHashMap<>();
            // Basic metadata
            props.put("name", name);
            props.put("labels", n.getMetadata() != null ? n.getMetadata().getLabels() : null);
            props.put("annotations", n.getMetadata() != null ? n.getMetadata().getAnnotations() : null);
            OffsetDateTime ts = n.getMetadata() != null ? n.getMetadata().getCreationTimestamp() : null;
            props.put("creationTimestamp", ts != null ? ts.toString() : null);
            // Status details
            if (n.getStatus() != null) {
                props.put("capacity", n.getStatus().getCapacity());
                props.put("allocatable", n.getStatus().getAllocatable());
                if (n.getStatus().getNodeInfo() != null) {
                    props.put("osImage", n.getStatus().getNodeInfo().getOsImage());
                    props.put("kernelVersion", n.getStatus().getNodeInfo().getKernelVersion());
                    props.put("kubeletVersion", n.getStatus().getNodeInfo().getKubeletVersion());
                    props.put("containerRuntimeVersion", n.getStatus().getNodeInfo().getContainerRuntimeVersion());
                }
                if (n.getStatus().getAddresses() != null) {
                    Map<String, String> addresses = n.getStatus().getAddresses().stream()
                            .filter(a -> a.getType() != null && a.getAddress() != null)
                            .collect(Collectors.toMap(V1NodeAddress::getType, V1NodeAddress::getAddress, (a, b) -> a, LinkedHashMap::new));
                    props.put("addresses", addresses);
                }
                if (n.getStatus().getConditions() != null) {
                    // Flatten conditions as type -> status
                    Map<String, String> conditions = n.getStatus().getConditions().stream()
                            .filter(c -> c.getType() != null)
                            .collect(Collectors.toMap(V1NodeCondition::getType, c -> String.valueOf(c.getStatus()), (a, b) -> a, LinkedHashMap::new));
                    props.put("conditions", conditions);
                }
            }
            result.add(props);
        }
        return result;
    }

    /**
     * Attempts to retrieve the process list from a given Kubernetes node by scheduling a short-lived
     * helper pod on that node with hostPID enabled and running a "ps" command. The command output
     * is parsed and returned as a list of maps with keys: pid, user, cpu, mem, command.
     * <p>
     * Notes and limitations:
     * - Requires sufficient RBAC and admission permissions to create a pod in the selected namespace (defaults to kube-system).
     * - Cluster policies may prevent hostPID or scheduling on master/control-plane nodes.
     * - On any error, this method returns an empty list to remain safe for collectors.
     *
     * @param nodeName name of the node where processes should be listed (required)
     * @return list of process info maps; empty list on failure or if not permitted
     */
    public List<Map<String, Object>> nodeProcessList(String nodeName) throws ApiException {
        final List<Map<String, Object>> processes = new ArrayList<>();
        if (nodeName == null || nodeName.isBlank()) {
            return processes;
        }
        final String namespace = "kube-system"; // best chance to have permissions
        final String podName = ("proc-list-" + nodeName + "-" + System.currentTimeMillis()).toLowerCase().replaceAll("[^a-z0-9-]", "-");
        final CoreV1Api api = KubeTransport.core(getClient());

        V1Container container = new V1Container()
                .name("runner")
                .image("busybox:1.36")
                .addCommandItem("sh")
                .addArgsItem("-c")
                .addArgsItem("ps -eo pid,user,pcpu,pmem,comm --no-headers || ps aux || true");

        V1PodSpec spec = new V1PodSpec();
        spec.setHostPID(true);
        spec.setRestartPolicy("Never");
        spec.setNodeName(nodeName);
        spec.addContainersItem(container);

        V1Pod pod = new V1Pod()
                .metadata(new V1ObjectMeta()
                        .name(podName)
                        .namespace(namespace)
                        .putLabelsItem("app", "proc-list"))
                .spec(spec);

        boolean created = false;
        api.createNamespacedPod(namespace, pod).execute();
        created = true;

        // Wait up to ~30s for completion
        long deadline = System.currentTimeMillis() + 30_000L;
        String phase = null;
        while (System.currentTimeMillis() < deadline) {
            V1Pod p = api.readNamespacedPod(podName, namespace).execute();
            phase = p != null && p.getStatus() != null ? p.getStatus().getPhase() : null;
            if ("Succeeded".equalsIgnoreCase(phase) || "Failed".equalsIgnoreCase(phase)) {
                break;
            }
            try {
                Thread.sleep(750L);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                break;
            }
        }

        // Read logs regardless of phase to capture any output
        String logs = api.readNamespacedPodLog(podName, namespace).execute();
        if (logs != null) {
            String[] lines = logs.split("\r?\n");
            for (String line : lines) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) continue;
                // Expecting: pid user pcpu pmem comm
                String[] parts = trimmed.split("\\s+", 5);
                try {
                    Map<String, Object> m = new LinkedHashMap<>();
                    if (parts.length >= 1) m.put("pid", parts[0]);
                    if (parts.length >= 2) m.put("user", parts[1]);
                    if (parts.length >= 3) m.put("cpu", parts[2]);
                    if (parts.length >= 4) m.put("mem", parts[3]);
                    if (parts.length >= 5) m.put("command", parts[4]);
                    processes.add(m);
                } catch (Exception ignored) {
                    // ignore parse errors for individual lines
                }
            }
        }
        if (created) {
            try {
                api.deleteNamespacedPod(podName, namespace).execute();
            } catch (Exception ignored) { /*noop*/ }
        }
        return processes;
    }

    /**
     * Lists containers across all namespaces in the connected Kubernetes cluster.
     * Each entry contains basic fields: namespace, pod, container, image, node, ready, restarts, state, containerID.
     * This method is defensive and returns an empty list on any error to keep collectors safe.
     */
    public List<Map<String, Object>> containers() throws ApiException {
        final List<Map<String, Object>> out = new ArrayList<>();
        final CoreV1Api api = KubeTransport.core(getClient());
        final List<V1Pod> pods = api.listPodForAllNamespaces().execute().getItems();
        for (V1Pod pod : pods) {
            final V1ObjectMeta meta = pod.getMetadata();
            final String ns = meta != null ? meta.getNamespace() : null;
            final String podName = meta != null ? meta.getName() : null;
            final String node = pod.getSpec() != null ? pod.getSpec().getNodeName() : null;
            final List<V1Container> containers = pod.getSpec() != null ? pod.getSpec().getContainers() : null;
            final List<V1ContainerStatus> statuses = pod.getStatus() != null ? pod.getStatus().getContainerStatuses() : null;

            if (containers == null || containers.isEmpty()) {
                continue;
            }

            for (V1Container c : containers) {
                final String cname = c.getName();
                final String image = c.getImage();

                Boolean ready = null;
                Integer restarts = null;
                String state = null;
                String cid = null;

                if (statuses != null) {
                    for (V1ContainerStatus st : statuses) {
                        if (st != null && ((st.getName() == null && cname == null) || (st.getName() != null && st.getName().equals(cname)))) {
                            ready = st.getReady();
                            restarts = st.getRestartCount();
                            cid = st.getContainerID();
                            if (st.getState() != null) {
                                if (st.getState().getRunning() != null) {
                                    state = "Running";
                                } else if (st.getState().getWaiting() != null) {
                                    state = "Waiting";
                                } else if (st.getState().getTerminated() != null) {
                                    state = "Terminated";
                                }
                            }
                            break;
                        }
                    }
                }

                Map<String, Object> m = new LinkedHashMap<>();
                m.put("namespace", ns);
                m.put("pod", podName);
                m.put("container", cname);
                m.put("image", image);
                m.put("node", node);
                if (ready != null) m.put("ready", ready);
                if (restarts != null) m.put("restarts", restarts);
                if (state != null) m.put("state", state);
                if (cid != null) m.put("containerID", cid);
                out.add(m);
            }
        }
        return out;
    }

    /**
     * Extracts logs for all pods and their containers into files inside the specified directory.
     * This method streams data directly to disk to handle very large logs safely.
     * <p>
     * Filenames are generated as: namespace__pod__container.log (sanitized for filesystem safety).
     * <p>
     * Notes:
     * - Requires permissions to read pod logs across targeted namespaces.
     * - On any individual error, the method skips the offending item and continues.
     *
     * @param outDir directory where log files will be written; created if missing
     * @return list of file paths written; may be empty on errors or if no pods are found
     */
    public List<Path> extractLogs(Path outDir) throws ApiException, IOException {
        return extractLogs(outDir, null, null, false, null, null);
    }

    /**
     * Extracts logs for pods that match the provided filters. Streams logs to files to avoid large memory usage.
     *
     * @param outDir          directory for output files (will be created if necessary)
     * @param namespace       if non-null, limits to this namespace; otherwise all namespaces
     * @param labelSelector   optional label selector (e.g., "app=my-app")
     * @param includePrevious if true, also attempts to fetch previous container instance logs
     * @param sinceSeconds    optional lower bound for logs based on time window (seconds)
     * @param tailLines       optional limit of the number of log lines from the end
     * @return list of paths of the files created
     */
    public List<Path> extractLogs(Path outDir, String namespace, String labelSelector, boolean includePrevious,
                                  Integer sinceSeconds, Integer tailLines) throws ApiException, IOException {
        final List<Path> written = new ArrayList<>();
        if (outDir == null) return written;
        Files.createDirectories(outDir);

        final CoreV1Api api = KubeTransport.core(getClient());
        final List<V1Pod> pods;
        if (namespace != null && !namespace.isBlank()) {
            if (labelSelector != null && !labelSelector.isBlank()) {
                pods = api.listNamespacedPod(namespace).labelSelector(labelSelector).execute().getItems();
            } else {
                pods = api.listNamespacedPod(namespace).execute().getItems();
            }
        } else {
            if (labelSelector != null && !labelSelector.isBlank()) {
                pods = api.listPodForAllNamespaces().labelSelector(labelSelector).execute().getItems();
            } else {
                pods = api.listPodForAllNamespaces().execute().getItems();
            }
        }

        if (pods == null || pods.isEmpty()) return written;

        for (V1Pod pod : pods) {
            final V1ObjectMeta meta = pod.getMetadata();
            final V1PodSpec spec = pod.getSpec();
            final String ns = meta != null ? meta.getNamespace() : "default";
            final String podName = meta != null ? meta.getName() : null;
            if (podName == null || spec == null || spec.getContainers() == null) continue;

            for (V1Container c : spec.getContainers()) {
                final String container = c.getName();
                if (container == null || container.isBlank()) continue;
                final String fileName = sanitize(ns) + "__" + sanitize(podName) + "__" + sanitize(container) + ".log";
                final Path file = outDir.resolve(fileName);

                // Fetch logs via public fluent API (loads response as String). Use filters to mitigate huge logs.
                try {
                    String logs = api.readNamespacedPodLog(podName, ns)
                            .container(container)
                            .previous(includePrevious)
                            .sinceSeconds(sinceSeconds)
                            .tailLines(tailLines)
                            .timestamps(false)
                            .execute();
                    if (logs != null) {
                        try (OutputStream out = Files.newOutputStream(file, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                            byte[] bytes = logs.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                            out.write(bytes);
                            out.flush();
                        }
                        written.add(file);
                    }
                } catch (Exception e) {
                    // Skip this container on any error and continue
                }
            }
        }
        return written;
    }

    private static String sanitize(String s) {
        if (s == null) return "unknown";
        String out = s.trim();
        if (out.isEmpty()) return "unknown";
        out = out.replaceAll("[\\\\/\\s]", "_");
        out = out.replaceAll("[^A-Za-z0-9._-]", "-");
        if (out.length() > 200) out = out.substring(0, 200);
        return out;
    }
}
