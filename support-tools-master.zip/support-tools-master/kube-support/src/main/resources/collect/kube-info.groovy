import com.edifecs.support.kube.KubeSupport
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "Kubernetes Cluster Info",
        description = "Returns information from the current Kubernetes cluster as a Map.",
        author = "Junie (JetBrains)",
        usage = '''Usage: script-runner /collect/kube-info [config file]
Examples:
    script-runner "/collect/kube-info"
    # with explicit kubeconfig (YAML or .properties)
    script-runner "/collect/kube-info /path/to/kubeconfig.yaml"
    script-runner "/collect/kube-info /path/to/kube.properties"

Supported .properties:
    kube.kubeconfig=/path/to/kubeconfig.yaml'''
)
@Argument(name = "Config file (optional)", description = "Path/URI/classpath to kubeconfig YAML or .properties (kube.kubeconfig)")
@Role("kubernetes")
static def execute(String... args) {
    KubeSupport.info {
        initialize(args)

        def ctx = (Object)delegate
        def map = new LinkedHashMap<String, Object>()
        map.version = clusterVersion()
        map.stats = basicStats()
        add('kube.info', map)
    }
}

execute(args)
