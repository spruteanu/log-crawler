package com.edifecs.support.installer;

import com.edifecs.support.core.Utils;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Optional;

/**
 * @author victtern
 * Created: 01 2023
 */
public class Main {

    private static final Logger LOG = LogManager.getLogger(Main.class);

    private static final HelpFormatter HELP_FORMATTER = new HelpFormatter();
    private static final Options OPTIONS = getOptions();

    public static void main(String[] args) {
        final Optional<CommandLine> cmdOpt = Utils.checkForValidArgumentsOrHelp(args, OPTIONS, v -> usage());

        try {
            if (cmdOpt.isPresent()) {
                final CommandLine cmd = cmdOpt.get();
                getConnection(null, null, cmd.getOptionValue("driver"), cmd.getOptionValue("url"));
            }
        } catch (Exception e) {
            LOG.error("Tool failed", e);
        }
    }

    private static Connection getConnection(String user, String password, String driver, String url) throws SQLException {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver couldn't be loaded.", e);
        }
    }

    private static Options getOptions() {
        return new Options()
                .addOption(Option.builder("driver").desc("Driver class").required().hasArg().build())
                .addOption(Option.builder("url").desc("Connection url").required().hasArg().build())
                .addOption(Option.builder("help").hasArg(false).desc("print help message").build());
    }

    private static void usage() {
        final String cmdLine = "test-jdbc-connection.bat" + " -driver <driverClass> [-help]";
        HELP_FORMATTER.printHelp(cmdLine, OPTIONS);
    }
}
