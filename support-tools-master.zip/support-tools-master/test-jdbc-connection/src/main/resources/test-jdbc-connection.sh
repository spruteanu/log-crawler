#!/bin/sh

if [ -f ${JAVA_HOME}/bin/java ]
then
    JAVA_EXE=${JAVA_HOME}/bin/java
else
    # use a default
    JAVA_EXE=java
fi

JAVA_OPTS="-Xmx512M"

echo -------------------------------------------------
${JAVA_EXE} -version
echo -------------------------------------------------

CLASSES=.
CP=$CLASSES:$CLASSES/*:test-jdbc-connection-1.0-SNAPSHOT-jar-with-dependencies.jar

$JAVA_EXE $JAVA_OPTS -cp $CP com.edifecs.support.installer.Main $@
