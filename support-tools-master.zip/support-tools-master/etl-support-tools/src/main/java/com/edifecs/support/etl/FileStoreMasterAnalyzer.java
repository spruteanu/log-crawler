package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author victtern
 * Created: Mar 2023
 */
public class FileStoreMasterAnalyzer {

    private static final Map<String, String> OPERATIONS = new HashMap<>(Map.of(
            "FileStoreDB get record FileID", "Retrieve record(s) from DB:                                                                     ",
            "Updated db metadata record", "Update record(s) in DB:                                                                         ",
            "FileStoreServer getInputStream", "Create an Input Stream:                                                                         ",
            "FileStoreServer getOutputStream FileID=", "Create an Output stream:                                                                        ",
            "remote write time: ", "Write a file through RMI to NAS:                                                                ",
            "FileStoreDB create record FileID", "Insert a record in DB:                                                                          ",
            "remote read time: ", "Read a file through RMI from NAS:                                                               ",
            "FileStoreServer get FileID=", "Get a File from file repo (read record DB and create java.io.File):                             ",
            "--> Renamed the file:", "Renamed the file from temp to active on NAS:                                                    ",
            "FileStoreServer put FileID=", "Stored a file on NAS(rename the file, insert record in DB):                                     "
    ));

    public static void main(String[] args) throws IOException, ParseException {
        OPERATIONS.put("-> Generated file name", "Generating a file name:                                                                         ");
        OPERATIONS.put("File [", "Creating a new file:                                                                            ");
        final List<String> lines = new ArrayList<>(Files.readAllLines(Path.of(new File("src/logs/file-store-master.log").toURI())));

        final Map<String, List<String>> grouped = lines.stream().collect(Collectors.groupingBy(line -> getOperation(line).orElse("Unknown Operation")));
        for (Map.Entry<String, List<String>> opEntry : grouped.entrySet()) {
            if (!"Unknown Operation".equals(opEntry.getKey())) {
                printStats(OPERATIONS.get(opEntry.getKey()), calculateAverage(opEntry.getValue()));
            }
        }

//        final Map<String, Long> creatingFilesStartTimeMap = new HashMap<>();
//        final List<Long> creatingFilesDurations = new ArrayList<>();
//        for (String line : lines) {
//            if (line.contains("-> Generated file name")) {
//                creatingFilesStartTimeMap.put(getFileNameStart(line), Utils.readTime(line));
//                continue;
//            }
//            if (line.contains("File [") && line.endsWith("] create successfully")) {
//                final String fileName = getFileNameEnd(line);
//                if (creatingFilesStartTimeMap.containsKey(fileName)) {
//                    creatingFilesDurations.add(Utils.readTime(line) - creatingFilesStartTimeMap.get(fileName));
//                    creatingFilesStartTimeMap.remove(fileName);
//                }
//            }
//        }
//        printStats("Creating a new file:                                                                            ",
//                creatingFilesDurations.stream().mapToLong(a -> a).sum() / creatingFilesDurations.size());
    }

    private static String getFileNameStart(String row) {
        return row.substring(row.indexOf("--> Generated file name ") + "--> Generated file name ".length(), row.indexOf(" in "));
    }

    private static String getFileNameEnd(String row) {
        return row.substring(row.indexOf("File [") + 6, row.indexOf("] create successfully"));
    }

    private static Optional<String> getOperation(String line) {
        return OPERATIONS.keySet().stream().filter(line::contains).findFirst();
    }

    private static long calculateAverage(List<String> rows) {
        long totalDurationMs = 0;
        for (String row : rows) {
            totalDurationMs += readTime(row);
        }
        return totalDurationMs / rows.size();
    }

    private static long readTime(String row) {
        if ((!row.endsWith(" ms") && row.endsWith("ms"))) {
            row = row.replace("ms", "");
            return Long.parseLong(row.substring(row.lastIndexOf("in ") + 3).trim());
        }
        if (row.endsWith(" ms")) {
            row = row.replace(" ms", "");
        }
        if (row.length() - row.indexOf("in ") < 10) {
            return Long.parseLong(row.substring(row.lastIndexOf("in ") + 3));
        }
        return Long.parseLong(row.substring(row.lastIndexOf(": ") + 2));
    }

    private static long printStats(String prefix, long average) {
        System.out.println(prefix + average + " ms");
        return average;
    }
}
