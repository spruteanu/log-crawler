package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * @author victtern
 * Created: Oct 2021
 */
public class EtlLogProcessor {

    public static void main(String args[]) throws IOException {
        final List<String> lines = Files.readAllLines(Path.of(new File("src/logs/etl.log").toURI()));
        double average = lines.stream()
                .filter(line -> line.contains("finished to process the file"))
                .mapToDouble(line -> {
                    int startIdx = line.lastIndexOf("minute(s) ") + "minute(s) ".length();
                    int endIdx = line.indexOf(" second(s)");
                    return Double.parseDouble(line.substring(startIdx, endIdx));
                }).summaryStatistics().getAverage();
        System.out.println("Average is: " + average);
    }
}
