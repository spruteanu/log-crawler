package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * @author victtern
 * Created: Oct 2022
 */
public class QueriesTracerAnalyzer {

    private static final int TOP_N_QUERIES = 50;

    private static final Comparator<QueryRow> DURATION_DESCENDING_COMPARATOR = Comparator.comparingLong(QueryRow::getDuration).reversed();

    public static void main(String[] args) throws IOException, ParseException {
        final List<String> rows = new ArrayList<>(Files.readAllLines(Path.of(new File("src/logs/queries-tracer.log").toURI())));

        final List<QueryRow> queries = readQueryRows(rows);

        System.out.printf("Analyzed %s queries %n", queries.size());
        System.out.printf("Top %s queries: %n", TOP_N_QUERIES);
        System.out.println("Date                    | Duration          | Query");
        queries.stream().sorted(DURATION_DESCENDING_COMPARATOR)
                .limit(TOP_N_QUERIES)
                .forEach(qRow -> System.out.println(qRow.toString()));
    }

    private static List<QueryRow> readQueryRows(List<String> rows) throws ParseException {
        final List<QueryRow> result = new ArrayList<>();
        StringBuilder querySb = new StringBuilder();
        String firstRow = null;
        Long prevTime = null;
        for (String row : rows) {
            if (isStartQueryRow(row)) {
                Long time = checkIfAddRow(result, querySb, firstRow, prevTime);
                querySb = new StringBuilder(row);
                firstRow = row;
                prevTime = time;
            } else {
                querySb.append(row);
            }
        }
        checkIfAddRow(result, querySb, firstRow, prevTime);
        return result;
    }

    private static Long checkIfAddRow(List<QueryRow> result, StringBuilder querySb, String firstRow, Long prevTime) throws ParseException {
        Long time = null;
        if (firstRow != null) {
            time = Utils.readTime(firstRow);
        }
        if (querySb.length() > 0) {
            final Long duration = prevTime != null && time != null ? time - prevTime : 0;
            result.add(new QueryRow(readQuery(querySb.toString()), Utils.readDate(firstRow), duration));
        }
        return time;
    }

    private static String readQuery(String fullQuery) {
        return fullQuery.substring(fullQuery.indexOf(" -     ") + 7);
    }

    private static boolean isStartQueryRow(String row) {
        return row.contains("DEBUG") || row.contains("TRACE") || row.contains("INFO") || row.contains("ERROR");
    }


    static class QueryRow implements Comparator<QueryRow> {
        private final String query;
        private final String date;
        private final Long duration;

        QueryRow(String query, String date, Long duration) {
            this.query = query;
            this.date = date;
            this.duration = duration;
        }

        @Override
        public int compare(QueryRow o1, QueryRow o2) {
            return Long.compare(o1.duration, o2.duration);
        }

        public Long getDuration() {
            return duration;
        }

        @Override
        public String toString() {
            return String.format("%s | %17s | %s", date, Utils.prettyPrintDuration(duration), query);
        }
    }
}
