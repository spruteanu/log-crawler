package com.edifecs.support.etl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;

/**
 * @author victtern
 * Created: Oct 2022
 */
public final class Utils {

    private static final String LOGS_TIME_PATTERN = "yyyy-MM-dd hh:mm:ss,SSS";

    private Utils() {}

    public static String readDate(String row) {
        if (row == null) {
            return null;
        }
        final String[] terms = row.split(" ");
        try {
            final String date = terms[0] + " " + terms[1];
            new SimpleDateFormat(LOGS_TIME_PATTERN).parse(date);
            return date;
        } catch (ParseException e) {
            System.out.println("Current row does not contains a date: " + row);
            return null;
        }
    }

    public static Long readTime(String row) throws ParseException {
        final String date = readDate(row);
        return date != null ? new SimpleDateFormat(LOGS_TIME_PATTERN).parse(date).getTime() : null;
    }

    public static String prettyPrintDuration(Long durationMs) {
        final StringBuilder sb = new StringBuilder();
        final Duration duration = Duration.ofMillis(durationMs);
        addDurationPart(sb, duration.toHours(), "h");
        addDurationPart(sb, duration.toMinutesPart(), "m");
        addDurationPart(sb, duration.toSecondsPart(), "s");
        sb.append(duration.toMillisPart()).append("ms");
        return sb.toString();
    }

    private static void addDurationPart(StringBuilder sb, long durationPart, String suffix) {
        if (durationPart > 0) {
            sb.append(durationPart).append(suffix);
        }
    }
}
