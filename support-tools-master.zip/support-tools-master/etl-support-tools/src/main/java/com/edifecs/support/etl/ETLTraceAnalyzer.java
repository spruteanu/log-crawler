package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.edifecs.support.etl.Utils.readTime;

/**
 * @author victtern
 * Created: Oct 2021
 */
@SuppressWarnings({"squid:S1192"})
public class ETLTraceAnalyzer {

    private static final Comparator<String> THREAD_NAME_COMPARATOR = Comparator.comparingInt(ETLTraceAnalyzer::threadIndex);
    private static final String ETL_THREAD_MARKER = "[servicemanager_JMSETLProcessor";
    private static final boolean IS_GBD = false;

    public static void main(String[] args) throws IOException, ParseException {
        final List<String> lines = Files.readAllLines(Path.of(new File("C:\\Users\\victtern\\Desktop\\temp\\support\\Oct 06 2022 [Slow etl]\\Oct10\\latest\\TM2-BIS/etl.log.9").toURI())).stream()
                .filter(line -> line.contains(ETL_THREAD_MARKER))
                .collect(Collectors.toList());
        final Map<String, List<String>> grouped = lines.stream().collect(Collectors.groupingBy(line -> {
            int startIdx = line.lastIndexOf(ETL_THREAD_MARKER);
            int endIdx = line.indexOf("]", startIdx) + 1;
            return line.substring(startIdx, endIdx);
        }));
        final TreeMap<String, List<String>> sorted = new TreeMap<>(THREAD_NAME_COMPARATOR);
        sorted.putAll(grouped);
        long totalETLFinished = 0;
        long nrOfPackages = 0;
        for (Map.Entry<String, List<String>> entry : sorted.entrySet()) {
            final Map<String, List<Long>> stats = statsForThread(entry.getValue());
            nrOfPackages += printStats(entry.getKey(), stats);
            totalETLFinished += average(stats.get("fileprocessingtime"));
        }
        long totalTimeSeconds = (getLastTime(lines) - getFirstTime(lines)) / 1000;
        totalTimeSeconds = totalTimeSeconds == 0 ? 1 : totalTimeSeconds;
        print("Total packages processed: " + nrOfPackages);
        print("Processing average overall(ms): " + (totalETLFinished / sorted.size()));
        print("Total time(seconds): " + totalTimeSeconds);
        print("Nr of packages per second: " + (nrOfPackages / totalTimeSeconds));
        print("");
        print("");
        print("------- Legend --------");
        print("Retrieved JMS Message           - Fetched a JMS message from the queue");
        if (IS_GBD) {
            print("Created Transmission and Events - Creating etl packages and inserting the transmission and start/end events with required properties in DB");
        } else {
            print("Created Transmission             - Creating etl packages and inserting the transmission with required properties in DB");
            print("Created Start Event              - Created and inserted start event in DB");
            print("Created End Event                - Created and inserted end event in DB");
        }
        print("Parsed Errors                   - Parsed errors report");
        print("Parsed XData                    - Parsed XData report");
        print("Perform DB Updates              - Inserting transmission updates into DB");
        if (!IS_GBD) {
            print("Saved Index File             - Saved Index File into File Repo");
        }
        print("Saved EDI File                  - Saved EDI File into File Repo");
        if (IS_GBD) {
            print("Saved Attachments               - Saved other attachments into File Repo");
        }
        print("ETL Package Finished            - Total time to process an ETL package");
    }

    private static long getFirstTime(List<String> rows) throws ParseException {
        for (String row : rows) {
            Long time = readTime(row);
            if (time != null) {
                return time;
            }
        }
        return 0;
    }

    private static long getLastTime(List<String> rows) throws ParseException {
        for (int i = rows.size() - 1; i >= 0; i--) {
            Long time = readTime(rows.get(i));
            if (time != null) {
                return time;
            }
        }
        return 0;
    }

    @SuppressWarnings("squid:S3776")
    private static Map<String, List<Long>> statsForThread(List<String> entries) throws ParseException {
        Map<String, List<Long>> stats = new LinkedHashMap<>();
        long resumeServiceThread = 0;
        long startedToCreateETL = 0;
        long transmissionCreated = 0;
        long startEventCreated = 0;
        long startErrorParsing = 0;
        long startXDataParsing = 0;
        long startStoringDataFile = 0;
        long startStoringAttachments = 0;
        long startStoringIndexFile = 0;
        for (String row : entries) {
            if (row.contains("Resume service thread")) {
                resumeServiceThread = readTime(row);
                startedToCreateETL = 0;
                transmissionCreated = 0;
                startEventCreated = 0;
                startErrorParsing = 0;
                startXDataParsing = 0;
                startStoringDataFile = 0;
                startStoringAttachments = 0;
                startStoringIndexFile = 0;
            }
            if (resumeServiceThread <= 0) {
                continue;
            }
            if (row.contains("Received JMS message")) {
                addStat(stats, "receivedjmsmsg", readTime(row) - resumeServiceThread);
            }
            if (row.contains("Creating an EtlPackage from EtlMessage")) {
                startedToCreateETL = readTime(row);
            }
            String createdTransmissionMarker = IS_GBD ? "Finding the event SID for" : "Finding the event ID for";
            if (row.contains(createdTransmissionMarker)) {
                transmissionCreated = readTime(row);
                addStat(stats, "createdtransmission", transmissionCreated - startedToCreateETL);
            }
            if (!IS_GBD && row.contains("Start Event:")) {
                startEventCreated = readTime(row);
                addStat(stats, "startevent", startEventCreated - transmissionCreated);
            }
            if (!IS_GBD && row.contains("End Event:")) {
                addStat(stats, "endevent", readTime(row) - startEventCreated);
            }
            String startedParsingErrorsMarker = IS_GBD ? "'GBD Error Parser' started parsing" : "'Error Parser' started parsing";
            if (row.contains(startedParsingErrorsMarker)) {
                startErrorParsing = readTime(row);
            }
            String endParsingErrorsMarker = IS_GBD ? "'GBD Error Parser' finished" : "'Error Parser' finished";
            if (row.contains(endParsingErrorsMarker)) {
                addStat(stats, "errorparsing", readTime(row) - startErrorParsing);
            }
            String xdataParsingStartMarker = IS_GBD ? "'LDNS' started parsing" : "'XData' started parsing";
            if (row.contains(xdataParsingStartMarker)) {
                startXDataParsing = readTime(row);
            }
            String xdataEndParsingMarker = IS_GBD ? "'LDNS' started parsing" : "'XData' finished";
            if (row.contains(xdataEndParsingMarker)) {
                addStat(stats, "xdataparsing", readTime(row) - startXDataParsing);
            }
            String dbUpdatesMarker = IS_GBD ? "Loading transmission" : "Executed Loader batch containing";
            if (row.contains(dbUpdatesMarker) && (!IS_GBD || row.contains(": loaded "))) {
                addStat(stats, "dbupdates", IS_GBD ? parseGbdLoadingData(row) : parseLoadingData(row));
            }
            if (!IS_GBD && row.contains("Storing index file")) {
                startStoringIndexFile = readTime(row);
            }
            if (!IS_GBD && row.contains("'DataIndexer' processed ")) {
                long endDataIndexerProcessing = readTime(row);
                long storedIndexFile = endDataIndexerProcessing - startStoringIndexFile;
                addStat(stats, "saveindexfile", storedIndexFile);
            }
            String startStoringDataFileMarker = IS_GBD ? "Saving DATA file for transmission" : "Attach DATA file";
            if (row.contains(startStoringDataFileMarker)) {
                startStoringDataFile = readTime(row);
            }
            String endSaveDataFileMarker = IS_GBD ? "Saving attachments for transmission" : "Handle attachments for";
            if (row.contains(endSaveDataFileMarker)) {
                long storingAttStartTime = readTime(row);
                addStat(stats, "savedatafile", storingAttStartTime - startStoringDataFile);
                if (!IS_GBD) {
                    startStoringAttachments = storingAttStartTime;
                }
            }
            if (IS_GBD && row.contains("Saving attachments for transmission")) {
                startStoringAttachments = readTime(row);
            }
            if ((IS_GBD && row.contains("Saved ") && row.contains(" attachments for transmission")) || (!IS_GBD && row.contains("Complete package "))) {
                addStat(stats, "savedattachments", readTime(row) - startStoringAttachments);
            }
            if ((row.contains("finished to process the file") || row.contains("failed to process the file"))) {
                final long fileProcessedIn = parseFileProcessingTime(row);
                addStat(stats, "fileprocessingtime", fileProcessedIn);
                removeBiggerValue(stats, "receivedjmsmsg", fileProcessedIn);
                if (stats.containsKey("createdtransmission")) {
                    removeBiggerValue(stats, "createdtransmission", fileProcessedIn);
                }
//                if (fileProcessedIn > 15000) {
//                    removeLast(stats, "dbupdates");
//                    removeLast(stats, "fileprocessingtime");
//                }
            }
        }
        return stats;
    }

    private static void removeBiggerValue(Map<String, List<Long>> statsMap, String key, long max) {
        final List<Long> stats = statsMap.get(key);
        if (stats == null) {
            return;
        }
        final int lastElIdx = stats.size() - 1;
        if (!stats.isEmpty() && lastElIdx >= 0 && stats.get(lastElIdx) > max) {
            stats.remove(lastElIdx);
        }
    }

    @SuppressWarnings("squid:S3776")
    private static long printStats(String threadName, Map<String, List<Long>> stats) {
        print("------------- Stats for Thread " + threadIndex(threadName) + " -------------");
        final List<Long> fileProcessingTimeList = stats.get("fileprocessingtime");
        if (fileProcessingTimeList != null) {
            long etlProcessedAverage = average(fileProcessingTimeList);
            print("Nr of ETL Packages:              " + stats.get("fileprocessingtime").size());
            long sum = 0;
            if (stats.get("receivedjmsmsg") != null) {
                sum += printStats("Retrieved JMS Message:           ", average(stats.get("receivedjmsmsg")), etlProcessedAverage);
            }
            if (stats.containsKey("createdtransmission")) {
                String prefix = IS_GBD ? "Created Transmission and Events: " : "Created Transmission:        ";
                sum += printStats(prefix, average(stats.get("createdtransmission")), etlProcessedAverage);
            }
            if (!IS_GBD && stats.containsKey("startevent")) {
                sum += printStats("Created Start Event:     ", average(stats.get("startevent")), etlProcessedAverage);
            }
            if (!IS_GBD && stats.containsKey("endevent")) {
                sum += printStats("Created End Event:       ", average(stats.get("endevent")), etlProcessedAverage);
            }
            if (stats.containsKey("errorparsing")) {
                sum += printStats("Parsed Errors:                   ", average(stats.get("errorparsing")), etlProcessedAverage);
            }
            if (stats.containsKey("xdataparsing")) {
                sum += printStats("Parsed XData:                    ", average(stats.get("xdataparsing")), etlProcessedAverage);
            }
            if (stats.containsKey("dbupdates")) {
                sum += printStats("Perform DB Updates:              ", average(stats.get("dbupdates")), etlProcessedAverage);
            }
            if (stats.containsKey("saveindexfile")) {
                sum += printStats("Saved Index File:                ", average(stats.get("saveindexfile")), etlProcessedAverage);
            }
            if (stats.containsKey("savedatafile")) {
                sum += printStats("Saved EDI File:                  ", average(stats.get("savedatafile")), etlProcessedAverage);
            }
            if (stats.containsKey("savedattachments")) {
                sum += printStats("Saved Attachments:               ", average(stats.get("savedattachments")), etlProcessedAverage);
            }
            print("Processes SUM:                   " + sum + " ms");
            print("ETL Package Finished:            " + etlProcessedAverage + " ms");
            print("");
            return stats.get("fileprocessingtime").size();
        }
        return 0;
    }

    private static long printStats(String prefix, long average, long etlProcessedAverage) {
        String percents = average != etlProcessedAverage ? ((average * 100) / etlProcessedAverage) + "%" : "";
        print(prefix + average + " ms (" + percents + ")");
        return average;
    }

    @SuppressWarnings("squid:S106")
    private static long average(List<Long> l) {
        return Math.round(l.stream().mapToLong(i -> i).average().orElse(0));
    }

    private static void print(String str) {
        System.out.println(str);
    }

    private static void addStat(Map<String, List<Long>> stats, String statKey, long time) {
        if (time > 0) {
            stats.computeIfAbsent(statKey, key -> new ArrayList<>()).add(time);
        }
    }

    private static long parseFileProcessingTime(String raw) {
        // Executed Loader batch containing 74 records in 30 ms. Prepared Statement batches: 35
        String str = raw.substring(raw.indexOf(" in ") + 4);
        double hours = Double.parseDouble(str.substring(0, str.indexOf(" hour")));
        str = str.substring(str.indexOf(" hour(s) ") + " hour(s) ".length());
        double minutes = Double.parseDouble(str.substring(0, str.indexOf(" minute")));
        str = str.substring(str.indexOf(" minute(s) ") + " minute(s) ".length());
        double seconds = Double.parseDouble(str.substring(0, str.indexOf(" second")));
        return (long) (hours * 60 * 60 * 1000 + minutes * 60 * 1000 + seconds * 1000);
    }

    private static long parseLoadingData(String raw) {
        String str = raw.substring(raw.indexOf(" in ") + 4);
        return Long.parseLong(str.substring(0, str.indexOf(" ms")));
    }

    private static long parseGbdLoadingData(String row) {
        // Loading transmission 8654066473252057-277 (CC4FC936-B496-43BA-967F-9AEB30426D94-277): loaded 5 items and 0 errors in 0:00:00.067
        String str = row.substring(row.indexOf(" in ") + 4);
        String[] terms = str.split(":");
        long hours = Long.parseLong(terms[0]);
        long minutes = Long.parseLong(terms[1]);
        String[] secondsTerms = terms[2].split("\\.");
        long seconds = Long.parseLong(secondsTerms[0]);
        long mls = Long.parseLong(secondsTerms[1]);
        return TimeUnit.HOURS.toMillis(hours) + TimeUnit.MINUTES.toMillis(minutes) + TimeUnit.SECONDS.toMillis(seconds) + mls;
    }

    private static Integer threadIndex(String threadName) {
        String cleanedThreadName = threadName.replace(ETL_THREAD_MARKER, "");
        return Integer.parseInt(cleanedThreadName.replace("]", ""));
    }
}
