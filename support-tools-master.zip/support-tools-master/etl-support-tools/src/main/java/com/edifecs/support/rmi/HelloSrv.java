package com.edifecs.support.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface HelloSrv extends Remote {
    String SERVICE_NAME = "HelloSrv";

    String sayHello() throws RemoteException;
}
