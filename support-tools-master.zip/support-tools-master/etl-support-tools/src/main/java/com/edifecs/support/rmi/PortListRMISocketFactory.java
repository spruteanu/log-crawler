package com.edifecs.support.rmi;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.rmi.server.RMISocketFactory;
import java.util.*;

/**
 * Custom implementation of the RMISocketFactory.
 * Used to control the ports used by the RMI for Remote object binding.
 * It uses the existing RMISocketFactory to create the sockets,
 * but the request on "0" port will be redirected to an available port from the list.
 *
 * @author SergiuO
 */
class PortListRMISocketFactory extends RMISocketFactory {
    static final int MIN_PORTS = 5;
    private final RMISocketFactory originalFactory;
    private final Set<Integer> ports;
    private final Set<Integer> availablePorts;

    PortListRMISocketFactory(List<Integer> ports) {
        this(getDefaultFactory(), ports);
    }

    PortListRMISocketFactory(int minPort, int maxPort) {
        this(portsRange(minPort, maxPort));
    }

    PortListRMISocketFactory(RMISocketFactory originalFactory, List<Integer> ports) {
        if (originalFactory == null) {
            throw new NullPointerException("Null originalFactory not allowed.");
        }
        if (ports == null || ports.size() < MIN_PORTS) {
            throw new IllegalArgumentException(String.format("At least %s ports needs to be provided.", MIN_PORTS));
        }
        this.originalFactory = originalFactory;
        this.ports = new LinkedHashSet<>(ports);
        availablePorts = new LinkedHashSet<>(ports);
    }

    public ServerSocket createServerSocket(int port) throws IOException {
        return createServerInternal(port, true);
    }

    @SuppressWarnings("squid:S3776")
    private ServerSocket createServerInternal(int port, boolean resetPortsIfNeeded) throws IOException {
        Integer serverPort;
        if (port == 0) {
            serverPort = nextPort();
            if (serverPort == null) {
                if (resetPortsIfNeeded) {
                    synchronized (this) {
                        if (availablePorts.isEmpty()) {
                            availablePorts.addAll(ports);
                        }
                        serverPort = nextPort();
                    }
                    resetPortsIfNeeded = false;
                } else {
                    throw new IOException("No ports available.");
                }
            }
        } else {
            serverPort = port;
        }
        final ServerSocket result;
        try {
            result = originalFactory.createServerSocket(serverPort);
        } catch (SocketException e) {
            if (port == 0) {
                return createServerInternal(0, resetPortsIfNeeded);
            } else {
                throw e;
            }
        }
        return result;
    }

    private synchronized Integer nextPort() {
        if (availablePorts.isEmpty()) {
            return null;
        }
        final Integer port = availablePorts.iterator().next();
        availablePorts.remove(port);
        return port;
    }

    public Socket createSocket(String host, int port) throws IOException {
        return originalFactory.createSocket(host, port);
    }

    public static RMISocketFactory getDefaultFactory() {
        RMISocketFactory result = RMISocketFactory.getSocketFactory();
        if (result == null) {
            result = RMISocketFactory.getDefaultSocketFactory();
        }
        return result;
    }

    @Override
    public int hashCode() {
        return getClass().hashCode() ^ portsHash();
    }

    private int portsHash() {
        int result = 0;
        int i = 0;
        for (final Iterator<Integer> it = ports.iterator(); it.hasNext(); i++) {
            result += result + (it.next() >> i);
        }
        return result;
    }

    private boolean portsEqual(Object obj) {
        final PortListRMISocketFactory factory1 = (PortListRMISocketFactory) obj;
        return ports.containsAll(factory1.ports) && factory1.ports.containsAll(ports);
    }

    @Override
    public boolean equals(Object obj) {
        return obj != null && getClass().equals(obj.getClass()) && portsEqual(obj);
    }

    private static List<Integer> portsRange(int minPort, int maxPort) {
        if (maxPort < minPort || minPort <= 0) {
            throw new IllegalArgumentException(String.format("Invalid port range (%s - %s).", minPort, maxPort));
        }
        List<Integer> ports = new ArrayList<>(maxPort - minPort);
        for (int i = minPort; i <= maxPort; i++) {
            ports.add(i);
        }
        return ports;
    }

    public static PortListRMISocketFactory fromRange(int minPort, int maxPort) {
        return minPort > 0 && maxPort > 0 ? new PortListRMISocketFactory(minPort, maxPort) : null;
    }
}
