package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author victtern
 * Created: Mar 2023
 */
public class FileStoreClientAnalyzer {

    private static final Map<String, String> OPERATIONS = Map.of(
            "Created remote output stream in", "Created remote Output Stream:                                                                   ",
            "Created temp paged file: ", "Created temporary paged file:                                                                   ",
            "Created remote output handler for temp paged file", "Created temporary paged file remote Output Handler:                                             ",
            "Copied binary content to paged file in", "Copied binary content to temporary paged file:                                                  ",
            "Copied non binary content to paged file", "Copied non binary content to paged file:                                                                ",
            "Copied paged file to remote file store file", "Copied paged file to remote file store file:                                                    ",
            "Deleted temporary paged file in", "Deleted temporary paged file in:                                                                ",
            "Copied to remote file store archiving and encrypting", "Copied to remote file store archiving and encrypting:                                           ",
            "Persisted file to master file store", "Persisted file to master file store:                                                            ",
            "ClientFileRepository StoreFile (STEP 2: Serialize FileID)", "ClientFileRepository StoreFile (STEP 2: Serialize FileID):                                      "
    );

    public static void main(String[] args) throws IOException {
        final List<String> lines = new ArrayList<>(Files.readAllLines(Path.of(new File("src/logs/file-store-client.log").toURI())));

        final Map<String, List<String>> grouped = lines.stream().collect(Collectors.groupingBy(line -> getOperation(line).orElse("Unknown Operation")));
        for (Map.Entry<String, List<String>> opEntry : grouped.entrySet()) {
            if (!"Unknown Operation".equals(opEntry.getKey())) {
                printStats(OPERATIONS.get(opEntry.getKey()), calculateAverage(opEntry.getValue()));
            }
        }
    }

    private static Optional<String> getOperation(String line) {
        return OPERATIONS.keySet().stream().filter(line::contains).findFirst();
    }

    private static long calculateAverage(List<String> rows) {
        long totalDurationMs = 0;
        for (String row : rows) {
            totalDurationMs += readTime(row);
        }
        return totalDurationMs / rows.size();
    }

    private static long readTime(String row) {
        if (row.endsWith(" ms")) {
            row = row.replace(" ms", "");
        }
        return Long.parseLong(row.substring(row.lastIndexOf(": ") + 2));
    }

    private static long printStats(String prefix, long average) {
        System.out.println(prefix + average + " ms");
        return average;
    }
}
