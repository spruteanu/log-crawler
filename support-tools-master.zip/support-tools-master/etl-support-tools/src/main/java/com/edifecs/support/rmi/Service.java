package com.edifecs.support.rmi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RMISocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

@SuppressWarnings({"squid:S2629", "squid:S3457", "squid:S112"})
public class Service implements HelloSrv {

    private final Logger logger = Logger.getLogger(this.getClass().getName());
    private int servicePortStart;
    private int servicePortEnd;
    private int registryPort = Registry.REGISTRY_PORT;

    public String sayHello() {
        logger.log(Level.INFO, "Client invoked remote method");
        return "Hello, server time: " + new Date();
    }

    private void bootstrapServer() throws Exception {
        if (servicePortStart > 0 && servicePortEnd > 0) {
            logger.info(String.format("Setting service port range to %d - %d", servicePortStart, servicePortEnd));
            RMISocketFactory factory = PortListRMISocketFactory.fromRange(servicePortStart, servicePortEnd);
            RMISocketFactory.setSocketFactory(factory);
        }

        Service obj = new Service();
        HelloSrv service = (HelloSrv) UnicastRemoteObject.exportObject(obj, 0);

        logger.log(Level.INFO, "Creating registry on port " + registryPort);
        Registry registry = LocateRegistry.createRegistry(registryPort);

        registry.bind(SERVICE_NAME, service);
        logger.log(Level.INFO, "Service bound");
    }

    public void run() {
        try {
            FileHandler fileHandler = new FileHandler("service.log", true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);

            bootstrapServer();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Service exception", e);
        }
    }

    public void setRegistryPort(int port) {
        this.registryPort = port;
    }

    public void setServicePortStart(int servicePort) {
        this.servicePortStart = servicePort;
    }

    public void setServicePortEnd(int servicePort) {
        this.servicePortEnd = servicePort;
    }
}
