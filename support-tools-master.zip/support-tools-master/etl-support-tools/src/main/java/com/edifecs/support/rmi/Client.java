package com.edifecs.support.rmi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

@SuppressWarnings({"squid:S2629", "squid:S3457"})
public class Client {

    private static final Logger logger = Logger.getLogger(Client.class.getName());

    private String registryHost;
    private int registryPort;

    public void run() {
        try {
            FileHandler fileHandler = new FileHandler("client.log", true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);

            Registry registry;
            if (registryHost != null && registryPort > 0) {
                logger.log(Level.INFO, String.format("Connecting to registry on host '%s', port %s", registryHost, registryPort));
                registry = LocateRegistry.getRegistry(registryHost, registryPort);
            } else if (registryHost != null) {
                logger.log(Level.INFO, String.format("Connecting to registry on host '%s', port 1099", registryHost));
                registry = LocateRegistry.getRegistry(registryHost);
            } else if (registryPort > 0) {
                logger.log(Level.INFO, String.format("Connecting to registry on host 'localhost', port %d", registryPort));
                registry = LocateRegistry.getRegistry(registryPort);
            } else {
                logger.log(Level.INFO, "Connecting to RMI registry on host 'localhost', port 1099");
                registry = LocateRegistry.getRegistry();
            }

            HelloSrv service = (HelloSrv) registry.lookup(HelloSrv.SERVICE_NAME);
            String response = service.sayHello();
            logger.log(Level.INFO, "Service Response: " + response);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Client exception", e);
        }
    }

    public void setRegistryHost(String registryHost) {
        this.registryHost = registryHost;
    }

    public void setRegistryPort(int port) {
        this.registryPort = port;
    }
}
