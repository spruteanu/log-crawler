package com.edifecs.support.etl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * @author victtern
 * Created: Oct 2021
 */
public class FilesToolProcessor {

    public static void main(String args[]) throws IOException {
        final List<String> lines = Files.readAllLines(Path.of(new File("src/logs/nas.txt").toURI()));
        double average = lines.stream()
                .filter(line -> line.endsWith("' ms"))
                .mapToLong(line -> {
                    int startIdx = line.lastIndexOf("file in '") + "file in '".length();
                    int endIdx = line.indexOf("' ms");
                    return Long.parseLong(line.substring(startIdx, endIdx));
        }).summaryStatistics().getAverage();
        System.out.println("Average is: " + average);
    }
}
