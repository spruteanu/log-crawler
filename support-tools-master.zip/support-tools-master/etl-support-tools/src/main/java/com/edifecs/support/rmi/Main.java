package com.edifecs.support.rmi;

import java.util.Map;
import java.util.TreeMap;

@SuppressWarnings("squid:S106")
public class Main {

    private static final String APP_TYPE = "appType";
    private static final String SERVICE_TYPE = "serviceType";
    private static final String CLIENT_TYPE = "clientType";

    private static final String SERVICE_PORT_START = "servicePortStart";
    private static final String SERVICE_PORT_END = "servicePortEnd";
    private static final String REGISTRY_HOST = "registryHost";
    private static final String REGISTRY_PORT = "registryPort";
    private static final String PORT_MESSAGE = " should be followed by a port number";

    public static void main(String[] args) {
        Map<String, String> arguments = parseArguments(args);
        validate(arguments);
        if (arguments.get(APP_TYPE).equals(SERVICE_TYPE)) {
            runService(arguments);
        } else {
            runClient(arguments);
        }
    }

    private static void runService(Map<String, String> arguments) {
        Service service = new Service();
        String servicePortStartArg = arguments.get(SERVICE_PORT_START);
        if (servicePortStartArg != null) {
            int servicePortStart = Integer.parseInt(servicePortStartArg);
            service.setServicePortStart(servicePortStart);
        }

        String servicePortEndArg = arguments.get(SERVICE_PORT_END);
        if (servicePortEndArg != null) {
            int servicePortEnd = Integer.parseInt(servicePortEndArg);
            service.setServicePortEnd(servicePortEnd);
        }

        String registryPortArg = arguments.get(REGISTRY_PORT);
        if (registryPortArg != null) {
            int registryPort = Integer.parseInt(registryPortArg);
            service.setRegistryPort(registryPort);
        }
        service.run();
    }

    private static void runClient(Map<String, String> arguments) {
        Client client = new Client();
        String registryHost = arguments.get(REGISTRY_HOST);
        client.setRegistryHost(registryHost);
        String registryPortArg = arguments.get(REGISTRY_PORT);
        if (registryPortArg != null) {
            int registryPort = Integer.parseInt(registryPortArg);
            client.setRegistryPort(registryPort);
        }
        client.run();
    }

    @SuppressWarnings("squid:S127")
    private static Map<String, String> parseArguments(String[] args) {
        Map<String, String> parameters = new TreeMap<>();
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-service":
                    parameters.put(APP_TYPE, SERVICE_TYPE);
                    break;
                case "-client":
                    parameters.put(APP_TYPE, CLIENT_TYPE);
                    break;
                case "-service-port-start":
                    parameters.put(SERVICE_PORT_START, args[i + 1]);
                    i++;
                    break;
                case "-service-port-end":
                    parameters.put(SERVICE_PORT_END, args[i + 1]);
                    i++;
                    break;
                case "-registry-host":
                    parameters.put(REGISTRY_HOST, args[i + 1]);
                    i++;
                    break;
                case "-registry-port":
                    parameters.put(REGISTRY_PORT, args[i + 1]);
                    i++;
                    break;
                default:
                    error("invalid command-line argument: " + args[i]);
            }
        }
        return parameters;
    }

    @SuppressWarnings("squid:S1192")
    private static void validate(Map<String, String> arguments) {
        String appType = arguments.get(APP_TYPE);
        if (appType == null) {
            usage();
        }
        String servicePortStart = arguments.get(SERVICE_PORT_START);
        if (servicePortStart != null && !servicePortStart.matches("^\\d+$")) {
            error(SERVICE_PORT_START + PORT_MESSAGE);
        }
        String servicePortEnd = arguments.get(SERVICE_PORT_END);
        if (servicePortEnd != null && !servicePortEnd.matches("^\\d+$")) {
            error(SERVICE_PORT_END + PORT_MESSAGE);
        }
        String registryPort = arguments.get(REGISTRY_PORT);
        if (registryPort != null && !registryPort.matches("^\\d+$")) {
            error(REGISTRY_PORT + PORT_MESSAGE);
        }
    }

    private static void error(String error) {
        System.out.print("Error: ");
        System.out.println(error);
        usage();
    }

    private static void usage() {
        System.out.println("Usage:");
        System.out.println("    rmi-tool -service [-registry-port <port>] [-service-port-start <port> -service-port-end <port>]");
        System.out.println("    rmi-tool -client [-registry-host <host>] [-registry-port <port>]");
        System.exit(-1);
    }
}
