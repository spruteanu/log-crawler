import com.edifecs.support.ec2.Ec2Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "EC2 Info",
        description = "Returns basic information about AWS EC2 in the configured/implicit region as a Map.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/ec2-info [config file]
Examples:
    script-runner "/collect/ec2-info"
    # with explicit AWS client config (Java .properties):
    script-runner "/collect/ec2-info /path/to/aws.properties"

Supported config properties (Java .properties):
    aws.region=us-east-1
    aws.profile=default
    aws.accessKeyId=AKIA...
    aws.secretAccessKey=...
    aws.sessionToken=...'''
)
@Argument(name = "Config file (optional)", description = "Path/URI/classpath to a .properties file used to construct AWS SDK client; see Supported config properties in usage")
@Role("ec2")
static def execute(String... args) {
    Ec2Support.info {
        initialize(args)
        Map<String, Object> map = new LinkedHashMap<>()
        try {
            // Region resolution: prefer explicit context setting, then environment, then system property
            String regionVal = getRegion()
            if (!regionVal) {
                regionVal = System.getenv("AWS_REGION") ?: System.getenv("AWS_DEFAULT_REGION") ?: System.getProperty("aws.region")
            }
            map.region = regionVal

            // Instances: list minimal info using helper
            def ids = listInstanceIds() ?: []
            map.instanceCount = ids.size()
            map.instanceIds = ids as String[]
        } catch (Throwable t) {
            add('ec2.info.error', String.valueOf(t.message))
        }
        add('ec2.info', map)
    }
}

execute(args)
