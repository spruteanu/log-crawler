import com.edifecs.support.ec2.Ec2Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "List Environment Variables (EC2)",
        description = "Retrieves environment variables from the current host (intended for use on an EC2 instance).",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/ec2-environment-vars [config file]
Examples:
    script-runner "/collect/ec2-environment-vars"
    # with explicit AWS client config (Java .properties) if you also want to initialize AWS context (optional):
    script-runner "/collect/ec2-environment-vars /path/to/aws.properties"

Supported config properties (Java .properties):
    aws.region=us-east-1
    aws.profile=default
    aws.accessKeyId=AKIA...
    aws.secretAccessKey=...
    aws.sessionToken=...'''
)
@Argument(name = "Config file (optional)", description = "Path/URI/classpath to a .properties file used to construct AWS SDK client; see Supported config properties in usage")
@Role("ec2")
static def execute(String... args) {
    Ec2Support.info {
        initialize(args)
        // Unlike Docker, we don't exec into a remote container. We read env vars from the current host.
        add('environment.vars', shellOutput('printenv'))
    }
}

execute(args)
