package com.edifecs.support.ec2;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import software.amazon.awssdk.services.ec2.Ec2Client;

/**
 * Ec2Support provides helpers to create and validate AWS EC2 client connections
 * using AWS SDK v2. It centralizes common connection scenarios: default
 * credential/provider chain, profile-based, and static credentials.
 */
@SuppressWarnings({"squid:S2095", "squid:S3740"})
public class Ec2Support implements AutoCloseable {
    private Ec2Client client;

    public Ec2Client getClient() {
        return client;
    }

    public void setClient(Ec2Client client) {
        this.client = client;
    }

    public Ec2Support withClient(Ec2Client client) {
        setClient(client);
        return this;
    }

    @Override
    public void close() throws Exception {
        if (client != null) {
            try { client.close(); } catch (Exception ignore) { /* noop */ }
            client = null;
        }
    }

    static Ec2Support of() {
        final Ec2Support support = new Ec2Support();
        support.withClient(Ec2Transport.ec2Default(null));
        return support;
    }
    static Ec2Support of(Ec2Client client) {
        return new Ec2Support().withClient(client);
    }

    public static Ec2Context info(Ec2Context context, @DelegatesTo(Ec2Context.class) Closure closure) {
        GroovyUtil.closureCall(closure, context);
        return context;
    }

    public static Context info(@DelegatesTo(Ec2Context.class) Closure closure) {
        Context context = Context.lookupInstance(closure);
        if (context instanceof Ec2Context) {
            return info((Ec2Context) context, closure);
        }
        final Ec2Context ctx = context != null ? (Ec2Context) new Ec2Context().clone(context) : new Ec2Context();
        info(ctx, closure);
        return ctx;
    }
}
