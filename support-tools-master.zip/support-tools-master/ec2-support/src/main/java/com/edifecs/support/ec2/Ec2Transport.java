package com.edifecs.support.ec2;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.DescribeRegionsRequest;
import software.amazon.awssdk.services.ec2.model.DescribeRegionsResponse;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.GetCallerIdentityRequest;
import software.amazon.awssdk.services.sts.model.GetCallerIdentityResponse;

import java.util.Objects;

/**
 * AwsTransport provides helpers to create AWS SDK v2 clients for EC2/STS calls
 * with multiple authentication options (default chain, profile, static creds)
 * and a minimal connectivity check.
 */
public final class Ec2Transport {

    private Ec2Transport() {}

    public static Ec2Client ec2Default(String region) {
        Region r = region(region);
        return Ec2Client.builder()
                .region(r)
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    public static Ec2Client ec2FromProfile(String profile, String region) {
        Objects.requireNonNull(profile, "profile");
        Region r = region(region);
        AwsCredentialsProvider provider = ProfileCredentialsProvider.create(profile);
        return Ec2Client.builder().region(r).credentialsProvider(provider).build();
    }

    public static Ec2Client ec2FromStatic(String accessKeyId, String secretAccessKey, String sessionToken, String region) {
        Objects.requireNonNull(accessKeyId, "accessKeyId");
        Objects.requireNonNull(secretAccessKey, "secretAccessKey");
        Region r = region(region);
        AwsBasicCredentials base = AwsBasicCredentials.create(accessKeyId, secretAccessKey);
        AwsCredentialsProvider provider = sessionToken != null && !sessionToken.isBlank()
                ? StaticCredentialsProvider.create(software.amazon.awssdk.auth.credentials.AwsSessionCredentials.create(accessKeyId, secretAccessKey, sessionToken))
                : StaticCredentialsProvider.create(base);
        return Ec2Client.builder().region(r).credentialsProvider(provider).build();
    }

    public static boolean pingSts(AwsCredentialsProvider provider, String region) {
        try (StsClient sts = StsClient.builder().region(region(region)).credentialsProvider(provider).build()) {
            GetCallerIdentityResponse id = sts.getCallerIdentity(GetCallerIdentityRequest.builder().build());
            return id != null && id.userId() != null;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean pingEc2(Ec2Client ec2) {
        try {
            DescribeRegionsResponse res = ec2.describeRegions(DescribeRegionsRequest.builder().allRegions(false).build());
            return res != null && res.hasRegions();
        } catch (Exception e) {
            return false;
        }
    }

    private static Region region(String region) {
        if (region == null || region.isBlank()) {
            // Let SDK resolve default region via env/system settings if omitted
            return Region.AWS_GLOBAL;
        }
        return Region.of(region);
    }
}
