package com.edifecs.support.ec2;

import com.edifecs.support.core.Context;
import com.edifecs.support.core.GroovyUtil;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.DescribeInstancesRequest;
import software.amazon.awssdk.services.ec2.model.DescribeInstancesResponse;
import software.amazon.awssdk.services.ec2.model.Reservation;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Ec2Context extends the generic Context with AWS EC2 specific helpers and configuration.
 * It encapsulates an Ec2Client factory (via Ec2Support) and provides a simple API for:
 * - Initializing client from default chain, profile or static credentials
 * - Selecting region
 * - Listing instances (minimal helper)
 * <p>
 * Supported config properties (Java .properties):
 * aws.region
 * aws.profile
 * aws.accessKeyId
 * aws.secretAccessKey
 * aws.sessionToken
 */
public class Ec2Context extends Context {
    private Ec2Support utils;

    private String region;
    private String profile;
    private String accessKeyId;
    private String secretAccessKey;
    private String sessionToken;

    public Ec2Support getUtils() {
        return utils;
    }

    public void setUtils(Ec2Support utils) {
        this.utils = utils;
    }

    public synchronized Ec2Support utils() {
        if (utils == null) {
            // Build client based on configured properties
            Ec2Client client;
            if (profile != null && !profile.isBlank()) {
                client = Ec2Transport.ec2FromProfile(profile, region);
            } else if (accessKeyId != null && !accessKeyId.isBlank() && secretAccessKey != null && !secretAccessKey.isBlank()) {
                client = Ec2Transport.ec2FromStatic(accessKeyId, secretAccessKey, sessionToken, region);
            } else {
                client = Ec2Transport.ec2Default(region);
            }
            utils = Ec2Support.of(client);
        }
        return utils;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Ec2Context region(String region) {
        setRegion(region);
        return this;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public void setAccessKeyId(String accessKeyId) {
        this.accessKeyId = accessKeyId;
    }

    public String getSecretAccessKey() {
        return secretAccessKey;
    }

    public void setSecretAccessKey(String secretAccessKey) {
        this.secretAccessKey = secretAccessKey;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    @Override
    public Context clone(Context source) {
        final Context clone = super.clone(source);
        if (source instanceof Ec2Context) {
            Ec2Context ec2 = (Ec2Context) source;
            this.region = ec2.region;
            this.profile = ec2.profile;
            this.accessKeyId = ec2.accessKeyId;
            this.secretAccessKey = ec2.secretAccessKey;
            this.sessionToken = ec2.sessionToken;
            this.utils = ec2.utils;
        }
        return clone;
    }

    /**
     * Initialize from optional arguments.
     * Usage options:
     * - No args: use default credentials/provider chain and default region resolution.
     * - One arg: path/URI/classpath to .properties file with keys defined above.
     */
    public void initialize(String[] args) {
        if (args != null && args.length > 0 && args[0] != null && !args[0].trim().isEmpty()) {
            String configLocation = args[0].trim();
            try {
                String content = GroovyUtil.lookupText(resolveVariable(configLocation));
                Properties props = new Properties();
                props.load(new StringReader(content));
                this.region = trimToNull(props.getProperty("aws.region"));
                this.profile = trimToNull(props.getProperty("aws.profile"));
                this.accessKeyId = trimToNull(props.getProperty("aws.accessKeyId"));
                this.secretAccessKey = trimToNull(props.getProperty("aws.secretAccessKey"));
                this.sessionToken = trimToNull(props.getProperty("aws.sessionToken"));
            } catch (Exception e) {
                // fall back to defaults on any error
            }
        }
        // ensure utils is created lazily with above settings on first use
    }

    private String trimToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    // --- EC2 helpers ---

    /**
     * Minimal helper to list instance IDs in the configured region.
     */
    public List<String> listInstanceIds() {
        Ec2Client client = utils().getClient();
        List<String> ids = new ArrayList<>();
        try {
            String nextToken = null;
            do {
                DescribeInstancesResponse resp = client.describeInstances(DescribeInstancesRequest.builder().maxResults(1000).nextToken(nextToken).build());
                for (Reservation r : resp.reservations()) {
                    r.instances().forEach(i -> ids.add(i.instanceId()));
                }
                nextToken = resp.nextToken();
            } while (nextToken != null && !nextToken.isBlank());
        } catch (Exception e) {
            // Swallow exceptions and record as error to context
            error("ec2.listInstances.error", String.valueOf(e.getMessage()));
        }
        return ids;
    }
}
