Junie Guidelines for This Project

Purpose
- Provide a clear, repeatable way for Junie (the autonomous JetBrains-powered assistant) to make minimal, safe, and traceable changes to this repository.
- Ensure changes respect the project’s multi-module nature (Java/Groovy back end, Angular front end) and do not break builds or tests.

Scope
- Applies to all automated contributions made by Junie in this repository.
- Complements general engineering practices; does not replace human code review and governance.

Core Principles
- Minimal viable change: Prefer the smallest change that fully satisfies the issue.
- Explicit communication: Keep the User informed with concise status updates and final summaries.
- Safety first: Avoid large refactors; preserve public APIs and behavior unless explicitly requested.
- Consistency: Follow existing patterns, code style, and module boundaries.
- Test confidence: Run relevant tests after changes; avoid introducing flakiness.

Repository Overview (high level)
- Root modules include:
  - support-ide, support-ide-web, tm-support, logs-analysis, script-commons, support-commons, etc.
  - Back end: Java/Groovy (Gradle/Maven via root pom.xml).
  - Front end: Angular under support-ide-web/src/main/web.
  - Docs and diagrams: docs/.

Workflow for Junie
1) Understand the issue
- Read the issue description carefully; extract acceptance criteria.
- Note date/time if relevant to the task.

2) Plan privately, then publish
- Create an internal plan; once solid, publish/update the plan using the status update mechanism (update_status), including a short analysis and a numbered plan with progress markers.

3) Explore code safely
- Use project search for targeted keywords, file and symbol names.
- Inspect file structures before opening entire files; avoid opening large files wholesale.

4) Make minimal changes
- Prefer adding or editing a single file when feasible.
- If renaming identifiers, use the dedicated rename tool to update all references consistently.
- Avoid cross-module changes unless necessary.

5) Keep the User informed
- Use update_status to share findings, decisions, and next actions whenever the plan changes or important milestones are reached.
- At completion, submit a concise summary of what changed and why using submit.

6) Verify
- Build or run targeted tests where applicable. Use test tooling to run only impacted tests if possible.
- Validate that changes do not affect unrelated modules.

Tooling Rules (must follow)
- Prefer specialized tools over generic shell commands.
- Use search_project for locating files/text; avoid broad shell find/grep.
- Use get_file_structure and open to navigate files efficiently.
- Use rename_element for any renaming; never simulate renames with blind search/replace.
- Use search_replace for precise, line-exact edits. Provide unique search blocks.
- Use create for adding new files (docs, code, tests). Keep files inside the repo.
- Use run_test/build only when required to validate changes.
- Do not combine special tools and shell commands in the same call.

Coding Conventions
- Java/Groovy (server-side):
  - Match existing formatting and idioms in the touched module.
  - Preserve method signatures and public APIs unless the issue explicitly requests changes.
  - Add unit tests in the corresponding test trees when changing behavior.
- Angular/TypeScript (UI under support-ide-web):
  - Follow the existing component/service/module patterns.
  - Keep HTML/SCSS changes scoped to the relevant components; avoid global overrides.
  - Respect Angular change detection and observable patterns seen in the project.

Documentation Practices
- Place diagrams and images in docs/; prefer vector (SVG) where possible.
- For new docs, create markdown in docs/ with clear sections (Purpose, Context, How to Use, Limitations).
- Link key docs from README.md for discoverability when appropriate.

Testing and Validation
- Prefer running only the tests related to modified modules.
- When adding behavior, add tests that:
  - Reproduce the original issue (if applicable).
  - Verify the fix and guard against regressions.
- Use [DEBUG_LOG] prefixes for any temporary debug prints in tests; remove or keep minimal.
- For testing, use spock framework by default, if applicable.

Performance and Reliability
- Avoid introducing heavy operations on hot paths.
- Keep external calls resilient; handle nulls and unexpected inputs defensively.

Security and Secrets
- Do not hardcode secrets or credentials.
- Sanitize or mask sensitive information in logs and errors.

Error Handling and Logging
- Provide actionable error messages; avoid leaking sensitive info.
- Reuse existing logging frameworks and patterns found in the module.

When to Decline or Ask for Clarification
- Requirements conflict with existing constraints or are ambiguous.
- Changes require architectural decisions beyond the scope of a minimal fix.
- You suspect unintended impact across modules.

Deliverables Checklist (per issue)
- Plan published via update_status with clear progress markers.
- Minimal code/doc changes implemented.
- Tests/build executed as needed; results summarized.
- README or docs updated when appropriate.
- Final submit with a concise summary of changes and final plan statuses.

Appendix: Module Pointers (non-exhaustive)
- Back end controllers/services examples:
  - support-ide/src/main/java/com/edifecs/support/ide/controller/
  - support-ide/src/main/java/com/edifecs/support/ide/service/
- Front end (Angular):
  - support-ide-web/src/main/web/src/app/features/
- Scripts and tests:
  - tm-support/src/main/resources/collect/
  - tm-support/src/test/groovy/
  - support-ide/src/test/groovy/

This document will evolve as Junie accumulates more task experience in this repository. Prefer incremental updates that clarify expectations without overconstraining future work.