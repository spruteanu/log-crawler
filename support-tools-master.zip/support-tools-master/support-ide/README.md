# Support IDE Module

This module provides a Spring Boot application with an embedded Tomcat server that serves as an IDE backend for discovering and executing scripts.

## Features

- Discovers scripts in JARs and directories
- Provides REST API endpoints to list scripts and their metadata
- Allows execution of scripts and returns execution results
- Supports script content retrieval

## Configuration

The application is configured via `application.properties`:

```properties
# Server configuration
server.port=8080
server.servlet.context-path=/support-ide

# Application name
spring.application.name=support-ide

# Logging configuration
logging.level.root=INFO
logging.level.com.edifecs.support.ide=DEBUG

# Actuator configuration
management.endpoints.web.exposure.include=health,info,metrics

# Scripts configuration
scripts.lib.path=lib
scripts.path=scripts
```

You can customize these settings as needed.

## API Endpoints

### List all scripts

```
GET /support-ide/api/scripts
```

Returns a list of all discovered scripts with their metadata.

### Get script details

```
GET /support-ide/api/scripts/{scriptPath}
```

Returns the metadata for a specific script.

### Get script content

```
GET /support-ide/api/scripts/{scriptPath}/content
```

Returns the content of a specific script.

### Execute a script

```
POST /support-ide/api/scripts/{scriptPath}/execute?args=arg1&args=arg2
```

Executes a script with the provided arguments and returns the execution results.

### Refresh script cache

```
POST /support-ide/api/scripts/refresh
```

Refreshes the script cache by rediscovering scripts.

## Running the Application

To run the application:

1. Build the project:
   ```
   mvn clean install
   ```

2. Run the application:
   ```
   java -jar support-ide/target/support-ide-1.0-SNAPSHOT.jar
   ```

3. Access the API at `http://localhost:8080/support-ide/api/scripts`

## Integration with Frontend

This backend can be integrated with any frontend application that can make HTTP requests. The API returns JSON responses that can be easily consumed by JavaScript applications.

## Dependencies

- Spring Boot 2.7.18
- Support Commons module
- Groovy 3.0.23
