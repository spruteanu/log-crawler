# gRPC Agent Installation Script (Windows)
# This script installs the Support Tools gRPC Agent as a Windows Service.
# Usage (Run PowerShell as Administrator):
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   .\install-windows.ps1

Write-Host "Installing gRPC Agent (Windows)..."

# Configuration
$InstallDir = "C:\\SupportGrpcAgent"
$ServiceName = "SupportGrpcAgent"
$DisplayName = "Support Tools gRPC Agent"
$StartScript = Join-Path $InstallDir "start-grpc-agent.cmd"

# Ensure install directory exists
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
}

# Copy files (assumes script is run from the extracted bundle directory)
Get-ChildItem -Path . -Filter *.jar | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $InstallDir -Force
}
if (Test-Path ".\start-grpc-agent.cmd") {
    Copy-Item -Path ".\start-grpc-agent.cmd" -Destination $InstallDir -Force
} else {
    Write-Host "ERROR: start-grpc-agent.cmd not found in current directory." -ForegroundColor Red
    exit 1
}

# Create/Update Windows Service
# Use sc.exe to register a service that runs the startup script via cmd.exe
$binPath = "cmd.exe /c `"$StartScript`""

# If service exists, delete it first to update configuration
$existing = sc.exe query $ServiceName 2>$null | Select-String -Pattern "$ServiceName"
if ($existing) {
    Write-Host "Existing service found. Stopping and deleting..."
    sc.exe stop $ServiceName | Out-Null
    Start-Sleep -Seconds 3
    sc.exe delete $ServiceName | Out-Null
    Start-Sleep -Seconds 2
}

Write-Host "Creating Windows service '$ServiceName'..."
sc.exe create $ServiceName binPath= "$binPath" start= auto DisplayName= "$DisplayName" | Out-Null

# Grant service the ability to restart automatically and set description
sc.exe description $ServiceName "Support Tools gRPC agent service (runs start-grpc-agent.cmd)" | Out-Null

Write-Host "Installation complete. Configure the service in start-grpc-agent.cmd and start it with:"
Write-Host "  sc start $ServiceName"
