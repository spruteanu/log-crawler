# gRPC Agent Installation Notes

## Overview
This bundle contains everything needed to deploy the Support Tools gRPC Agent on a remote server.

## Prerequisites
- Java 11 or higher
- Linux/Unix environment with bash
- Root or sudo access for installation

## Installation Steps

1. **Extract the bundle:**
   ```bash
   unzip support-tools.zip
   cd support-tools
   ```

2. **Configure the startup script:**
   Edit `start-agent.sh` and set:
   - `PORT`: The port for the gRPC server (default: 9090)
   - `AUTH_TOKEN`: Authentication token for security (optional but recommended)
   - `TOOL_LOCATION`: Directory where tools will be extracted (default: /tmp)

3. **Run the installation script:**
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

4. **Start the service:**
   ```bash
   sudo systemctl start support-agent
   ```

5. **Check service status:**
   ```bash
   sudo systemctl status support-agent
   ```

## Configuration

### Server Configuration
In the Support Tools IDE, configure your server with:
- **Use gRPC**: Enable this option
- **gRPC Host**: The hostname/IP of the remote server
- **gRPC Port**: The port configured in start-agent.sh (default: 9090)
- **gRPC Auth Token**: The same token configured in start-agent.sh

### Security Considerations
- Always use an authentication token in production environments
- Consider using TLS for encrypted communication (requires code modification)
- Restrict network access to the gRPC port using firewall rules
- Run the service with minimal required privileges

## Troubleshooting

### Check logs:
```bash
sudo journalctl -u support-agent -f
```

### Common issues:
- **Port already in use**: Change the PORT in start-agent.sh
- **Permission denied**: Ensure the service has write access to TOOL_LOCATION
- **Java not found**: Install Java 11+ or update PATH
- **Connection refused**: Check firewall settings and network connectivity

### Manual start (for testing):
```bash
cd /opt/support-tools
./start-agent.sh
```

## Uninstallation

To remove the gRPC agent:
```bash
sudo systemctl stop support-agent
sudo systemctl disable support-agent
sudo rm /etc/systemd/system/support-agent.service
sudo rm -rf /opt/support-tools
sudo systemctl daemon-reload
```
