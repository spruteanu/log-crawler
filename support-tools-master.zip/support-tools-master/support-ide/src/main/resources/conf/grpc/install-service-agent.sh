#!/bin/bash
# gRPC Agent Installation Script
echo "Installing gRPC Agent..."

# Create installation directory
INSTALL_DIR="/opt/support-grpc-agent"
sudo mkdir -p $INSTALL_DIR

# Copy files
sudo cp *.jar $INSTALL_DIR/
sudo cp start-grpc-agent.sh $INSTALL_DIR/
sudo chmod +x $INSTALL_DIR/start-grpc-agent.sh

# Create systemd service
sudo tee /etc/systemd/system/support-grpc-agent.service > /dev/null <<EOF
[Unit]
Description=Support Tools gRPC Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/start-grpc-agent.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable support-grpc-agent

echo "Installation complete. Configure the service in start-grpc-agent.sh and then start it with:"
echo "sudo systemctl start support-grpc-agent"
