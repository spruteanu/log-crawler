package com.edifecs.support.ide.service;

import com.edifecs.support.Storage;
import com.edifecs.support.core.ApacheZipWalker;
import com.edifecs.support.core.ZipWalker;
import com.edifecs.support.ide.model.Server;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Builds the gRPC agent bundle ZIP as a streaming response to avoid OOM for large archives.
 * Extracted from ServerController to keep the controller slim and focused.
 */
@SuppressWarnings("squid:S1192")
public class GrpcAgentBundle {
    private static final Logger LOGGER = LogManager.getLogger(GrpcAgentBundle.class);
    private static final String GRPC_CONF_BASE = "conf/grpc/";

    private final ProgressCallback progressCallback;

    // Server related fields moved to class level
    private final String hostname;
    private final String token;
    private final int port;
    private final String toolLocation;

    public GrpcAgentBundle(Server server, ProgressCallback progressCallback) {
        this.progressCallback = progressCallback;
        this.hostname = server.getHostname();
        // compute token if not provided on server
        String tk = server.getGrpcToken();
        if (tk == null || tk.isEmpty()) {
            tk = computeGrpcToken(this.hostname);
        }
        this.token = tk;
        this.port = server.getGrpcPort();
        String tl = server.getToolLocation();
        this.toolLocation = (tl != null && !tl.isEmpty()) ? tl : "/tmp";
    }

    private void addServerConfig(ZipArchiveOutputStream zaos) {
        String config = "hostname=" + hostname + "\n" +
                "authToken=" + token + "\n" +
                "port=" + port + "\n" +
                "toolLocation=" + toolLocation + "\n";
        ApacheZipWalker.zipIt(zaos,
                new ByteArrayInputStream(config.getBytes(StandardCharsets.UTF_8)),
                "server-info.properties");
    }

    private void addInstallationNotes(ZipArchiveOutputStream zaos) throws IOException {
        String notes = readResourceAsString(GRPC_CONF_BASE + "README.md");
        ApacheZipWalker.zipIt(zaos,
                new ByteArrayInputStream(notes.getBytes(StandardCharsets.UTF_8)),
                "README.md");
    }

    private void addGrpcDependencies(ZipArchiveOutputStream zaos, String sessionId) throws IOException {
        // Get support-tools.zip file path using Storage utility
        Path supportToolsZipPath = Storage.toolImagePath();

        if (!Files.exists(supportToolsZipPath) || !Storage.isCrcEqual(supportToolsZipPath)) {
            Storage.createSupportToolsZip();
        }

        LOGGER.info("Adding all files from support-tools.zip to gRPC agent bundle (Apache): {}", supportToolsZipPath);

        try (ZipWalker zipWalker = ZipWalker.of(supportToolsZipPath.toFile())) {
            AtomicLong totalFiles = new AtomicLong(0);
            AtomicLong processedFiles = new AtomicLong(0);

            // First pass: count files
            zipWalker.walk(entry -> {
                if (!entry.getZipEntry().isDirectory()) {
                    totalFiles.incrementAndGet();
                }
            });

            LOGGER.debug("Total files to process (Apache): {}", totalFiles.get());

            // Second pass: process files with progress tracking
            try (ZipWalker zipWalker2 = ZipWalker.of(supportToolsZipPath.toFile())) {
                zipWalker2.walk(entry -> {
                    try {
                        if (!entry.getZipEntry().isDirectory()) {
                            String entryName = entry.getZipEntry().getName();
                            try (InputStream inputStream = entry.getInputStream()) {
                                ApacheZipWalker.zipIt(zaos, inputStream, entryName);
                            }
                            long processed = processedFiles.incrementAndGet();
                            long total = totalFiles.get();
                            if (processed % 10 == 0 || processed == total) {
                                progressCallback.sendProgress(sessionId, "progress",
                                        String.format("Processing dependencies... (%d/%d files)", processed, total));
                            }
                            LOGGER.debug("Added file to gRPC bundle: {} ({}/{})", entryName, processed, total);
                        }
                    } catch (IOException e) {
                        LOGGER.error("Failed to add entry to gRPC bundle: {}", entry.getZipEntry().getName(), e);
                        throw new RuntimeException("Failed to process zip entry", e);
                    }
                });
            }
        } catch (Exception e) {
            LOGGER.error("Error walking through support-tools.zip", e);
            throw new IOException("Failed to process support-tools.zip", e);
        }
    }

    private void addStartupScript(ZipArchiveOutputStream zaos) throws IOException {
        // Linux startup script
        String template = readResourceAsString(GRPC_CONF_BASE + "start-agent.sh.template");
        String startupScript = template
                .replace("{{PORT}}", String.valueOf(port))
                .replace("{{AUTH_TOKEN}}", token)
                .replace("{{TOOL_LOCATION}}", toolLocation);
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(startupScript.getBytes(StandardCharsets.UTF_8)), "start-agent.sh");

        // Windows startup script
        String templateWin = readResourceAsString(GRPC_CONF_BASE + "start-agent.cmd.template");
        // Ensure Windows-friendly default tool location if input is blank or looks like a POSIX path
        String toolLocWin = toolLocation;
        if (toolLocWin.trim().isEmpty()) {
            toolLocWin = "C:\\Temp";
        }
        String startupScriptWin = templateWin
                .replace("{{PORT}}", String.valueOf(port))
                .replace("{{AUTH_TOKEN}}", token)
                .replace("{{TOOL_LOCATION}}", toolLocWin);
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(startupScriptWin.getBytes(StandardCharsets.UTF_8)), "start-agent.cmd");

        // Linux stop script
        String stopTemplate = readResourceAsString(GRPC_CONF_BASE + "stop-agent.sh.template");
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(stopTemplate.getBytes(StandardCharsets.UTF_8)), "stop-agent.sh");

        // Windows stop script
        String stopTemplateWin = readResourceAsString(GRPC_CONF_BASE + "stop-agent.cmd.template");
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(stopTemplateWin.getBytes(StandardCharsets.UTF_8)), "stop-agent.cmd");
    }

    public StreamingResponseBody toStreamingBody(String sessionId) {
        return outputStream -> {
            try (ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(outputStream)) {
                // Send initial progress
                progressCallback.sendProgress(sessionId, "starting", "Starting bundle creation...");

                // Add installation script
                addInstallationScript(zaos);
                progressCallback.sendProgress(sessionId, "progress", "Added installation scripts...");

                // Add startup script with injected token and settings
                addStartupScript(zaos);
                progressCallback.sendProgress(sessionId, "progress", "Added startup scripts...");

                // Add a small config file with host/token for reference
                addServerConfig(zaos);
                progressCallback.sendProgress(sessionId, "progress", "Added server configuration...");

                // Add installation notes
                addInstallationNotes(zaos);
                progressCallback.sendProgress(sessionId, "progress", "Added installation notes...");

                // Add gRPC JAR dependencies - this streams directly without loading all into memory
                progressCallback.sendProgress(sessionId, "progress", "Adding gRPC dependencies...");
                addGrpcDependencies(zaos, sessionId);
                progressCallback.sendProgress(sessionId, "completed", "Bundle creation completed!");
                zaos.finish();
            }
        };
    }

    private String computeGrpcToken(String hostname) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(hostname.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 16 && i < digest.length; i++) {
                sb.append(String.format("%02x", digest[i]));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to compute gRPC token", e);
        }
    }

    private String readResourceAsString(String resourcePath) throws IOException {
        try (InputStream in = getClass().getClassLoader().getResourceAsStream(resourcePath)) {
            if (in == null) {
                throw new IOException("Resource not found: " + resourcePath);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private void addInstallationScript(ZipArchiveOutputStream zaos) throws IOException {
        // Linux installer
        String installScript = readResourceAsString(GRPC_CONF_BASE + "install-service-agent.sh");
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(installScript.getBytes(StandardCharsets.UTF_8)), "install-service-agent.sh");

        // Windows installer (PowerShell)
        String installWindows = readResourceAsString(GRPC_CONF_BASE + "install-service-agent.ps1");
        ApacheZipWalker.zipIt(zaos, new ByteArrayInputStream(installWindows.getBytes(StandardCharsets.UTF_8)), "install-service-agent.ps1");
    }

    public static GrpcAgentBundle of(Server server) {
        return new GrpcAgentBundle(server, new ProgressCallback.MockProgressCallback());
    }
    public static GrpcAgentBundle of(Server server, ProgressCallback progressCallback) {
        return new GrpcAgentBundle(server, progressCallback);
    }
}
