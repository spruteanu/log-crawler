/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.Storage;
import com.edifecs.support.Support;
import com.edifecs.support.collect.InformationContext;
import com.edifecs.support.core.Context;
import com.edifecs.support.scripts.Metadata;
import com.edifecs.support.ide.controller.ScriptController.NewScriptData;
import com.edifecs.support.ide.model.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Service for script discovery and execution.
 * This class is responsible for discovering, executing scripts and returning their results.
 */
@Service
@EnableScheduling
public class ScriptService {

    private static final Logger LOGGER = LogManager.getLogger(ScriptService.class);

    @Value("${scripts.lib.path:lib}")
    private String libPath;

    @Value("${scripts.path:scripts}")
    private String scriptsPath;

    private String destinationPath;

    /**
     * Cache for discovered scripts to avoid rediscovering them on every request.
     */
    private final ConcurrentMap<String, List<Metadata>> scriptCache = new ConcurrentHashMap<>();
    
    private final ServerService serverService;
    private final GrpcServer grpcServer;
    
    @Autowired
    public ScriptService(ServerService serverService, GrpcServer grpcServer) {
        this.serverService = serverService;
        this.grpcServer = grpcServer;
    }

    @Value("${support.destination.path:./results}")
    public void setDestinationPath(String destinationPath) {
        this.destinationPath = destinationPath;
        Storage.destinationDefault(destinationPath);
    }

    @Value("${support.image.path:image}")
    public void setImagePath(String imagePath) {
        Storage.imagePath(imagePath);
    }

    /**
     * Bean for discovering scripts.
     * This bean is responsible for discovering scripts in the specified paths.
     *
     * @return a list of discovered script metadata
     */
    public List<Metadata> discoverScripts() {
        try {
            Path libDir = Paths.get(libPath);
            Path scriptsDir = Paths.get(scriptsPath);
            
            // Create directories if they don't exist
            File libDirFile = libDir.toFile();
            File scriptsDirFile = scriptsDir.toFile();
            
            if (!libDirFile.exists()) {
                libDirFile.mkdirs();
            }
            
            if (!scriptsDirFile.exists()) {
                scriptsDirFile.mkdirs();
            }
            
            // Discover scripts
            List<Metadata> scripts = Metadata.lookup(libDir, scriptsDir);
            
            // Cache the scripts
            scriptCache.put("all", scripts);
            
            LOGGER.info("Discovered {} scripts", scripts.size());
            return scripts;
        } catch (IOException e) {
            LOGGER.error("Failed to discover scripts", e);
            return Collections.emptyList();
        }
    }

    /**
     * Get the cached scripts.
     *
     * @return a list of cached script metadata
     */
    public List<Metadata> getCachedScripts() {
        if (scriptCache.containsKey("all")) {
            return scriptCache.get("all");
        }
        return discoverScripts();
    }

    /**
     * Find a script by path.
     *
     * @param scriptPath the path of the script to find
     * @return an Optional containing the script metadata if found, or empty if not found
     */
    public Optional<Metadata> findScript(String scriptPath) {
        final String lScript = scriptPath.toLowerCase();
        return getCachedScripts().stream()
                .filter(m -> m.getName().toLowerCase().contains(lScript) || m.getPath().toLowerCase().contains(lScript))
                .findFirst();
    }

    /**
     * Get the scripts path.
     *
     * @return the scripts path
     */
    public String getScriptsPath() {
        return scriptsPath;
    }

    /**
     * Get the lib path.
     *
     * @return the lib path
     */
    public String getLibPath() {
        return libPath;
    }

    /**
     * Refresh the script cache by rediscovering all scripts.
     * This method should be called after creating new scripts to ensure the cache is up-to-date.
     *
     * @return a refreshed list of discovered script metadata
     */
    public List<Metadata> refreshCache() {
        LOGGER.info("Refreshing script cache");
        scriptCache.clear();
        return discoverScripts();
    }

    /**
     * Filter provided scripts by the given user roles.
     * If a script has no roles specified, it is accepted.
     * If roles are specified, the script is accepted only if there is an intersection
     * between script roles and user roles.
     *
     * @param scripts the list of scripts to filter
     * @param userRoles the roles of the current user
     * @return filtered list of scripts available to the user
     */
    public List<Metadata> filterScriptsByUserRoles(List<Metadata> scripts, java.util.Collection<String> userRoles) {
        if (scripts == null || scripts.isEmpty()) return java.util.Collections.emptyList();
        final java.util.Set<String> user = (userRoles == null) ? java.util.Collections.emptySet() : userRoles.stream()
                .filter(java.util.Objects::nonNull)
                .map(s -> s.trim().toLowerCase())
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toSet());
        return scripts.stream().filter(m -> {
            java.util.Set<String> roles = m.getRoles();
            if (roles == null || roles.isEmpty()) return true; // no roles specified => accessible to all
            for (String r : roles) {
                if (user.contains(r.trim().toLowerCase())) return true;
            }
            return false;
        }).collect(Collectors.toList());
    }

    /**
     * Execute a script and return its results.
     *
     * @param metadata the script metadata
     * @param args the script arguments
     * @return a map containing the execution results
     */
    public Map<String, Object> executeScript(Metadata metadata, String[] args) {
        return executeScript(metadata, args, null);
    }
    
    /**
     * Execute a script and return its results.
     *
     * @param metadata the script metadata
     * @param args the script arguments
     * @param serverId the ID of the server to execute the script on (null for local execution)
     * @return a map containing the execution results
     */
    public Map<String, Object> executeScript(Metadata metadata, String[] args, String serverId) {
        Map<String, Object> result = new HashMap<>();
        result.put("scriptName", metadata.getName());
        result.put("scriptPath", metadata.getPath());
        
        // If serverId is provided, execute the script on the remote server
        if (serverId != null && !serverId.isEmpty()) {
            return executeScriptRemotely(metadata, args, serverId);
        }

        // Local execution
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;
        try {
            // Redirect System.out and System.err to capture output
            System.setOut(printStream);
            System.setErr(printStream);
            // Execute the script
            Context context = Support.execute(metadata, args);
            printStream.flush();
            String output = outputStream.toString();
            // Set the result
            result.put("success", true);
            result.put("output", output);
            if (context.hasValues()) {
                final Map<String, Object> filteredResults = Storage.filterValues(context, new LinkedHashMap<>());
                result.put("result", filteredResults);
                context.values().put("output", output);
            } else {
                result.put("result", context.toString());
            }
            final Path dPath = Storage.toDisk(destinationPath, context);
            result.put("destination", dPath.toString());
        } catch (Exception e) {
            LOGGER.error("Failed to execute script: {}", metadata.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
            result.put("stackTrace", e.getStackTrace());
        } finally {
            // Restore System.out and System.err
            System.setOut(originalOut);
            System.setErr(originalErr);
        }

        return result;
    }
    
    /**
     * Execute a script on a remote server.
     *
     * @param metadata the script metadata
     * @param args the script arguments
     * @param serverId the ID of the server to execute the script on
     * @return a map containing the execution results
     */
    private Map<String, Object> executeScriptRemotely(Metadata metadata, String[] args, String serverId) {
        Map<String, Object> result = new HashMap<>();
        result.put("scriptName", metadata.getName());
        result.put("scriptPath", metadata.getPath());
        // Get the server configuration
        Optional<Server> serverOpt = serverService.getServerById(serverId);
        if (serverOpt.isEmpty()) {
            throw new IllegalArgumentException("Server not found with ID: " + serverId);
        }
        Server server = serverOpt.get();
        try {
            // For now, configure gRPC with default settings
            grpcServer.configure(server.getHostname(), server.getGrpcPort(), server.getGrpcToken());

            LOGGER.info("Using gRPC to execute script on server: {}", server.getName());
            Map<String, Object> executionResult = grpcServer.executeScript(server, metadata, args);

            // Copy the execution result to the final result
            result.putAll(executionResult);
            
            // Add server information to the result
            result.put("server", server.getName());
            result.put("hostname", grpcServer.getEffectiveGrpcHost(server.getHostname()));
            result.put("protocol", "gRPC");
            result.put("port", grpcServer.getGrpcPort());

            final Context ctx = InformationContext.of().script(metadata.toScript(args)).add(result);
            Storage.toDisk(destinationPath, ctx);
        } catch (Exception e) {
            LOGGER.error("Failed to execute script on remote server: {}", metadata.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
            result.put("stackTrace", e.getStackTrace());
        }
        
        return result;
    }

    /**
     * Get the content of a script.
     *
     * @param metadata the script metadata
     * @return the script content
     */
    public String getScriptContent(Metadata metadata) {
        try {
            if (metadata.getContent() != null) {
                return metadata.getContent();
            }

            if (metadata.isLibraryScript()) {
                // For library scripts, the content should already be in the metadata
                return "// Script content not available";
            } else {
                // For file scripts, read the content from the file
                return new String(Files.readAllBytes(Paths.get(metadata.getPath())));
            }
        } catch (IOException e) {
            LOGGER.error("Failed to read script content: {}", metadata.getName(), e);
            return "// Failed to read script content: " + e.getMessage();
        }
    }

    private String toScript(NewScriptData newScriptData) {
        // Generate script content
        String scriptContent;
        try {
            if (newScriptData.getSelectedScripts() != null && !newScriptData.getSelectedScripts().isEmpty()) {
                // Combine multiple scripts
                scriptContent = combineScripts(newScriptData);
            } else if (newScriptData.getScriptContent() != null && !newScriptData.getScriptContent().trim().isEmpty()) {
                // Use provided script content
                scriptContent = newScriptData.getScriptContent();
            } else {
                throw new IllegalArgumentException("Either selectedScripts or scriptContent must be provided");
            }
        } catch (Exception e) {
            LOGGER.error("Failed to generate script content: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to generate script content: " + e.getMessage(), e);
        }
        return scriptContent;
    }

    /**
     * Create a new script with the provided data.
     *
     * @param newScriptData the new script data including name, description, author, and either selectedScripts or scriptContent
     * @param scriptsPath the path where the script should be created
     * @return the created script metadata
     * @throws IOException if there's an error writing the script file
     * @throws IllegalArgumentException if required script data is missing
     * @throws RuntimeException if there's an error validating or compiling the script
     */
    public Metadata createScript(NewScriptData newScriptData, Path scriptsPath) throws IOException, IllegalArgumentException {
        LOGGER.info("Creating new script: {}", newScriptData.getName());

        // Validate input data
        if (newScriptData.getName() == null || newScriptData.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Script name is required");
        }

        // Generate unique filename and path
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String uniqueId = UUID.randomUUID().toString().substring(0, 8);
        String fileName = newScriptData.getName().replaceAll("[^a-zA-Z0-9_-]", "_") + "_" + timestamp + "_" + uniqueId + ".groovy";

        Path scriptPath = scriptsPath.resolve(fileName);
        final String scriptContent = toScript(newScriptData);
        // Write script to file
        try {
            Files.write(scriptPath, scriptContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        } catch (IOException e) {
            LOGGER.error("Failed to write script file: {}", scriptPath, e);
            throw new IOException("Failed to write script file: " + e.getMessage(), e);
        }

        // Validate the script
        try {
            // Check that the script is correct
            Metadata scriptMetadata = Metadata.parseMeta(scriptPath);
            if (scriptMetadata == null) {
                throw new RuntimeException("Failed to parse script metadata: Script validation returned null");
            }

            // Check if there was an error during parsing
            // Errors are stored in the description field by the error() method
            String description = scriptMetadata.getDescription();
            if (description != null && (description.startsWith("Failed to parse") || description.contains("Error:"))) {
                throw new RuntimeException("Script validation error: " + description);
            }
        } catch (Exception e) {
            // If validation fails, try to delete the invalid script file
            try {
                Files.deleteIfExists(scriptPath);
                LOGGER.info("Deleted invalid script file: {}", scriptPath);
            } catch (IOException deleteEx) {
                LOGGER.warn("Failed to delete invalid script file: {}", scriptPath, deleteEx);
            }

            LOGGER.error("Script validation failed: {}", e.getMessage(), e);
            throw new RuntimeException("Script validation failed: " + e.getMessage(), e);
        }

        // Create and return metadata
        Metadata metadata = new Metadata();
        metadata.setName(newScriptData.getName());
        metadata.setDescription(newScriptData.getDescription());
        metadata.setAuthor(newScriptData.getAuthor());
        metadata.setPath(scriptPath.toString());
        metadata.setType("groovy");
        metadata.setContent(scriptContent);

        LOGGER.info("Successfully created script: {}", scriptPath);
        
        // Update last modified date of image path scripts to current date
        updateImagePathScriptsModificationTime();
        
        return metadata;
    }

    /**
     * Update the last modified time of scripts in the image path to the current date.
     */
    private void updateImagePathScriptsModificationTime() {
        // Get the image path from Storage
        Path imagePath = Storage.imagePath();
        if (!Files.exists(imagePath)) {
            LOGGER.debug("Image path does not exist: {}", imagePath);
            return;
        }
        final FileTime currentFileTime = FileTime.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
        try (Stream<Path> files = Files.walk(imagePath)) {
            files.filter(Files::isRegularFile)
                    .filter(path -> path.toString().toLowerCase().endsWith(".zip"))
                    .forEach(scriptFile -> {
                        try {
                            Files.setLastModifiedTime(scriptFile, currentFileTime);
                            LOGGER.debug("Updated last modified time of image path script: {}", scriptFile);
                        } catch (IOException e) {
                            LOGGER.warn("Failed to update last modified time for: {}", scriptFile, e);
                        }
                    });
        } catch (Exception e) {
            LOGGER.error("Failed to update image path scripts modification time", e);
        }
    }

    /**
     * Combine multiple scripts into a single script.
     */
    private String combineScripts(NewScriptData newScriptData) {
        StringBuilder combinedContent = new StringBuilder();
        combinedContent.append("import com.edifecs.support.Support\n");
        combinedContent.append("import com.edifecs.support.scripts.Description\n\n");

        // Add comment about combined scripts
        combinedContent.append("// This script combines the following scripts:\n");
        List<Metadata> selectedScripts = newScriptData.getSelectedScripts();
        for (Metadata script : selectedScripts) {
            combinedContent.append("// - ").append(script.getName()).append(" (").append(script.getDescription()).append(")\n");
        }
        combinedContent.append("\n");

        combinedContent.append(generateMethodHeader(newScriptData));
        combinedContent.append("static def execute(String... args) {\n");
        combinedContent.append("\tSupport.info {\n\n");
        // Add each script as an inclusion
        for (int i = 0; i < selectedScripts.size(); i++) {
            Metadata script = selectedScripts.get(i);
            combinedContent.append("\t\t// ").append("=".repeat(60)).append("\n");
            combinedContent.append("\t\t// Script ").append(i + 1).append(": ").append(script.getName()).append("\n");
            combinedContent.append("\t\t// Author: ").append(script.getAuthor() != null ? script.getAuthor() : "Unknown").append("\n");
            combinedContent.append("\t\t// Description: ").append(script.getDescription() != null ? script.getDescription() : "No description").append("\n");
            combinedContent.append("\t\t// ").append("=".repeat(60)).append("\n\n");
            
            combinedContent.append("\t\tinclude('").append(script.toScript()).append("')\n");
            
            if (i < selectedScripts.size() - 1) {
                combinedContent.append("\n\n");
            }
        }
        combinedContent.append("\t}\n");
        combinedContent.append("}\n\n");
        combinedContent.append("execute(args)\n");
        return combinedContent.toString();
    }

    /**
     * Generate script header with metadata.
     */
    private String generateMethodHeader(NewScriptData newScriptData) {
        return "@Description(\n" +
                "        name = '" + newScriptData.getName() + "',\n" +
                "        description = '" + newScriptData.getDescription() + "',\n" +
                "        author = '" + newScriptData.getAuthor() + "'\n" +
                ")\n";
    }
}
