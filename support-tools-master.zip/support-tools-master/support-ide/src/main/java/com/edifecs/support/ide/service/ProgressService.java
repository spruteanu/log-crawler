package com.edifecs.support.ide.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Service bean responsible for tracking progress and sending SSE updates.
 * Extracted from ServerController to promote reuse and testability.
 */
@Service
@Profile("ide")
public class ProgressService implements ProgressCallback {

    private static final Logger LOGGER = LogManager.getLogger(ProgressService.class);

    // Progress tracking for operations
    private final Map<String, SseEmitter> progressEmitters = new ConcurrentHashMap<>();
    private final Map<String, AtomicLong> progressCounters = new ConcurrentHashMap<>();

    /**
     * Create and register an SseEmitter for the specified session.
     */
    public SseEmitter createEmitter(String sessionId) {
        LOGGER.info("Establishing SSE connection, session: {}", sessionId);
        SseEmitter emitter = new SseEmitter(300000L); // 5 minutes timeout
        progressEmitters.put(sessionId, emitter);
        progressCounters.put(sessionId, new AtomicLong(0));

        emitter.onCompletion(() -> cleanup(sessionId, "completed"));
        emitter.onTimeout(() -> cleanup(sessionId, "timeout"));
        emitter.onError(ex -> cleanup(sessionId, "error"));

        // Send initial connection acknowledgment to help frontend initialize listeners
        try {
            Map<String, Object> init = new HashMap<>();
            init.put("status", "connected");
            init.put("message", "SSE connection established");
            init.put("timestamp", System.currentTimeMillis());
            emitter.send(SseEmitter.event().name("progress").data(init));
        } catch (Exception e) {
            LOGGER.warn("Failed to send initial SSE event for session {}: {}", sessionId, e.getMessage());
        }
        return emitter;
    }

    private void cleanup(String sessionId, String reason) {
        switch (reason) {
            case "completed":
                LOGGER.debug("SSE connection completed for session: {}", sessionId);
                break;
            case "timeout":
                LOGGER.warn("SSE connection timeout for session: {}", sessionId);
                break;
            case "error":
                LOGGER.error("SSE connection error for session: {}", sessionId);
                break;
            default:
                LOGGER.debug("SSE cleanup for session: {} reason: {}", sessionId, reason);
        }
        progressEmitters.remove(sessionId);
        progressCounters.remove(sessionId);
    }

    /**
     * Send progress update via SSE if session ID is provided.
     */
    @Override
    public void sendProgress(String sessionId, String status, String message) {
        if (sessionId == null || sessionId.isEmpty()) {
            return;
        }
        SseEmitter emitter = progressEmitters.get(sessionId);
        if (emitter != null) {
            try {
                Map<String, Object> progressData = new HashMap<>();
                progressData.put("status", status);
                progressData.put("message", message);
                progressData.put("timestamp", System.currentTimeMillis());

                emitter.send(SseEmitter.event()
                        .name("progress")
                        .data(progressData));

                LOGGER.debug("Sent progress update for session {}: {} - {}", sessionId, status, message);
            } catch (Exception e) {
                LOGGER.error("Failed to send progress update for session: {}", sessionId, e);
                // Remove failed emitter
                progressEmitters.remove(sessionId);
                progressCounters.remove(sessionId);
            }
        }
    }
}
