

package com.edifecs.support.ide.service;

import com.edifecs.support.ide.model.Cluster;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class ClusterService {
    private static final Logger LOGGER = LogManager.getLogger(ClusterService.class);
    private static final String FILE_EXT = ".json";

    @Value("${support.clusters.directory:results/clusters}")
    private String clustersDirectory;

    private final EncryptionService encryptionService;
    private final ObjectMapper objectMapper;
    private final List<Cluster> clusters = new ArrayList<>();

    public ClusterService(EncryptionService encryptionService) {
        this.encryptionService = encryptionService;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @PostConstruct
    public void init() throws IOException {
        Path dir = Paths.get(clustersDirectory);
        if (!Files.exists(dir)) {
            Files.createDirectories(dir);
            LOGGER.info("Created the cluster directory: {}", dir);
        }
        loadAll();
    }

    private void loadAll() {
        clusters.clear();
        Path dir = Paths.get(clustersDirectory);
        try (Stream<Path> paths = Files.list(dir)) {
            paths.filter(p -> p.toString().endsWith(FILE_EXT)).forEach(this::loadOne);
        } catch (IOException e) {
            LOGGER.error("Error loading clusters from {}", dir, e);
        }
    }

    private void loadOne(Path path) {
        try {
            Cluster c = objectMapper.readValue(path.toFile(), Cluster.class);
            clusters.add(c);
        } catch (IOException e) {
            LOGGER.error("Error reading cluster from {}", path, e);
        }
    }

    public List<Cluster> getAllClusters() {
        return new ArrayList<>(clusters);
    }

    public List<Cluster> getActiveClusters() {
        return clusters.stream().filter(Cluster::isActive).collect(Collectors.toList());
    }

    public Optional<Cluster> getClusterById(String id) {
        return clusters.stream().filter(c -> Objects.equals(c.getId(), id)).findFirst();
    }

    public Cluster createCluster(Cluster input) {
        Cluster c = new Cluster()
                .setId(UUID.randomUUID().toString())
                .setName(nullSafeTrim(input.getName()))
                .setDescription(nullSafeTrim(input.getDescription()))
                .setActive(input.isActive())
                .setAwsRegion(nullSafeTrim(input.getAwsRegion()))
                .setClusterName(nullSafeTrim(input.getClusterName()))
                .setAuthMode(input.getAuthMode())
                .setAwsProfile(nullSafeTrim(input.getAwsProfile()))
                .setCreatedAt(LocalDateTime.now())
                .setUpdatedAt(LocalDateTime.now());

        if (c.getAuthMode() == Cluster.AuthMode.STATIC) {
            setAwsCreds(input, c);
        }

        persistCluster(c);
        clusters.add(c);
        return c;
    }

    public Optional<Cluster> updateCluster(String id, Cluster input) {
        Optional<Cluster> opt = getClusterById(id);
        if (opt.isEmpty()) return Optional.empty();

        Cluster c = opt.get();
        if (notBlank(input.getName())) c.setName(input.getName().trim());
        c.setDescription(nullSafeTrim(input.getDescription()));
        c.setActive(input.isActive());
        if (notBlank(input.getAwsRegion())) c.setAwsRegion(input.getAwsRegion().trim());
        if (notBlank(input.getClusterName())) c.setClusterName(input.getClusterName().trim());
        if (input.getAuthMode() != null) c.setAuthMode(input.getAuthMode());
        c.setAwsProfile(nullSafeTrim(input.getAwsProfile()));

        if (c.getAuthMode() == Cluster.AuthMode.STATIC) {
            setAwsCreds(input, c);
        } else {
            c.setAwsAccessKeyId(null);
            c.setAwsSecretAccessKey(null);
            c.setAwsSessionToken(null);
        }

        c.setUpdatedAt(LocalDateTime.now());
        persistCluster(c);
        return Optional.of(c);
    }

    private void setAwsCreds(Cluster input, Cluster c) {
        if (notBlank(input.getAwsAccessKeyId())) {
            c.setAwsAccessKeyId(encryptionService.encrypt(input.getAwsAccessKeyId()));
        }
        if (notBlank(input.getAwsSecretAccessKey())) {
            c.setAwsSecretAccessKey(encryptionService.encrypt(input.getAwsSecretAccessKey()));
        }
        if (notBlank(input.getAwsSessionToken())) {
            c.setAwsSessionToken(encryptionService.encrypt(input.getAwsSessionToken()));
        }
    }

    public boolean deleteCluster(String id) {
        Optional<Cluster> opt = getClusterById(id);
        if (opt.isEmpty()) return false;

        Cluster c = opt.get();
        Path path = Paths.get(clustersDirectory, c.getId() + FILE_EXT);
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            LOGGER.error("Error deleting cluster file {}", path, e);
            return false;
        }
        clusters.remove(c);
        return true;
    }

    public void persistCluster(Cluster c) {
        Path path = Paths.get(clustersDirectory, c.getId() + FILE_EXT);
        try {
            objectMapper.writeValue(path.toFile(), c);
            LOGGER.debug("Cluster saved: {}", path);
        } catch (IOException e) {
            LOGGER.error("Error saving cluster {} to {}", c.getName(), path, e);
        }
    }

    private static boolean notBlank(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static String nullSafeTrim(String s) {
        return s == null ? null : s.trim();
    }
}