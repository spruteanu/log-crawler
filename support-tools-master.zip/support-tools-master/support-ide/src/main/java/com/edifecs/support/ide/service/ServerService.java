/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.Storage;
import com.edifecs.support.core.ProcessHelper;
import com.edifecs.support.ide.model.Server;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.annotation.PostConstruct;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Service for managing server configurations for remote script execution.
 */
@Service
@SuppressWarnings("squid:S1192")
public class ServerService {
    private static final Logger LOGGER = LogManager.getLogger(ServerService.class);
    private static final String SERVER_FILE_EXTENSION = ".json";

    @Value("${support.servers.directory:results/servers}")
    private String serversDirectory;

    private final EncryptionService encryptionService;
    private final ObjectMapper objectMapper;
    private final List<Server> servers = new ArrayList<>();

    @Autowired
    public ServerService(EncryptionService encryptionService) {
        this.encryptionService = encryptionService;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    /**
     * Initialize the server service.
     * Creates the servers directory if it doesn't exist and loads existing server configurations.
     */
    @PostConstruct
    public void init() throws IOException {
        Path serversPath = Paths.get(serversDirectory);

        // Create servers directory if it doesn't exist
        if (!Files.exists(serversPath)) {
            Files.createDirectories(serversPath);
            LOGGER.info("Created servers directory: {}", serversPath);
        }

        // Load existing server configurations
        loadServers();
    }

    /**
     * Load all server configurations from disk.
     */
    public List<Server> loadServers() {
        servers.clear();
        Path serversPath = Paths.get(serversDirectory);

        try (Stream<Path> paths = Files.list(serversPath)) {
            paths.filter(path -> path.toString().endsWith(SERVER_FILE_EXTENSION))
                    .forEach(this::loadServer);
        } catch (IOException e) {
            LOGGER.error("Failed to load servers from {}", serversPath, e);
        }

        return new ArrayList<>(servers);
    }

    /**
     * Load a single server configuration from disk.
     */
    private void loadServer(Path path) {
        try {
            Server server = objectMapper.readValue(path.toFile(), Server.class);
            servers.add(server);
            LOGGER.debug("Loaded server configuration: {}", server.getName());
        } catch (IOException e) {
            LOGGER.error("Failed to load server configuration from {}", path, e);
        }
    }

    /**
     * Get all server configurations.
     */
    public List<Server> getAllServers() {
        return new ArrayList<>(servers);
    }

    /**
     * Get active server configurations.
     */
    public List<Server> getActiveServers() {
        return servers.stream()
                .filter(Server::isActive)
                .collect(Collectors.toList());
    }

    /**
     * Get a server configuration by ID.
     */
    public Optional<Server> getServerById(String id) {
        return servers.stream()
                .filter(server -> server.getId().equals(id))
                .findFirst();
    }

    /**
     * Create a new server configuration.
     */
    public Server createServer(Server server) {
        // Generate ID if not provided
        if (server.getId() == null || server.getId().isEmpty()) {
            server.setId(UUID.randomUUID().toString());
        }

        // Set timestamps
        LocalDateTime now = LocalDateTime.now();
        server.setCreatedAt(now);
        server.setUpdatedAt(now);

        // Encrypt password if provided
        final String pwd = server.getPassword();
        if (pwd != null && !pwd.isEmpty()) {
            server.setPassword(encryptionService.encrypt(pwd));
        }

        // Save to disk
        saveServer(server);

        // Add to in-memory list
        servers.add(server);

        return server;
    }

    /**
     * Update an existing server configuration.
     */
    public Optional<Server> updateServer(String id, Server updatedServer) {
        return getServerById(id).map(existingServer -> {
            // Update fields
            existingServer.setName(updatedServer.getName());
            existingServer.setHostname(updatedServer.getHostname());
            existingServer.setPort(updatedServer.getPort());
            existingServer.setUsername(updatedServer.getUsername());
            existingServer.setDescription(updatedServer.getDescription());
            existingServer.setToolLocation(updatedServer.getToolLocation());
            existingServer.setGrpcToken(updatedServer.getGrpcToken());
            existingServer.setActive(updatedServer.isActive());
            existingServer.setUpdatedAt(LocalDateTime.now());

            // Update password if provided
            if (updatedServer.getPassword() != null && !updatedServer.getPassword().isEmpty()) {
                existingServer.setPassword(encryptionService.encrypt(updatedServer.getPassword()));
            }

            // Save to disk
            saveServer(existingServer);

            return existingServer;
        });
    }

    /**
     * Delete a server configuration.
     */
    public boolean deleteServer(String id) {
        Optional<Server> serverOpt = getServerById(id);
        if (serverOpt.isPresent()) {
            Server server = serverOpt.get();

            // Remove from disk
            Path serverPath = Paths.get(serversDirectory, server.getId() + SERVER_FILE_EXTENSION);
            try {
                Files.deleteIfExists(serverPath);
            } catch (IOException e) {
                LOGGER.error("Failed to delete server file: {}", serverPath, e);
                return false;
            }

            // Remove from in-memory list
            servers.remove(server);

            return true;
        }
        return false;
    }

    /**
     * Save a server configuration to disk.
     */
    private void saveServer(Server server) {
        Path serverPath = Paths.get(serversDirectory, server.getId() + SERVER_FILE_EXTENSION);
        try {
            objectMapper.writeValue(serverPath.toFile(), server);
            LOGGER.debug("Saved server configuration: {}", server.getName());
        } catch (IOException e) {
            LOGGER.error("Failed to save server configuration: {}", server.getName(), e);
        }
    }

    /**
     * Persist the given server instance to disk.
     * Exposed for controllers/services that modify additional fields like systemInfo.
     */
    public void persistServer(Server server) {
        saveServer(server);
    }

    /**
     * Collects a common set of local system properties (works on Windows and Linux) using ProcessHelper.
     * Returned map is suitable for persisting into Server.systemInfo.
     */
    public Map<String, String> collectLocalSystemInfo() {
        final Map<String, String> info = new LinkedHashMap<>();
        // Tool location (where support-tool resides by default for this process)
        String toolLoc = Storage.toolPath() != null ? Storage.toolPath().toString() : ".";
        info.put("tool.location", Path.of(toolLoc).toAbsolutePath().toString());
        try {
            if (ProcessHelper.isWindows()) {
                collectWindowsInfo(info);
            } else if (ProcessHelper.isLinux()) {
                collectLinuxInfo(info);
            } else {
                // Fallback generic Java info
                info.put("os.name", System.getProperty("os.name"));
                info.put("os.arch", System.getProperty("os.arch"));
                info.put("available.processors", String.valueOf(Runtime.getRuntime().availableProcessors()));
                // Memory (generic)
                long totalMem = Runtime.getRuntime().maxMemory();
                if (totalMem > 0) {
                    info.put("memory.total.bytes", formatBytes(totalMem));
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to collect full system info: {}", e.getMessage(), e);
        }
        return info;
    }

    /**
     * Refreshes system info of the given server and persists it to disk.
     */
    public void saveSystemInfo(Server server) {
        Map<String, String> info = collectLocalSystemInfo();
        server.setSystemInfo(info);
        server.setUpdatedAt(LocalDateTime.now());
        persistServer(server);
    }

    private void collectWindowsInfo(Map<String, String> info) throws IOException {
        // Hostname
        info.put("hostname", execOneLine("hostname"));
        // IP address (first IPv4)
        String ipconfig = exec("ipconfig");
        String ip = extractFirstMatch(ipconfig, "IPv4 Address[ .:]*([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)");
        if (ip == null) {
            ip = extractFirstMatch(ipconfig, "IPv4[ .:]*([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)");
        }
        if (ip != null) info.put("ip.address", ip);
        // OS name and version
        String osName = exec("wmic os get Caption /value");
        String caption = extractFirstMatch(osName, "Caption=\\s*(.*)");
        if (caption != null) info.put("os.name", caption.trim());
        String osArch = exec("wmic os get OSArchitecture /value");
        String arch = extractFirstMatch(osArch, "OSArchitecture=\\s*(.*)");
        if (arch != null) info.put("os.arch", arch.trim());
        // CPU info
        String cpu = exec("wmic cpu get NumberOfCores,NumberOfLogicalProcessors /value");
        String cores = extractFirstMatch(cpu, "NumberOfCores=([0-9]+)");
        String threads = extractFirstMatch(cpu, "NumberOfLogicalProcessors=([0-9]+)");
        if (cores != null) info.put("cpu.cores", cores);
        if (threads != null) info.put("cpu.threads", threads);
        info.putIfAbsent("available.processors", String.valueOf(Runtime.getRuntime().availableProcessors()));
        // Memory
        String mem = exec("wmic computersystem get TotalPhysicalMemory /value");
        String totalMem = extractFirstMatch(mem, "TotalPhysicalMemory=([0-9]+)");
        if (totalMem != null) info.put("memory.total.bytes", totalMem);
        // User
        info.put("user.name", System.getProperty("user.name"));
    }

    private void collectLinuxInfo(Map<String, String> info) throws IOException {
        // Hostname
        info.put("hostname", execOneLine("hostname"));
        // IP address (first from hostname -I)
        String ips = execOneLine("hostname -I");
        if (ips != null && !ips.isEmpty()) {
            String firstIp = ips.trim().split("\\s+")[0];
            info.put("ip.address", firstIp);
        }
        // OS name/version
        String osRelease = exec("cat /etc/os-release");
        String pretty = extractFirstMatch(osRelease, "PRETTY_NAME=\"?(.*?)\"?(?:\n|$)");
        if (pretty != null) info.put("os.name", pretty);
        // Arch
        info.put("os.arch", execOneLine("uname -m"));
        // CPU
        String nproc = execOneLine("nproc");
        if (nproc != null) info.put("cpu.cores", nproc);
        info.putIfAbsent("available.processors", String.valueOf(Runtime.getRuntime().availableProcessors()));
        // Memory
        String memInfo = exec("cat /proc/meminfo");
        String memKb = extractFirstMatch(memInfo, "MemTotal:\\s+([0-9]+)\\s+kB");
        if (memKb != null) {
            try {
                long kb = Long.parseLong(memKb);
                info.put("memory.total.bytes", String.valueOf(kb * 1024));
            } catch (NumberFormatException ignore) { /* noop */ }
        }
        // User
        info.put("user.name", System.getProperty("user.name"));
    }

    private String exec(String command) throws IOException {
        ProcessHelper.Result r = new ProcessHelper(command).withLoggingObserver().withBash().executeAndGetResult();
        if (r.getRc() == 0) {
            return r.getOutput();
        }
        LOGGER.debug("Command '{}' failed with rc {}", command, r.getRc());
        return "";
    }

    private String execOneLine(String command) throws IOException {
        String out = exec(command);
        if (out == null) return null;
        String trimmed = out.trim();
        int nl = trimmed.indexOf('\n');
        return nl >= 0 ? trimmed.substring(0, nl).trim() : trimmed;
    }

    private String extractFirstMatch(String text, String regex) {
        if (text == null) return null;
        Pattern p = Pattern.compile(regex, Pattern.MULTILINE);
        Matcher m = p.matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        return null;
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        final String[] units = {"KB", "MB", "GB", "TB", "PB", "EB"};
        double value = bytes;
        int unitIndex = -1;
        while (value >= 1024 && unitIndex < units.length - 1) {
            value /= 1024.0;
            unitIndex++;
        }
        if (unitIndex < 0) {
            return bytes + " B";
        }
        return String.format(java.util.Locale.US, "%.2f %s", value, units[unitIndex]);
    }

    /**
     * Get the decrypted password for a server.
     */
    public String getDecryptedPassword(Server server) {
        final String pwd = server.getPassword();
        if (pwd == null || pwd.isEmpty()) {
            return null;
        }
        return encryptionService.decrypt(pwd);
    }

    /**
     * Get the server configuration directory path.
     */
    public String getServersDirectory() {
        return serversDirectory;
    }

    /**
     * Get the server configuration directory path.
     */
    public Path serversDirectoryPath() {
        return Paths.get(serversDirectory);
    }
    public Path serversImagePath() {
        return Storage.toolPath().resolve("results").resolve("image");
    }

    private static String sanitizeFilename(String input) {
        if (input == null || input.isEmpty()) return "server";
        return input.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
    public String serverToolImageFileName(Server server) {
        return "support-tool-" + sanitizeFilename(server.getHostname()) + ".zip";
    }

    public String remoteImageFolderPath(Server server) {
        final String toolLocation = server.getToolLocation();
        return (toolLocation.endsWith("/") ? toolLocation : toolLocation + "/") + "results/image";
    }
    public String remoteImageFilePath(Server server) {
        return remoteImageFolderPath(server) + "/" + serverToolImageFileName(server);
    }
    public Path checkCreateServerImage(Server server, String sessionId, ProgressCallback progressCallback) throws IOException {
        Path serverImagePath = serversImagePath().resolve(serverToolImageFileName(server));
        final File file = serverImagePath.toFile();
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            serverImagePath = Files.createFile(serverImagePath);
            try (final OutputStream outputStream = Files.newOutputStream(serverImagePath)) {
                GrpcAgentBundle.of(server, progressCallback).toStreamingBody(sessionId).writeTo(outputStream);
            }
        }
        return serverImagePath;
    }
}
