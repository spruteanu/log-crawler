package com.edifecs.support.ide.config;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.resource.ResourceTransformer;
import org.springframework.web.servlet.resource.ResourceTransformerChain;
import org.springframework.web.servlet.resource.ResourceTransformerSupport;
import org.springframework.web.servlet.resource.TransformedResource;
import org.springframework.web.servlet.resource.ResourceResolverChain;
import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Injects a small script tag into the served index.html of the SPA under /support-ide/**
 * to render a Settings button without modifying the Angular bundle.
 */
public class IndexHtmlInjectionTransformer extends ResourceTransformerSupport {

    private static final byte[] INJECT_SNIPPET = ("\n<!-- injected by Support IDE -->\n" +
            "<script src=\"js/ide-inject.js\"></script>\n").getBytes(StandardCharsets.UTF_8);

    private boolean isInjectionEnabled() {
        String prop = System.getProperty("support.ide.inject.enabled", "false");
        return "true".equalsIgnoreCase(prop);
    }

    @Override
    public Resource transform(HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain) throws IOException {
        Resource transformed = transformerChain.transform(request, resource);
        if (!isInjectionEnabled()) {
            return transformed; // Do not inject legacy script; Angular app handles menu
        }
        String requestPath = request != null ? request.getRequestURI() : "";
        // Only inject into index.html under /support-ide path
        if (requestPath != null && requestPath.startsWith("/support-ide") && isIndexHtml(transformed)) {
            byte[] bytes = transformed.getInputStream().readAllBytes();
            String content = new String(bytes, StandardCharsets.UTF_8);
            int idx = content.lastIndexOf("</body>");
            if (idx >= 0 && content.indexOf("/js/ide-inject.js") == -1) {
                String updated = content.substring(0, idx) + new String(INJECT_SNIPPET, StandardCharsets.UTF_8) + content.substring(idx);
                return new TransformedResource(transformed, updated.getBytes(StandardCharsets.UTF_8));
            }
        }
        return transformed;
    }

    private boolean isIndexHtml(Resource resource) {
        try {
            String filename = resource.getFilename();
            if (filename == null) return false;
            return filename.equalsIgnoreCase("index.html");
        } catch (Exception e) {
            return false;
        }
    }
}
