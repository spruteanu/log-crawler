package com.edifecs.support.ide.config;

import com.edifecs.support.ide.service.CustomUserDetailsService;
import com.edifecs.support.ide.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@Profile("ide")
public class SecurityConfig {

    // KEEP THIS BEAN
    @Bean
    public UserDetailsService userDetailsService(UserService userService) {
        return new CustomUserDetailsService(userService);
    }

    // KEEP THIS BEAN
    @Bean
    public PasswordEncoder passwordEncoder(com.edifecs.support.ide.service.PasswordService passwordService) {
        // ... implementation is unchanged
        return new PasswordEncoder() {
            @Override
            public String encode(CharSequence rawPassword) {
                return rawPassword == null ? null : rawPassword.toString();
            }

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                if (rawPassword == null || encodedPassword == null) return false;
                int idx = encodedPassword.indexOf(':');
                if (idx <= 0) return false;
                String salt = encodedPassword.substring(0, idx);
                String hash = encodedPassword.substring(idx + 1);
                return passwordService.matches(rawPassword.toString(), salt, hash);
            }
        };
    }

    // KEEP THIS BEAN
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    // KEEP THIS BEAN
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // ... implementation is unchanged
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login", "/assets/**", "/css/**", "/js/**", "/images/**").permitAll()
                        // Allow anyone authenticated to get their own info
                        .requestMatchers("/api/users/me").authenticated()
                        // All other user management endpoints require ADMIN
                        .requestMatchers("/api/users/**").hasRole("ADMIN")
                        .requestMatchers("/api/**").authenticated()
                        .anyRequest().permitAll()
                )
                .exceptionHandling(ex -> ex
                        .defaultAuthenticationEntryPointFor(
                                (request, response, authException) -> response.sendError(401),
                                new org.springframework.security.web.util.matcher.AntPathRequestMatcher("/api/**")
                        )
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/", true)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/api/logout")
                        .logoutSuccessHandler((request, response, authentication) -> {
                            response.setStatus(200);
                        })
                );
        return http.build();
    }
}
