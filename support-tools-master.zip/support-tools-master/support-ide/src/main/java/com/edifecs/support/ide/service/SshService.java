/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.ide.model.Server;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.channel.ChannelExec;
import org.apache.sshd.client.channel.ClientChannelEvent;
import org.apache.sshd.client.keyverifier.AcceptAllServerKeyVerifier;
import org.apache.sshd.client.session.ClientSession;
import org.apache.sshd.scp.client.ScpClient;
import org.apache.sshd.scp.client.ScpClientCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Service for SSH connectivity and remote script execution.
 */
@Service
@SuppressWarnings("squid:S1192")
public class SshService {
    private static class Connection {
        final SshClient client;
        final ClientSession session;

        Connection(SshClient client, ClientSession session) {
            this.client = client;
            this.session = session;
        }
    }

    private static final Logger LOGGER = LogManager.getLogger(SshService.class);
    private static final int DEFAULT_TIMEOUT = 60000; // 60 seconds

    private final ServerService serverService;

    @Autowired
    public SshService(ServerService serverService) {
        this.serverService = serverService;
    }

    private static void close(Server server, Connection conn) {
        if (conn == null) return;
        try {
            if (conn.session != null && conn.session.isOpen()) {
                conn.session.close();
            }
        } catch (IOException e) {
            LOGGER.error("Failed to close SSH session for server: {}", server.getName(), e);
        } finally {
            try {
                if (conn.client != null) {
                    conn.client.stop();
                }
            } catch (Exception e) {
                LOGGER.error("Failed to stop SSH client for server: {}", server.getName(), e);
            }
        }
    }

    /**
     * Execute a script on a remote server.
     *
     * @param server        The server to connect to
     * @param scriptContent The script content to execute
     * @param args          The script arguments
     * @return A map containing the execution result
     */
    public Map<String, Object> executeScript(Server server, String scriptContent, String[] args) {
        Map<String, Object> result = new HashMap<>();
        Connection conn = null;

        try {
            // Connect to the server
            conn = connectToServer(server);

            // Create a temporary script file
            Path tempScriptFile = createTempScriptFile(scriptContent);

            // Upload the script to the remote server
            String remoteScriptPath = uploadScript(conn.session, tempScriptFile);

            // Make the script executable
            makeScriptExecutable(conn.session, remoteScriptPath);

            // Execute the script
            String output = executeRemoteScript(conn.session, remoteScriptPath, args);

            // Clean up the remote script
            cleanupRemoteScript(conn.session, remoteScriptPath);

            // Delete the local temp file
            Files.deleteIfExists(tempScriptFile);

            // Set the result
            result.put("success", true);
            result.put("output", output);
            result.put("result", output);

        } catch (Exception e) {
            LOGGER.error("Failed to execute script on remote server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
            result.put("stackTrace", e.getStackTrace());
        } finally {
            close(server, conn);
        }

        return result;
    }

    /**
     * Collect system information from a remote server over SSH.
     * Returns a map of key-value pairs with important system attributes.
     */
    @SuppressWarnings({"squid:S3776", "squid:S5850"})
    public Map<String, String> collectSystemInfo(Server server) {
        Map<String, String> info = new HashMap<>();
        Connection conn = null;
        try {
            conn = connectToServer(server);

            // Try Linux/Unix first
            String hostname = safeExec(conn.session, "hostname").trim();
            String uname = safeExec(conn.session, "uname -a").trim();
            info.put("system.hostname", hostname);
            info.put("system.uname", uname);

            String osRelease = safeExec(conn.session, "cat /etc/os-release");
            boolean linuxDetected = !uname.isEmpty() || !osRelease.isEmpty();

            if (linuxDetected) {
                if (osRelease.isEmpty()) {
                    String lsb = safeExec(conn.session, "lsb_release -ds").trim();
                    if (!lsb.isEmpty()) info.put("system.os.name", lsb);
                } else {
                    String[] lines = osRelease.split("\n");
                    for (String line : lines) {
                        int idx = line.indexOf('=');
                        if (idx > 0) {
                            String key = line.substring(0, idx).trim();
                            String val = line.substring(idx + 1).trim();
                            val = val.replaceAll("^\"|\"$", "");
                            if ("NAME".equals(key)) info.put("system.os.name", val);
                            if ("VERSION".equals(key)) info.put("system.os.version", val);
                            if ("ID".equals(key)) info.put("system.os.id", val);
                        }
                    }
                }

                info.put("system.user", safeExec(conn.session, "whoami").trim());
                String uptime = safeExec(conn.session, "uptime -p || uptime").trim();
                if (!uptime.isEmpty()) info.put("system.uptime", uptime);

                String cores = safeExec(conn.session, "nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || echo").trim();
                if (!cores.isEmpty()) info.put("system.cpu.cores", cores);
                String cpuModel = safeExec(conn.session, "(lscpu 2>/dev/null | grep -i 'Model name' | sed 's/.*: *//') || (cat /proc/cpuinfo 2>/dev/null | grep -m1 'model name' | sed 's/.*: *//')").trim();
                if (!cpuModel.isEmpty()) info.put("system.cpu.model", cpuModel);
                String arch = safeExec(conn.session, "(lscpu 2>/dev/null | grep -i 'Architecture' | sed 's/.*: *//') || uname -m").trim();
                if (!arch.isEmpty()) info.put("system.arch", arch);

                String freeOut = safeExec(conn.session, "free -m 2>/dev/null");
                if (!freeOut.isEmpty()) {
                    String[] lines = freeOut.split("\n");
                    for (String line : lines) {
                        if (line.toLowerCase().startsWith("mem:")) {
                            String[] parts = line.trim().split("\\s+");
                            if (parts.length >= 4) {
                                info.put("system.mem.total.mb", parts[1]);
                                info.put("system.mem.used.mb", parts[2]);
                                info.put("system.mem.free.mb", parts[3]);
                            }
                            break;
                        }
                    }
                }

                String dfOut = safeExec(conn.session, "df -h / 2>/dev/null");
                if (!dfOut.isEmpty()) {
                    String[] lines = dfOut.split("\n");
                    if (lines.length >= 2) {
                        String[] parts = lines[1].trim().split("\\s+");
                        if (parts.length >= 6) {
                            info.put("system.disk.root.size", parts[1]);
                            info.put("system.disk.root.used", parts[2]);
                            info.put("system.disk.root.avail", parts[3]);
                            info.put("system.disk.root.use%", parts[4]);
                            info.put("system.disk.root.mount", parts[5]);
                        }
                    }
                }
            } else {
                // Assume Windows box; prefer PowerShell for richer info
                String ps = "powershell -NoProfile -NonInteractive -Command ";

                // Hostname
                String whost = safeExec(conn.session, ps + "[System.Net.Dns]::GetHostName()\n").trim();
                if (!whost.isEmpty()) info.put("system.hostname", whost);
                info.put("system.os.platform", "windows");

                // OS name and version
                String wosName = safeExec(conn.session, ps + "(Get-CimInstance Win32_OperatingSystem | Select-Object -ExpandProperty Caption)").trim();
                String wosVer = safeExec(conn.session, ps + "(Get-CimInstance Win32_OperatingSystem | Select-Object -ExpandProperty Version)").trim();
                if (!wosName.isEmpty()) info.put("system.os.name", wosName);
                if (!wosVer.isEmpty()) info.put("system.os.version", wosVer);

                // Architecture
                String warch = safeExec(conn.session, ps + "$env:PROCESSOR_ARCHITECTURE").trim();
                if (!warch.isEmpty()) info.put("system.arch", warch);

                // CPU
                String wcores = safeExec(conn.session, ps + "(Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors").trim();
                if (!wcores.isEmpty()) info.put("system.cpu.cores", wcores);
                String wcpuModel = safeExec(conn.session, ps + "(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name)").trim();
                if (!wcpuModel.isEmpty()) info.put("system.cpu.model", wcpuModel);

                // Memory MB
                String wmemTotal = safeExec(conn.session, ps + "[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1MB)").trim();
                String wmemFreeKB = safeExec(conn.session, ps + "(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory)").trim();
                if (!wmemTotal.isEmpty()) info.put("system.mem.total.mb", wmemTotal);
                if (!wmemFreeKB.isEmpty()) {
                    try {
                        long kb = Long.parseLong(wmemFreeKB.replaceAll("[^0-9]", ""));
                        info.put("system.mem.free.mb", String.valueOf(kb / 1024));
                    } catch (NumberFormatException ignore) { /*noop*/ }
                }

                // Disk C: (GB)
                String wdiskSize = safeExec(conn.session, ps + "[math]::Round(((Get-CimInstance Win32_LogicalDisk -Filter \"DeviceID='C:'\").Size)/1GB,2)").trim();
                String wdiskFree = safeExec(conn.session, ps + "[math]::Round(((Get-CimInstance Win32_LogicalDisk -Filter \"DeviceID='C:'\").FreeSpace)/1GB,2)").trim();
                if (!wdiskSize.isEmpty()) info.put("system.disk.c.size.gb", wdiskSize);
                if (!wdiskFree.isEmpty()) info.put("system.disk.c.free.gb", wdiskFree);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to collect some system info from server {}: {}", server.getName(), e.getMessage());
        } finally {
            close(server, conn);
        }
        return info;
    }

    private String safeExec(ClientSession session, String command) {
        try {
            return executeCommand(session, command);
        } catch (IOException e) {
            return "";
        }
    }

    /**
     * Execute a command on the remote server and return the output.
     *
     * @param session The SSH session
     * @param command The command to execute
     * @return The command output
     */
    private String executeCommand(ClientSession session, String command) throws IOException {
        LOGGER.debug("Executing command: {}", command);
        try (ChannelExec channel = session.createExecChannel(command)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            channel.setOut(out);
            channel.setErr(err);
            channel.open().verify(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS);
            channel.waitFor(EnumSet.of(ClientChannelEvent.CLOSED, ClientChannelEvent.EOF, ClientChannelEvent.EXIT_STATUS), DEFAULT_TIMEOUT);
            Integer code = channel.getExitStatus();
            String output = out.toString(StandardCharsets.UTF_8);
            String error = err.toString(StandardCharsets.UTF_8);
            if (code != null && code != 0) {
                throw new IOException("Command failed with exit status " + code + ". Error: " + error + ". Output: " + output);
            }
            return output;
        }
    }

    /**
     * Clean up a remote file.
     *
     * @param session        The SSH session
     * @param remoteFilePath The path to the remote file to delete
     */
    void cleanupRemoteFile(ClientSession session, String remoteFilePath) {
        try {
            executeCommand(session, "rm -f " + remoteFilePath);
            LOGGER.info("Cleaned up remote file: {}", remoteFilePath);
        } catch (IOException e) {
            LOGGER.warn("Failed to cleanup remote file: {}. Error: {}", remoteFilePath, e.getMessage());
        }
    }

    /**
     * Connect to a server using SSH.
     *
     * @param server The server to connect to
     * @return An SSHClient instance
     */
    private Connection connectToServer(Server server) throws IOException {
        SshClient client = SshClient.setUpDefaultClient();
        client.setServerKeyVerifier(AcceptAllServerKeyVerifier.INSTANCE);
        client.start();

        var connect = client.connect(server.getUsername(), server.getHostname(), server.getPort());
        connect.verify(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS);
        ClientSession session = connect.getSession();

        String password = serverService.getDecryptedPassword(server);
        session.addPasswordIdentity(password);
        session.auth().verify(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS);

        return new Connection(client, session);
    }

    /**
     * Create a temporary script file.
     *
     * @param scriptContent The script content
     * @return The path to the temporary script file
     */
    private Path createTempScriptFile(String scriptContent) throws IOException {
        Path tempFile = Files.createTempFile("script_", ".sh");
        Files.write(tempFile, scriptContent.getBytes(StandardCharsets.UTF_8));
        return tempFile;
    }

    /**
     * Upload a script to the remote server.
     *
     * @param session    The SSH session
     * @param scriptFile The local script file
     * @return The path to the remote script file
     */
    private String uploadScript(ClientSession session, Path scriptFile) throws IOException {
        String remoteScriptPath = "/tmp/script_" + System.currentTimeMillis() + ".sh";
        ScpClient scp = ScpClientCreator.instance().createScpClient(session);
        scp.upload(scriptFile.toString(), remoteScriptPath);
        return remoteScriptPath;
    }

    /**
     * Make a script executable on the remote server.
     *
     * @param session          The SSH session
     * @param remoteScriptPath The path to the remote script file
     */
    private void makeScriptExecutable(ClientSession session, String remoteScriptPath) throws IOException {
        executeCommand(session, "chmod +x " + remoteScriptPath);
    }

    /**
     * Execute a script on the remote server.
     *
     * @param session          The SSH session
     * @param remoteScriptPath The path to the remote script file
     * @param args             The script arguments
     * @return The script output
     */
    private String executeRemoteScript(ClientSession session, String remoteScriptPath, String[] args) throws IOException {
        StringBuilder commandBuilder = new StringBuilder(remoteScriptPath);
        if (args != null && args.length > 0) {
            for (String arg : args) {
                commandBuilder.append(" ").append(escapeArgument(arg));
            }
        }
        return executeCommand(session, commandBuilder.toString());
    }

    /**
     * Clean up the remote script file.
     *
     * @param session          The SSH session
     * @param remoteScriptPath The path to the remote script file
     */
    private void cleanupRemoteScript(ClientSession session, String remoteScriptPath) {
        try {
            executeCommand(session, "rm -f " + remoteScriptPath);
        } catch (IOException e) {
            LOGGER.warn("Failed to clean up remote script: {}", remoteScriptPath, e);
        }
    }

    /**
     * Escape a command argument for shell execution.
     *
     * @param arg The argument to escape
     * @return The escaped argument
     */
    private String escapeArgument(String arg) {
        if (arg == null) {
            return "\"\"";
        }

        // Replace " with \"
        arg = arg.replace("\"", "\\\"");

        // Wrap in quotes
        return "\"" + arg + "\"";
    }

    private boolean isWindows(ClientSession session) {
        boolean isWindows;
        try {
            String uname = executeCommand(session, "uname").toLowerCase();
            isWindows = uname.isBlank();
        } catch (Exception ex) {
            isWindows = true;
        }
        return isWindows;
    }

    private void checkCreateDirectory(String remoteDir, String sessionId, ProgressCallback progressCallback, boolean isWindows, ClientSession session) throws IOException {
        if (isWindows) {
            String psMkDir = "powershell -Command \"New-Item -ItemType Directory -Force -Path '" + remoteDir.replace("'", "''") + "'\"";
            executeCommand(session, psMkDir);
        } else {
            executeCommand(session, "mkdir -p " + remoteDir);
        }
        progressCallback.sendProgress(sessionId, "progress", "Remote directory prepared...");
    }

    /**
     * Deploy a gRPC agent bundle to a remote server using streaming approach to control memory consumption.
     * Re-uses the logic from download bundle method but deploys to remote server instead of downloading.
     * Steps:
     * - connect via SSH
     * - ensure remoteDir exists
     * - create bundle using streaming approach (like downloadServerBundle)
     * - upload the zip as remoteZipPath
     * - unzip into remoteDir
     * - cleanup uploaded zip
     * Returns a result map with success flag, stdout, and details.
     */
    public Map<String, Object> deployAgent(Server server, String sessionId, ProgressCallback progressCallback) {
        Map<String, Object> result = new LinkedHashMap<>();
        Connection conn = null;
        try {
            progressCallback.sendProgress(sessionId, "progress", "Connecting to remote server...");
            conn = connectToServer(server);
            boolean isWindows = isWindows(conn.session);
            final String remoteToolLocation = server.getToolLocation();
            final String remoteToolImage = serverService.remoteImageFolderPath(server);
            final String remoteImageFilePath = serverService.remoteImageFilePath(server);
            checkCreateDirectory(remoteToolImage, sessionId, progressCallback, isWindows, conn.session);

            final Path serverImagePath = serverService.checkCreateServerImage(server, sessionId, progressCallback);
            progressCallback.sendProgress(sessionId, "progress", "Uploading bundle to remote server...");

            ScpClient scp = ScpClientCreator.instance().createScpClient(conn.session);
            scp.upload(serverImagePath.toString(), remoteImageFilePath);
            progressCallback.sendProgress(sessionId, "progress", "Extracting bundle on remote server...");

            final String unzipOutput = unzipRemoteFile(conn.session, isWindows,
                    "powershell -Command \"Expand-Archive -Path '" + remoteImageFilePath.replace("'", "''") +
                            "' -DestinationPath '" + remoteToolLocation.replace("'", "''") + "' -Force\"",
                    "cd " + remoteToolLocation + " && unzip -o " + remoteImageFilePath);

            progressCallback.sendProgress(sessionId, "progress", "Cleaning up temporary files...");

            result.put("success", true);
            result.put("remoteDir", server.getToolLocation());
            result.put("unzipOutput", unzipOutput);
            result.put("remoteZipPath", remoteImageFilePath);
            result.put("isWindows", isWindows);
        } catch (Exception e) {
            LOGGER.error("Failed to deploy gRPC agent bundle to remote server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
        } finally {
            close(server, conn);
        }
        return result;
    }

    private String unzipRemoteFile(ClientSession session, boolean isWindows, String windowsCommand, String linuxCommand) throws IOException {
        return executeCommand(session, isWindows ? windowsCommand : linuxCommand);
    }

    /**
     * Start the gRPC agent on the remote server using the generated start script.
     * Will attempt Linux or Windows command based on the provided flag.
     * Returns a map with success, output, and error if any.
     */
    public Map<String, Object> startAgent(Server server, String toolLocation, boolean isWindows) {
        Map<String, Object> result = new HashMap<>();
        Connection conn = null;
        try {
            conn = connectToServer(server);
            final String output = unzipRemoteFile(conn.session, isWindows,
                    "powershell -Command \"$ErrorActionPreference='Stop'; Set-Location -Path '" + toolLocation.replace("'", "''") + "'; if (Test-Path './start-agent.cmd') { Start-Process -FilePath 'cmd.exe' -ArgumentList '/c start-agent.cmd' -WindowStyle Hidden } else { throw 'start-agent.cmd not found' }\"",
                    "bash -lc 'cd " + toolLocation + " && chmod +x ./start-agent.sh 2>/dev/null || true && nohup ./start-agent.sh >/dev/null 2>&1 & disown'");
            result.put("success", true);
            result.put("output", output);
        } catch (Exception e) {
            LOGGER.error("Failed to start agent on remote server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
        } finally {
            close(server, conn);
        }
        return result;
    }

}
