/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.Support;
import com.edifecs.support.collect.InformationContext;
import com.edifecs.support.ide.grpc.*;
import com.edifecs.support.scripts.Metadata;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * GrpcAgentService acts as a gRPC agent on the remote side and is responsible for:
 * - Performing connectivity tests physically on the remote box
 * - Performing selected script execution physically on the remote box
 * - Starting/stopping the gRPC server that listens for requests from GrpcServer
 */
@SuppressWarnings({"squid:S2629", "squid:S1066"})
@Service
public class GrpcAgentService extends ScriptExecutionServiceGrpc.ScriptExecutionServiceImplBase {

    private static final Logger LOGGER = LogManager.getLogger(GrpcAgentService.class);
    private static final String DEFAULT_TOOL_LOCATION = "/tmp";

    private Server server;
    private final String authToken;
    private final String toolLocation;
    private int port = GrpcServer.DEFAULT_PORT;

    public GrpcAgentService() {
        this(null, DEFAULT_TOOL_LOCATION);
    }

    public GrpcAgentService(String authToken, String toolLocation) {
        this.authToken = authToken;
        this.toolLocation = toolLocation != null ? toolLocation : DEFAULT_TOOL_LOCATION;
    }

    /**
     * Start the gRPC agent server.
     */
    public void start() throws IOException {
        start(port);
    }

    /**
     * Start the gRPC agent server on the specified port.
     */
    public void start(int port) throws IOException {
        this.port = port;

        server = ServerBuilder.forPort(port)
                .addService(this)
                .build()
                .start();

        LOGGER.info("gRPC Agent Service started on port {}", port);
        LOGGER.info("Tool location: {}", toolLocation);
        LOGGER.info("Authentication: {}", authToken != null && !authToken.isEmpty() ? "Enabled" : "Disabled");

        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("Shutting down gRPC agent server...");
            try {
                GrpcAgentService.this.stop();
            } catch (InterruptedException e) {
                LOGGER.error("Error during shutdown", e);
                Thread.currentThread().interrupt();
            }
        }));
    }

    /**
     * Stop the gRPC agent server.
     */
    public void stop() throws InterruptedException {
        if (server != null) {
            server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
            LOGGER.info("gRPC agent server stopped");
        }
    }

    /**
     * Block until the server shuts down.
     */
    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }

    /**
     * Check if the server is running.
     */
    public boolean isRunning() {
        return server != null && !server.isShutdown();
    }


    @SuppressWarnings({"squid:S3776", "squid:S1066"})
    @Override
    public void executeScript(ExecuteScriptRequest request, StreamObserver<ExecuteScriptResponse> responseObserver) {
        LOGGER.info("Received executeScript request");

        ExecuteScriptResponse.Builder responseBuilder = ExecuteScriptResponse.newBuilder();

        try {
            // Validate auth token if configured
            if (authToken != null && !authToken.isEmpty()) {
                if (!authToken.equals(request.getAuthToken())) {
                    responseBuilder.setSuccess(false)
                            .setError("Authentication failed");
                    responseObserver.onNext(responseBuilder.build());
                    responseObserver.onCompleted();
                    return;
                }
            }

            // Create metadata based on whether script name or content is provided
            Metadata metadata;
            if (!request.getScriptName().isEmpty()) {
                // Script name provided - create metadata from script name
                LOGGER.info("Executing script by name: {}", request.getScriptName());
                metadata = createMetadataFromScript(request.getScriptName());
            } else if (!request.getScriptContent().isEmpty()) {
                // Script content provided - create metadata from content
                LOGGER.info("Executing script from content");
                metadata = createMetadataFromContent(request.getScriptContent());
            } else {
                responseBuilder.setSuccess(false)
                        .setError("Neither script name nor script content provided");
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            String[] args = request.getArgsList().toArray(new String[0]);

            // Execute using Support facade with metadata and arguments
            InformationContext context = (InformationContext) Support.execute(metadata, args);

            String output = context.getDestination() != null ?
                    "Script executed successfully. Results saved to: " + context.getDestination() :
                    "Script executed successfully.";

            responseBuilder.setSuccess(true).setOutput(output);

            // Add destination if available
            if (context.getDestination() != null) {
                responseBuilder.setDestination(context.getDestination());
            }

            // Extract InformationContext values and add to result map
            Map<String, Object> contextValues = context.values();
            if (contextValues != null && !contextValues.isEmpty()) {
                for (Map.Entry<String, Object> entry : contextValues.entrySet()) {
                    String key = entry.getKey();
                    Object value = entry.getValue();

                    if (value == null) {
                        responseBuilder.putResult(key, "null");
                    } else if (value instanceof java.io.File) {
                        // Handle file objects - copy file if it exists and add path to result
                        java.io.File file = (java.io.File) value;
                        if (file.exists() && file.isFile()) {
                            String copiedFilePath = copyFileToResults(file, context.getDestination());
                            responseBuilder.putResult(key, copiedFilePath != null ? copiedFilePath : file.getAbsolutePath());
                        } else {
                            responseBuilder.putResult(key, file.getAbsolutePath());
                        }
                    } else if (value instanceof String && isFilePath((String) value)) {
                        // Handle string values that represent file paths
                        java.io.File file = new java.io.File((String) value);
                        if (file.exists() && file.isFile()) {
                            String copiedFilePath = copyFileToResults(file, context.getDestination());
                            responseBuilder.putResult(key, copiedFilePath != null ? copiedFilePath : (String) value);
                        } else {
                            responseBuilder.putResult(key, (String) value);
                        }
                    } else {
                        // Handle other types by converting to string
                        responseBuilder.putResult(key, value.toString());
                    }
                }
            }

        } catch (Exception e) {
            LOGGER.error("Error executing script", e);
            responseBuilder.setSuccess(false)
                    .setError("Execution failed: " + e.getMessage());
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public void testConnection(TestConnectionRequest request, StreamObserver<TestConnectionResponse> responseObserver) {
        LOGGER.info("Received testConnection request");

        TestConnectionResponse.Builder responseBuilder = TestConnectionResponse.newBuilder();

        try {
            // Validate auth token if configured
            if (authToken != null && !authToken.isEmpty()) {
                if (!authToken.equals(request.getAuthToken())) {
                    responseBuilder.setSuccess(false)
                            .setError("Authentication failed");
                    responseObserver.onNext(responseBuilder.build());
                    responseObserver.onCompleted();
                    return;
                }
            }

            // Perform connectivity test
            responseBuilder.setSuccess(true)
                    .setMessage("Connection test successful from gRPC Agent Service");

        } catch (Exception e) {
            LOGGER.error("Error during connection test", e);
            responseBuilder.setSuccess(false)
                    .setError("Connection test failed: " + e.getMessage());
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    /**
     * Execute script using script-runner.sh in the extracted tool directory.
     */
    String executeScript(String scriptName, String[] args) {
        final InformationContext context = new InformationContext();
        context.script(scriptName);

        Support.execute(context, args);
        return null;
    }

    /**
     * Create Metadata object from script name for serialization on remote side.
     */
    private Metadata createMetadataFromScript(String scriptName) {
        // Create metadata and populate with script information
        Metadata metadata = new Metadata();
        metadata.setName(scriptName);

        // Try to lookup the script metadata from the system
        try {
            Metadata foundMetadata = Metadata.get(scriptName);
            if (foundMetadata != null) {
                return foundMetadata;
            }
        } catch (Exception e) {
            LOGGER.debug("Could not find metadata for script: {}, creating basic metadata", scriptName);
        }

        // If not found, create basic metadata with script name
        metadata.setName(scriptName);
        metadata.setType("groovy"); // Default type
        return metadata;
    }

    /**
     * Create Metadata object from script content for serialization on remote side.
     */
    private Metadata createMetadataFromContent(String scriptContent) {
        // Create metadata and populate with script content
        Metadata metadata = new Metadata();
        metadata.setContent(scriptContent);
        metadata.setType("groovy"); // Default type for script content
        metadata.setName("dynamic-script"); // Default name for content-based scripts
        return metadata;
    }

    /**
     * Copy file from remote server to results folder in the destination.
     */
    private String copyFileToResults(java.io.File sourceFile, String destination) {
        if (sourceFile == null || !sourceFile.exists() || !sourceFile.isFile()) {
            return null;
        }

        try {
            // Create results folder if destination is available
            if (destination != null && !destination.isEmpty()) {
                java.nio.file.Path destPath = java.nio.file.Paths.get(destination);
                java.nio.file.Path resultsDir = destPath.resolve("results");
                java.nio.file.Files.createDirectories(resultsDir);

                // Copy file to results folder
                java.nio.file.Path targetFile = resultsDir.resolve(sourceFile.getName());
                java.nio.file.Files.copy(sourceFile.toPath(), targetFile,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);

                LOGGER.info("Copied file {} to {}", sourceFile.getAbsolutePath(), targetFile);
                return targetFile.toString();
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to copy file {} to results folder: {}", sourceFile.getAbsolutePath(), e.getMessage());
        }

        return null;
    }

    /**
     * Check if a string value represents a file path.
     */
    private boolean isFilePath(String value) {
        if (value == null || value.trim().isEmpty()) {
            return false;
        }

        // Check for common file path patterns
        return value.contains("/") || value.contains("\\") ||
                value.endsWith(".log") || value.endsWith(".txt") ||
                value.endsWith(".xml") || value.endsWith(".json") ||
                value.endsWith(".csv") || value.endsWith(".properties") ||
                value.matches(".*\\.[a-zA-Z]{2,4}$"); // ends with file extension
    }

    /**
     * Escape shell arguments to prevent injection attacks.
     */
    String escapeArgument(String arg) {
        if (arg == null) {
            return "";
        }
        // Simple escaping - wrap in single quotes and escape any single quotes
        return "'" + arg.replace("'", "'\"'\"'") + "'";
    }
}
