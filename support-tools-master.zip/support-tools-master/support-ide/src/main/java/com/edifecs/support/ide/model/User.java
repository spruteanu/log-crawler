package com.edifecs.support.ide.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Simple user model for Support IDE authentication/authorization.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {
    private String username;
    private String passwordHash;
    private String salt;
    private Set<String> roles = new HashSet<>();
    private boolean enabled = true;
    private String firstName;
    private String lastName;
    /**
     * Optional primary/selected role of the user for UI preferences.
     */
    private String selectedRole;

    public User() {}

    public User(String username, String passwordHash, String salt, Set<String> roles, boolean enabled) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.salt = salt;
        if (roles != null) this.roles = new HashSet<>(roles);
        this.enabled = enabled;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles != null ? new HashSet<>(roles) : new HashSet<>();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isAdmin() {
        return roles != null && roles.contains("ADMIN");
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSelectedRole() {
        return selectedRole;
    }

    public void setSelectedRole(String selectedRole) {
        this.selectedRole = selectedRole;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(username, user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }
}
