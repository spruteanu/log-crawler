/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.config;

import com.edifecs.support.ide.grpc.server.ScriptExecutionServiceImpl;
import com.edifecs.support.ide.service.ScriptService;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.TimeUnit;

/**
 * Spring component that manages the gRPC server lifecycle.
 * Starts the gRPC server when the Spring application is ready and stops it when the application shuts down.
 */
@Component
public class GrpcServerManager implements ApplicationListener<ApplicationReadyEvent> {

    private static final Logger LOGGER = LogManager.getLogger(GrpcServerManager.class);

    @Value("${grpc.server.enabled:true}")
    private boolean grpcServerEnabled;

    @Value("${grpc.server.port:9090}")
    private int grpcServerPort;

    @Value("${grpc.server.port.retry.max:5}")
    private int maxPortRetries;

    @Value("${grpc.server.port.retry.range:100}")
    private int portRetryRange;

    @Value("${grpc.server.auth-token:}")
    private String grpcAuthToken;

    @Value("${grpc.server.tool-location:/tmp}")
    private String grpcToolLocation;

    private Server grpcServer;

        @org.springframework.beans.factory.annotation.Autowired
        private ScriptService scriptService;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (grpcServerEnabled) {
            startGrpcServer();
        } else {
            LOGGER.info("gRPC server is disabled via configuration");
        }
    }

    /**
     * Start the gRPC server.
     */
    @SuppressWarnings("squid:S3776")
    private void startGrpcServer() {
        // Validate configuration
        if (grpcServerPort <= 0 || grpcServerPort > 65535) {
            LOGGER.error("Invalid gRPC server port: {}. Must be between 1 and 65535. gRPC functionality will be disabled.", grpcServerPort);
            return;
        }
        
        if (maxPortRetries < 0) {
            LOGGER.warn("Invalid maxPortRetries: {}. Using 0 (no retries).", maxPortRetries);
            maxPortRetries = 0;
        }

        ScriptExecutionServiceImpl service = new ScriptExecutionServiceImpl(
            grpcAuthToken.isEmpty() ? null : grpcAuthToken,
            grpcToolLocation,
            scriptService
        );

        int actualPort = grpcServerPort;
        boolean serverStarted = false;
        IOException lastException = null;
        int maxPort = Math.min(65535, grpcServerPort + Math.max(maxPortRetries, portRetryRange));

        LOGGER.info("Attempting to start gRPC server on port {} with up to {} retries (max port: {})", 
            grpcServerPort, maxPortRetries, maxPort);

        // Try the configured port first, then retry with incremental ports
        for (int attempt = 0; attempt <= maxPortRetries && !serverStarted; attempt++) {
            actualPort = grpcServerPort + attempt;
            
            // Skip if port exceeds valid range
            if (actualPort > 65535 || actualPort > maxPort) {
                LOGGER.debug("Skipping port {} as it exceeds maximum allowed port", actualPort);
                break;
            }

            // Check if port is available before attempting to bind
            if (!isPortAvailable(actualPort)) {
                if (attempt == 0) {
                    LOGGER.warn("Configured gRPC port {} is already in use, trying alternative ports", actualPort);
                } else {
                    LOGGER.debug("Port {} is already in use, trying next port", actualPort);
                }
                continue;
            }

            try {
                LOGGER.debug("Attempting to start gRPC server on port {}", actualPort);
                
                grpcServer = ServerBuilder.forPort(actualPort)
                        .addService(service)
                        .build()
                        .start();

                serverStarted = true;
                LOGGER.info("gRPC Script Execution Server started successfully on port {}", actualPort);
                if (attempt > 0) {
                    LOGGER.warn("Original port {} was in use, started on alternative port {}", 
                        grpcServerPort, actualPort);
                }
                LOGGER.info("Tool location: {}", grpcToolLocation);
                LOGGER.info("Authentication: {}", 
                    grpcAuthToken != null && !grpcAuthToken.isEmpty() ? "Enabled" : "Disabled");

            } catch (IOException e) {
                lastException = e;
                if (attempt == 0) {
                    LOGGER.warn("Failed to start gRPC server on configured port {}: {}", 
                        actualPort, e.getMessage());
                } else {
                    LOGGER.debug("Failed to start gRPC server on port {}: {}", 
                        actualPort, e.getMessage());
                }
            }
        }

        if (!serverStarted) {
            int endPort = Math.min(actualPort, maxPort);
            LOGGER.error("Failed to start gRPC server after {} attempts. Tried ports {}-{}. " +
                "gRPC functionality will be disabled. Last error: {}", 
                maxPortRetries + 1, grpcServerPort, endPort, 
                lastException != null ? lastException.getMessage() : "Unknown error");
            
            // Don't throw exception - allow application to start without gRPC server
            grpcServer = null;
        } else {
            // Update the port number for other components that might need it
            this.grpcServerPort = actualPort;
        }
    }

    /**
     * Check if a port is available for binding.
     * @param port the port to check
     * @return true if the port is available, false otherwise
     */
    private boolean isPortAvailable(int port) {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            serverSocket.setReuseAddress(true);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Stop the gRPC server when the Spring context is closed.
     */
    @EventListener
    public void onContextClosed(ContextClosedEvent event) {
        stopGrpcServer();
    }

    /**
     * Stop the gRPC server during bean destruction.
     */
    @PreDestroy
    public void stopGrpcServer() {
        if (grpcServer != null) {
            LOGGER.info("Shutting down gRPC server...");
            try {
                grpcServer.shutdown().awaitTermination(30, TimeUnit.SECONDS);
                LOGGER.info("gRPC server stopped successfully");
            } catch (InterruptedException e) {
                LOGGER.error("Error during gRPC server shutdown", e);
                Thread.currentThread().interrupt();
                // Force shutdown if graceful shutdown fails
                grpcServer.shutdownNow();
            }
            grpcServer = null;
        }
    }

    /**
     * Check if the gRPC server is running.
     */
    public boolean isServerRunning() {
        return grpcServer != null && !grpcServer.isShutdown();
    }

    /**
     * Get the gRPC server port.
     */
    public int getGrpcServerPort() {
        return grpcServerPort;
    }

    /**
     * Check if gRPC server is enabled.
     */
    public boolean isGrpcServerEnabled() {
        return grpcServerEnabled;
    }
}
