/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Spring Boot application entry point for the Support IDE application.
 * This application provides a web interface for discovering and executing scripts.
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.edifecs.support.ide", "com.edifecs.support.scripts"})
public class SupportIdeApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(SupportIdeApplication.class);
        app.setAdditionalProfiles("ide");
        app.run(args);
    }
}
