/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.model;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Model class representing a server configuration for remote script execution.
 */
public class Server {
    private String id;
    private String name;
    private String hostname;
    private int port = 22; // Default SSH port
    private String username;

    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private boolean active = true;

    private String password;
    private String toolLocation = "/tmp"; // Default location where support-tool will be copied

    // gRPC authentication token (optional, if not set backend may compute from hostname)
    private String grpcToken;
    
    // gRPC server port (default 9090)
    private int grpcPort = 9090;

    // Collected system information from remote host (key-value pairs)
    private Map<String, String> systemInfo;

    public Server() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    //    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getToolLocation() {
        return toolLocation;
    }

    public void setToolLocation(String toolLocation) {
        this.toolLocation = toolLocation;
    }

    public String getGrpcToken() {
        return grpcToken;
    }

    public void setGrpcToken(String grpcToken) {
        this.grpcToken = grpcToken;
    }

    public int getGrpcPort() {
        return grpcPort;
    }

    public void setGrpcPort(int grpcPort) {
        this.grpcPort = grpcPort;
    }

    public Map<String, String> getSystemInfo() {
        return systemInfo;
    }

    public void setSystemInfo(Map<String, String> systemInfo) {
        this.systemInfo = systemInfo;
    }

    /**
     * Create a clone of this Server and apply overrides from the given map.
     * Only known fields are overridden; unknown keys are ignored.
     * This method does NOT mutate the current instance.
     */
    public Server clone(Map<String, Object> overrides) {
        Server s = new Server();
        // copy fields
        s.id = this.id;
        s.name = this.name;
        s.hostname = this.hostname;
        s.port = this.port;
        s.username = this.username;
        s.description = this.description;
        s.createdAt = this.createdAt;
        s.updatedAt = this.updatedAt;
        s.active = this.active;
        s.password = this.password;
        s.toolLocation = this.toolLocation;
        s.grpcToken = this.grpcToken;
        s.grpcPort = this.grpcPort;
        s.systemInfo = this.systemInfo;

        if (overrides != null && !overrides.isEmpty()) {
            for (Map.Entry<String, Object> e : overrides.entrySet()) {
                String key = e.getKey();
                Object val = e.getValue();
                if (val == null) continue;
                switch (key) {
                    case "id":
                        s.setId(asString(val, s.getId()));
                        break;
                    case "name":
                        s.setName(asString(val, s.getName()));
                        break;
                    case "hostname":
                        s.setHostname(asString(val, s.getHostname()));
                        break;
                    case "port":
                        s.setPort(asInt(val, s.getPort()));
                        break;
                    case "username":
                        s.setUsername(asString(val, s.getUsername()));
                        break;
                    case "password":
                        s.setPassword(asString(val, s.getPassword()));
                        break;
                    case "toolLocation":
                        s.setToolLocation(asString(val, s.getToolLocation()));
                        break;
                    case "grpcToken":
                        s.setGrpcToken(asString(val, s.getGrpcToken()));
                        break;
                    case "grpcPort":
                        s.setGrpcPort(asInt(val, s.getGrpcPort()));
                        break;
                    case "active":
                        s.setActive(asBoolean(val, s.isActive()));
                        break;
                    case "description":
                        s.setDescription(asString(val, s.getDescription()));
                        break;
                    default:
                        // ignore unknown keys
                        break;
                }
            }
        }
        return s;
    }

    private static String asString(Object v, String def) {
        if (v == null) return def;
        return String.valueOf(v);
    }

    private static int asInt(Object v, int def) {
        if (v == null) return def;
        if (v instanceof Number) return ((Number) v).intValue();
        try {
            return Integer.parseInt(String.valueOf(v).trim());
        } catch (Exception ignore) { return def; }
    }

    private static boolean asBoolean(Object v, boolean def) {
        if (v == null) return def;
        if (v instanceof Boolean) return (Boolean) v;
        String s = String.valueOf(v).trim().toLowerCase();
        if ("true".equals(s) || "1".equals(s) || "yes".equals(s)) return true;
        if ("false".equals(s) || "0".equals(s) || "no".equals(s)) return false;
        return def;
    }

    @Override
    public String toString() {
        return "Server{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", hostname='" + hostname + '\'' +
                ", port=" + port +
                ", username='" + username + '\'' +
                ", description='" + description + '\'' +
                ", toolLocation='" + toolLocation + '\'' +
                ", grpcToken='" + grpcToken + '\'' +
                ", grpcPort=" + grpcPort +
                ", active=" + active +
                '}';
    }
}
