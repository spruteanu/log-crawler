/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.controller;

import com.edifecs.support.ide.model.ApiError;
import com.edifecs.support.ide.model.Server;
import com.edifecs.support.ide.service.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Controller for server management operations.
 */
@RestController
@Profile("ide")
@RequestMapping("/api/servers")
@SuppressWarnings({"squid:S1192", "squid:S1452"})
public class ServerController {

    private static final Logger LOGGER = LogManager.getLogger(ServerController.class);

    private final ServerService serverService;
    private final EncryptionService encryptionService;
    private final SshService sshService;
    private final GrpcServer grpcServer;

    private final ProgressService progressService;

    @Autowired
    public ServerController(ServerService serverService, EncryptionService encryptionService, SshService sshService, GrpcServer grpcServer, ProgressService progressService) {
        this.serverService = serverService;
        this.encryptionService = encryptionService;
        this.sshService = sshService;
        this.grpcServer = grpcServer;
        this.progressService = progressService;
    }

    /**
     * Get all servers.
     *
     * @return a list of all server configurations
     */
    @GetMapping
    public ResponseEntity<List<Server>> getAllServers() {
        LOGGER.info("Getting all servers");
        return ResponseEntity.ok(serverService.getAllServers());
    }

    /**
     * Get active servers.
     *
     * @return a list of active server configurations
     */
    @GetMapping("/active")
    public ResponseEntity<List<Server>> getActiveServers() {
        LOGGER.info("Getting active servers");
        return ResponseEntity.ok(serverService.getActiveServers());
    }

    /**
     * Get a specific server by ID.
     *
     * @param id the server ID
     * @return the server configuration
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getServerById(@PathVariable("id") String id) {
        LOGGER.info("Getting server by ID: {}", id);
        Optional<Server> server = serverService.getServerById(id);
        if (server.isPresent()) {
            return ResponseEntity.ok(server.get());
        } else {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * Create a new server.
     *
     * @param server the server configuration to create
     * @return the created server configuration
     */
    @PostMapping
    public ResponseEntity<Server> createServer(@RequestBody Server server) {
        LOGGER.info("Creating new server: {}", server.getName());

        // Handle frontend-encrypted password
        if (server.getPassword() != null && !server.getPassword().isEmpty()) {
            try {
                // Decrypt the password from frontend encryption
                String decryptedPassword = encryptionService.decryptFromFrontend(server.getPassword());
                // Set the decrypted password for the server service to encrypt properly
                server.setPassword(decryptedPassword);
            } catch (Exception e) {
                LOGGER.error("Error decrypting password from frontend", e);
                // If decryption fails, assume the password is not encrypted
            }
        }

        Server createdServer = serverService.createServer(server);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdServer);
    }

    /**
     * Update an existing server.
     *
     * @param id     the server ID
     * @param server the updated server configuration
     * @return the updated server configuration
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateServer(@PathVariable("id") String id, @RequestBody Server server) {
        LOGGER.info("Updating server with ID: {}", id);

        // Handle frontend-encrypted password
        if (server.getPassword() != null && !server.getPassword().isEmpty()) {
            try {
                // Decrypt the password from frontend encryption
                String decryptedPassword = encryptionService.decryptFromFrontend(server.getPassword());
                // Set the decrypted password for the server service to encrypt properly
                server.setPassword(decryptedPassword);
            } catch (Exception e) {
                LOGGER.error("Error decrypting password from frontend", e);
                // If decryption fails, assume the password is not encrypted
            }
        }

        Optional<Server> updatedServer = serverService.updateServer(id, server);
        if (updatedServer.isPresent()) {
            return ResponseEntity.ok(updatedServer.get());
        } else {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * Delete a server.
     *
     * @param id the server ID
     * @return a response indicating success or failure
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteServer(@PathVariable("id") String id) {
        LOGGER.info("Deleting server with ID: {}", id);
        boolean deleted = serverService.deleteServer(id);
        if (deleted) {
            return ResponseEntity.ok().build();
        } else {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * Get encryption key for frontend use.
     * This endpoint provides a key that the frontend can use to encrypt passwords before sending them to the backend.
     *
     * @return the encryption key for frontend use
     */
    @GetMapping("/encryption-key")
    public ResponseEntity<String> getEncryptionKey() {
        LOGGER.info("Getting encryption key for frontend use");
        // Return the key that matches what decryptFromFrontend expects
        String key = encryptionService.getFrontendEncryptionKey();
        return ResponseEntity.ok(key);
    }

    /**
     * Generate a new gRPC authentication token.
     * This endpoint provides a randomly generated token that can be used for gRPC authentication.
     *
     * @return a new gRPC authentication token
     */
    @PostMapping("/generate-grpc-token")
    public ResponseEntity<Map<String, String>> generateGrpcToken() {
        LOGGER.info("Generating new gRPC authentication token (legacy random token endpoint)");

        // Legacy random token generation preserved for backward compatibility
        String token = UUID.randomUUID().toString().replace("-", "") +
                UUID.randomUUID().toString().replace("-", "");

        Map<String, String> response = new HashMap<>();
        response.put("token", token);

        return ResponseEntity.ok(response);
    }

    /**
     * Generate a gRPC authentication token based on hostname.
     * Token is a deterministic function of the provided hostname.
     */
    @GetMapping("/generate-grpc-token/{hostname}")
    public ResponseEntity<Map<String, String>> generateGrpcTokenForHost(@PathVariable("hostname") String hostname) {
        LOGGER.info("Generating gRPC authentication token for host: {}", hostname);
        String token = computeGrpcToken(hostname);
        Map<String, String> response = new HashMap<>();
        response.put("token", token);
        response.put("hostname", hostname);
        return ResponseEntity.ok(response);
    }

    /**
     * Test connection to a server.
     *
     * @param id the server ID
     * @return a response indicating success or failure
     */
    @PostMapping("/{id}/test-connection")
    public ResponseEntity<?> testConnection(@PathVariable("id") String id) {
        LOGGER.info("Testing connection to server with ID: {}", id);
        Optional<Server> serverOpt = serverService.getServerById(id);

        if (serverOpt.isEmpty()) {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }

        Server server = serverOpt.get();

        try {
            // Create a simple test script
            String testScript = "echo 'Connection successful'";

            // Execute the test script on the remote server
            Map<String, Object> result = sshService.executeScript(server, testScript, new String[0]);

            // Check if the execution was successful
            boolean success = (boolean) result.getOrDefault("success", false);

            if (success) {
                // On successful connection, collect system info and persist it to the server instance
                Map<String, String> sysInfo = sshService.collectSystemInfo(server);
                server.setSystemInfo(sysInfo);
                server.setUpdatedAt(LocalDateTime.now());
                serverService.persistServer(server);

                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Successfully connected to " + server.getHostname());
                response.put("systemInfo", sysInfo);
                return ResponseEntity.ok(response);
            } else {
                String errorMessage = (String) result.getOrDefault("error", "Unknown error");
                ApiError error = new ApiError(500, "Connection Failed", errorMessage, "/servers/" + id + "/test-connection");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
            }
        } catch (Exception e) {
            LOGGER.error("Error testing connection to server: {}", server.getName(), e);
            ApiError error = new ApiError(500, "Connection Failed", "Failed to connect to server: " + e.getMessage(), "/servers/" + id + "/test-connection");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * Test gRPC connection to the remote agent for the given server id.
     */
    @PostMapping("/{id}/grpc-test-connection")
    public ResponseEntity<?> testGrpcConnection(@PathVariable("id") String id) {
        LOGGER.info("Testing gRPC connection for server id: {}", id);
        Optional<Server> serverOpt = serverService.getServerById(id);
        if (serverOpt.isEmpty()) {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id + "/grpc-test-connection");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
        Server server = serverOpt.get();
        try {
            // Configure gRPC host/port and auth token
            String hostname = server.getHostname();
            String token = (server.getGrpcToken() != null && !server.getGrpcToken().isEmpty()) ? server.getGrpcToken() : computeGrpcToken(hostname);
            grpcServer.configure(hostname, server.getGrpcPort(), token);

            Map<String, Object> result = grpcServer.testConnection(server);
            boolean success = (boolean) result.getOrDefault("success", false);
            Map<String, Object> response = new HashMap<>();
            response.put("success", success);
            response.put("message", String.valueOf(result.getOrDefault("message", success ? "gRPC connection successful" : "gRPC connection failed")));
            if (!success) {
                response.put("error", String.valueOf(result.getOrDefault("error", "")));
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            LOGGER.error("Error testing gRPC connection for server: {}", server.getName(), e);
            ApiError error = new ApiError(500, "gRPC Connection Failed", e.getMessage(), "/servers/" + id + "/grpc-test-connection");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * Establish SSE connection for download progress tracking.
     *
     * @param sessionId Unique session ID for tracking download progress
     */
    @GetMapping(value = "/download-progress/{sessionId}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter downloadProgress(@PathVariable("sessionId") String sessionId) {
        LOGGER.info("Establishing SSE connection for download progress, session: {}", sessionId);
        return progressService.createEmitter(sessionId);
    }

    private StreamingResponseBody streamingBodyFromFile(Path filePath, String sessionId) {
        return outputStream -> {
            long fileSize = Files.size(filePath);
            long totalBytesRead = 0;
            try (InputStream inputStream = Files.newInputStream(filePath)) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                    // Send progress update
                    if (sessionId != null) {
                        int percentage = (int) ((totalBytesRead * 100) / fileSize);
                        progressService.sendProgress(sessionId, "progress", "Downloaded " + percentage + "%");
                    }
                }
            }
        };
    }

    private StreamingResponseBody serverDownloadStreaming(String sessionId, Server server) throws IOException {
        final Path path = serverService.checkCreateServerImage(server, sessionId, progressService);
        return streamingBodyFromFile(path, sessionId);
    }

    /**
     * Download a host-specific gRPC agent bundle for the given server ID.
     * The generated bundle includes the server hostname and a deterministic auth token.
     * Uses streaming response to avoid OOM issues with large zip files.
     *
     * @param sessionId Optional session ID for progress tracking
     */
    @GetMapping("/{id}/grpc-agent-bundle")
    public ResponseEntity<StreamingResponseBody> downloadServerBundle(
            @PathVariable("id") String id,
            @RequestParam(value = "sessionId", required = false) String sessionId) {
        LOGGER.info("Generating host-specific gRPC agent bundle for server id: {}", id);
        Optional<Server> serverOpt = serverService.getServerById(id);
        if (serverOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        Server server = serverOpt.get();
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + serverService.serverToolImageFileName(server));
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(serverDownloadStreaming(sessionId, server));
        } catch (Exception e) {
            LOGGER.error("Error creating host-specific gRPC agent bundle for server: {}", server.getName(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    private String computeGrpcToken(String hostname) {
        if (hostname == null) hostname = "";
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(hostname.trim().toLowerCase().getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            // Return 64-char hex; optionally truncate if needed
            return sb.toString();
        } catch (Exception e) {
            // Fallback to random if hashing fails
            return UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "");
        }
    }

    /**
     * Establish SSE connection for deployment progress tracking.
     *
     * @param sessionId Unique session ID for tracking deployment progress
     */
    @GetMapping(value = "/deploy-progress/{sessionId}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter deployProgress(@PathVariable("sessionId") String sessionId) {
        LOGGER.info("Establishing SSE connection for deployment progress, session: {}", sessionId);
        return progressService.createEmitter(sessionId);
    }

    /**
     * Deploy the gRPC agent bundle to the remote server for the given server id.
     * Generates a host-specific bundle using streaming approach to control memory consumption,
     * ensures the tool directory exists, copies the bundle, and unzips it.
     * Returns detailed error information if something goes wrong.
     */
    @PostMapping("/{id}/grpc-agent-deploy")
    public ResponseEntity<?> deployGrpcAgentToServer(@PathVariable("id") String id,
                                                     @RequestBody(required = false) Map<String, Object> overrides,
                                                     @RequestParam(value = "sessionId", required = false) String sessionId) {
        LOGGER.info("Deploying gRPC agent bundle to remote server, id={}", id);
        Optional<Server> serverOpt = serverService.getServerById(id);
        if (serverOpt.isEmpty()) {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id + "/grpc-agent-deploy");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
        Server server = serverOpt.get();
        try {
            progressService.sendProgress(sessionId, "starting", "Starting deployment...");

            // Apply overrides to this in-memory server object (do not persist)
            if (overrides != null) {
                server = server.clone(overrides);
            }

            progressService.sendProgress(sessionId, "progress", "Configuration processed...");
            progressService.sendProgress(sessionId, "progress", "Creating deployment bundle...");

            // Use streaming approach to create and deploy bundle (reuse logic from download bundle method)
            Map<String, Object> result = sshService.deployAgent(server, sessionId, progressService);
            boolean success = (boolean) result.getOrDefault("success", false);
            if (!success) {
                String errorMessage = String.valueOf(result.getOrDefault("error", "Unknown error during deployment"));
                progressService.sendProgress(sessionId, "error", errorMessage);
                ApiError error = new ApiError(500, "gRPC Agent Deployment Failed", errorMessage, "/servers/" + id + "/grpc-agent-deploy");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
            }

            progressService.sendProgress(sessionId, "completed", "Deployment completed successfully!");

            // Success
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.putAll(result);
            response.put("usedHostname", server.getHostname());
            response.put("usedPort", server.getPort());
            response.put("usedToolLocation", server.getToolLocation());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            LOGGER.error("Error deploying gRPC agent bundle for server: {}", server.getName(), e);
            progressService.sendProgress(sessionId, "error", "Deployment failed: " + e.getMessage());
            ApiError error = new ApiError(500, "gRPC Agent Deployment Error", e.getMessage(), "/servers/" + id + "/grpc-agent-deploy");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * Ensure the gRPC agent is deployed and running on the remote server.
     * If the agent is not reachable, deploy the bundle (creating the tool directory if needed),
     * start the agent with OS-specific script, wait a bit, and re-check connectivity.
     * Progress updates are emitted over SSE if sessionId is provided (reuse /deploy-progress/{sessionId}).
     */
    @PostMapping("/{id}/ensure-agent-running")
    public ResponseEntity<?> ensureAgentRunning(@PathVariable("id") String id,
                                                @RequestParam(value = "sessionId", required = false) String sessionId) {
        LOGGER.info("Ensuring gRPC agent is running for server id: {}", id);
        Optional<Server> serverOpt = serverService.getServerById(id);
        if (serverOpt.isEmpty()) {
            ApiError error = new ApiError(404, "Not Found", "Server not found with ID: " + id, "/servers/" + id + "/ensure-agent-running");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
        Server server = serverOpt.get();

        String hostname = server.getHostname();
        int port = server.getGrpcPort() > 0 ? server.getGrpcPort() : GrpcServer.DEFAULT_PORT;
        String token = (server.getGrpcToken() != null && !server.getGrpcToken().isEmpty()) ? server.getGrpcToken() : computeGrpcToken(hostname);

        try {
            progressService.sendProgress(sessionId, "starting", "Checking gRPC connectivity...");
            grpcServer.configure(hostname, port, token);
            Map<String, Object> check = grpcServer.testConnection(server);
            boolean ok = (boolean) check.getOrDefault("success", false);
            if (ok) {
                progressService.sendProgress(sessionId, "completed", "Agent is already running.");
                return ResponseEntity.ok(Map.of("success", true, "alreadyRunning", true));
            }

            progressService.sendProgress(sessionId, "progress", "Deploying agent bundle (if needed)...");
            Map<String, Object> deploy = sshService.deployAgent(server, sessionId, progressService);
            if (!(boolean) deploy.getOrDefault("success", false)) {
                String msg = String.valueOf(deploy.getOrDefault("error", "Deployment failed"));
                progressService.sendProgress(sessionId, "error", msg);
                ApiError error = new ApiError(500, "Agent Deployment Failed", msg, "/servers/" + id + "/ensure-agent-running");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
            }

            boolean isWindows = (boolean) deploy.getOrDefault("isWindows", false);
            progressService.sendProgress(sessionId, "progress", "Starting agent...");
            Map<String, Object> start = sshService.startAgent(server, server.getToolLocation(), isWindows);
            if (!(boolean) start.getOrDefault("success", false)) {
                String msg = String.valueOf(start.getOrDefault("error", "Failed to start agent"));
                progressService.sendProgress(sessionId, "error", msg);
                ApiError error = new ApiError(500, "Agent Start Failed", msg, "/servers/" + id + "/ensure-agent-running");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
            }

            // Wait and re-test connectivity a few times
            int retries = 5;
            int waited = 0;
            for (int i = 1; i <= retries; i++) {
                try {
                    Thread.sleep(2000L);
                    waited += 2;
                } catch (InterruptedException ignore) {
                    /*noop*/
                    Thread.currentThread().interrupt();
                }
                progressService.sendProgress(sessionId, "progress", "Verifying agent is up (" + i + "/" + retries + ")...");
                Map<String, Object> retry = grpcServer.testConnection(server);
                if ((boolean) retry.getOrDefault("success", false)) {
                    progressService.sendProgress(sessionId, "completed", "Agent is running. Proceeding.");
                    return ResponseEntity.ok(Map.of("success", true, "alreadyRunning", false, "waitedSeconds", waited));
                }
            }
            progressService.sendProgress(sessionId, "error", "Agent did not become reachable after start.");
            ApiError error = new ApiError(504, "Agent Not Reachable", "Agent did not become reachable after start", "/servers/" + id + "/ensure-agent-running");
            return ResponseEntity.status(HttpStatus.GATEWAY_TIMEOUT).body(error);
        } catch (Exception e) {
            LOGGER.error("Error ensuring agent is running for server: {}", server.getName(), e);
            progressService.sendProgress(sessionId, "error", "Error: " + e.getMessage());
            ApiError error = new ApiError(500, "Ensure Agent Error", e.getMessage(), "/servers/" + id + "/ensure-agent-running");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * Returns the local system information of the machine running Support IDE backend.
     */
    @GetMapping("/local-system-info")
    public ResponseEntity<Map<String, String>> getLocalSystemInfo() {
        LOGGER.info("Collecting local system information");
        Map<String, String> info = serverService.collectLocalSystemInfo();
        return ResponseEntity.ok(info);
    }
}
