/*
 * Service for integrating with AWS CLI + kubectl.
 * Build temporary kubeconfig via `aws eks update-kubeconfig` and run kubectl commands.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.core.ProcessHelper;
import com.edifecs.support.ide.model.Cluster;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class KubernetesService {
    private static final Logger LOGGER = LogManager.getLogger(KubernetesService.class);

    /**
     * Creates a temporary kubeconfig using the AWS CLI.
     * Returns the path to the kubeconfig file.
     */
    public Path buildKubeconfig(Cluster c) throws Exception {
        Objects.requireNonNull(c, "null cluster");
        if (isBlank(c.getAwsRegion()) || isBlank(c.getClusterName())) {
            throw new IllegalArgumentException("awsRegion and clusterName are required");
        }

        Path kubeconfig = Files.createTempFile("kubeconfig-", ".yaml");

        List<String> cmd = new ArrayList<>();
        cmd.add("aws");
        cmd.add("eks");
        cmd.add("update-kubeconfig");
        cmd.add("--region");
        cmd.add(c.getAwsRegion());
        cmd.add("--name");
        cmd.add(c.getClusterName());
        cmd.add("--kubeconfig");
        cmd.add(kubeconfig.toString());
        if (c.getAuthMode() == Cluster.AuthMode.PROFILE && notBlank(c.getAwsProfile())) {
            cmd.add("--profile");
            cmd.add(c.getAwsProfile());
        }

        String command = cmd.get(0);
        String[] arguments = cmd.subList(1, cmd.size()).toArray(new String[0]);
        ProcessHelper ph = new ProcessHelper(command, arguments);
        if (c.getAuthMode() == Cluster.AuthMode.STATIC) {
            Map<String, String> env = new HashMap<>(System.getenv());
            if (notBlank(c.getAwsAccessKeyId())) {
                env.put("AWS_ACCESS_KEY_ID", decryptIfNeeded(c.getAwsAccessKeyId()));
            }
            if (notBlank(c.getAwsSecretAccessKey())) {
                env.put("AWS_SECRET_ACCESS_KEY", decryptIfNeeded(c.getAwsSecretAccessKey()));
            }
            if (notBlank(c.getAwsSessionToken())) {
                env.put("AWS_SESSION_TOKEN", decryptIfNeeded(c.getAwsSessionToken()));
            }
            ph.withEnvironment(env);
        }

        ProcessHelper.Result r = ph.withLoggingObserver().executeAndGetResult();
        if (r.getRc() != 0) {
            safeDelete(kubeconfig);
            String err = r.getOutput();
            throw new RuntimeException("aws eks update-kubeconfig failed (rc=" + r.getRc() + "): " + err);
        }
        LOGGER.info("Kubeconfig built in {}", kubeconfig);
        return kubeconfig;
    }

    /**
     * Test connection: `kubectl cluster-info`
     */
    public Map<String, Object> testConnection(Cluster c) {
        Map<String, Object> res = new LinkedHashMap<>();
        Path kube = null;
        try {
            kube = buildKubeconfig(c);
            ProcessHelper ph = kubectlWithKubeconfig(kube, "cluster-info");
            ProcessHelper.Result r = ph.executeAndGetResult();
            boolean ok = r.getRc() == 0;
            res.put("success", ok);
            if (ok) {
                res.put("message", r.getOutput());
            } else {
                res.put("error", firstNonEmpty(r.getOutput(), "Unknown error"));
            }
        } catch (Exception e) {
            res.put("success", false);
            res.put("error", e.getMessage());
        } finally {
            safeDelete(kube);
        }
        return res;
    }

    /**
     * Run `kubectl <args...>` and save the output in results.
     */
    public Map<String, Object> executeKubectl(Cluster c, List<String> args) {
        Map<String, Object> res = new LinkedHashMap<>();
        Path kube = null;
        try {
            kube = buildKubeconfig(c);

            List<String> cmd = new ArrayList<>();
            cmd.add("kubectl");
            if (args != null) cmd.addAll(args);

            String command = cmd.get(0);
            String[] arguments = cmd.size() > 1 ? cmd.subList(1, cmd.size()).toArray(new String[0]) : new String[0];
            ProcessHelper ph = new ProcessHelper(command, arguments);

            Map<String, String> env = new HashMap<>(System.getenv());
            env.put("KUBECONFIG", kube.toString());
            ph.withEnvironment(env);

            ProcessHelper.Result r = ph.withLoggingObserver().executeAndGetResult();
            boolean ok = r.getRc() == 0;
            res.put("success", ok);
            String out = firstNonEmpty(r.getOutput(), "");

            if (ok) {
                Path destDir = Paths.get("results");
                String ts = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss").format(LocalDateTime.now());
                String base = "k8s-" + safeName(c.getClusterName()) + "-" + ts;
                boolean isJson = containsArg(args, "-o") && containsArg(args, "json");
                Path outFile = destDir.resolve(base + (isJson ? ".json" : ".txt"));
                Files.createDirectories(destDir);
                Files.write(outFile, out.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                res.put("output", out);
                res.put("destination", outFile.toString());
            } else {
                res.put("output", out);
            }
        } catch (Exception e) {
            res.put("success", false);
            res.put("error", e.getMessage());
        } finally {
            safeDelete(kube);
        }
        return res;
    }

    private static ProcessHelper kubectlWithKubeconfig(Path kubeconfig, String... kubectlArgs) {
        List<String> cmd = new ArrayList<>();
        cmd.add("kubectl");
        cmd.addAll(Arrays.asList(kubectlArgs));
        ProcessHelper ph = new ProcessHelper(Arrays.toString(cmd.toArray(new String[0])));
        Map<String, String> env = new HashMap<>(System.getenv());
        env.put("KUBECONFIG", kubeconfig.toString());
        ph.withEnvironment(env);
        return ph;
    }

    private static boolean containsArg(List<String> args, String token) {
        if (args == null || token == null) return false;
        for (String a : args) {
            if (token.equalsIgnoreCase(a)) return true;
        }
        return false;
    }

    private static String safeName(String s) {
        if (s == null) return "cluster";
        return s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private static String firstNonEmpty(String a, String b, String fallback) {
        if (a != null && !a.isBlank()) return a;
        if (b != null && !b.isBlank()) return b;
        return fallback;
    }

    private static String firstNonEmpty(String a, String fallback) {
        if (a != null && !a.isBlank()) return a;
        return fallback;
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static boolean notBlank(String s) {
        return !isBlank(s);
    }

    private static void safeDelete(Path p) {
        if (p == null) return;
        try { Files.deleteIfExists(p); } catch (Exception ignore) {}
    }

    private static String decryptIfNeeded(String v) {
        return v;
    }
}