package com.edifecs.support.ide.controller;

import com.edifecs.support.ide.model.User;
import com.edifecs.support.ide.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@org.springframework.context.annotation.Profile("ide")
@RequestMapping("/api/users")
@SuppressWarnings({"squid:S1452", "squid:S1192"})
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public List<User> list() {
        return userService.listUsers();
    }

    public static class CreateUserRequest {
        public String username;
        public String password;
        public Set<String> roles;
        public String firstName;
        public String lastName;
        public String selectedRole;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateUserRequest req) {
        if (req == null || req.username == null || req.username.isBlank() || req.password == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "username and password are required"));
        }
        Set<String> roles = req.roles != null ? req.roles : Set.of();
        try {
            User u = userService.createUser(req.username, req.password, roles);
            // set optional properties if provided
            if (req.firstName != null || req.lastName != null || req.selectedRole != null) {
                u = userService.updateUser(req.username, null, null, req.firstName, req.lastName, req.selectedRole);
            }
            return ResponseEntity.status(HttpStatus.CREATED).body(u);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{username}")
    public ResponseEntity<?> delete(@PathVariable("username") String username) {
        if ("admin".equalsIgnoreCase(username)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Cannot delete default admin user"));
        }
        boolean ok = userService.deleteUser(username);
        return ok ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    public static class PasswordChangeRequest {
        public String password;
    }

    @PostMapping("/{username}/password")
    public ResponseEntity<?> resetPassword(@PathVariable("username") String username, @RequestBody PasswordChangeRequest req) {
        if (req == null || req.password == null || req.password.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "password is required"));
        }
        try {
            userService.setPassword(username, req.password);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/me/password")
    public ResponseEntity<?> changeOwnPassword(@RequestBody PasswordChangeRequest req) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        String username = auth.getName();
        if (req == null || req.password == null || req.password.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "password is required"));
        }
        userService.setPassword(username, req.password);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/me")
    public Map<String, Object> me() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return Map.of("authenticated", false);
        List<String> roles = auth.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList());
        return Map.of(
                "authenticated", auth.isAuthenticated(),
                "username", auth.getName(),
                "roles", roles
        );
    }

    public static class UpdateUserRequest {
        public Set<String> roles;
        public Boolean enabled;
        public String firstName;
        public String lastName;
        public String selectedRole;
    }

    @PutMapping("/{username}")
    public ResponseEntity<?> update(@PathVariable("username") String username, @RequestBody UpdateUserRequest req) {
        try {
            User u = userService.updateUser(
                    username,
                    req != null ? req.roles : null,
                    req != null ? req.enabled : null,
                    req != null ? req.firstName : null,
                    req != null ? req.lastName : null,
                    req != null ? req.selectedRole : null
            );
            return ResponseEntity.ok(u);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        }
    }
}
