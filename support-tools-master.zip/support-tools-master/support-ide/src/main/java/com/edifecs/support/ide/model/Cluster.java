package com.edifecs.support.ide.model;

import java.time.LocalDateTime;

public class Cluster {

    public enum AuthMode {
        PROFILE,
        STATIC
    }

    private String id;
    private String name;
    private String description;
    private boolean active = true;

    private String awsRegion;
    private String clusterName;

    private AuthMode authMode = AuthMode.PROFILE;
    private String awsProfile;

    private String awsAccessKeyId;
    private String awsSecretAccessKey;
    private String awsSessionToken;

    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();

    public Cluster() {
    }

    public String getId() {
        return id;
    }

    public Cluster setId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Cluster setName(String name) {
        this.name = name;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public Cluster setDescription(String description) {
        this.description = description;
        return this;
    }

    public boolean isActive() {
        return active;
    }

    public Cluster setActive(boolean active) {
        this.active = active;
        return this;
    }

    public String getAwsRegion() {
        return awsRegion;
    }

    public Cluster setAwsRegion(String awsRegion) {
        this.awsRegion = awsRegion;
        return this;
    }

    public String getClusterName() {
        return clusterName;
    }

    public Cluster setClusterName(String clusterName) {
        this.clusterName = clusterName;
        return this;
    }

    public AuthMode getAuthMode() {
        return authMode;
    }

    public Cluster setAuthMode(AuthMode authMode) {
        this.authMode = authMode;
        return this;
    }

    public String getAwsProfile() {
        return awsProfile;
    }

    public Cluster setAwsProfile(String awsProfile) {
        this.awsProfile = awsProfile;
        return this;
    }

    public String getAwsAccessKeyId() {
        return awsAccessKeyId;
    }

    public Cluster setAwsAccessKeyId(String awsAccessKeyId) {
        this.awsAccessKeyId = awsAccessKeyId;
        return this;
    }

    public String getAwsSecretAccessKey() {
        return awsSecretAccessKey;
    }

    public Cluster setAwsSecretAccessKey(String awsSecretAccessKey) {
        this.awsSecretAccessKey = awsSecretAccessKey;
        return this;
    }

    public String getAwsSessionToken() {
        return awsSessionToken;
    }

    public Cluster setAwsSessionToken(String awsSessionToken) {
        this.awsSessionToken = awsSessionToken;
        return this;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Cluster setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public Cluster setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    @Override
    public String toString() {
        return "Cluster{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", awsRegion='" + awsRegion + '\'' +
                ", clusterName='" + clusterName + '\'' +
                ", authMode=" + authMode +
                ", awsProfile='" + awsProfile + '\'' +
                ", active=" + active +
                '}';
    }
}
