/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.grpc.server;

import com.edifecs.support.ide.service.GrpcServer;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Main class for running the gRPC Script Execution Server.
 * This server can be deployed on remote machines to handle script execution requests.
 */
public class GrpcServerMain {
    
    private static final Logger LOGGER = LogManager.getLogger(GrpcServerMain.class);
    private static final String DEFAULT_TOOL_LOCATION = "/tmp";
    
    private Server server;
    private final int port;
    private final String authToken;
    private final String toolLocation;

    private int maxMessageSize = GrpcServer.DEFAULT_MAX_MESSAGE_SIZE;

    public GrpcServerMain(int port, String authToken, String toolLocation) {
        this.port = port;
        this.authToken = authToken;
        this.toolLocation = toolLocation;
    }

    public int getMaxMessageSize() {
        return maxMessageSize;
    }

    public void setMaxMessageSize(int maxMessageSize) {
        this.maxMessageSize = maxMessageSize;
    }

    /**
     * Start the gRPC server.
     */
    public void start() throws IOException {
        ScriptExecutionServiceImpl service = new ScriptExecutionServiceImpl(authToken, toolLocation);
        
        server = ServerBuilder.forPort(port)
                .maxInboundMessageSize(maxMessageSize)
                .addService(service)
                .build()
                .start();
        
        LOGGER.info("gRPC Script Execution Server started on port {}", port);
        LOGGER.info("Tool location: {}", toolLocation);
        LOGGER.info("Authentication: {}", authToken != null && !authToken.isEmpty() ? "Enabled" : "Disabled");
        
        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("Shutting down gRPC server...");
            try {
                GrpcServerMain.this.stop();
            } catch (InterruptedException e) {
                LOGGER.error("Error during shutdown", e);
                Thread.currentThread().interrupt();
            }
        }));
    }
    
    /**
     * Stop the gRPC server.
     */
    public void stop() throws InterruptedException {
        if (server != null) {
            server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
            LOGGER.info("gRPC server stopped");
        }
    }
    
    /**
     * Block until the server shuts down.
     */
    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }
    
    /**
     * Main method to start the server.
     */
    @SuppressWarnings({"squid:S3776", "squid:S127"})
    public static void main(String[] args) {
        int port = GrpcServer.DEFAULT_PORT;
        String authToken = null;
        String toolLocation = DEFAULT_TOOL_LOCATION;
        
        // Parse command line arguments
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--port":
                case "-p":
                    if (i + 1 < args.length) {
                        try {
                            port = Integer.parseInt(args[++i]);
                        } catch (NumberFormatException e) {
                            LOGGER.error("Invalid port number: {}", args[i]);
                            printUsageAndExit();
                        }
                    } else {
                        LOGGER.error("Port number required after --port");
                        printUsageAndExit();
                    }
                    break;
                    
                case "--auth-token":
                case "-t":
                    if (i + 1 < args.length) {
                        authToken = args[++i];
                    } else {
                        LOGGER.error("Auth token required after --auth-token");
                        printUsageAndExit();
                    }
                    break;
                    
                case "--tool-location":
                case "-l":
                    if (i + 1 < args.length) {
                        toolLocation = args[++i];
                    } else {
                        LOGGER.error("Tool location required after --tool-location");
                        printUsageAndExit();
                    }
                    break;
                    
                case "--help":
                case "-h":
                    printUsageAndExit();
                    break;
                    
                default:
                    LOGGER.error("Unknown argument: {}", args[i]);
                    printUsageAndExit();
            }
        }
        
        try {
            GrpcServerMain server = new GrpcServerMain(port, authToken, toolLocation);
            server.start();
            server.blockUntilShutdown();
        } catch (IOException e) {
            LOGGER.error("Failed to start server", e);
            System.exit(1);
        } catch (InterruptedException e) {
            LOGGER.error("Server interrupted", e);
            Thread.currentThread().interrupt();
            System.exit(1);
        }
    }

    @SuppressWarnings("squid:S106")
    private static void printUsageAndExit() {
        System.out.println("Usage: java -jar grpc-server.jar [OPTIONS]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -p, --port <port>           Server port (default: " + GrpcServer.DEFAULT_PORT + ")");
        System.out.println("  -t, --auth-token <token>    Authentication token (optional)");
        System.out.println("  -l, --tool-location <path>  Tool extraction location (default: " + DEFAULT_TOOL_LOCATION + ")");
        System.out.println("  -h, --help                  Show this help message");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  java -jar grpc-server.jar");
        System.out.println("  java -jar grpc-server.jar --port 8080 --auth-token mytoken");
        System.out.println("  java -jar grpc-server.jar -p 9090 -l /opt/support-tools");
        System.exit(0);
    }
}
