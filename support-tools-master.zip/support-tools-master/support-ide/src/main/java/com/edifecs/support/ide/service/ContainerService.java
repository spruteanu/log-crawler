/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.ide.model.Container;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.annotation.PostConstruct;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Service for managing Docker container descriptors with on-disk JSON storage.
 * Mirrors ServerService behavior but uses the "results/container" directory by default.
 */
@Service
@SuppressWarnings("squid:S1192")
public class ContainerService {
    private static final Logger LOGGER = LogManager.getLogger(ContainerService.class);
    private static final String CONTAINER_FILE_EXTENSION = ".json";

    @Value("${support.containers.directory:results/container}")
    private String containersDirectory;

    private final ObjectMapper objectMapper;
    private final List<Container> containers = new ArrayList<>();

    public ContainerService() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @PostConstruct
    public void init() throws IOException {
        final Path dir = Paths.get(containersDirectory);
        if (!Files.exists(dir)) {
            Files.createDirectories(dir);
            LOGGER.info("Created containers directory: {}", dir);
        }
        loadContainers();
    }

    public List<Container> loadContainers() {
        containers.clear();
        final Path dir = Paths.get(containersDirectory);
        try (Stream<Path> paths = Files.list(dir)) {
            paths.filter(path -> path.toString().endsWith(CONTAINER_FILE_EXTENSION))
                    .forEach(this::loadContainer);
        } catch (IOException e) {
            LOGGER.error("Failed to load containers from {}", dir, e);
        }
        return new ArrayList<>(containers);
    }

    private void loadContainer(Path path) {
        try {
            Container c = objectMapper.readValue(path.toFile(), Container.class);
            containers.add(c);
            LOGGER.debug("Loaded container descriptor: {}", c.getName());
        } catch (IOException e) {
            LOGGER.error("Failed to load container descriptor from {}", path, e);
        }
    }

    public List<Container> getAllContainers() {
        return new ArrayList<>(containers);
    }

    public List<Container> getActiveContainers() {
        return containers.stream().filter(Container::isActive).collect(Collectors.toList());
    }

    public Optional<Container> getContainerById(String id) {
        return containers.stream().filter(c -> Objects.equals(c.getId(), id)).findFirst();
    }

    public Container createContainer(Container container) {
        if (container.getId() == null || container.getId().isEmpty()) {
            container.setId(UUID.randomUUID().toString());
        }
        LocalDateTime now = LocalDateTime.now();
        container.setCreatedAt(now);
        container.setUpdatedAt(now);
        saveContainer(container);
        containers.add(container);
        return container;
    }

    public Optional<Container> updateContainer(String id, Container updated) {
        return getContainerById(id).map(existing -> {
            updated.setId(existing.getId());
            updated.setCreatedAt(existing.getCreatedAt());
            updated.setUpdatedAt(LocalDateTime.now());
            saveContainer(updated);
            int idx = containers.indexOf(existing);
            containers.set(idx, updated);
            return updated;
        });
    }

    public boolean deleteContainer(String id) {
        final Optional<Container> existing = getContainerById(id);
        if (existing.isEmpty()) return false;
        final Container toRemove = existing.get();
        final String fileName = sanitizeFilename(toRemove.getName()) + CONTAINER_FILE_EXTENSION;
        final Path path = Paths.get(containersDirectory, fileName);
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            LOGGER.warn("Failed to delete container file {}", path, e);
        }
        return containers.remove(toRemove);
    }

    public void persistContainer(Container container) {
        saveContainer(container);
        final Optional<Container> existing = getContainerById(container.getId());
        if (existing.isEmpty()) {
            containers.add(container);
        } else {
            containers.set(containers.indexOf(existing.get()), container);
        }
    }

    public void saveContainer(Container container) {
        final String fileName = sanitizeFilename(container.getName()) + CONTAINER_FILE_EXTENSION;
        final Path path = Paths.get(containersDirectory, fileName);
        try {
            final File file = path.toFile();
            if (!file.getParentFile().exists()) {
                // should be ensured by init, but keep safe
                Files.createDirectories(file.getParentFile().toPath());
            }
            try (OutputStream os = Files.newOutputStream(path)) {
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(os, container);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to save container {} to {}", container.getName(), path, e);
        }
    }

    public String getContainersDirectory() {
        return containersDirectory;
    }

    public Path containersDirectoryPath() {
        return Paths.get(containersDirectory);
    }

    private String sanitizeFilename(String input) {
        return input == null ? "container" : input.replaceAll("[^a-zA-Z0-9-_]", "_");
    }
}
