/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.controller;

import com.edifecs.support.Storage;
import com.edifecs.support.SupportRuntimeException;
import com.edifecs.support.collect.ContextHistory;
import com.edifecs.support.core.Utils;
import com.edifecs.support.core.ZipWalker;
import com.edifecs.support.ide.grpc.DownloadFileRequest;
import com.edifecs.support.ide.grpc.DownloadFileResponse;
import com.edifecs.support.ide.grpc.ScriptExecutionServiceGrpc;
import com.edifecs.support.ide.model.ApiError;
import com.edifecs.support.ide.model.Server;
import com.edifecs.support.ide.model.User;
import com.edifecs.support.ide.service.ScriptService;
import com.edifecs.support.ide.service.ServerService;
import com.edifecs.support.ide.service.UserService;
import com.edifecs.support.scripts.Metadata;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import java.util.stream.Collectors;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * REST controller for script-related operations.
 * This controller provides endpoints for listing, getting details of, and executing scripts.
 */
@RestController
@Profile("ide")
@RequestMapping("/api/scripts")
@SuppressWarnings({"squid:S1192", "squid:S1452"})
public class ScriptController {

    private static final Logger LOGGER = LogManager.getLogger(ScriptController.class);

    private final ScriptService scriptService;
    private final ServerService serverService;
    private final UserService userService;

    @Autowired
    public ScriptController(ScriptService scriptService, ServerService serverService, UserService userService) {
        this.scriptService = scriptService;
        this.serverService = serverService;
        this.userService = userService;
    }

    /**
     * Get all available scripts.
     *
     * @return a list of script metadata
     */
    @GetMapping
    public ResponseEntity<List<Metadata>> getAllScripts(Authentication authentication) {
        // Resolve authentication either from the method argument or the SecurityContext
        org.springframework.security.core.Authentication auth = authentication;
        if (auth == null) {
            auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        }

        final String userName = (auth != null && auth.getName() != null) ? auth.getName() : "anonymous";
        LOGGER.info("Getting all scripts for user: {}", userName);

        List<Metadata> scripts = scriptService.getCachedScripts();
        final User u = userService.listUsers().stream().filter(user -> user.getUsername().equalsIgnoreCase(userName)).findFirst().orElse(null);
        java.util.Collection<String> roles;
        if (u == null) {
            roles = (auth == null) ? java.util.Collections.emptySet() : auth.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toSet());
        } else {
            roles = u.getRoles();
        }
        return ResponseEntity.ok(scriptService.filterScriptsByUserRoles(scripts, roles));
    }

    /**
     * Get details of a specific script.
     *
     * @param scriptPath the path of the script
     * @return the script metadata
     */
    @GetMapping("/{scriptPath}")
    public ResponseEntity<Metadata> getScript(@PathVariable("scriptPath") String scriptPath) {
        LOGGER.info("Getting script: {}", scriptPath);
        Optional<Metadata> metadata = scriptService.findScript(scriptPath);

        return metadata.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Get the content of a specific script.
     *
     * @param scriptPath the path of the script
     * @return the script content
     */
    @GetMapping("/{scriptPath}/content")
    public ResponseEntity<String> getScriptContent(@PathVariable("scriptPath") String scriptPath) {
        LOGGER.info("Getting script content: {}", scriptPath);
        Optional<Metadata> metadata = scriptService.findScript(scriptPath);

        return metadata.map(m -> ResponseEntity.ok(scriptService.getScriptContent(m)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Execute a script.
     *
     * @param scriptPath the path of the script
     * @param args the script arguments
     * @param serverId the ID of the server to execute the script on (optional)
     * @return the execution results
     */
    @PostMapping("/{scriptPath}/execute")
    public ResponseEntity<Map<String, Object>> executeScript(
            @PathVariable("scriptPath") String scriptPath,
            @RequestParam(name = "args", required = false) String[] args,
            @RequestParam(name = "serverId", required = false) String serverId) {

        String argsStr = (args != null ? String.join(", ", args) : "none");
        String whereStr = (serverId != null ? " on server: " + serverId : " locally");
        LOGGER.info("Executing script: {} with args: {}{}", scriptPath, argsStr, whereStr);

        Optional<Metadata> metadata = scriptService.findScript(scriptPath);

        if (metadata.isPresent()) {
            try {
                Map<String, Object> result = scriptService.executeScript(
                    metadata.get(), 
                    args != null ? args : new String[0],
                    serverId
                );
                return ResponseEntity.ok(result);
            } catch (Exception e) {
                LOGGER.error("Error executing script: {}", scriptPath, e);
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "Error executing script: " + e.getMessage()
                ));
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Refresh the script cache.
     *
     * @return the refreshed list of script metadata
     */
    @PostMapping("/refresh")
    public ResponseEntity<List<Metadata>> refreshScripts() {
        LOGGER.info("Refreshing scripts");
        return ResponseEntity.ok(scriptService.refreshCache());
    }

    @GetMapping("/server-name")
    public ResponseEntity<String> getServerName() {
        final String serverName = Utils.lookupHostName("localhost");
        return ResponseEntity.ok(serverName);
    }

    /**
     * Get context history list.
     *
     * @return a list of context history entries
     */
    @GetMapping("/history")
    public ResponseEntity<List<ContextHistory>> getContextHistory() {
        LOGGER.info("Getting context history");
        try {
            List<ContextHistory> history = Storage.lookupContextHistory();
            return ResponseEntity.ok(history);
        } catch (IOException e) {
            LOGGER.error("Error retrieving context history", e);
            return ResponseEntity.badRequest().body(new ArrayList<>());
        }
    }

    /**
     * Find script metadata by context history scripts.
     *
     * @param scripts comma-separated list of script paths
     * @return a list of matching script metadata
     */
    @GetMapping("/find-by-scripts")
    public ResponseEntity<List<Metadata>> findScriptsByPaths(@RequestParam("scripts") String scripts) {
        LOGGER.info("Finding scripts by paths: {}", scripts);
        
        if (scripts == null || scripts.trim().isEmpty()) {
            return ResponseEntity.ok(new ArrayList<>());
        }
        
        String[] scriptPaths = scripts.split(",");
        List<Metadata> matchingScripts = new ArrayList<>();
        for (String scriptPath : scriptPaths) {
            String trimmedPath = scriptPath.trim();
            Optional<Metadata> metadata = scriptService.findScript(trimmedPath);
            metadata.ifPresent(matchingScripts::add);
        }
        return ResponseEntity.ok(matchingScripts);
    }

    ResponseEntity<Resource> downloadFileLocally(String filePath) {
        if (filePath == null || filePath.trim().isEmpty()) {
            LOGGER.warn("Download request with empty file path");
            return ResponseEntity.badRequest().build();
        }

        try {
            final ContextHistoryResult result = validateContextHistoryResult(filePath);
            if (!result.isValidPath) {
                LOGGER.warn("Unauthorized download attempt for path: {}", filePath);
                return ResponseEntity.notFound().build();
            }

            // Check if file exists and is readable
            if (!Files.exists(result.requestedPath) || !Files.isReadable(result.requestedPath)) {
                LOGGER.warn("File not found or not readable: {}", filePath);
                return ResponseEntity.notFound().build();
            }

            // Prevent directory traversal attacks
            String canonicalPath = result.requestedPath.toFile().getCanonicalPath();
            if (!canonicalPath.equals(result.requestedPath.toAbsolutePath().toString())) {
                LOGGER.warn("Potential directory traversal attack detected for path: {}", filePath);
                return ResponseEntity.notFound().build();
            }

            Path file = result.requestedPath;
            if (Files.isDirectory(file)) {
                file = file.getParent().resolve(file.getFileName() + ".zip");
                if (!file.toFile().exists()) {
                    LOGGER.info("Archiving directory as zip file: {}", file);
                    ZipWalker.zipIt(result.requestedPath, file);
                }
                LOGGER.info("Downloading directory as zip file: {}", file);
            }
            Resource resource = new FileSystemResource(file);
            // Determine content type
            String contentType = Files.probeContentType(file);
            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            // Get filename for download
            String filename = file.getFileName().toString();

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                    .body(resource);

        } catch (IOException e) {
            LOGGER.error("Error processing download request for: {}", filePath, e);
            return ResponseEntity.internalServerError().build();
        } catch (Exception e) {
            LOGGER.error("Unexpected error during download: {}", filePath, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @SuppressWarnings("squid:S3776")
    ResponseEntity<Resource> downloadFileRemotely(String filePath, String serverName) {
        try {
            // Validate input
            if (filePath == null || filePath.trim().isEmpty()) {
                return ResponseEntity.badRequest().build();
            }

            // Resolve server by name
            Optional<Server> serverOpt = serverService.getAllServers().stream()
                    .filter(s -> serverName.equalsIgnoreCase(s.getName()))
                    .findFirst();
            if (serverOpt.isEmpty()) {
                LOGGER.warn("Server not found by name: {}", serverName);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
            Server server = serverOpt.get();

            // Create gRPC channel and stub
            ManagedChannel channel = null;
            try {
                String host = server.getHostname();
                int port = server.getGrpcPort();
                channel = ManagedChannelBuilder.forAddress(host, port)
                        .usePlaintext()
                        .build();

                ScriptExecutionServiceGrpc.ScriptExecutionServiceBlockingStub stub =
                        ScriptExecutionServiceGrpc.newBlockingStub(channel);

                DownloadFileRequest.Builder requestBuilder =
                        DownloadFileRequest.newBuilder().setFilePath(filePath);
                if (server.getGrpcToken() != null && !server.getGrpcToken().isEmpty()) {
                    requestBuilder.setAuthToken(server.getGrpcToken());
                }

                Iterator<DownloadFileResponse> iterator = stub.downloadFile(requestBuilder.build());

                // Create temp file to store the downloaded content
                Path tempFile = Files.createTempFile("download-", "-" + Paths.get(filePath).getFileName()); // todo: create temp file in results directory
                String remoteFileName = Paths.get(filePath).getFileName().toString();
                while (iterator.hasNext()) {
                    DownloadFileResponse chunk = iterator.next();
                    if (!chunk.getSuccess()) {
                        LOGGER.error("Remote download failed: {}", chunk.getError());
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                    }
                    if (!chunk.getFileName().isEmpty()) {
                        remoteFileName = chunk.getFileName();
                    }
                    byte[] data = chunk.getChunkData().toByteArray();
                    if (data.length > 0) {
                        Files.write(tempFile, data, StandardOpenOption.APPEND);
                    }
                }

                Resource resource = new FileSystemResource(tempFile.toFile());
                String contentType = Files.probeContentType(tempFile);
                if (contentType == null) {
                    contentType = "application/octet-stream";
                }

                return ResponseEntity.ok()
                        .contentType(MediaType.parseMediaType(contentType))
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + remoteFileName + "\"")
                        .body(resource);

            } finally {
                if (channel != null) {
                    try {
                        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to download file remotely from server {} path {}", serverName, filePath, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download a file from script execution results.
     *
     * @param filePath the path to the file to download (relative to execution destination)
     * @return the file as a downloadable resource
     */
    @GetMapping("/download")
    public ResponseEntity<Resource> downloadFile(@RequestParam("path") String filePath,
                                                 @RequestParam(name = "server", required = false) String serverName) {
        if (serverName != null && !serverName.isBlank()) {
            LOGGER.info("Download request for file: {} from server: {}", filePath, serverName);
            return downloadFileRemotely(filePath, serverName);
        } else {
            LOGGER.info("Download request for file: {}", filePath);
            return downloadFileLocally(filePath);
        }
    }

    @NotNull
    private static ContextHistoryResult validateContextHistoryResult(String filePath) throws IOException {
        // Security validation: Check if the requested path is from a valid execution result
        List<ContextHistory> history = Storage.lookupContextHistory();
        boolean isValidPath = false;
        Path requestedPath = Paths.get(filePath).normalize();

        for (ContextHistory entry : history) {
            String destination = entry.getDestination();
            if (destination != null) {
                Path destinationPath = Paths.get(destination).normalize();

                // Check if the requested path is the destination itself or a file within it
                if (requestedPath.equals(destinationPath) ||
                    requestedPath.startsWith(destinationPath) ||
                    destinationPath.toString().equals(requestedPath.toString())) {
                    isValidPath = true;
                    break;
                }
            }
        }
        return new ContextHistoryResult(isValidPath, requestedPath);
    }

    /**
     * Create a new script with the provided data and return a refreshed list of all scripts.
     * 
     * @param newScriptData the new script data including name, description, author, and either selectedScripts or scriptContent
     * @return a refreshed list of all script metadata including the newly created script, or an error response if script creation fails
     */
    @PostMapping("/create")
    public ResponseEntity<?> createScript(@RequestBody NewScriptData newScriptData) {
        LOGGER.info("Creating new script: {}", (newScriptData.getName() != null ? newScriptData.getName() : "unnamed"));
        try {
            Metadata createdScript = scriptService.createScript(newScriptData, Paths.get(scriptService.getScriptsPath()));
            LOGGER.info("Successfully created script: {}", createdScript.getName());
            
            // Refresh the cache and return the updated list of all scripts
            List<Metadata> refreshedScripts = scriptService.refreshCache();
            return ResponseEntity.ok(refreshedScripts);
        } catch (IllegalArgumentException e) {
            // Invalid input data
            LOGGER.error("Invalid script data: {}", e.getMessage(), e);
            ApiError error = new ApiError(400, "Bad Request", e.getMessage(), "/api/scripts/create");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (IOException e) {
            // File system error
            LOGGER.error("File system error during script creation: {}", e.getMessage(), e);
            ApiError error = new ApiError(500, "Internal Server Error", "Failed to write script to file: " + e.getMessage(), "/api/scripts/create");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        } catch (SupportRuntimeException e) {
            // Script compilation error
            LOGGER.error("Script compilation error: {}", e.getMessage(), e);
            ApiError error = new ApiError(400, "Bad Request", "Invalid script content: " + e.getMessage(), "/api/scripts/create");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (RuntimeException e) {
            // Script validation or other runtime error
            LOGGER.error("Script validation error: {}", e.getMessage(), e);
            ApiError error = new ApiError(400, "Bad Request", "Invalid script content: " + e.getMessage(), "/api/scripts/create");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (Exception e) {
            // Unexpected error
            LOGGER.error("Unexpected error during script creation: {}", e.getMessage(), e);
            ApiError error = new ApiError(500, "Internal Server Error", "An unexpected error occurred: " + e.getMessage(), "/api/scripts/create");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * DTO for new script creation data.
     */
    public static class NewScriptData {
        private String name;
        private String description;
        private String author;
        private List<Metadata> selectedScripts;
        private String scriptContent;

        // Getters and setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public String getAuthor() { return author; }
        public void setAuthor(String author) { this.author = author; }
        
        public List<Metadata> getSelectedScripts() { return selectedScripts; }
        public void setSelectedScripts(List<Metadata> selectedScripts) { this.selectedScripts = selectedScripts; }
        
        public String getScriptContent() { return scriptContent; }
        public void setScriptContent(String scriptContent) { this.scriptContent = scriptContent; }
    }

    private static class ContextHistoryResult {
        public final boolean isValidPath;
        public final Path requestedPath;

        public ContextHistoryResult(boolean isValidPath, Path requestedPath) {
            this.isValidPath = isValidPath;
            this.requestedPath = requestedPath;
        }
    }
}
