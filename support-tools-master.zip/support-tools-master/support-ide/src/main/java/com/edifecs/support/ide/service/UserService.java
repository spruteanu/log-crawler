package com.edifecs.support.ide.service;

import com.edifecs.support.Storage;
import com.edifecs.support.ide.model.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {
    private static final Logger LOGGER = LogManager.getLogger(UserService.class);

    private final ObjectMapper mapper = new ObjectMapper();
    private final PasswordService passwordService;
    private final Map<String, User> users = new HashMap<>();
    private final Set<String> roles = new TreeSet<>();
    private Path storePath;
    private Path rolesPath;

    public UserService(PasswordService passwordService) {
        this.passwordService = passwordService;
    }

    @PostConstruct
    public void init() {
        // Store users and roles under toolPath/results/users
        Path dir = Storage.toolPath().resolve("results").resolve("users");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            LOGGER.warn("Failed to create users directory {}: {}", dir, e.toString());
        }
        storePath = dir.resolve("users.json");
        rolesPath = dir.resolve("roles.json");
        load();
        if (users.isEmpty()) {
            LOGGER.info("User store is empty. Creating default admin user.");
            // Ensure base ADMIN role exists
            roles.add("ADMIN");
            createUser("admin", "admin", Set.of("ADMIN"));
            save();
        }
    }

    public synchronized List<User> listUsers() {
        return users.values().stream()
                .sorted(Comparator.comparing(User::getUsername))
                .collect(Collectors.toList());
    }

    public synchronized Optional<User> getUser(String username) {
        return Optional.ofNullable(users.get(username));
    }

    public synchronized boolean userExists(String username) {
        return users.containsKey(username);
    }

    public synchronized User createUser(String username, String rawPassword, Set<String> roles) {
        if (users.containsKey(username)) {
            throw new IllegalArgumentException("User already exists: " + username);
        }
        String salt = passwordService.generateSalt();
        String hash = passwordService.hash(rawPassword, salt);
        User u = new User(username, hash, salt, roles != null ? roles : Set.of(), true);
        users.put(username, u);
        save();
        return u;
    }

    public synchronized boolean deleteUser(String username) {
        User removed = users.remove(username);
        if (removed != null) {
            save();
            return true;
        }
        return false;
    }

    public synchronized void setPassword(String username, String rawPassword) {
        User u = users.get(username);
        if (u == null) throw new IllegalArgumentException("No such user: " + username);
        String salt = passwordService.generateSalt();
        String hash = passwordService.hash(rawPassword, salt);
        u.setSalt(salt);
        u.setPasswordHash(hash);
        save();
    }

    public synchronized boolean verify(String username, String rawPassword) {
        User u = users.get(username);
        if (u == null || !u.isEnabled()) return false;
        return passwordService.matches(rawPassword, u.getSalt(), u.getPasswordHash());
    }

    public synchronized User updateUser(String username, Set<String> roles, Boolean enabled, String firstName, String lastName) {
        return updateUser(username, roles, enabled, firstName, lastName, null);
    }

    public synchronized User updateUser(String username, Set<String> roles, Boolean enabled, String firstName, String lastName, String selectedRole) {
        User u = users.get(username);
        if (u == null) throw new IllegalArgumentException("No such user: " + username);
        if (roles != null) {
            u.setRoles(roles);
        }
        if (enabled != null) {
            u.setEnabled(enabled);
        }
        if (firstName != null) {
            u.setFirstName(firstName);
        }
        if (lastName != null) {
            u.setLastName(lastName);
        }
        if (selectedRole != null) {
            u.setSelectedRole(selectedRole);
        }
        save();
        return u;
    }

    private synchronized void load() {
        users.clear();
        roles.clear();
        if (storePath != null && Files.exists(storePath)) {
            try {
                List<User> list = mapper.readValue(Files.readAllBytes(storePath), new TypeReference<>() {});
                for (User u : list) {
                    users.put(u.getUsername(), u);
                }
            } catch (Exception e) {
                LOGGER.error("Failed to load users from {}: {}", storePath, e.toString());
            }
        }
        if (rolesPath != null && Files.exists(rolesPath)) {
            try {
                Set<String> rs = mapper.readValue(Files.readAllBytes(rolesPath), new TypeReference<>() {});
                roles.addAll(rs);
            } catch (Exception e) {
                LOGGER.error("Failed to load roles from {}: {}", rolesPath, e.toString());
            }
        }
    }

    private synchronized void save() {
        try {
            // Ensure directory exists
            if (storePath != null) {
                Path parent = storePath.getParent();
                if (parent != null) Files.createDirectories(parent);
            }
            List<User> list = new ArrayList<>(users.values());
            mapper.writerWithDefaultPrettyPrinter().writeValue(storePath.toFile(), list);

            // Persist roles as a dedicated list (managed independently from users)
            if (rolesPath != null) {
                Path parent = rolesPath.getParent();
                if (parent != null) Files.createDirectories(parent);
                mapper.writerWithDefaultPrettyPrinter().writeValue(rolesPath.toFile(), roles);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to save users/roles to {} / {}: {}", storePath, rolesPath, e.toString());
        }
    }
    public synchronized Set<String> listRoles() {
        return new TreeSet<>(roles);
    }

    public synchronized boolean addRole(String role) {
        if (role == null || role.isBlank()) return false;
        boolean added = roles.add(role.trim());
        if (added) save();
        return added;
    }

    public synchronized boolean renameRole(String oldName, String newName) {
        if (oldName == null || newName == null) return false;
        if (!roles.contains(oldName)) return false;
        String nn = newName.trim();
        if (nn.isBlank()) return false;
        if (roles.contains(nn)) return false;
        roles.remove(oldName);
        roles.add(nn);
        // update users
        for (User u : users.values()) {
            if (u.getRoles() != null && u.getRoles().remove(oldName)) {
                Set<String> rs = new HashSet<>(u.getRoles());
                rs.add(nn);
                u.setRoles(rs);
            }
            if (nn.equals(oldName) || (u.getSelectedRole() != null && u.getSelectedRole().equals(oldName))) {
                u.setSelectedRole(nn);
            }
        }
        save();
        return true;
    }

    public synchronized boolean deleteRole(String role) {
        if (role == null) return false;
        if (!roles.remove(role)) return false;
        for (User u : users.values()) {
            if (u.getRoles() != null) {
                Set<String> rs = new HashSet<>(u.getRoles());
                rs.remove(role);
                u.setRoles(rs);
            }
            if (role.equals(u.getSelectedRole())) {
                u.setSelectedRole(null);
            }
        }
        save();
        return true;
    }
}
