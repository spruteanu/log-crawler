/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.PathResourceResolver;

import java.io.IOException;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // This handler for /js/** is likely correct
        registry.addResourceHandler("/js/**")
                .addResourceLocations("classpath:/static/js/")
                .resourceChain(true);

        // Main handler for the Single Page Application
        registry.addResourceHandler("/**")
                // CORRECTED PATH: Remove "/browser" from this line
                .addResourceLocations("classpath:/static/")
                .resourceChain(true)
                .addTransformer(new IndexHtmlInjectionTransformer())
                .addResolver(new PathResourceResolver() {
                    @Override
                    protected Resource getResource(String resourcePath, Resource location) throws IOException {
                        Resource requestedResource = location.createRelative(resourcePath);
                        // Allow Spring Boot's default error handling to resolve public error pages
                        if (resourcePath != null && (resourcePath.startsWith("error/") || resourcePath.startsWith("error"))) {
                            return null; // delegate to other resolvers/handlers (e.g., BasicErrorController with public/error/*.html)
                        }
                        if (requestedResource.exists() && requestedResource.isReadable()) {
                            return requestedResource;
                        } else {
                            // Fallback to the main index.html for SPA routing
                            return location.createRelative("index.html");
                        }
                    }
                });
    }
}
