/*
 * REST Controller for cluster management and kubectl exec.
 */

package com.edifecs.support.ide.controller;

import com.edifecs.support.ide.model.ApiError;
import com.edifecs.support.ide.model.Cluster;
import com.edifecs.support.ide.service.ClusterService;
import com.edifecs.support.ide.service.KubernetesService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@org.springframework.context.annotation.Profile("ide")
@RequestMapping("/api/clusters")
@SuppressWarnings({"squid:S1452", "squid:S1192"})
public class ClusterController {
    private static final Logger LOGGER = LogManager.getLogger(ClusterController.class);

    private final ClusterService clusterService;
    private final KubernetesService kubernetesService;

    public ClusterController(ClusterService clusterService, KubernetesService kubernetesService) {
        this.clusterService = clusterService;
        this.kubernetesService = kubernetesService;
    }

    @GetMapping
    public ResponseEntity<List<Cluster>> getAll() {
        return ResponseEntity.ok(clusterService.getAllClusters());
    }

    @GetMapping("/active")
    public ResponseEntity<List<Cluster>> getActive() {
        return ResponseEntity.ok(clusterService.getActiveClusters());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable String id) {
        return clusterService.getClusterById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> {
                    ApiError err = new ApiError(404, "Not Found", "Cluster does not exist: " + id, "/api/clusters/" + id);
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
                });
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Cluster c) {
        try {
            Cluster created = clusterService.createCluster(c);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            LOGGER.error("Error creating cluster", e);
            ApiError err = new ApiError(400, "Bad Request", e.getMessage(), "/api/clusters");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id, @RequestBody Cluster c) {
        try {
            return clusterService.updateCluster(id, c)
                    .<ResponseEntity<?>>map(ResponseEntity::ok)
                    .orElseGet(() -> {
                        ApiError err = new ApiError(404, "Not Found", "Cluster does not exist: " + id, "/api/clusters/" + id);
                        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
                    });
        } catch (Exception e) {
            LOGGER.error("Error updating cluster {}", id, e);
            ApiError err = new ApiError(400, "Bad Request", e.getMessage(), "/api/clusters/" + id);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable String id) {
        boolean ok = clusterService.deleteCluster(id);
        if (ok) return ResponseEntity.ok().build();
        ApiError err = new ApiError(404, "Not Found", "Cluster does not exist: " + id, "/api/clusters/" + id);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
    }

    @PostMapping("/{id}/test-connection")
    public ResponseEntity<Map<String, Object>> testConnection(@PathVariable String id) {
        Optional<Cluster> opt = clusterService.getClusterById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("success", false, "error", "Cluster does not exist: " + id));
        }
        Map<String, Object> res = kubernetesService.testConnection(opt.get());
        return ResponseEntity.ok(res);
    }

    @PostMapping("/{id}/kubectl")
    public ResponseEntity<Map<String, Object>> executeKubectl(
            @PathVariable String id,
            @RequestParam(name = "args", required = false) List<String> args,
            @RequestBody(required = false) Map<String, Object> body
    ) {
        Optional<Cluster> opt = clusterService.getClusterById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("success", false, "error", "Cluster does not exist: " + id));
        }

        List<String> effectiveArgs = args != null ? args : extractArgsFromBody(body);
        if (effectiveArgs == null) effectiveArgs = Collections.emptyList();

        Map<String, Object> res = kubernetesService.executeKubectl(opt.get(), effectiveArgs);
        return ResponseEntity.ok(res);
    }

    private List<String> extractArgsFromBody(Map<String, Object> body) {
        if (body == null) return null;
        Object a = body.get("args");
        if (a instanceof List<?>) {
            List<?> raw = (List<?>) a;
            List<String> out = new ArrayList<>();
            for (Object o : raw) {
                if (o != null) out.add(String.valueOf(o));
            }
            return out;
        }
        return null;
    }
}