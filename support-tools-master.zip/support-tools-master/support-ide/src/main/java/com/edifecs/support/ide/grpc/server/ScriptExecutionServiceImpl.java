/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.grpc.server;

import com.edifecs.support.Storage;
import com.edifecs.support.core.ProcessHelper;
import com.edifecs.support.core.Provider;
import com.edifecs.support.core.ZipWalker;
import com.edifecs.support.ide.grpc.*;
import com.edifecs.support.ide.service.ScriptService;
import com.edifecs.support.scripts.Metadata;
import io.grpc.stub.StreamObserver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Optional;

/**
 * Implementation of the gRPC ScriptExecutionService.
 * This service handles script execution requests from remote clients.
 */
@SuppressWarnings({"squid:S1192", "squid:S3776"})
public class ScriptExecutionServiceImpl extends ScriptExecutionServiceGrpc.ScriptExecutionServiceImplBase {

    private static final Logger LOGGER = LogManager.getLogger(ScriptExecutionServiceImpl.class);
    private static final String DESTINATION_PROPERTY = "destination";

    private final String authToken;
    private final String toolLocation;
    private final ScriptService scriptService; // optional, may be null when not running in Spring

    public ScriptExecutionServiceImpl(String authToken, String toolLocation) {
        this(authToken, toolLocation, null);
    }

    public ScriptExecutionServiceImpl(String authToken, String toolLocation, ScriptService scriptService) {
        this.authToken = authToken;
        this.toolLocation = toolLocation != null ? toolLocation : "/tmp";
        this.scriptService = (scriptService != null) ? scriptService : initScriptService();
    }

    private ScriptService initScriptService() {
        try {
            final ScriptService ss = Provider.instance().get(ScriptService.class);
            if (toolLocation != null) {
                Storage.toolPath(toolLocation);
            }
            return ss;
        } catch (Exception t) {
            LOGGER.warn("Failed to initialize ScriptService via Provider: {}", t.getMessage());
            return null;
        }
    }

    private void applyServiceResult(ExecuteScriptResponse.Builder builder, Map<String, Object> serviceResult) throws IOException {
        if (serviceResult == null) {
            return;
        }
        Object successObj = serviceResult.get("success");
        if (successObj instanceof Boolean) {
            builder.setSuccess((Boolean) successObj);
        } else if (successObj != null) {
            builder.setSuccess(Boolean.parseBoolean(successObj.toString()));
        }
        Object outputObj = serviceResult.get("output");
        if (outputObj != null) {
            builder.setOutput(outputObj.toString());
        }
        Object errorObj = serviceResult.get("error");
        if (errorObj != null) {
            builder.setError(errorObj.toString());
        }
        Object destObj = serviceResult.get(DESTINATION_PROPERTY);
        if (destObj != null) {
            final Path dPath = Paths.get(destObj.toString());
            if (dPath.toFile().isDirectory()) {
                final Path parent = dPath.getParent();
                if (parent != null) {
                    final Path dzPath = parent.resolve(dPath.getFileName().toString() + ".zip");
                    ZipWalker.zipIt(dPath, dzPath);
                    builder.setDestination(dzPath.toString());
                    serviceResult.put(DESTINATION_PROPERTY, builder.getDestination());
                } else {
                    builder.setDestination(destObj.toString());
                }
            } else {
                builder.setDestination(destObj.toString());
            }
        }
        Object resultObj = serviceResult.get("result");
        if (resultObj instanceof Map<?, ?>) {
            Map<?, ?> map = (Map<?, ?>) resultObj;
            for (Map.Entry<?, ?> e : map.entrySet()) {
                String k = e.getKey() != null ? e.getKey().toString() : "null";
                String v = e.getValue() != null ? e.getValue().toString() : "";
                builder.putResult(k, v);
            }
        } else if (resultObj != null) {
            builder.putResult("result", resultObj.toString());
        }
    }
    @SuppressWarnings("squid:S2142")
    @Override
    public void executeScript(ExecuteScriptRequest request, StreamObserver<ExecuteScriptResponse> responseObserver) {
        LOGGER.info("Received ExecuteScript request");
        ExecuteScriptResponse.Builder responseBuilder = ExecuteScriptResponse.newBuilder();
        if (authToken != null && !authToken.isEmpty() && !authToken.equals(request.getAuthToken())) {
            responseBuilder.setSuccess(false).setError("Invalid authentication token");
            responseObserver.onNext(responseBuilder.build());
            responseObserver.onCompleted();
            return;
        }
        try {
            Optional<Metadata> mdOpt = Optional.empty();
            if (request.hasMetadata() && !request.getMetadata().getContent().isEmpty()) {
                mdOpt = scriptService.findScript(request.getMetadata().getName());
            }

            boolean executed = false;
            if (mdOpt.isEmpty()) {
                // Prefer ScriptService, similar to ScriptController#executeScript
                LOGGER.info("Executing script by name: {}", request.getScriptName());
                if (scriptService != null) {
                    mdOpt = scriptService.findScript(request.getScriptName());
                }
            }
            String[] args = request.getArgsList().toArray(new String[0]);
            if (mdOpt.isPresent()) {
                final Metadata metadata = mdOpt.get();
                Map<String, Object> serviceResult = scriptService.executeScript(metadata, args);
                applyServiceResult(responseBuilder, serviceResult);
                executed = true;
            } else {
                String targetLocation = request.getToolLocation().isEmpty() ? toolLocation : request.getToolLocation();
                Path toolPath = Paths.get(targetLocation);
                // Try the alternative method once
                Path runner = toolPath.resolve("script-runner.sh");
                if (Files.isRegularFile(runner)) {
                    ProcessResult result = executeScriptRunner(toolPath, request.getScriptContent(), args);
                    responseBuilder.setSuccess(result.exitCode == 0).setDestination(toolPath.toString()).setOutput(result.stdout);
                    executed = true;
                    if (result.stderr != null && !result.stderr.isEmpty()) {
                        responseBuilder.setError(result.stderr);
                    }
                }
            }
            if (!executed) {
                responseBuilder.setSuccess(false).setError("Neither script name nor content provided. Execution skipped.");
            }
        } catch (Exception e) {
            LOGGER.error("Error executing script: {}", e.getMessage(), e);
            responseBuilder.setSuccess(false).setError("Script execution failed: " + e.getMessage());
        }
        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public void testConnection(TestConnectionRequest request, StreamObserver<TestConnectionResponse> responseObserver) {
        LOGGER.info("Received TestConnection request");

        TestConnectionResponse.Builder responseBuilder = TestConnectionResponse.newBuilder();
        try {
            // Validate auth token if configured
            if (authToken != null && !authToken.isEmpty() && !authToken.equals(request.getAuthToken())) {
                responseBuilder.setSuccess(false)
                        .setError("Invalid authentication token");
            } else {
                responseBuilder.setSuccess(true)
                        .setMessage("Connection successful");
            }

        } catch (Exception e) {
            LOGGER.error("Error testing connection: {}", e.getMessage(), e);
            responseBuilder.setSuccess(false)
                    .setError("Connection test failed: " + e.getMessage());
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public void downloadFile(DownloadFileRequest request, StreamObserver<DownloadFileResponse> responseObserver) {
        LOGGER.info("Received DownloadFile request for path: {}", request.getFilePath());
        
        DownloadFileResponse.Builder responseBuilder = DownloadFileResponse.newBuilder();
        
        try {
            // Validate auth token if configured
            if (authToken != null && !authToken.isEmpty() && !authToken.equals(request.getAuthToken())) {
                responseBuilder.setSuccess(false)
                        .setError("Invalid authentication token");
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            // Validate file path
            String filePath = request.getFilePath();
            if (filePath == null || filePath.trim().isEmpty()) {
                responseBuilder.setSuccess(false)
                        .setError("File path cannot be empty");
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            Path path = Paths.get(filePath);
            
            // Check if file exists and is readable
            if (!Files.exists(path)) {
                responseBuilder.setSuccess(false)
                        .setError("File does not exist: " + filePath);
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            if (!Files.isRegularFile(path)) {
                responseBuilder.setSuccess(false)
                        .setError("Path is not a regular file: " + filePath);
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            if (!Files.isReadable(path)) {
                responseBuilder.setSuccess(false)
                        .setError("File is not readable: " + filePath);
                responseObserver.onNext(responseBuilder.build());
                responseObserver.onCompleted();
                return;
            }

            // Stream file content in chunks to avoid memory issues
            String fileName = path.getFileName().toString();
            long fileSize = Files.size(path);
            
            LOGGER.info("Starting streaming download for file: {} (size: {} bytes)", fileName, fileSize);
            
            // Define chunk size (64KB)
            int chunkSize = 64 * 1024;
            byte[] buffer = new byte[chunkSize];
            
            try (java.io.InputStream inputStream = Files.newInputStream(path);
                 java.io.BufferedInputStream bufferedInputStream = new java.io.BufferedInputStream(inputStream)) {
                
                int bytesRead;
                long totalBytesRead = 0;
                
                while ((bytesRead = bufferedInputStream.read(buffer)) != -1) {
                    totalBytesRead += bytesRead;
                    boolean isLastChunk = totalBytesRead >= fileSize;
                    
                    // Create chunk data (only the bytes that were actually read)
                    byte[] chunkData = new byte[bytesRead];
                    System.arraycopy(buffer, 0, chunkData, 0, bytesRead);
                    
                    DownloadFileResponse chunkResponse = DownloadFileResponse.newBuilder()
                            .setSuccess(true)
                            .setChunkData(com.google.protobuf.ByteString.copyFrom(chunkData))
                            .setFileName(fileName)
                            .setFileSize(fileSize)
                            .setIsLastChunk(isLastChunk)
//                            .setServerName(serverName)
                            .build();
                    
                    responseObserver.onNext(chunkResponse);
                }
                
                LOGGER.info("Successfully streamed file: {} ({} bytes in {} chunks)", 
                           fileName, totalBytesRead, Math.ceil((double) totalBytesRead / chunkSize));
                
                responseObserver.onCompleted();
                return;
            }

        } catch (IOException e) {
            LOGGER.error("Error reading file: {}", e.getMessage(), e);
            responseBuilder.setSuccess(false)
                    .setError("Failed to read file: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.error("Unexpected error during file download: {}", e.getMessage(), e);
            responseBuilder.setSuccess(false)
                    .setError("File download failed: " + e.getMessage());
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public StreamObserver<UploadFileRequest> uploadFile(final StreamObserver<UploadFileResponse> responseObserver) {
        LOGGER.info("Received UploadFile request (client-streaming)");
        return new UploadStreamObserver(responseObserver);
    }

    /**
     * Execute script using script-runner.sh in the extracted tool directory.
     */
    private static class ProcessResult {
        final int exitCode;
        final String stdout;
        final String stderr;

        ProcessResult(int exitCode, String stdout, String stderr) {
            this.exitCode = exitCode;
            this.stdout = stdout;
            this.stderr = stderr;
        }
    }

    private ProcessResult executeScriptRunner(Path toolPath, String scriptName, String[] args) throws IOException {
        // Execute script-runner.sh with arguments using ProcessHelper in the specified directory
        LOGGER.info("Executing script runner in directory: {} with script: {}", toolPath, scriptName);
        java.util.List<String> argList = new java.util.ArrayList<>();
        argList.add(scriptName);
        if (args != null && args.length > 0) {
            java.util.Collections.addAll(argList, args);
        }
        final ProcessHelper helper;
        if (ProcessHelper.isLinux()) {
            helper = new ProcessHelper("./script-runner.sh", argList.toArray(new String[0]));
        } else {
            helper = new ProcessHelper(".\\script-runner.bat", argList.toArray(new String[0]));
        }
        helper.withDirectory(toolPath.toFile());
        ProcessHelper.Result result = helper.executeAndGetResult();
        return new ProcessResult(result.getRc(), result.getOutput(), "");
    }

    private class UploadStreamObserver implements StreamObserver<UploadFileRequest>, AutoCloseable {
        private final StreamObserver<UploadFileResponse> responseObserver;
        private java.io.OutputStream out;
        private Path tempFile;
        private Path targetDir;
        private String fileName;
        private long received;
        private boolean initialized;
        private boolean finished;

        public UploadStreamObserver(StreamObserver<UploadFileResponse> responseObserver) {
            this.responseObserver = responseObserver;
            received = 0L;
            initialized = false;
            finished = false;
        }

        private void fail(String message, Throwable t) {
            LOGGER.error("Upload failed: {}", message, t);
            try { if (out != null) out.close(); } catch (IOException ignore) { /*noop*/ }
            try {
                if (tempFile != null) {
                    Files.deleteIfExists(tempFile);
                }
            } catch (IOException ignore) { /*noop*/ }
            responseObserver.onNext(UploadFileResponse.newBuilder()
                    .setSuccess(false)
                    .setError(message)
                    .setBytesReceived(received)
                    .build());
            responseObserver.onCompleted();
            finished = true;
        }

        private void initIfNeeded(UploadFileRequest req) {
            if (initialized) return;
            // Validate auth token
            if (authToken != null && !authToken.isEmpty() && !authToken.equals(req.getAuthToken())) {
                fail("Invalid authentication token", null);
                return;
            }
            // Determine destination directory and file name
            String destPath = (req.getDestinationPath() != null && !req.getDestinationPath().isEmpty())
                    ? req.getDestinationPath() : toolLocation;
            fileName = (req.getFileName() != null && !req.getFileName().isEmpty())
                    ? req.getFileName() : ("uploaded-" + System.currentTimeMillis());
            try {
                targetDir = Paths.get(destPath);
                Files.createDirectories(targetDir);
                tempFile = Files.createTempFile(targetDir, ".upload-", ".part");
                // Use a larger buffer to align with typical gRPC chunk sizes for efficiency
                out = new java.io.BufferedOutputStream(
                        Files.newOutputStream(tempFile, java.nio.file.StandardOpenOption.WRITE),
                        com.edifecs.support.ide.service.GrpcServer.DEFAULT_CHUNK_SIZE);
                initialized = true;
                LOGGER.info("Initialized upload to dir: {}, temp: {}, final name: {}", targetDir, tempFile, fileName);
            } catch (Exception e) {
                fail("Failed to initialize upload: " + e.getMessage(), e);
            }
        }

        @Override
        public void onNext(UploadFileRequest req) {
            if (finished) return;
            if (!initialized) {
                initIfNeeded(req);
                if (!initialized) return; // failed during init
            }
            try {
                if (!req.getChunkData().isEmpty()) {
                    // Avoid copying into a new byte[] to be memory-efficient
                    req.getChunkData().writeTo(out);
                    received += req.getChunkData().size();
                }
            } catch (Exception e) {
                fail("I/O error while receiving data: " + e.getMessage(), e);
            }
        }

        @Override
        public void onError(Throwable t) {
            if (finished) return;
            fail("Upload stream error: " + t.getMessage(), t);
        }

        @SuppressWarnings("squid:S1141")
        @Override
        public void onCompleted() {
            if (finished) return;
            try {
                if (out != null) out.flush();
                if (out != null) out.close();
                Path finalPath = targetDir.resolve(fileName);
                try {
                    Files.move(tempFile, finalPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                } catch (Exception moveEx) {
                    // If move fails, try copy then delete
                    Files.copy(tempFile, finalPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    Files.deleteIfExists(tempFile);
                }
                UploadFileResponse resp = UploadFileResponse.newBuilder()
                        .setSuccess(true)
                        .setSavedPath(finalPath.toString())
                        .setBytesReceived(received)
                        .build();
                responseObserver.onNext(resp);
                responseObserver.onCompleted();
                LOGGER.info("Upload completed: {} ({} bytes)", finalPath, received);
            } catch (Exception e) {
                fail("Failed to finalize upload: " + e.getMessage(), e);
            }
        }

        @Override
        public void close() throws Exception {
            onCompleted();
            if (out != null) {
                out.close();
            }
        }
    }
}
