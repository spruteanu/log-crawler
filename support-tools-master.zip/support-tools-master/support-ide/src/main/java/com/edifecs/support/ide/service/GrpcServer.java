/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import com.edifecs.support.ide.grpc.*;
import com.edifecs.support.ide.model.Server;
import com.edifecs.support.scripts.Metadata;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * GrpcServer acts as a gRPC client that communicates with remote GrpcAgentService instances.
 * This service starts/stops with the support-ide web application and is responsible for:
 * - Executing remote server connectivity tests
 * - Executing selected groovy scripts on remote servers via gRPC agents
 */
@SuppressWarnings("squid:S1192")
@Service
public class GrpcServer {

    public static final int DEFAULT_MAX_MESSAGE_SIZE = 100 * 1024 * 1024;
    public static final int DEFAULT_PORT = 9090;
    private static final Logger LOGGER = LogManager.getLogger(GrpcServer.class);

    public static final int DEFAULT_CHUNK_SIZE = 64 * 1024;

    private String grpcHost;
    private int grpcPort = DEFAULT_PORT; // Default port
    private String grpcAuthToken;
    private int maxMessageSize = DEFAULT_MAX_MESSAGE_SIZE;

    public String getGrpcHost() {
        return grpcHost;
    }

    public void setGrpcHost(String grpcHost) {
        this.grpcHost = grpcHost;
    }

    public int getGrpcPort() {
        return grpcPort;
    }

    public void setGrpcPort(int grpcPort) {
        this.grpcPort = grpcPort;
    }

    public String getGrpcAuthToken() {
        return grpcAuthToken;
    }

    public void setGrpcAuthToken(String grpcAuthToken) {
        this.grpcAuthToken = grpcAuthToken;
    }

    public int getMaxMessageSize() {
        return maxMessageSize;
    }

    public void setMaxMessageSize(int maxMessageSize) {
        this.maxMessageSize = maxMessageSize;
    }

    /**
     * Configure the gRPC client settings.
     *
     * @param grpcHost      the hostname or IP address of the gRPC server
     * @param grpcPort      the port of the gRPC server
     * @param grpcAuthToken the authentication token (optional)
     */
    public void configure(String grpcHost, int grpcPort, String grpcAuthToken) {
        this.grpcHost = grpcHost;
        this.grpcPort = grpcPort;
        this.grpcAuthToken = grpcAuthToken;

        LOGGER.info("GrpcServer configured - Host: {}, Port: {}, Auth: {}",
                grpcHost, grpcPort, grpcAuthToken != null ? "enabled" : "disabled");
    }

    /**
     * Get the effective gRPC host, using fallback if not configured.
     *
     * @param fallbackHostname the fallback hostname to use
     * @return the effective hostname
     */
    public String getEffectiveGrpcHost(String fallbackHostname) {
        if (grpcHost != null && !grpcHost.trim().isEmpty()) {
            return grpcHost;
        }
        return fallbackHostname;
    }

    /**
     * Execute a script with tool image on a remote server using gRPC.
     * This method is equivalent to SshService.executeScriptWithToolImage().
     *
     * @param server   the server configuration
     * @param metadata the script metadata
     * @param args     the script arguments
     * @return a map containing the execution results
     */
    public Map<String, Object> executeScript(Server server, Metadata metadata, String[] args) {
        Map<String, Object> result = new HashMap<>();
        ManagedChannel channel = null;

        try {
            // Create gRPC channel
            channel = createChannel(server);
            ScriptExecutionServiceGrpc.ScriptExecutionServiceBlockingStub stub =
                    ScriptExecutionServiceGrpc.newBlockingStub(channel);

            // Build request
            ExecuteScriptRequest.Builder requestBuilder =
                    ExecuteScriptRequest.newBuilder()
                            .setScriptName(metadata.getName())
                            .setToolLocation(server.getToolLocation());

            // Prefer inline content from metadata when provided via the protobuf ScriptMetadata
            String inline = metadata.getContent();
            if (inline != null && !inline.trim().isEmpty()) {
                ScriptMetadata.Builder mdBuilder = ScriptMetadata.newBuilder();
                mdBuilder.setContent(inline);
                mdBuilder.setName(metadata.getName());
                mdBuilder.setType(metadata.getType());
                requestBuilder.setMetadata(mdBuilder.build());
            }

            if (grpcAuthToken != null) {
                requestBuilder.setAuthToken(grpcAuthToken);
            }

            for (String arg : args) {
                requestBuilder.addArgs(arg);
            }

            // Execute the request
            ExecuteScriptResponse response = stub.executeScript(requestBuilder.build());

            // Convert response to result map
            result.put("success", response.getSuccess());
            result.put("output", response.getOutput());

            if (!response.getError().isEmpty()) {
                result.put("error", response.getError());
            }

            if (!response.getResultMap().isEmpty()) {
                result.put("result", new HashMap<>(response.getResultMap()));
            }

            if (!response.getDestination().isEmpty()) {
                result.put("destination", response.getDestination());
            }

        } catch (StatusRuntimeException e) {
            LOGGER.error("gRPC call failed for server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", "gRPC call failed: " + e.getStatus().getDescription());
        } catch (Exception e) {
            LOGGER.error("Error executing script with tool image via gRPC on server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", "Error executing script: " + e.getMessage());
        } finally {
            if (channel != null) {
                closeChannel(channel);
            }
        }

        return result;
    }

    /**
     * Test connection to a gRPC server.
     *
     * @param server the server configuration
     * @return a map containing the connection test results
     */
    public Map<String, Object> testConnection(Server server) {
        Map<String, Object> result = new HashMap<>();
        ManagedChannel channel = null;

        try {
            // Create gRPC channel
            channel = createChannel(server);
            ScriptExecutionServiceGrpc.ScriptExecutionServiceBlockingStub stub =
                    ScriptExecutionServiceGrpc.newBlockingStub(channel);

            // Build request
            TestConnectionRequest.Builder requestBuilder = TestConnectionRequest.newBuilder();
            if (grpcAuthToken != null) {
                requestBuilder.setAuthToken(grpcAuthToken);
            }

            // Execute the request
            TestConnectionResponse response = stub.testConnection(requestBuilder.build());

            // Convert response to result map
            result.put("success", response.getSuccess());
            result.put("message", response.getMessage());

            if (!response.getError().isEmpty()) {
                result.put("error", response.getError());
            }

        } catch (StatusRuntimeException e) {
            LOGGER.error("gRPC connection test failed for server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", "gRPC connection test failed: " + e.getStatus().getDescription());
        } catch (Exception e) {
            LOGGER.error("Error testing gRPC connection to server: {}", server.getName(), e);
            result.put("success", false);
            result.put("error", "Error testing connection: " + e.getMessage());
        } finally {
            if (channel != null) {
                closeChannel(channel);
            }
        }

        return result;
    }

    /**
     * Upload a local file to the remote gRPC agent.
     * @param server target server
     * @param localFile path to local file
     * @param destinationPath destination directory on server (if null/empty, server default is used)
     * @param remoteFileName desired file name on server (if null/empty, server picks a name)
     */
    @SuppressWarnings("squid:S3776")
    public Map<String, Object> uploadFile(Server server, java.nio.file.Path localFile, String destinationPath, String remoteFileName) {
        Map<String, Object> result = new HashMap<>();
        ManagedChannel channel = null;
        try {
            if (localFile == null || !java.nio.file.Files.isReadable(localFile)) {
                result.put("success", false);
                result.put("error", "Local file is not readable: " + localFile);
                return result;
            }
            channel = createChannel(server);
            ScriptExecutionServiceGrpc.ScriptExecutionServiceStub asyncStub = ScriptExecutionServiceGrpc.newStub(channel);

            final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
            final java.util.concurrent.atomic.AtomicReference<UploadFileResponse> responseRef = new java.util.concurrent.atomic.AtomicReference<>();
            final java.util.concurrent.atomic.AtomicReference<Throwable> errorRef = new java.util.concurrent.atomic.AtomicReference<>();

            StreamObserver<UploadFileResponse> responseObserver = new StreamObserver<>() {
                @Override
                public void onNext(UploadFileResponse value) {
                    responseRef.set(value);
                }

                @Override
                public void onError(Throwable t) {
                    errorRef.set(t);
                    latch.countDown();
                }

                @Override
                public void onCompleted() {
                    latch.countDown();
                }
            };

            StreamObserver<UploadFileRequest> requestObserver = asyncStub.uploadFile(responseObserver);

            // First chunk can carry metadata too; we'll include auth/destination/file name on each message for simplicity
            int chunkSize = DEFAULT_CHUNK_SIZE;
            byte[] buffer = new byte[chunkSize];
            long totalSent = 0L;
            try (java.io.InputStream in = new java.io.BufferedInputStream(java.nio.file.Files.newInputStream(localFile))) {
                int read;
                while ((read = in.read(buffer)) != -1) {
                    UploadFileRequest.Builder builder = UploadFileRequest.newBuilder();
                    if (grpcAuthToken != null) builder.setAuthToken(grpcAuthToken);
                    if (destinationPath != null) builder.setDestinationPath(destinationPath);
                    if (remoteFileName != null) builder.setFileName(remoteFileName);
                    builder.setChunkData(com.google.protobuf.ByteString.copyFrom(buffer, 0, read));
                    builder.setTotalSize(java.nio.file.Files.size(localFile));
                    requestObserver.onNext(builder.build());
                    totalSent += read;
                }
            }
            requestObserver.onCompleted();

            // Wait for server response
            if (!latch.await(60, java.util.concurrent.TimeUnit.SECONDS)) {
                throw new RuntimeException("Timed out waiting for upload response");
            }
            if (errorRef.get() != null) {
                throw new RuntimeException("Upload failed: " + errorRef.get().getMessage(), errorRef.get());
            }
            UploadFileResponse resp = responseRef.get();
            if (resp != null) {
                result.put("success", resp.getSuccess());
                if (!resp.getError().isEmpty()) result.put("error", resp.getError());
                if (!resp.getSavedPath().isEmpty()) result.put("savedPath", resp.getSavedPath());
                result.put("bytesReceived", resp.getBytesReceived());
            } else {
                result.put("success", false);
                result.put("error", "No response from server");
            }
        } catch (Exception e) {
            LOGGER.error("Error uploading file via gRPC to server: " + server.getName(), e);
            result.put("success", false);
            result.put("error", e.getMessage());
        } finally {
            if (channel != null) {
                closeChannel(channel);
            }
        }
        return result;
    }

    /**
     * Create a gRPC channel for connecting to a server.
     *
     * @param server the server configuration
     * @return the managed channel
     */
    private ManagedChannel createChannel(Server server) {
        String host = getEffectiveGrpcHost(server.getHostname());
        int port = server.getGrpcPort();

        LOGGER.debug("Creating gRPC channel to {}:{}", host, port);

        return ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext() // For simplicity, using plaintext. In production, consider TLS.
                .maxInboundMessageSize(maxMessageSize)
                .build();
    }

    /**
     * Close a gRPC channel gracefully.
     *
     * @param channel the channel to close
     */
    private void closeChannel(ManagedChannel channel) {
        try {
            channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            LOGGER.warn("Interrupted while shutting down gRPC channel", e);
            channel.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

}
