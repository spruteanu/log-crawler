package com.edifecs.support.ide.controller;

import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Profile("ide")
public class SettingsPageController {

    // Deprecated endpoints: static pages removed in favor of Angular routes
    @GetMapping(value = "/support-ide/settings", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<Void> settingsPage() {
        return ResponseEntity.notFound().build();
    }

    @GetMapping(value = "/support-ide/users", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<Void> usersPage() {
        return ResponseEntity.notFound().build();
    }
}
