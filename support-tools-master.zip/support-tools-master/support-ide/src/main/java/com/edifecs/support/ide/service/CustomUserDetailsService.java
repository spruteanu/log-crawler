package com.edifecs.support.ide.service;

import com.edifecs.support.ide.model.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Collection;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class CustomUserDetailsService implements UserDetailsService {

    private final UserService userService;

    public CustomUserDetailsService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User u = userService.getUser(username).orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
        Collection<? extends GrantedAuthority> authorities = mapRoles(u.getRoles());
        // Provide encoded password in format salt:hash for PasswordEncoder to verify
        String encoded = (u.getSalt() == null ? "" : u.getSalt()) + ":" + (u.getPasswordHash() == null ? "" : u.getPasswordHash());
        return new org.springframework.security.core.userdetails.User(u.getUsername(), encoded, u.isEnabled(), true, true, true, authorities) {
        };
    }

    private Collection<? extends GrantedAuthority> mapRoles(Set<String> roles) {
        if (roles == null) return Set.of();
        return roles.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(String::toUpperCase)
                .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toSet());
    }
}
