/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Base64;

/**
 * Service for encrypting and decrypting sensitive data like passwords.
 */
@Service
public class EncryptionService {

    @Value("${support.encryption.key.file:results/encryption/key.dat}")
    private String keyFilePath;

    private TextEncryptor encryptor;
    private String salt;
    private String password;

    /**
     * Initialize the encryption service.
     * Generates or loads encryption keys.
     */
    @PostConstruct
    public void init() throws IOException {
        Path keyFile = Paths.get(keyFilePath);
        
        // Create directories if they don't exist
        if (!Files.exists(keyFile.getParent())) {
            Files.createDirectories(keyFile.getParent());
        }
        
        // Generate or load encryption keys
        if (Files.exists(keyFile)) {
            String[] keyData = new String(Files.readAllBytes(keyFile), StandardCharsets.UTF_8).split(":");
            if (keyData.length == 2) {
                password = keyData[0];
                salt = keyData[1];
            } else {
                generateNewKeys(keyFile);
            }
        } else {
            generateNewKeys(keyFile);
        }
        
        // Create the encryptor
        encryptor = Encryptors.text(password, salt);
    }
    
    /**
     * Generate new encryption keys and save them to the key file.
     */
    private void generateNewKeys(Path keyFile) throws IOException {
        // Generate a random password and salt
        password = KeyGenerators.string().generateKey();
        salt = KeyGenerators.string().generateKey();
        
        // Save the keys to the file
        String keyData = password + ":" + salt;
        Files.write(keyFile, keyData.getBytes(StandardCharsets.UTF_8), 
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    /**
     * Encrypt a plaintext string.
     * 
     * @param plaintext The plaintext to encrypt
     * @return The encrypted text, or null if the input is null
     */
    public String encrypt(String plaintext) {
        if (plaintext == null) {
            return null;
        }
        return encryptor.encrypt(plaintext);
    }
    
    /**
     * Decrypt an encrypted string.
     * 
     * @param encrypted The encrypted text to decrypt
     * @return The decrypted plaintext, or null if the input is null
     */
    public String decrypt(String encrypted) {
        if (encrypted == null) {
            return null;
        }
        return encryptor.decrypt(encrypted);
    }
    
    /**
     * Encrypt a plaintext string for frontend use.
     * This is a simpler encryption that can be decrypted by the frontend.
     * 
     * @param plaintext The plaintext to encrypt
     * @return Base64 encoded encrypted text
     */
    public String encryptForFrontend(String plaintext) {
        if (plaintext == null) {
            return null;
        }
        // Simple XOR encryption with the first 8 chars of the password as key
        String key = password.substring(0, Math.min(8, password.length()));
        byte[] encrypted = xorEncrypt(plaintext.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }
    
    /**
     * Decrypt a string encrypted for frontend use.
     * 
     * @param encrypted Base64 encoded encrypted text
     * @return The decrypted plaintext
     */
    public String decryptFromFrontend(String encrypted) {
        if (encrypted == null) {
            return null;
        }
        // Simple XOR decryption with the first 8 chars of the password as key
        String key = password.substring(0, Math.min(8, password.length()));
        byte[] encryptedBytes = Base64.getDecoder().decode(encrypted);
        byte[] decrypted = xorEncrypt(encryptedBytes, key.getBytes(StandardCharsets.UTF_8));
        return new String(decrypted, StandardCharsets.UTF_8);
    }
    
    /**
     * Get the encryption key for frontend use.
     * This returns the same key that decryptFromFrontend uses.
     * 
     * @return The encryption key for frontend use
     */
    public String getFrontendEncryptionKey() {
        // Return the same key that decryptFromFrontend uses
        return password.substring(0, Math.min(8, password.length()));
    }
    
    /**
     * Simple XOR encryption/decryption.
     * 
     * @param data The data to encrypt/decrypt
     * @param key The encryption key
     * @return The encrypted/decrypted data
     */
    private byte[] xorEncrypt(byte[] data, byte[] key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte) (data[i] ^ key[i % key.length]);
        }
        return result;
    }
}
