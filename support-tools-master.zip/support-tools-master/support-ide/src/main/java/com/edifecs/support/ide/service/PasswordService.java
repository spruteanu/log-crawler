package com.edifecs.support.ide.service;

import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

@Service
public class PasswordService {

    private static final String HASH_ALGO = "SHA-256"; // simple but better than plain text
    private final SecureRandom random = new SecureRandom();

    public String generateSalt() {
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public String hash(String rawPassword, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance(HASH_ALGO);
            md.update(Base64.getDecoder().decode(salt));
            byte[] digest = md.digest(rawPassword.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Hash algorithm not available: " + HASH_ALGO, e);
        }
    }

    public boolean matches(String rawPassword, String salt, String expectedHash) {
        return hash(rawPassword, salt).equals(expectedHash);
    }
}
