package com.edifecs.support.ide.service;

/**
 * Functional interface for progress callback.
 */
@FunctionalInterface
public interface ProgressCallback {
    void sendProgress(String sessionId, String status, String message);

    class MockProgressCallback implements ProgressCallback {
        @Override
        public void sendProgress(String sessionId, String status, String message) {
            /*noop*/
        }
    }
}

