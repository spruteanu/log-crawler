package com.edifecs.support.ide.controller;

import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Profile("ide")
@RestController
public class LoginPageController {

    @GetMapping(value = "/login", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<Resource> loginPage() {
        Resource res = new ClassPathResource("static/login.html");
        if (res.exists()) {
            return ResponseEntity.ok(res);
        }
        return ResponseEntity.notFound().build();
    }
}
