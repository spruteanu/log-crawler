package com.edifecs.support.ide.controller;

import com.edifecs.support.ide.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@org.springframework.context.annotation.Profile("ide")
@SuppressWarnings({"squid:S1452", "squid:S1192"})
@RequestMapping("/api/roles")
public class RolesController {
    private final UserService userService;

    public RolesController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public Set<String> list() {
        return userService.listRoles();
    }

    public static class CreateRoleRequest {
        public String name;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateRoleRequest req) {
        if (req == null || req.name == null || req.name.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Role name is required"));
        }
        boolean ok = userService.addRole(req.name.trim());
        if (!ok) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Role already exists or invalid"));
        }
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    public static class RenameRoleRequest {
        public String newName;
    }

    @PutMapping("/{name}")
    public ResponseEntity<?> rename(@PathVariable("name") String name, @RequestBody RenameRoleRequest req) {
        if (req == null || req.newName == null || req.newName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "New role name is required"));
        }
        boolean ok = userService.renameRole(name, req.newName.trim());
        return ok ? ResponseEntity.ok().build() : ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Role not found or new name in use"));
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<?> delete(@PathVariable("name") String name) {
        boolean ok = userService.deleteRole(name);
        return ok ? ResponseEntity.ok().build() : ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Role not found"));
    }
}
