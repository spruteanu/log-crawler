/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.config;

import com.edifecs.support.ide.grpc.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration test for gRPC server functionality.
 */
@SpringBootTest
@TestPropertySource(properties = {
    "grpc.server.enabled=true",
    "grpc.server.port=9091", // Use different port to avoid conflicts
    "grpc.server.auth-token=test-token",
    "grpc.server.tool-location=/tmp/test",
    "server.port=0" // Use random port for web server
})
class GrpcServerIntegrationTest {

    @Autowired
    private GrpcServerManager grpcServerManager;

    private ManagedChannel channel;
    private ScriptExecutionServiceGrpc.ScriptExecutionServiceBlockingStub stub;

    @BeforeEach
    void setUp() {
        // Wait a bit for the gRPC server to start
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Create gRPC client
        channel = ManagedChannelBuilder.forAddress("localhost", 9091)
                .usePlaintext()
                .build();
        stub = ScriptExecutionServiceGrpc.newBlockingStub(channel);
    }

    @AfterEach
    void tearDown() {
        if (channel != null) {
            try {
                channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Test
    void testGrpcServerIsRunning() {
        assertTrue(grpcServerManager.isServerRunning(), "gRPC server should be running");
        assertTrue(grpcServerManager.isGrpcServerEnabled(), "gRPC server should be enabled");
        assertEquals(9091, grpcServerManager.getGrpcServerPort(), "gRPC server port should be 9091");
    }

    @Test
    void testTestConnectionWithValidToken() {
        TestConnectionRequest request = TestConnectionRequest.newBuilder()
                .setAuthToken("test-token")
                .build();

        TestConnectionResponse response = stub.testConnection(request);

        assertTrue(response.getSuccess(), "Connection test should succeed with valid token");
        assertEquals("Connection successful", response.getMessage());
        assertTrue(response.getError().isEmpty(), "Error should be empty for successful connection");
    }

    @Test
    void testTestConnectionWithInvalidToken() {
        TestConnectionRequest request = TestConnectionRequest.newBuilder()
                .setAuthToken("invalid-token")
                .build();

        TestConnectionResponse response = stub.testConnection(request);

        assertFalse(response.getSuccess(), "Connection test should fail with invalid token");
        assertEquals("Invalid authentication token", response.getError());
    }

    @Test
    void testExecuteScriptWithValidToken() {
        ExecuteScriptRequest request = ExecuteScriptRequest.newBuilder()
                .setAuthToken("test-token")
                .setScriptContent("echo 'Hello World'")
                .build();

        ExecuteScriptResponse response = stub.executeScript(request);

        assertTrue(response.getSuccess(), "Script execution should succeed with valid token");
        assertTrue(response.getOutput().contains("Hello World"), "Output should contain expected text");
    }

    @Test
    void testExecuteScriptWithInvalidToken() {
        ExecuteScriptRequest request = ExecuteScriptRequest.newBuilder()
                .setAuthToken("invalid-token")
                .setScriptContent("echo 'Hello World'")
                .build();

        ExecuteScriptResponse response = stub.executeScript(request);

        assertFalse(response.getSuccess(), "Script execution should fail with invalid token");
        assertEquals("Invalid authentication token", response.getError());
    }


    @Test
    void testExecuteScriptWithContentField() {
        ExecuteScriptRequest.Builder builder = ExecuteScriptRequest.newBuilder()
                .setAuthToken("test-token");
        try {
            java.lang.reflect.Method m = builder.getClass().getMethod("setContent", String.class);
            m.invoke(builder, "echo 'Hello Content'");
        } catch (Exception e) {
            // Fallback for older stubs where 'content' is unavailable
            builder.setScriptContent("echo 'Hello Content'");
        }
        ExecuteScriptRequest request = builder.build();

        ExecuteScriptResponse response = stub.executeScript(request);

        assertTrue(response.getSuccess(), "Script execution should succeed with valid token");
        assertTrue(response.getOutput().contains("Hello Content"), "Output should contain expected text from content");
    }

    @Test
    void testDownloadFileWithValidToken() throws IOException {
        // Create a temporary test file
        Path tempFile = Files.createTempFile("test-download", ".txt");
        String testContent = "This is a test file for download";
        Files.write(tempFile, testContent.getBytes());

        try {
            DownloadFileRequest request = DownloadFileRequest.newBuilder()
                    .setAuthToken("test-token")
                    .setFilePath(tempFile.toString())
                    .build();

            // Collect all streaming chunks
            java.util.Iterator<DownloadFileResponse> responseIterator = stub.downloadFile(request);
            java.io.ByteArrayOutputStream fileContent = new java.io.ByteArrayOutputStream();
            String fileName = null;
            long fileSize = 0;
            boolean success = false;
            
            while (responseIterator.hasNext()) {
                DownloadFileResponse chunk = responseIterator.next();
                success = chunk.getSuccess();
                if (!success) {
                    fail("File download should succeed with valid token: " + chunk.getError());
                }
                fileName = chunk.getFileName();
                fileSize = chunk.getFileSize();
                fileContent.write(chunk.getChunkData().toByteArray());
            }

            assertTrue(success, "File download should succeed with valid token");
            assertEquals(tempFile.getFileName().toString(), fileName);
            assertEquals(testContent, new String(fileContent.toByteArray()));
            assertEquals(testContent.length(), fileSize);
        } finally {
            // Cleanup
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testDownloadFileWithInvalidToken() throws IOException {
        // Create a temporary test file
        Path tempFile = Files.createTempFile("test-download", ".txt");
        Files.write(tempFile, "Test content".getBytes());

        try {
            DownloadFileRequest request = DownloadFileRequest.newBuilder()
                    .setAuthToken("invalid-token")
                    .setFilePath(tempFile.toString())
                    .build();

            java.util.Iterator<DownloadFileResponse> responseIterator = stub.downloadFile(request);
            assertTrue(responseIterator.hasNext(), "Should have at least one response");
            DownloadFileResponse response = responseIterator.next();

            assertFalse(response.getSuccess(), "File download should fail with invalid token");
            assertEquals("Invalid authentication token", response.getError());
        } finally {
            // Cleanup
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testDownloadNonExistentFile() {
        DownloadFileRequest request = DownloadFileRequest.newBuilder()
                .setAuthToken("test-token")
                .setFilePath("/path/to/non/existent/file.txt")
                .build();

        java.util.Iterator<DownloadFileResponse> responseIterator = stub.downloadFile(request);
        assertTrue(responseIterator.hasNext(), "Should have at least one response");
        DownloadFileResponse response = responseIterator.next();

        assertFalse(response.getSuccess(), "File download should fail for non-existent file");
        assertTrue(response.getError().contains("File does not exist"), "Error should indicate file does not exist");
    }

    @Test
    void testDownloadFileWithEmptyPath() {
        DownloadFileRequest request = DownloadFileRequest.newBuilder()
                .setAuthToken("test-token")
                .setFilePath("")
                .build();

        java.util.Iterator<DownloadFileResponse> responseIterator = stub.downloadFile(request);
        assertTrue(responseIterator.hasNext(), "Should have at least one response");
        DownloadFileResponse response = responseIterator.next();

        assertFalse(response.getSuccess(), "File download should fail for empty path");
        assertEquals("File path cannot be empty", response.getError());
    }
}