/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

/**
 * Test class for GrpcServerManager port conflict handling.
 */
class GrpcServerManagerPortConflictTest {

    private GrpcServerManager grpcServerManager;
    private List<ServerSocket> occupiedSockets;
    private static final int TEST_BASE_PORT = 19090; // Use a different port range for testing

    @BeforeEach
    void setUp() {
        grpcServerManager = new GrpcServerManager();
        occupiedSockets = new ArrayList<>();

        // Set test configuration using reflection
        ReflectionTestUtils.setField(grpcServerManager, "grpcServerEnabled", true);
        ReflectionTestUtils.setField(grpcServerManager, "grpcServerPort", TEST_BASE_PORT);
        ReflectionTestUtils.setField(grpcServerManager, "maxPortRetries", 3);
        ReflectionTestUtils.setField(grpcServerManager, "portRetryRange", 10);
        ReflectionTestUtils.setField(grpcServerManager, "grpcAuthToken", "");
        ReflectionTestUtils.setField(grpcServerManager, "grpcToolLocation", "/tmp");
    }

    @AfterEach
    void tearDown() {
        // Clean up occupied sockets
        for (ServerSocket socket : occupiedSockets) {
            try {
                if (!socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException e) {
                // Ignore cleanup errors
            }
        }
        occupiedSockets.clear();

        // Stop the gRPC server if it was started
        if (grpcServerManager.isServerRunning()) {
            grpcServerManager.stopGrpcServer();
        }
    }

    @Test
    void testGrpcServerStartsOnConfiguredPortWhenAvailable() {
        System.out.println("[DEBUG_LOG] Testing gRPC server starts on configured port when available");

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server started successfully
        assertTrue(grpcServerManager.isServerRunning(), "gRPC server should be running");
        assertEquals(TEST_BASE_PORT, grpcServerManager.getGrpcServerPort(),
            "Server should start on configured port");

        System.out.println("[DEBUG_LOG] gRPC server started successfully on port " + TEST_BASE_PORT);
    }

    @Test
    void testGrpcServerRetriesWhenConfiguredPortIsOccupied() throws IOException {
        System.out.println("[DEBUG_LOG] Testing gRPC server retries when configured port is occupied");

        // Occupy the configured port
        ServerSocket occupiedSocket = new ServerSocket(TEST_BASE_PORT);
        occupiedSockets.add(occupiedSocket);
        System.out.println("[DEBUG_LOG] Occupied port " + TEST_BASE_PORT);

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server started on alternative port
        assertTrue(grpcServerManager.isServerRunning(), "gRPC server should be running");
        assertEquals(TEST_BASE_PORT + 1, grpcServerManager.getGrpcServerPort(),
            "Server should start on next available port");

        System.out.println("[DEBUG_LOG] gRPC server started successfully on alternative port " +
            grpcServerManager.getGrpcServerPort());
    }

    @Test
    void testGrpcServerRetriesMultiplePortsWhenNeeded() throws IOException {
        System.out.println("[DEBUG_LOG] Testing gRPC server retries multiple ports when needed");

        // Occupy the first 3 ports
        for (int i = 0; i < 3; i++) {
            ServerSocket occupiedSocket = new ServerSocket(TEST_BASE_PORT + i);
            occupiedSockets.add(occupiedSocket);
            System.out.println("[DEBUG_LOG] Occupied port " + (TEST_BASE_PORT + i));
        }

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server started on the 4th port (index 3)
        assertTrue(grpcServerManager.isServerRunning(), "gRPC server should be running");
        assertEquals(TEST_BASE_PORT + 3, grpcServerManager.getGrpcServerPort(),
            "Server should start on 4th port after 3 retries");

        System.out.println("[DEBUG_LOG] gRPC server started successfully on port " +
            grpcServerManager.getGrpcServerPort() + " after multiple retries");
    }

    @Test
    void testGrpcServerFailsGracefullyWhenAllPortsOccupied() throws IOException {
        System.out.println("[DEBUG_LOG] Testing gRPC server fails gracefully when all ports occupied");

        // Occupy all retry ports (base port + maxPortRetries)
        for (int i = 0; i <= 3; i++) { // 0 to maxPortRetries (3) = 4 ports
            ServerSocket occupiedSocket = new ServerSocket(TEST_BASE_PORT + i);
            occupiedSockets.add(occupiedSocket);
            System.out.println("[DEBUG_LOG] Occupied port " + (TEST_BASE_PORT + i));
        }

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server failed to start but application continues
        assertFalse(grpcServerManager.isServerRunning(), "gRPC server should not be running");

        System.out.println("[DEBUG_LOG] gRPC server failed gracefully as expected when all ports occupied");
    }

    @Test
    void testGrpcServerDisabledConfiguration() {
        System.out.println("[DEBUG_LOG] Testing gRPC server disabled configuration");

        // Disable gRPC server
        ReflectionTestUtils.setField(grpcServerManager, "grpcServerEnabled", false);

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server is not running
        assertFalse(grpcServerManager.isServerRunning(), "gRPC server should not be running when disabled");
        assertFalse(grpcServerManager.isGrpcServerEnabled(), "gRPC server should be disabled");

        System.out.println("[DEBUG_LOG] gRPC server correctly disabled via configuration");
    }

    @Test
    void testInvalidPortConfiguration() {
        System.out.println("[DEBUG_LOG] Testing invalid port configuration");

        // Set invalid port
        ReflectionTestUtils.setField(grpcServerManager, "grpcServerPort", -1);

        // Start the server
        ApplicationReadyEvent mockEvent = mock(ApplicationReadyEvent.class);
        grpcServerManager.onApplicationEvent(mockEvent);

        // Verify server failed to start due to invalid configuration
        assertFalse(grpcServerManager.isServerRunning(), "gRPC server should not start with invalid port");

        System.out.println("[DEBUG_LOG] gRPC server correctly rejected invalid port configuration");
    }
}
