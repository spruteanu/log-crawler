/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.config;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for GrpcServerManager to verify Spring integration.
 */
@SpringBootTest
@TestPropertySource(properties = {
    "grpc.server.enabled=false", // Disable gRPC server for testing
    "server.port=0" // Use random port for web server
})
class GrpcServerManagerTest {

    @Autowired
    private GrpcServerManager grpcServerManager;

    @Test
    void testGrpcServerManagerBeanCreation() {
        assertNotNull(grpcServerManager, "GrpcServerManager should be autowired successfully");
    }

    @Test
    void testGrpcServerConfiguration() {
        // Since we disabled the gRPC server, it should not be running
        assertFalse(grpcServerManager.isServerRunning(), "gRPC server should not be running when disabled");
        assertFalse(grpcServerManager.isGrpcServerEnabled(), "gRPC server should be disabled via configuration");
    }

    @Test
    void testGrpcServerPort() {
        // Default port should be 9090 (from application.properties)
        assertEquals(9090, grpcServerManager.getGrpcServerPort(), "gRPC server port should be 9090");
    }
}
