/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

package com.edifecs.support.ide.controller

import com.edifecs.support.SupportRuntimeException
import com.edifecs.support.ide.model.ApiError
import com.edifecs.support.ide.service.ScriptService
import com.edifecs.support.scripts.Metadata
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Specification

import java.nio.file.Paths

class ScriptControllerSpec extends Specification {

    ScriptService scriptService
    ScriptController scriptController

    def setup() {
        scriptService = Mock(ScriptService)
        scriptController = new ScriptController(scriptService)
    }

    def "getAllScripts should return all scripts from the cache"() {
        given:
        def scripts = [
            new Metadata().name("script1").path("/path/to/script1"),
            new Metadata().name("script2").path("/path/to/script2")
        ]
        scriptService.getCachedScripts() >> scripts

        when:
        def response = scriptController.getAllScripts()

        then:
        response.statusCode == HttpStatus.OK
        response.body == scripts
        response.body.size() == 2
        response.body[0].name == "script1"
        response.body[1].name == "script2"
    }

    def "getScript should return the script when it exists"() {
        given:
        def scriptPath = "script1"
        def script = new Metadata().name(scriptPath).path("/path/to/script1")
        scriptService.findScript(scriptPath) >> Optional.of(script)

        when:
        def response = scriptController.getScript(scriptPath)

        then:
        response.statusCode == HttpStatus.OK
        response.body == script
        response.body.name == scriptPath
    }

    def "getScript should return 404 when the script does not exist"() {
        given:
        def scriptPath = "nonexistent"
        scriptService.findScript(scriptPath) >> Optional.empty()

        when:
        def response = scriptController.getScript(scriptPath)

        then:
        response.statusCode == HttpStatus.NOT_FOUND
        response.body == null
    }

    def "getScriptContent should return the script content when the script exists"() {
        given:
        def scriptPath = "script1"
        def script = new Metadata().name(scriptPath).path("/path/to/script1")
        def content = "println 'Hello, World!'"
        scriptService.findScript(scriptPath) >> Optional.of(script)
        scriptService.getScriptContent(script) >> content

        when:
        def response = scriptController.getScriptContent(scriptPath)

        then:
        response.statusCode == HttpStatus.OK
        response.body == content
    }

    def "getScriptContent should return 404 when the script does not exist"() {
        given:
        def scriptPath = "nonexistent"
        scriptService.findScript(scriptPath) >> Optional.empty()

        when:
        def response = scriptController.getScriptContent(scriptPath)

        then:
        response.statusCode == HttpStatus.NOT_FOUND
        response.body == null
    }

    def "executeScript should execute the script and return the result when the script exists"() {
        given:
        def scriptPath = "script1"
        def script = new Metadata().name(scriptPath).path("/path/to/script1")
        def args = ["arg1", "arg2"] as String[]
        def result = [success: true, output: "Script output", result: "Script result"]
        scriptService.findScript(scriptPath) >> Optional.of(script)
        scriptService.executeScript(script, args) >> result

        when:
        def response = scriptController.executeScript(scriptPath, args)

        then:
        response.statusCode == HttpStatus.OK
        response.body == result
        response.body.success == true
        response.body.output == "Script output"
        response.body.result == "Script result"
    }

    def "executeScript should handle null args"() {
        given:
        def scriptPath = "script1"
        def script = new Metadata().name(scriptPath).path("/path/to/script1")
        def result = [success: true, output: "Script output", result: "Script result"]
        scriptService.findScript(scriptPath) >> Optional.of(script)
        scriptService.executeScript(script, [] as String[]) >> result

        when:
        def response = scriptController.executeScript(scriptPath, null)

        then:
        response.statusCode == HttpStatus.OK
        response.body == result
    }

    def "executeScript should return 404 when the script does not exist"() {
        given:
        def scriptPath = "nonexistent"
        def args = ["arg1", "arg2"] as String[]
        scriptService.findScript(scriptPath) >> Optional.empty()

        when:
        def response = scriptController.executeScript(scriptPath, args)

        then:
        response.statusCode == HttpStatus.NOT_FOUND
        response.body == null
    }

    def "executeScript should return bad request when execution fails"() {
        given:
        def scriptPath = "script1"
        def script = new Metadata().name(scriptPath).path("/path/to/script1")
        def args = ["arg1", "arg2"] as String[]
        def exception = new RuntimeException("Script execution failed")
        scriptService.findScript(scriptPath) >> Optional.of(script)
        scriptService.executeScript(script, args) >> { throw exception }

        when:
        def response = scriptController.executeScript(scriptPath, args)

        then:
        response.statusCode == HttpStatus.BAD_REQUEST
        response.body.success == false
        response.body.error == "Error executing script: Script execution failed"
    }

    def "refreshScripts should refresh the script cache"() {
        given:
        def scripts = [
            new Metadata().name("script1").path("/path/to/script1"),
            new Metadata().name("script2").path("/path/to/script2")
        ]
        scriptService.refreshCache() >> scripts

        when:
        def response = scriptController.refreshScripts()

        then:
        response.statusCode == HttpStatus.OK
        response.body == scripts
        response.body.size() == 2
        response.body[0].name == "script1"
        response.body[1].name == "script2"
    }
    
    def "createScript should successfully create a script and return refreshed scripts"() {
        given:
        def newScriptData = new ScriptController.NewScriptData(
            name: "testScript",
            description: "Test script description",
            author: "Test Author",
            scriptContent: "println 'Hello, World!'"
        )
        def createdScript = new Metadata().name("testScript").path("/path/to/testScript")
        def refreshedScripts = [
            createdScript,
            new Metadata().name("script2").path("/path/to/script2")
        ]
        scriptService.getScriptsPath() >> "/path/to/scripts"
        scriptService.createScript(newScriptData, Paths.get("/path/to/scripts")) >> createdScript
        scriptService.refreshCache() >> refreshedScripts

        when:
        def response = scriptController.createScript(newScriptData)

        then:
        response.statusCode == HttpStatus.OK
        response.body == refreshedScripts
        response.body.size() == 2
        response.body[0].name == "testScript"
    }
    
    def "createScript should return bad request for invalid input parameters"() {
        given:
        def newScriptData = new ScriptController.NewScriptData(
            name: "testScript",
            description: "Test script description",
            author: "Test Author"
            // Missing scriptContent and selectedScripts
        )
        def errorMessage = "Either selectedScripts or scriptContent must be provided"
        scriptService.getScriptsPath() >> "/path/to/scripts"
        scriptService.createScript(newScriptData, Paths.get("/path/to/scripts")) >> { throw new IllegalArgumentException(errorMessage) }

        when:
        def response = scriptController.createScript(newScriptData)

        then:
        response.statusCode == HttpStatus.BAD_REQUEST
        response.body instanceof ApiError
        response.body.status == 400
        response.body.error == "Bad Request"
        response.body.message == errorMessage
        response.body.path == "/api/scripts/create"
    }
    
    def "createScript should return internal server error for file system errors"() {
        given:
        def newScriptData = new ScriptController.NewScriptData(
            name: "testScript",
            description: "Test script description",
            author: "Test Author",
            scriptContent: "println 'Hello, World!'"
        )
        def errorMessage = "Failed to write file"
        scriptService.getScriptsPath() >> "/path/to/scripts"
        scriptService.createScript(newScriptData, Paths.get("/path/to/scripts")) >> { throw new IOException(errorMessage) }

        when:
        def response = scriptController.createScript(newScriptData)

        then:
        response.statusCode == HttpStatus.INTERNAL_SERVER_ERROR
        response.body instanceof ApiError
        response.body.status == 500
        response.body.error == "Internal Server Error"
        response.body.message == "Failed to write script to file: " + errorMessage
        response.body.path == "/api/scripts/create"
    }
    
    def "createScript should return bad request for script compilation errors"() {
        given:
        def newScriptData = new ScriptController.NewScriptData(
            name: "testScript",
            description: "Test script description",
            author: "Test Author",
            scriptContent: "invalid script content"
        )
        def errorMessage = "Failed to compile script"
        scriptService.getScriptsPath() >> "/path/to/scripts"
        scriptService.createScript(newScriptData, Paths.get("/path/to/scripts")) >> { throw new SupportRuntimeException(errorMessage) }

        when:
        def response = scriptController.createScript(newScriptData)

        then:
        response.statusCode == HttpStatus.BAD_REQUEST
        response.body instanceof ApiError
        response.body.status == 400
        response.body.error == "Bad Request"
        response.body.message == "Invalid script content: " + errorMessage
        response.body.path == "/api/scripts/create"
    }
    
    def "createScript should return internal server error for unexpected errors"() {
        given:
        def newScriptData = new ScriptController.NewScriptData(
            name: "testScript",
            description: "Test script description",
            author: "Test Author",
            scriptContent: "println 'Hello, World!'"
        )
        def errorMessage = "Unexpected error"
        scriptService.getScriptsPath() >> "/path/to/scripts"
        scriptService.createScript(newScriptData, Paths.get("/path/to/scripts")) >> { throw new RuntimeException(errorMessage) }

        when:
        def response = scriptController.createScript(newScriptData)

        then:
        response.statusCode == HttpStatus.INTERNAL_SERVER_ERROR
        response.body instanceof ApiError
        response.body.status == 500
        response.body.error == "Internal Server Error"
        response.body.message == "An unexpected error occurred: " + errorMessage
        response.body.path == "/api/scripts/create"
    }
}
