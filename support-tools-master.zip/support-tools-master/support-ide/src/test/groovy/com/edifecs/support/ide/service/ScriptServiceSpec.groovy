package com.edifecs.support.ide.service

import com.edifecs.support.scripts.Metadata
import spock.lang.Specification

class ScriptServiceSpec extends Specification {

    def scriptService = new ScriptService(Mock(ServerService), Mock(GrpcServer))

    def "returns empty list when scripts is null or empty"() {
        when:
        def r1 = scriptService.filterScriptsByUserRoles(null, ["admin"]) 
        def r2 = scriptService.filterScriptsByUserRoles(Collections.emptyList(), ["admin"]) 

        then:
        r1 != null && r1.isEmpty()
        r2 != null && r2.isEmpty()
    }

    def "includes scripts with no roles regardless of user roles"() {
        given:
        def s1 = new Metadata().name("no-roles-1") // roles default is empty set
        def s2 = new Metadata().name("no-roles-2")
        def scripts = [s1, s2]

        when:
        def result1 = scriptService.filterScriptsByUserRoles(scripts, null)
        def result2 = scriptService.filterScriptsByUserRoles(scripts, [])
        def result3 = scriptService.filterScriptsByUserRoles(scripts, [null, "  ", "Admin"]) 

        then:
        result1 == scripts
        result2 == scripts
        result3 == scripts
    }

    def "filters by intersection of roles (case-insensitive, trims, ignores null/blank user roles)"() {
        given:
        def s1 = new Metadata().name("A") // no roles -> should be included
        def s2 = new Metadata().name("B").filters("admin", "dev")
        def s3 = new Metadata().name("C").filters("ops")
        def s4 = new Metadata().name("D").filters(" Qa ") // script role with spaces
        def scripts = [s1, s2, s3, s4]

        and:
        // user roles contain mixed case, extra spaces, nulls and blanks
        def userRoles = ["  ADMIN ", null, "", "  qa  "]

        when:
        def result = scriptService.filterScriptsByUserRoles(scripts, userRoles)

        then:
        // s1 is included (no roles); s2 included (admin match); s3 excluded; s4 included (qa match)
        result*.name == ["A", "B", "D"]
    }

    def "scripts with roles are excluded when user has no roles"() {
        given:
        def s1 = new Metadata().name("A").filters("admin")
        def s2 = new Metadata().name("B").filters("OPS")
        def s3 = new Metadata().name("C") // no roles
        def scripts = [s1, s2, s3]

        when:
        def r1 = scriptService.filterScriptsByUserRoles(scripts, null)
        def r2 = scriptService.filterScriptsByUserRoles(scripts, Collections.emptyList())

        then:
        r1*.name == ["C"]
        r2*.name == ["C"]
    }
}
