import com.edifecs.support.Storage
import com.edifecs.support.Support
import com.edifecs.support.core.ProcessHelper
import com.edifecs.support.core.Utils
import org.apache.commons.io.FileUtils
import spock.lang.Ignore
import spock.lang.Specification

import java.nio.charset.Charset

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class ScriptsTest extends Specification {

    void 'verify environment script'() {
        def context = Support.info {
            include('/collect/environment-vars.groovy')
        }
        expect:
        context
        context.value('environment.vars')

        and:
        null != (context = Support.info {
            include('/collect/environment-vars.groovy')
            include('/validate/validate-vars ECRootPath XE_ROOT')
        })
        context
        context.value('environment.vars')
    }

    @Ignore
    void 'verify processes script'() {
        def context = Support.info {
            include('/collect/processes.groovy')
        }
        expect:
        context
        context.value('processes.list')
//        println  context.value('processes.list')
    }

    void 'verify all-logs script'() {
        def context = Support.info {
            include("/collect/all-logs.groovy ${protectionDomainPath()}/*.log")
        }
        expect:
        context
        context.values()

        and: 'verify logs filtered by specified range dates'
        null != (context = Support.info {
            include("/collect/all-logs.groovy ${protectionDomainPath()}/*.log \"2023-04-20...\"")
        })
        context.values()

        and: 'verify logs filtered by relative time periods'
        null != (context = Support.info {
            include("/collect/all-logs.groovy ${protectionDomainPath()}/*.log \"week#%d%m%n\"")
        })
        !context.values()
    }

    @Ignore
    void 'verify tomcat-logs script'() {
        def context = Support.info {
            include('/collect/tomcat-logs.groovy c:/tomcat')
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify lsof script'() {
        def context = Support.info {
            include('/collect/lsof.groovy ' + ['pidXXX or process name list'].join(','))
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify java-lsof script'() {
        final name = ProcessHelper.isLinux() ? 'lib/config-server' : 'lib\\config-server'
        def context = Support.info {
            include('/collect/java-lsof.groovy ' + name)
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify kill process fixture'() {
        def context = Support.fixture {
            include('/fixture/kill-process.groovy ' + ['pidXXX or process name list'].join(','))
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify kill java process fixture'() {
        def context = Support.fixture {
            include('/fixture/kill-java-process.groovy ' + ['pidXXX or Java command line matching pattern, example: ServiceManager'].join(','))
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify rmdir fixture'() {
        def context = Support.fixture {
            include('/fixture/rmdir ' + ['Directory(ies) list, example: ${ECRootPath}/XEServer/profiles/STEIRA_Processing/log'].join(','))
        }
        expect:
        context
        context.values()
    }

    @Ignore
    void 'verify windows service fixture'() {
        def context = Support.fixture {
            include('/fixture/windows-service tmqabcbis1 EdifecsTMAgent start')
            include('/fixture/windows-service tmqabcbis1 EdifecsTMAgent stop')
        }
        expect:
        context
        context.values()
        context.getErrorInfo()
    }

    @Ignore
    void 'verify windows service running'() {
        def context = Support.fixture {
            validateServiceRunning('tmqabcbis1', 'EdifecsTMAgent')
            validateServiceRunning('tmqabcbis1', 'EdifecsTMBusinessItemService')
            validateServiceRunning('tmqabcbis1', 'EdifecsTMETL')
        }
        expect:
        context
        context.values()
        context.getErrorInfo()
    }

    @Ignore
    void 'verify ssh fixture'() {
        def context = Support.fixture {
            include("/fixture/ssh Administrator@plt-tmbc-eim 'cd \$IM_DATA && ls'")
//            include('/fixture/ssh Administrator@plt-tmbc-eim "cd /opt/EIM/IM_DATA && ls -l"')
//            include('/fixture/ssh Administrator@plt-tmbc-eim < file-with-commands')
        }
        expect:
        context
        context.values()
        context.getErrorInfo()
    }

    @Ignore
    void 'verify several scripts'() {
        def context = Support.info {
            include('/collect/environment-vars.groovy')
            include('/collect/processes.groovy')
//            include('/collect/all-logs ServiceManager')
        }
        expect:
        context
        context.values()

        and:
        context.destination('${ECRootPath}/info-context/content.zip')
        Storage.toDisk(context)
    }

    void 'verify path comparison script'() {
        final path = new File(this.class.protectionDomain.codeSource.location.file).toPath()
        final targetCmp = new File(path.toFile().getParentFile(), Utils.timeSuffixedPath('pc', null))
        targetCmp.mkdir()
        final files = [] as List<File>
        FileUtils.copyDirectory(path.toFile(), targetCmp, {
            final bf = it.isFile()
            if (it.getName().toLowerCase().endsWith('xml')) {
                files.add(it)
            }
            return bf
        })
        if (files) {
            FileUtils.writeStringToFile(new File(targetCmp, files.first().getName()),
                    "print('Path file comparison line')", Charset.defaultCharset(), true)
        }

        def context = Support.info {
            include("/validate/compare-files.groovy $path ${targetCmp.getAbsolutePath()}")
        }

        expect:
        context.hasErrors()
    }

    static File protectionDomainFile() {
        new File(ScriptsTest.protectionDomain.codeSource.location.file)
    }

    static String protectionDomainPath() {
        return protectionDomainFile().absolutePath
    }

    static String protectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }
}
