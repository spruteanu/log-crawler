import com.edifecs.support.Support
import com.edifecs.support.scripts.Description

@Description(
        name = "List Environment Variables",
        description = "Retrieves system environment variables for Linux and Windows.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/environment-vars'''
)
static def execute() {
    Support.info {
        if (isLinux()) {
            add('environment.vars', shellOutput('printenv'))
//        shell('printenv > ${destination}/environment.vars')
        } else {
            add('environment.vars', shellOutput('set'))
//        shell('echo > ${destination}/environment.vars')
        }
    }
}
execute()
