package collect

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "Java LSOF",
        description = "Lists open files for running Java processes.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/java-lsof [process name]
    Examples:
      script-runner /collect/java-lsof
      script-runner "/collect/java-lsof my-java-app"'''
)
@Argument(name = "process name", description = "Optional name of a Java process to filter results.")
static def execute(String... args) {
    Support.info {
        javaLsof(args)
    }
}
execute(args)
