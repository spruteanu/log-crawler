package collect

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "List Open files",
        description = "Retrieves a list of open files for a given process, either by PID or process name.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/lsof [PID or process name]
    Examples: script-runner "/collect/lsof 1234 or java"'''
)
@Argument(name = "PID(s) or process name", description = "Process ID(s) or process name to fetch open file details")
static def execute(String... args) {
    Support.info {
        lsof(args)
    }
}

execute(args)
