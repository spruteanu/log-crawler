import com.edifecs.support.Support
import com.edifecs.support.log.PathDatePeriodPredicate
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

@Description(
        name = "Collect all logs",
        description = "Collects logs using provided arguments.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/all-logs [filter1] [filter2] ... [filter n]
where filter format:
[file path or wildcards] [date period[#log4j conversion string]]
    Examples:
#Collect all logs from $ECRootPath folder
script-runner /collect/all-logs

#Collect all TM logs from $ECRootPath folder
script-runner "/collect/all-logs TM*"

#Collect all profiles logs from $ECRootPath folder
script-runner "/collect/all-logs profiles*"

#Collect all TM logs from $ECRootPath folder for provided date range
script-runner "/collect/all-logs TM* \"2023-04-20...2023-05-20#%d %p %c - %m%n\""
script-runner "/collect/all-logs TM* \"2023-01-01 00:00...2023-12-31 23:59#%d %p %c - %m%n\""

#Collect all Service manager files with log file  extension from $ECRootPath/TM/ServiceManager/logs/ for dates after 2023-04-20
script-runner "/collect/all-logs $ECRootPath/TM/ServiceManager/logs/*.log \"2023-04-20...#%d %p %c - %m%n\""
'''
)
@Argument(name = "filter", description = """Used filter for logs collecting. Filter format: [file path or wildcards] [date period[#log4j conversion string]]
Supported Date Period Formats
The system supports two main types of date period formats:
1. Relative Time Periods:
   Format: [n] <unit>[s]
   Where:
   - [n] is an optional positive integer (defaults to 1 if omitted)
   - <unit> can be one of: day(s), week(s), month(s), year(s)
   - [s] is an optional plural 's'
   Short forms are also supported:
   - d for day(s)
   - w for week(s)
   - m for month(s)
   - y for year(s)
   Special case:
   - "yesterday" is supported as a keyword
   Examples:
   - "5 days", "3d", "1 week", "2w", "6 months", "1y", "yesterday"
2. Specific Date Range:
   Format: [start_date][...][end_date]
   Where:
   - [start_date] and [end_date] are in the format "yyyy-MM-dd[ HH:mm:ss]"
   - [...] is the literal string "..." (three dots)
   - Either start_date or end_date can be omitted, but not both
   Examples:
   - "2023-01-01...2023-12-31"
   - "2023-01-01 00:00:00...2023-12-31 23:59:59"
   - "...2023-12-31"
   - "2023-01-01..."
""")
static def execute(String... args) {
    Support.info {
        prefix('logs-')
        if (args) {
            for (String filter : args) {
                logFilter(filter)
            }
        } else {
            allLogsFilter()
        }
        if (PathDatePeriodPredicate.hasRange(args)) {
            final pathFilters = lookupPathFilters(source, logFilters())
            logs(pathFilters.path, PathDatePeriodPredicate.of(defaultLogFilter,
                    pathFilters.filters.toArray(new String[0] as String[])))
        } else {
            logs()
        }
    }
}

execute(args)
