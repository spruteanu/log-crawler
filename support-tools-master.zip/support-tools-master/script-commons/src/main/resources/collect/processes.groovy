import com.edifecs.support.Support
import com.edifecs.support.scripts.Description

@Description(
        name = "System process list",
        description = "Lists operating system processes",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/processes'''
)
def execute(String[] args) {
    Support.info {
        // todo: add functionality to collect processes remotely
        if (isLinux()) {
            add('processes.list', shellOutput('ps', 'aux'))
//        shell('printenv > ${destination}/environment.vars')
        } else {
            add('processes.list', shellOutput('tasklist', '/V'))
//        shell('echo > ${destination}/environment.vars')
        }
    }
}
execute(args)
