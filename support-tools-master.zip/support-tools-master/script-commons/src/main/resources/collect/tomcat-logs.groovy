package collect

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

@Description(
        name = "Collect Web Application Logs",
        description = "Collects logs from the web application logs directory.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/tomcat-logs [Tomcat installation path] [Application context]
    Examples: script-runner "/collect/tomcat-logs /opt/tomcat tm"'''
)
@Argument(name = "Tomcat installation path", description = "Path to the Tomcat installation directory.")
@Argument(name = "Application context", description = "Name of the web application context.")
static def execute(String... args) {
    Support.info {
        final location = args ? args[0] : null
        if (location != null) {
            add findFiles("$location/logs", "*")
            final String appContext = args.length > 1 ? args[1] : 'tm'
            add findFiles("$location/webapps/$appContext/WEB-INF/logs", "*")
        } else {
            error('tomcat.location', 'Tomcat location not found')
        }
    }
}
execute(args)
