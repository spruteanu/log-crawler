import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.Support
import com.edifecs.support.core.NasTest

@Description(
        name = "File system speed test",
        description = "Verify file system how fast a file can be copied synchronously or asynchronously",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/nas-test [folder] [sourceFile] [repeats count] [number of threads]
    Examples: "script-runner /collect/nas-test source-file.txt 2000 50"'''
)
@Argument(name = "folder", description = "Folder name where nas test will be performed")
@Argument(name = "sourceFile", description = "Used source file to be cloned/copied")
@Argument(name = "repeats count", description = "Number of repeats")
@Argument(name = "number of threads", description = "Number of used threads to perform the test, default value one, which means test will run synchronously", required = false)
static def execute(String[] args) {
    Support.info {
        NasTest.execute(args)
    }
}

execute(args)
