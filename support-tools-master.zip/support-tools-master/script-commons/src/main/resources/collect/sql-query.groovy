import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

@Description(
        name = "SQL query",
        description = "Executes SQL query scripts over provided database",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/sql-query [dbProperties file] [script1] [scriptN]
    Examples: script-runner /collect/sql-query "enablement.properties users.sql partners.sql"'''
)
@Argument(name = "DB properties file", description = """Database properties file that will contain database connectivity details:

Microsoft SQL Server Example
# Basic connection properties
# JDBC Connection URL (required)
url=jdbc:sqlserver://localhost:1433;databaseName=mydb
# Database username (required)
username=sa
# Database password (required)
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
# JDBC driver class name (required)
driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver

# SQL Server specific properties
trustServerCertificate=true
encrypt=true
integratedSecurity=false
applicationName=MyApplication

# Connection pooling properties
initialSize=5
maxActive=10
maxIdle=5
# Query timeout settings
queryTimeout=30

Oracle Example
url=jdbc:oracle:thin:@localhost:1521:XE
username=system
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
driverClassName=oracle.jdbc.OracleDriver

# Example of db properties defined in EIM
#Supported database types:
#   MSSQL - SQL Server
#   MsSqlAzure - Azure SQL Server
#   Oracle12c - Oracle 12c
#   Oracle19c - Oracle 19c
#   PostgreSQL - Postgre 13.x
database.type=MSSQL
server=localhost
database=EcEnablement
username=CDWeb
password={enc}U4Wi47iHluc=
port=1433
instance=MSSQLSERVER
trustservercertificate=true
encrypt=true
""")
@Argument(name = "SQL script", description = "Script with defined queries")
protected def execute(String[] args) {
    return Support.sqlInfo {
        final List<String> scripts = initialize(args)
        for (final script : scripts) {
            queryFrom(script)
        }
    }
}

execute(args)
