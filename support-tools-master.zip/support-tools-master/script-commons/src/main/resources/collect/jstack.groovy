
import com.edifecs.support.Support
import com.edifecs.support.collect.ProcessInfo
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

@Description(
        name = "Get Java Stack Trace",
        description = "Collects stack traces of running Java processes for debugging purposes.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/jstack [process name]
    Examples:
     
#Collects stack traces for all Java processes    
script-runner "collect/jstack"

# Collect jstack traces only from Java processes matching 
script-runner "collect/jstack name-java-app" (collects stack traces for Java processes matching "name-java-app")
              
'''
)
@Argument(name = "process name", description = "Optional filter for Java process names to collect stack traces only for matching processes", required = false)
static def execute(String... args) {
    Support.info {
        if (args) {
            for (String filter : args) {
                for (ProcessInfo ph : findJavaProcess(filter)) {
                    jStack(ph.getPid())
                }
            }
        } else {
            for (ProcessHandle ph : findJavaProcess()) {
                jStack(ph.pid())
            }
        }
    }
}
execute(args)
