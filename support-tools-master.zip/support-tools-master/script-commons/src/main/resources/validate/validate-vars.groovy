
package validate

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "Environment variables validation",
        description = "Validates input variables to ensure they are correctly defined and not missing.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/validate-vars [variable1] [variable2] ... [variableN]
    Examples: script-runner "/validate/validate-vars VAR1 VAR2 VAR3"'''
)
@Argument(name = "Variables", description = "List of variables to validate")
static def execute(String... args) {
    Support.info {
        validateVariable args
    }
}
execute(args)
