import com.edifecs.support.Support
import com.edifecs.support.core.PathComparison
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "File Comparison",
        description = "Compares two directories or files and generates a report of differences.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /validate/compare-files [leftPath] [rightPath]
    Examples: script-runner "/validate/compare-files /path/to/left /path/to/right"'''
)
@Argument(name = "leftPath", description = "Path to the first file or directory to compare.")
@Argument(name = "rightPath", description = "Path to the second file or directory to compare.")
static def execute(String... args) {
    Support.info {
        String left = args ? args[0] : null
        String right = args != null && args.length > 1 ? args[1] : null

        final difference = PathComparison.compare left, right, {
            ignore { it.endsWith('bak') }
//        ignoreByRegEx('.+\\.zip')
//        ignoreByWildcard('*.zip')
            defaultFileComparator {
//            sizeComparison()
//            crc32Comparison()
                contentComparison()
//            contentComparisonWildcard('*.zip')
//            lineComparisonWildcard('*.groovy')
//            contentComparisonRegEx(null, '.+\\.groovy')
//            crc32Comparison()
            }
        }
        if (difference.hasDifference()) {
            error((left ?: 'missing') + "-" + (right ?: 'missing') + '-comparison-report.csv', difference.listAll().join('\n'))
        }
    }
}
execute(args)
