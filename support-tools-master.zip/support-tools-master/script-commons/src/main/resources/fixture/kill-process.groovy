package fixture

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "Kill Process",
        description = "Terminates a process by its PID or name.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/kill-process [PID or Process Name]
    Examples: 
    
# Kill process with PID 9876
script-runner "/fixture/kill-process 9876"

# Kill all processes matching keyword "name-of-app"
script-runner "/fixture/kill-process name-of-app"
'''
)
@Role("admin")
@Argument(name = "PID(s) or process name", description = "The process ID or name of the process to be terminated.")
static def execute(String... args) {
    Support.fixture {
        kill args
    }
}
execute(args)
