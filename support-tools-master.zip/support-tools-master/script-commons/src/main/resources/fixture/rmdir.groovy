package fixture

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "Remove directories",
        description = "Removes specified directories using either a Linux or Windows command, depending on the system.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/rmdir [directory1, directory2, ... directoryN]
    Examples:

# Removes a single directory
script-runner /fixture/rmdir /tmp/directory1

# Removes multiple directories
script-runner /fixture/rmdir /tmp/directory1,/tmp/directory2,/var/log/directory3
'''
)
@Role("admin")
@Argument(name = "Directory(ies)", description = "Comma-separated list of directories to be removed.")
static def execute(String... args) {
    Support.fixture {
        rmdir args
    }
}
execute(args)
