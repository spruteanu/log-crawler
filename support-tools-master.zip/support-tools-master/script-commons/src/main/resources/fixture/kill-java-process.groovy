package fixture

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */

@Description(
        name = "Kill Java Process",
        description = "Terminates Java processes by process ID (PID) or process name.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/kill-java-process [PID or process name]
    Examples:

# Kill Java process with PID 1234
script-runner "/fixture/kill-java-process 1234"

# Kill all Java processes containing "name-app" in their name or arguments
script-runner "/fixture/kill-java-process name-app"
'''
)
@Role("admin")
@Argument(name = "PID(s) or process name", description = "The Java process identifier (PID) or name to be terminated.")
static def execute(String... args){
    Support.fixture {
        killJava args
    }
}
execute()
