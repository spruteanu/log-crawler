import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "SQL execute",
        description = "Executes SQL query scripts over provided database",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /collect/sql-execute [dbProperties file] [script1] [scriptN]
    Examples: script-runner /collect/sql-execute "enablement.properties users.sql partners.sql"'''
)
@Role("admin")
@Argument(name = "DB properties file", description = """Database properties file that will contain database connectivity details:

Microsoft SQL Server Example
# Basic connection properties
# JDBC Connection URL (required)
jdbc.url=jdbc:sqlserver://localhost:1433;databaseName=mydb
# Database username (required)
jdbc.username=sa
# Database password (required)
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
# JDBC driver class name (required)
jdbc.driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver

# SQL Server specific properties
trustServerCertificate=true
encrypt=true
integratedSecurity=false
applicationName=MyApplication

# Connection pooling properties
initialSize=5
maxActive=10
maxIdle=5
# Query timeout settings
queryTimeout=30

Oracle Example
url=jdbc:oracle:thin:@localhost:1521:XE
username=system
password={enc}U4Wi47iHluc= #OR \$Dec{U4Wi47iHluc=}
driverClassName=oracle.jdbc.OracleDriver
""")
@Argument(name = "SQL script", description = "Script with defined queries")
protected def execute(String[] args) {
    return Support.sqlFixture {
        final List<String> scripts = initialize(args)
        for (final script : scripts) {
            executeFrom(script)
        }
    }
}

execute(args)
