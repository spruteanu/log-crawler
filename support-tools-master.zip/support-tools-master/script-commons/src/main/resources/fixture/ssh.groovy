package fixture

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@Description(
        name = "SSH Command",
        description = "Executes SSH commands on a remote host.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/ssh [SSH argument(s)]
    Examples: 
 
support "/fixture/ssh user@host command"'''
)
@Role("admin")
@Argument(name = "SSH argument(s)", description = "Arguments for SSH connection and command to execute")
static def execute(String... args) {
    Support.fixture {
        validateArgs('Wrong ssh arguments provided. Format: ssh {argument(s)}', { !args }, args)
        ssh args
    }
}
execute(args)
