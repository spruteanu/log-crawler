package fixture

import com.edifecs.support.Support
import com.edifecs.support.scripts.Argument
import com.edifecs.support.scripts.Description
import com.edifecs.support.scripts.Role

@Description(
        name = "Windows Service Command",
        description = "Executes Windows service commands (start, stop, etc.) on a remote host via the 'sc' command.",
        author = "Serge Pruteanu",
        usage = '''Usage: script-runner /fixture/windows-service [host] [service name] [service arguments]
    Examples: script-runner "/fixture/windows-service remoteHost myService start"
    '''
)
@Role("admin")
@Argument(name = "host", description = "The remote host where the service will be managed")
@Argument(name = "name", description = "The name of the Windows service to manage")
@Argument(name = "service arguments", description = "The arguments passed to the 'sc' command (e.g., start, stop)")
static def execute(String... args) {
    Support.fixture {
        validateArgs('Wrong service arguments provided. Format: [host, name, {service argument(s)}]', { !args || args.length < 3 }, args)
        final String[] sArgs = new ArrayList<String>(Arrays.asList(args)).subList(2, args.size()).toArray(new String[0])
        windowsService args[0], args[1], sArgs
    }
}
execute(args)
