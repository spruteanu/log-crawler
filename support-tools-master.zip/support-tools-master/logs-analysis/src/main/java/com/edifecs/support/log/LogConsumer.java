package com.edifecs.support.log;

import java.util.function.Consumer;

/**
 * @author Serge Pruteanu
 */
@FunctionalInterface
public interface LogConsumer extends Consumer<LogEntry> {
    void consume(LogEntry entry);

    default void accept(LogEntry logEntry) {
        consume(logEntry);
    }
}
