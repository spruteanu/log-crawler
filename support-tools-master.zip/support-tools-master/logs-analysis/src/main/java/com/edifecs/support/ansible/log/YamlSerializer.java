package com.edifecs.support.ansible.log;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.TypeDescription;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.error.YAMLException;
import org.yaml.snakeyaml.extensions.compactnotation.CompactConstructor;
import org.yaml.snakeyaml.inspector.TrustedTagInspector;
import org.yaml.snakeyaml.introspector.BeanAccess;
import org.yaml.snakeyaml.introspector.Property;
import org.yaml.snakeyaml.introspector.PropertyUtils;
import org.yaml.snakeyaml.nodes.MappingNode;
import org.yaml.snakeyaml.nodes.Node;
import org.yaml.snakeyaml.nodes.NodeTuple;
import org.yaml.snakeyaml.nodes.Tag;
import org.yaml.snakeyaml.representer.Represent;
import org.yaml.snakeyaml.representer.Representer;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@SuppressWarnings("squid:S2221")
class YamlSerializer {
    static final Pattern CASE_PATTERN = Pattern.compile("[A-Z]+");

    public static DumperOptions newDumperOptions() {
        final DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setDefaultScalarStyle(DumperOptions.ScalarStyle.PLAIN);
        options.setTimeZone(TimeZone.getDefault());
        options.setCanonical(false);
        options.setAllowReadOnlyProperties(false);
        return options;
    }

    static Yaml newKebabCaseYaml() {
        final AtomicReference<Yaml> holder = new AtomicReference<>();
        final DumperOptions options = newDumperOptions();
        final Yaml yaml = new Yaml(new IgnoringUnknownConstruct(newLoaderOptions()),
                new KebabCaseSkipNullRepresenter(holder, options), options);
        holder.set(yaml);
        return yaml;
    }

    public static String toKebabCase(String name) {
        String result = CASE_PATTERN.matcher(name).replaceAll("-$0").toLowerCase();
        if (result.startsWith("-")) {
            result = result.substring(1);
        }
        return result;
    }

    public static synchronized void addTypeDefinition(Yaml yaml, Class<?> javaBeanClass) {
        final String tagName = toKebabCase(javaBeanClass.getSimpleName());
        final TypeDescription typeDescription = new TypeDescription(javaBeanClass, new Tag(tagName));
        yaml.addTypeDescription(typeDescription);
    }

    static LoaderOptions newLoaderOptions() {
        final LoaderOptions options = new LoaderOptions();
        options.setTagInspector(new TrustedTagInspector());
        return options;
    }

    public static Yaml objectDumper() {
        return new Yaml(new CompactConstructor(newLoaderOptions()), new SkipNullRepresenter(newDumperOptions()));
    }

    public static Yaml ansibleVarsDumper() {
        final DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setDefaultScalarStyle(DumperOptions.ScalarStyle.LITERAL);
        return new Yaml(new Constructor(newLoaderOptions()), new AnsibleGroupVarsRepresenter(newDumperOptions()), options);
    }

    static <O> O read(Yaml yaml, InputStream io) {
        return yaml.load(io);
    }
    static <O> O read(Yaml yaml, Path path) throws IOException {
        try (final InputStream inputStream = Files.newInputStream(path)) {
            return read(yaml, inputStream);
        }
    }

    private static class IgnoringUnknownConstruct extends Constructor {
        public IgnoringUnknownConstruct(final LoaderOptions config) {
            super(config);
        }

        @Override
        protected Class<?> getClassForNode(Node node) {
            try {
                return super.getClassForNode(node);
            } catch (YAMLException e) {
                return LinkedHashMap.class;
            }
        }
    }

    private static class SkipNullRepresenter extends Representer {

        public SkipNullRepresenter(DumperOptions options) {
            super(options);
        }

        @Override
        protected NodeTuple representJavaBeanProperty(Object javaBean, Property property, Object propertyValue, Tag customTag) {
            if (propertyValue == null) {
                return null;
            }
            final Class<?> type = property.getType();
            if (!type.isPrimitive()) {
                return super.representJavaBeanProperty(javaBean, property, propertyValue, customTag);
            }
            if (int.class.isAssignableFrom(type) && 0 == (int) propertyValue) {
                return null;
            }
            if (long.class.isAssignableFrom(type) && 0L == (long) propertyValue) {
                return null;
            }
            if (short.class.isAssignableFrom(type) && (short) 0 == (Short) propertyValue) {
                return null;
            }
            if (float.class.isAssignableFrom(type) && Float.compare((float) propertyValue, 0.0F) == 0) {
                return null;
            }
            if (double.class.isAssignableFrom(type) && Double.compare((double) propertyValue, 0.0) == 0) {
                return null;
            }
            return super.representJavaBeanProperty(javaBean, property, propertyValue, customTag);
        }
    }

    private static class AnsibleGroupVarsRepresenter extends SkipNullRepresenter {

        public AnsibleGroupVarsRepresenter(DumperOptions options) {
            super(options);
            this.representers.put(AnsibleVaultedStr.class, new RepresentAnsibleVaultedStr());
        }

        private class RepresentAnsibleVaultedStr implements Represent {
            @Override
            public Node representData(Object data) {
                AnsibleVaultedStr avs = (AnsibleVaultedStr) data;
                return representScalar(new Tag("!vault"), avs.getValue());
            }
        }
    }

    public static class AnsibleVaultedStr {
        private final String value;

        public AnsibleVaultedStr(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return "!vault |\n" + value;
        }
    }

    private static class KebabCaseSkipNullRepresenter extends SkipNullRepresenter {
        private final AtomicReference<Yaml> holder;

        public KebabCaseSkipNullRepresenter(AtomicReference<Yaml> holder, DumperOptions options) {
            super(options);
            this.holder = holder;
            setPropertyUtils(createPropertyUtils());//NOSONAR
        }

        private static PropertyUtils createPropertyUtils() {
            return new KebabCaseFieldSortedPropertyUtils();
        }

        void addTypeDefinition(Class<?> javaBeanClass) {
            YamlSerializer.addTypeDefinition(holder.get(), javaBeanClass);
        }

        @Override
        protected MappingNode representJavaBean(Set<Property> properties, Object javaBean) {
            final Class<?> javaBeanClass = javaBean.getClass();
            if (!typeDefinitions.containsKey(javaBeanClass)) {
                addTypeDefinition(javaBeanClass);
            }
            return super.representJavaBean(properties, javaBean);
        }
    }

    private static class PropertyDelegate extends Property {

        private final Property delegate;

        public PropertyDelegate(String nameSubstitute, Property property) {
            super(nameSubstitute, property.getType());
            delegate = property;
        }

        @Override
        public Class<?>[] getActualTypeArguments() {
            return delegate.getActualTypeArguments();
        }

        @Override
        public void set(Object object, Object value) throws Exception {
            delegate.set(object, value);
        }

        @Override
        public Object get(Object object) {
            return delegate.get(object);
        }

        @Override
        public List<Annotation> getAnnotations() {
            return delegate.getAnnotations();
        }

        @Override
        public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
            return delegate.getAnnotation(annotationType);
        }

        @Override
        public boolean isWritable() {
            return delegate.isWritable();
        }

        @Override
        public boolean isReadable() {
            return delegate.isReadable();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            if (!super.equals(o)) return false;
            PropertyDelegate that = (PropertyDelegate) o;
            return Objects.equals(delegate, that.delegate);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), delegate);
        }
    }

    private static class KebabCaseFieldSortedPropertyUtils extends PropertyUtils {
        private final Map<Class<?>, Map<String, Property>> myPropertiesCache = new LinkedHashMap<>();

        private static boolean isMapOrCollection(Property property) {
            final Class<?> type = property.getType();
            return Map.class.isAssignableFrom(type) || Collection.class.isAssignableFrom(type);
        }

        @SuppressWarnings("unchecked")
        @Override
        protected Set<Property> createPropertySet(Class type, BeanAccess bAccess) {
            final Set<Property> result = new TreeSet<>((p1, p2) -> {
                int dif;
                final boolean p1Heavy = isMapOrCollection(p1);
                final boolean p2Heavy = isMapOrCollection(p2);
                if (p1Heavy && !p2Heavy) {
                    dif = 1;
                } else if (!p1Heavy && p2Heavy) {
                    dif = -1;
                } else {
                    dif = p1.getName().compareTo(p2.getName());
                }
                return dif;
            });
            result.addAll(super.createPropertySet(type, bAccess));
            return result;
        }

        @Override
        protected Map<String, Property> getPropertiesMap(Class<?> type, BeanAccess bAccess) {
            if (myPropertiesCache.containsKey(type)) {
                return myPropertiesCache.get(type);
            }
            final Map<String, Property> properties = super.getPropertiesMap(type, bAccess);
            final Map<String, Property> processedProperties = new LinkedHashMap<>(properties.size());
            for (final Map.Entry<String, Property> entry : properties.entrySet()) {
                String newName = toKebabCase(entry.getKey());
                processedProperties.put(newName, new PropertyDelegate(newName, entry.getValue()));
            }
            myPropertiesCache.put(type, processedProperties);
            return processedProperties;
        }
    }
}
