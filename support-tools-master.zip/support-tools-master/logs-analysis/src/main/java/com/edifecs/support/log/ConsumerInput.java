package com.edifecs.support.log;

import java.io.Closeable;

/**
 * @author Serge Pruteanu
 */
public interface ConsumerInput extends Closeable {
    String LINE_BREAK = System.lineSeparator();
    LogEntry next(Object source);
}
