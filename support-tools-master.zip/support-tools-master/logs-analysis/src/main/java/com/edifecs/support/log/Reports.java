package com.edifecs.support.log;

import com.edifecs.support.core.GroovyUtil;
import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import org.apache.commons.lang.StringEscapeUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class Reports {

    @SafeVarargs
    public static <O> List<O> toList(O obj, O... objs) {
        final List<O> csList = new ArrayList<>();
        csList.add(obj);
        if (objs != null) {
            csList.addAll(Arrays.asList(objs));
        }
        return csList;
    }

    public static List<String> toFields(String fields) {
        return Arrays.stream(fields.split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
    }

    public static Map<String, String> toFieldMap(List<String> fields) {
        return fields != null ? fields.stream().map(s -> {
            if (!s.contains(":")) {
                s = s + ":" + s;
            }
            return s.trim().split(":");
        }).collect(Collectors.toMap(pair -> pair[0], pair -> pair[1], Utils::leftMerger, LinkedHashMap::new)) : null;
    }

    public static Map<String, String> toFieldMap(String fields) {
        return toFieldMap(toFields(fields));
    }

    public static CsvReportable toCsvReportable(String script, String... args) {
        final CsvReportable reportable = new CsvReportable();
        GroovyUtil.include(script, reportable, args);
        return reportable;
    }

    @SuppressWarnings("rawtypes")
    public static CsvReportable toCsvReportable(@DelegatesTo(CsvReportable.class) Closure closure) {
        final CsvReportable reportable = GroovyUtil.lookupDelegate(closure, CsvReportable.class, CsvReportable::new);
        GroovyUtil.closureCall(closure, reportable);
        return reportable;
    }

    @SuppressWarnings("resource")
    public static CsvReportingConsumer csvConsumer(Path csvPath, Map<String, String> fields) throws IOException {
        return CsvReportingConsumer.of(csvPath).hasHeader().fields(fields.values());
    }
    public static CsvReportingConsumer csvConsumer(String csvPath, Map<String, String> fields) throws IOException {
        return csvConsumer(Paths.get(csvPath), fields);
    }
    public static CsvReportingConsumer csvConsumer(String csvPath, String field, String... fields) throws IOException {
        return csvConsumer(Paths.get(csvPath), toFieldMap(toList(field, fields)));
    }

    public static PrintWriter toPrintWriter(Path path) throws IOException {
        return new PrintWriter(Files.newBufferedWriter(path));
    }

    public interface Reportable extends Closeable {
        void ingest();
    }

    public static class CsvReportable implements Reportable {
        private String source;
        private String destination;
        private String start;
        private String end;
        private Map<String, String> fields;

        private Stream<Map<String, Object>> mapStream;
        private List<Consumer<Map<String, Object>>> consumers;
        private boolean hasCsvConsumer;

        public String getSource() {
            return source;
        }

        public void setSource(String source) {
            this.source = source;
        }
        public CsvReportable source(String source) {
            setSource(source);
            return this;
        }

        public String getDestination() {
            return destination;
        }

        public void setDestination(String destination) {
            this.destination = destination;
        }
        public CsvReportable destination(String destination) {
            setDestination(destination);
            return this;
        }

        public String getStart() {
            return start;
        }

        public void setStart(String start) {
            this.start = start;
        }
        public CsvReportable start(String start) {
            setStart(start);
            return this;
        }
        public boolean hasStart() {
            return start != null;
        }

        public String getEnd() {
            return end;
        }

        public void setEnd(String end) {
            this.end = end;
        }
        public CsvReportable end(String end) {
            setEnd(end);
            return this;
        }
        public boolean hasEnd() {
            return end != null;
        }

        public Map<String, String> getFields() {
            return fields;
        }

        public void setFields(Map<String, String> fields) {
            this.fields = fields;
        }
        public CsvReportable fields(Map<String, String> fields) {
            setFields(fields);
            return this;
        }

        public Stream<Map<String, Object>> getMapStream() {
            return mapStream;
        }
        public void setMapStream(Stream<Map<String, Object>> mapStream) {
            this.mapStream = mapStream;
        }

        public CsvReportable mapStream(Stream<Map<String, Object>> mapStream) {
            setMapStream(mapStream);
            return this;
        }

        public List<Consumer<Map<String, Object>>> getConsumers() {
            return consumers;
        }

        public void setConsumers(List<Consumer<Map<String, Object>>> consumers) {
            this.consumers = consumers;
        }
        public CsvReportable consumers(List<Consumer<Map<String, Object>>> consumers) {
            setConsumers(consumers);
            return this;
        }
        public CsvReportable consumers(Consumer<Map<String, Object>> consumer, Consumer<Map<String, Object>>... consumers) {
            setConsumers(toList(consumer, consumers));
            return this;
        }

        @SafeVarargs
        public final CsvReportable add(Consumer<Map<String, Object>> consumer, Consumer<Map<String, Object>>... consumers) {
            if (this.consumers == null) {
                this.consumers = new ArrayList<>();
            }
            final List<Consumer<Map<String, Object>>> cl = toList(consumer, consumers);
            for (Consumer<Map<String, Object>> c : cl) {
                if (c instanceof CsvReportingConsumer) {
                    hasCsvConsumer = true;
                }
                this.consumers.add(c);
            }
            return this;
        }

        public boolean hasStream() {
            return mapStream != null;
        }

        public boolean hasConsumers() {
            return consumers != null && !consumers.isEmpty();
        }

        public boolean hasCsvConsumer() {
            return hasCsvConsumer;
        }

        private List<AutoCloseable> lookupCloseables() {
            final List<AutoCloseable> closeables = new ArrayList<>();
            if (mapStream != null) {
                closeables.add(mapStream);
            }
            if (consumers != null) {
                for (Consumer<Map<String, Object>> consumer : consumers) {
                    if (consumer instanceof AutoCloseable) {
                        closeables.add((AutoCloseable) consumer);
                    }
                }
            }
            return closeables;
        }

        @Override
        public void ingest() {
            mapStream.forEach(toContainerConsumer());
        }

        @Override
        public void close() throws IOException {
            final List<Exception> exceptions = new ArrayList<>();
            for (AutoCloseable closeable : lookupCloseables()) {
                try {
                    closeable.close();
                } catch (Exception e) {
                    exceptions.add(e);
                }
            }
            if (!exceptions.isEmpty()) {
                final List<StackTraceElement> ste = new ArrayList<>();
                for (Exception exception : exceptions) {
                    ste.addAll(Arrays.asList(exception.getStackTrace()));
                }
                IOException cause = new IOException("Failed to close report closeables");
                cause.setStackTrace(ste.toArray(new StackTraceElement[0]));
                throw cause;
            }
        }

        protected Consumer<Map<String, Object>> toContainerConsumer() {
            return new ContainerMapConsumer(consumers);
        }
    }

    public static class ContainerMapConsumer implements Consumer<Map<String, Object>> {
        protected List<Consumer<Map<String, Object>>> consumers;

        public ContainerMapConsumer() {
            this(new ArrayList<>());
        }

        public ContainerMapConsumer(List<Consumer<Map<String, Object>>> consumers) {
            this.consumers = consumers;
        }

        public List<Consumer<Map<String, Object>>> getConsumers() {
            return consumers;
        }

        public void setConsumers(List<Consumer<Map<String, Object>>> consumers) {
            this.consumers = consumers;
        }
        public ContainerMapConsumer consumers(List<Consumer<Map<String, Object>>> consumers) {
            setConsumers(consumers);
            return this;
        }
        public ContainerMapConsumer add(List<Consumer<Map<String, Object>>> consumers) {
            this.consumers.addAll(consumers);
            return this;
        }

        @SafeVarargs
        public final ContainerMapConsumer add(Consumer<Map<String, Object>> consumer, Consumer<Map<String, Object>>... consumers) {
            this.consumers.add(consumer);
            if (consumers != null) {
                Collections.addAll(this.consumers, consumers);
            }
            return this;
        }

        @Override
        public void accept(Map<String, Object> map) {
            for (Consumer<Map<String, Object>> consumer : consumers) {
                consumer.accept(map);
            }
        }
    }

    public static class CsvReportingConsumer implements Consumer<Map<String, Object>>, Closeable {
        private PrintWriter writer;
        private List<String> fields;
        private boolean trimEmpty;
        private boolean hasHeader;

        public CsvReportingConsumer() {
        }

        public CsvReportingConsumer(PrintWriter writer, List<String> fields) {
            this.writer = writer;
            this.fields = fields;
        }

        public void setWriter(PrintWriter writer) {
            this.writer = writer;
        }

        public CsvReportingConsumer writer(PrintWriter writer) {
            setWriter(writer);
            return this;
        }

        public void setFields(List<String> fields) {
            this.fields = fields;
        }

        public CsvReportingConsumer fields(List<String> fields) {
            setFields(fields);
            return this;
        }

        public CsvReportingConsumer fields(Collection<String> fields) {
            setFields(new ArrayList<>(new LinkedHashSet<>(fields)));
            return this;
        }

        public CsvReportingConsumer trimEmpty() {
            trimEmpty = true;
            return this;
        }

        @Override
        public void close() throws IOException {
            writer.close();
        }
        List<String> toValues(Map<String, Object> map) {
            final List<String> values = new ArrayList<>(fields.size());
            for (final String field : fields) {
                values.add(StringEscapeUtils.escapeCsv(Objects.toString(map.get(field), "")));
            }
            return values;
        }
        public CsvReportingConsumer hasHeader() {
            hasHeader = true;
            return this;
        }
        public CsvReportingConsumer writeHeader() {
            writer.println(String.join(",", fields));
            hasHeader = false;
            return this;
        }

        @SuppressWarnings("resource")
        @Override
        public void accept(Map<String, Object> map) {
            if (hasHeader) {
                writeHeader();
            }
            if (!trimEmpty || (map != null && !map.isEmpty())) {
                writer.println(String.join(",", toValues(map)));
            }
        }

        @SuppressWarnings("squid:S1943")
        public static CsvReportingConsumer of(OutputStream outputStream, List<String> fields) {
            return new CsvReportingConsumer(new PrintWriter(outputStream), fields).writeHeader();
        }

        public static CsvReportingConsumer of(Writer writer, List<String> fields) {
            return new CsvReportingConsumer(new PrintWriter(writer), fields).writeHeader();
        }

        @SuppressWarnings("squid:S2095")
        public static CsvReportingConsumer of(Path path, List<String> fields) throws IOException {
            return new CsvReportingConsumer(toPrintWriter(path), fields).trimEmpty().writeHeader();
        }

        public static CsvReportingConsumer of(Path path) throws IOException {
            return of(path, new ArrayList<>());
        }
    }
}
