package com.edifecs.support.ansible.log;

import com.edifecs.support.log.LogEntry;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class DeploymentReport {
    private String id;
    private String status;
    private String startTime;
    private String duration;
    private String source;

    private String message;

    private Map<String, Object> properties = new LinkedHashMap<>();
    private Collection<LogEntry> errors;

    private AnsibleLogs logs;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DeploymentReport id(String id) {
        setId(id);
        return this;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public DeploymentReport status(String status) {
        setStatus(status);
        return this;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public DeploymentReport startTime(String startTime) {
        setStartTime(startTime);
        return this;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public DeploymentReport duration(String time) {
        setDuration(time);
        return this;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
    public DeploymentReport source(String source) {
        setSource(source);
        return this;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DeploymentReport message(String message) {
        setMessage(message);
        return this;
    }

    public Collection<LogEntry> getErrors() {
        return errors;
    }

    public void setErrors(Collection<LogEntry> errors) {
        this.errors = errors;
    }
    public DeploymentReport errors(Collection<LogEntry> errors) {
        setErrors(errors);
        return this;
    }

    AnsibleLogs getLogs() {
        return logs;
    }

    void setLogs(AnsibleLogs logs) {
        this.logs = logs;
    }
    DeploymentReport logs(AnsibleLogs logs) {
        setLogs(logs);
        return this;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

    public boolean isFailed() {
        return AnsibleLogs.isFailed(status) || (errors != null && !errors.isEmpty());
    }
    public boolean isDone() {
        return AnsibleLogs.isDone(status);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DeploymentReport");
        if (source != null) {
            sb.append(" source: '").append(source).append('\'');
        }
        if (status != null) {
            sb.append(" status: '").append(status).append('\'');
        }
        if (startTime != null) {
            sb.append(" start: '").append(startTime).append('\'');
        }
        if (duration != null) {
            sb.append(" duration: '").append(duration).append('\'');
        }
        if (message != null) {
            sb.append(" message: '").append(message).append('\'');
        }
        return sb.toString();
    }
}
