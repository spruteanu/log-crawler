package com.edifecs.support.log;

/**
 * @author Serge Pruteanu
 */
public interface ConsumerOutput extends LogConsumer {
}
