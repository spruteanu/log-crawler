package com.edifecs.support.log;

/**
 * @author Serge Pruteanu
 */
@SuppressWarnings({"rawtypes", "squid:S2157"})
public class ConsumerBuilder<T extends LogConsumer> implements Cloneable {
    protected LogsBuilder contextBuilder;
    private T consumer;
    private Object consumerObj;
    private Object[] args;

    ConsumerBuilder() {
    }

    ConsumerBuilder(LogsBuilder contextBuilder, Object consumer, Object... args) {
        this.contextBuilder = contextBuilder;
        this.consumerObj = consumer;
        this.args = args;
    }

    ConsumerBuilder using(T consumer) {
        this.consumer = consumer;
        return this;
    }

    LogsBuilder logsBuilder() {
        return contextBuilder;
    }

    @SuppressWarnings("unchecked")
    protected T newConsumer(Object object, Object... objArgs) {
        T result;
        if (object instanceof LogConsumer) {
            result = (T) object;
        } else if (object instanceof ConsumerBuilder) {
            result = (T) ((ConsumerBuilder) object).build();
        } else {
            result = (T) contextBuilder.getConsumer(object, objArgs);
        }
        return result;
    }

    protected T getConsumer() {
        if (consumer == null) {
            consumer = newConsumer(consumerObj, args);
        }
        return consumer;
    }

    protected T build() {
        return newConsumer(getConsumer());
    }
}
