package com.edifecs.support.log;

import com.edifecs.support.collect.InformationContext;
import com.edifecs.support.core.DatePredicate;
import com.edifecs.support.core.RafLineReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

import java.nio.file.Path;
import java.util.Date;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
public class PathDatePeriodPredicate implements Predicate<Path> {
    private static final Logger log = LogManager.getLogger(PathDatePeriodPredicate.class);
    static final char CONVERSION_SEPARATOR = '#';

    private final Predicate<Date> datePredicate;
    private final Function<String, Date> dateFunction;

    public PathDatePeriodPredicate(Predicate<Date> datePredicate, Function<String, Date> dateFunction) {
        this.datePredicate = datePredicate;
        this.dateFunction = dateFunction;
    }

    @Override
    public boolean test(Path path) {
        boolean result = false;
        try (RafLineReader reader = new RafLineReader(path.toFile())) {
            String line = reader.first();
            if (line == null) {
                return result;
            }
            final String lastLine = reader.last();
            final boolean lResult = datePredicate.test(dateFunction.apply(line));
            final boolean fResult = datePredicate.test(dateFunction.apply(lastLine));
            result = lResult || fResult;
        } catch (Exception e) {
            log.debug("Failed to check: '{}' for period: '{}'. Check that range dates and conversion pattern is defined properly", path, datePredicate, e);
        }
        if (result) {
            log.debug("'{}' matches period: '{}'", path, datePredicate);
        }
        return result;
    }

    public static boolean isRange(String dateTimePeriod) {
        return DatePredicate.isRange(dateTimePeriod);
    }
    public static boolean hasRange(String... args) {
        if (args == null) {
            return false;
        }
        for (String arg : args) {
            if (isRange(arg)) {
                return true;
            }
        }
        return false;
    }

    static int conversionsSeparatorIndex(String dateTimePattern) {
        return dateTimePattern.indexOf(CONVERSION_SEPARATOR);
    }

    @NotNull
    public static String lookupDateTimePeriod(String dateTimePattern) {
        final int idx = conversionsSeparatorIndex(dateTimePattern);
        if (idx != -1) {
            dateTimePattern = dateTimePattern.substring(0, idx);
        }
        return dateTimePattern;
    }

    public static boolean hasConversions(String dateTimePattern) {
        return conversionsSeparatorIndex(dateTimePattern) != -1;
    }

    public static PathDatePeriodPredicate of(String dateTimePeriod, Function<String, Date> dateFunction) {
        return new PathDatePeriodPredicate(DatePredicate.of(lookupDateTimePeriod(dateTimePeriod)), dateFunction);
    }
    public static PathDatePeriodPredicate of(String dateTimePeriod, String dateTimePattern, String datePattern, Function<String, Date> dateFunction) {
        return new PathDatePeriodPredicate(DatePredicate.of(lookupDateTimePeriod(dateTimePeriod), dateTimePattern, datePattern), dateFunction);
    }

    public static PathDatePeriodPredicate of(final String dateTimePeriod, final Log4jConsumer consumer) {
        consumer.toDate();
        return new PathDatePeriodPredicate(DatePredicate.of(lookupDateTimePeriod(dateTimePeriod)),
                line -> {
                    final LogEntry logEntry = consumer.consume(line);
                    return (Date) logEntry._get(Log4jConsumer.DATE);
                });
    }

    public static PathDatePeriodPredicate of(String conversionPattern, String dateTimePeriod) {
        return of(dateTimePeriod, Log4jConsumer.of(conversionPattern));
    }
    public static PathDatePeriodPredicate of(String dateTimePeriod) {
        final int idx = conversionsSeparatorIndex(dateTimePeriod);
        String conversionPattern;
        if (idx != -1) {
            conversionPattern = dateTimePeriod.substring(idx + 1);
            dateTimePeriod = dateTimePeriod.substring(0, idx);
        } else {
            conversionPattern = "%d%m%n";
        }
        return of(dateTimePeriod, Log4jConsumer.of(conversionPattern));
    }
    public static Predicate<Path> of(String defaultFilter, String[] arguments) {
        if (arguments == null) {
            throw new IllegalArgumentException("Arguments cannot be null");
        }
        Predicate<Path> predicate = null;
        for (int i = 0; i < arguments.length;) {
            String argument = arguments[i];
            Predicate<Path> pp = InformationContext.logPathPredicate(null, argument, defaultFilter);
            if (i < arguments.length - 1 && isRange(arguments[i + 1])) {
                pp = pp.and(of(arguments[i + 1]));
                i++;
            }
            predicate = predicate != null ? predicate.or(pp) : pp;
            i++;
        }
        return predicate;
    }
}
