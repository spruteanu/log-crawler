#!/bin/sh

if [ $1 ] && [ $2 ]
then
CURRENT_FOLDER=$(pwd)
FOLDER=$1

echo Loading '$FOLDER' using '$2'

./logstash/bin/logstash.sh -f $2

else
echo "Folder or logstash config is not provided.";

fi
