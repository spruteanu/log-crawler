#!/bin/sh
. nohup ./metricbeat/scripts/metricbeat.sh &
. nohup ./filebeat/scripts/filebeat.sh &
echo Packet requires configured sniffer
. nohup ./packetbeat/scripts/packetbeat.sh &
