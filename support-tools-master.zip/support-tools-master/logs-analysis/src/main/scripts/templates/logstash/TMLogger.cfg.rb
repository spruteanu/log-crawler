########################################################################################################################
# Logstash parsing rules for TM logs analysis. Processes ALL logs defined in TMLogger.cfg. In addition it includes
# HTR ETL and FileStore operations execution
# Depends on environment variables ${FOLDER}, ${CURRENT_FOLDER} defined in *load shell scripts
########################################################################################################################
input {
    file {
        path => "${FOLDER}/**/TM.log*"
        type => "TMLogger"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/ecdatabase.log*"
        type => "TMSQLLogger"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/etl.log*"
        type => "ETLLogger"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/BusinessItemService.log*"
        type => "BISLogger"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/trackinginfo.log*"
        type => "trackinginfo"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/hibernate.log*"
        type => "HibernateFileAppender"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/sql.log*"
        type => "sql"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/sqltiming.log*"
        type => "sqltiming"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/jdbc.log*"
        type => "jdbc"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/edifecs-security-audit.log*"
        type => "securityAuditAppender"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
    file {
        path => "${FOLDER}/**/workflow.log*"
        type => "workflowAppender"
        codec => multiline {
            pattern => "^\d"
            what => "previous"
            negate => true
        }
        # Bellow line is not for continuous log watch, path will be parsed always from start position
        sincedb_path => "/dev/null"
        start_position => "beginning"
    }
}

filter {
if [type] == "TMLogger" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} (?<Priority>[\w ]{5,}) %{JAVACLASS:EventCategory{37,} - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }

    if 'com.edifecs.shared.filestore' in [EventCategory] {
        if 'FileID' in [Message] {
            grok {
                match => [ 'Message', '(?<Action>.*)FileID[: =\)]{1,}\s*(?<FileID>\d+)(?<Execution>.+)\s+(?<ExecutionTime>\d+)\s+ms' ]
            }
        } else if 'ms' in [Message] {
            grok {
                match => [ 'Message', '(?<Action>.*);\s+(?:\w+\s*)*:\s(?<ExecutionTime>\d+)\s+ms' ]
            }
        }
    }

    if ![Action] {
        mutate {
            copy => { 'Execution' => 'Action' }
        }
    }
    mutate {
        remove_field => [ 'Execution' ]
    }
    if [ExecutionTime] {
        mutate {
            convert => { 'ExecutionTime' => 'integer' }
        }
    }
}
if [type] == "TMSQLLogger" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} (?<Priority>[\w ]{5,}) %{JAVACLASS:EventCategory{37,} - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
if [type] == "ETLLogger" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} - (?<Priority>[\w ]+) - \[(?<Thread>.+)\] (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }

    if 'Created Transmission:' in [Message] {
        grok {
            match => [ "Message", '.+:\s+(?<TransmissionSID>\d+)\s+for ETL package: (?:ID:|ZIP_)(?<PackageID>.*)' ]
        }
        mutate { add_field => ['Action', 'Created Transmission'] }
    } else if 'Move failed package' in [Message] {
        grok {
            match => [ "Message", '.+ZIP_(?<PackageID>.+) to Failed Queue.' ]
        }
        mutate { add_field => ['Action', 'Failed move package'] }
    } else if 'Subcomponent' in [Message] {
        grok {
            match => [ "Message", '.+\s+(?<PackageID>.+)\s+\((?<TransmissionSID>\d+)\)' ]
        }
        mutate { add_field => ['Action', 'Failed processing'] }
    } else if 'second(s).' in [Message] {
        grok {
            match => [ "Message", '.+\s+(?<Action>\w+\s+to process the file)\s+(?<PackageID>.+)\s+\((?<TransmissionSID>\d+)\).+%{NUMBER:Hours:int} hour\(s\)\s+%{NUMBER:Minutes:int} minute\(s\)\s+%{NUMBER:Seconds:float} second\(s\).' ]
        }
        ruby {
            code => "event.set('ExecutionTime', event.get('Hours')*3600 + event.get('Minutes')*60 + event.get('Seconds'))"
        }
        mutate {
            remove_field => [ 'Hours', 'Minutes', 'Seconds']
        }
    }
}
if [type] == "BISLogger" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} (?<Priority>[\w ]{5,}) %{JAVACLASS:EventCategory{37,} - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
if [type] == "trackinginfo" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} (?<Priority>[\w ]{5,}) %{JAVACLASS:EventCategory{37,} - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
if [type] == "HibernateFileAppender" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} - (?<Priority>[\w ]+) - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
if [type] == "sql" {
    grok {
        match => { "message" => '-----> (?<Date>\w+-\w+-\w+ \w+:\w+:\w+.\w+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss.SSS
    }
}
if [type] == "sqltiming" {
    grok {
        match => { "message" => '-----> (?<Date>\w+-\w+-\w+ \w+:\w+:\w+.\w+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss.SSS
    }
}
if [type] == "jdbc" {
    grok {
        match => { "message" => '(?<Date>\w+-\w+-\w+ \w+:\w+:\w+.\w+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss.SSS
    }
}
if [type] == "securityAuditAppender" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date}\\t(?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
if [type] == "workflowAppender" {
    grok {
        match => { "message" => '%{TIMESTAMP_ISO8601:Date} (?<Priority>[\w ]{5,}) %{JAVACLASS:EventCategory{37,} - (?<Message>.+)' }
        # Date-format => yyyy-MM-dd HH:mm:ss,SSS
    }
}
date {
    match => ['Date', 'yyyy-MM-dd HH:mm:ss,SSS']
}
mutate {
    strip => "Message"
    # Remove not needed fields
    remove_field => [ 'message', '@version', 'Date', 'host', 'path']
}
if 'multiline' in [tags] {
    mutate {
        remove_field => [ 'tags' ]
    }
    ruby {
        code => "event.set('Exception', event.get('Message').scan(/(?:[a-zA-Z$_][a-zA-Z$_0-9]*\.)*[a-zA-Z$_][a-zA-Z$_0-9]*Exception/))"
    }
}
}

output {
#if [type] == "TMLogger.cfg" {
    #some output here
#}
    elasticsearch {
        hosts => "localhost"
        index => "logs-tm-%{+YYYY.MM.dd}"
        template => "${CURRENT_FOLDER}/templates/index/tm-elastic-index.json"
        # document_id => "document_id_if_needed"
    }
    # Next lines are only for debugging.
    stdout { codec => rubydebug }
    # file {path => "TMLogger.cfg.result" codec => rubydebug}
}
