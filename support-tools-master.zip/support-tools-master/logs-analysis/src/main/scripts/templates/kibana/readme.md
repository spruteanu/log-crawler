**Overview**

Folder contains Kibana templates. Templates can be loaded by either running tm-dashboard-install.* shell script or through Kibana Management console:
   * Start ELK servers (servers-start shell script)
   * Open in browser Kibana page: [Kibana localhost](http://localhost:5601)
   * Click Management link from left navigation menu
   * Click [Saved Objects](http://localhost:5601/app/kibana#/management/kibana/objects)
   * Import templates in following sequence:
      * tm-index-pattern.json
      * tm-fs-exec-bar.json
      * tm-fs-exec-graph.json
      * tm-fs-exec-pivot.json
      * tm-fs-exec-time.json
      * tm-fs-dashboard.json
