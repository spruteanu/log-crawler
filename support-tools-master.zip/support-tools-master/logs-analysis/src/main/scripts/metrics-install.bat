@echo off

if "%1"=="" (
set PV=$packetbeat.version
set MV=$metricbeat.version
set FV=$filebeat.version
) else (
set PV=%1
set MV=%1
set FV=%1
)

wget https://artifacts.elastic.co/downloads/beats/packetbeat/packetbeat-%PV%-windows-x86_64.zip -O packetbeat.zip
echo Unpacking PacketBeat...
unzip -o packetbeat.zip -d .. >> install.log
move ..\packetbeat* ..\packetbeat
del packetbeat.zip >> install.log

wget https://artifacts.elastic.co/downloads/beats/metricbeat/metricbeat-%MV%-windows-x86_64.zip -O metricbeat.zip
echo Unpacking MetricBeat...
unzip -o metricbeat.zip -d .. >> install.log
move ..\metricbeat* ..\metricbeat
del metricbeat.zip >> install.log

wget https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-%FV%-windows-x86_64.zip -O filebeat.zip
echo Unpacking FileBeat...
unzip -o filebeat.zip -d .. >> install.log
move ..\filebeat* ..\filebeat
del filebeat.zip >> install.log

echo Staring Elastic and Kibana to load metrics dashboards.
@start cmd /c call ..\elasticsearch/bin/elasticsearch.bat
@start cmd /c call ..\kibana/bin/kibana.bat
echo Continue once Elastic and Kibana are started.
pause

echo Importing PacketBeat dashboards...
cmd /c ..\packetbeat\scripts\import_dashboards.exe >> install.log
echo Importing MetricBeat dashboards...
cmd /c ..\metricbeat\scripts\import_dashboards.exe >> install.log
echo Importing FileBeat dashboards...
cmd /c ..\filebeat\scripts\import_dashboards.exe >> install.log
