@echo off

pushd metricbeat
cmd /c metricbeat.exe
popd

pushd filebeat
cmd /c filebeat.exe
popd

@echo PacketBeat requires WpCap sniffer installed(wpcap.dll)
pushd packetbeat
cmd /c packetbeat.exe
popd
