import com.edifecs.support.ansible.log.AnsibleLogs
import com.edifecs.support.ansible.log.JobEvents

final String src = args[0]
final String dest = args[1]
final double maxDuration = args.length > 2 ? Double.parseDouble(args[2]) : 300.0d

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
AnsibleLogs.toCsv {
    source(src)
    def events = AnsibleLogs.jobEvents().defaultFields().add([
            "event_data.res.stderr": 'consoleError',
            "event_data.res.stdout": 'consoleOut',
            'event_data.res.rc'    : 'resultCode',
    ])
    mapStream events.toStream(src).filter(JobEvents.durationPredicate(maxDuration))
    add AnsibleLogs.csvConsumer(dest, events.fields)
}
