import com.edifecs.support.log.Log4jConsumer

log4j {
    message {
        if (get(Log4jConsumer.EVENT_CATEGORY).startsWith('com.edifecs.shared.filestore')) {
            if (get('Message').contains('FileID')) {
                match 'Message', ~/(?<Action>.*)FileID[: =\)]{1,}\s*(?<FileID>\d+)(?<Execution>.+)\s+(?<ExecutionTime>\d+)\s+ms/, {
                    if (!get('Action')) {
                        put 'Action', get('Execution')
                    }
                    remove 'Execution'
                }
            } else if (get('Message').endsWith('ms')) {
                match 'Message', ~/(?<Action>.*);\s+(?:\w+\s*)*:\s(?<ExecutionTime>\d+)\s+ms/, {
                    if (!get('Action')) {
                        put 'Action', get('Execution')
                    }
                    remove 'Execution'
                }
            }
        }
    }
}
