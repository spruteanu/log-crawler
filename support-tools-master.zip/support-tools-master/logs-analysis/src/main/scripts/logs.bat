@echo off

SET ERROR="false"
SET ERR_MESSAGE=""
:: check if JAVA_HOME specified
IF "%JAVA_HOME%"=="" (
	SET ERROR="true"
	SET ERR_MESSAGE=ERROR: java.exe could not be found. Please make sure to have JDK installed and the JAVA_HOME environment variable defined.
	goto end
)

:: check if java present
"%JAVA_HOME%\bin\java.exe" >nul 2>nul
IF "%errorlevel%" gtr "1" (
	SET ERROR="true"
    SET ERR_MESSAGE=ERROR: java.exe could not be found. Please make sure to have JDK installed and the JAVA_HOME environment variable defined.
    goto end
)

:: shutting down server
SET JAVA_EXE=%JAVA_HOME%\bin\java.exe
IF EXIST "%JAVA_EXE%" GOTO 3
SET JAVA_EXE=java.exe

:3
SET CONF=.;
SET LIB=lib\*

SET CP="%CONF%";"%LIB%"
SET JAVA_OPTS=-Xms256M -Xmx800M
SET LOG_OPTS=-Dlog4j.configurationFile="conf/log4j2.xml"
SET DEBUG_OPTS=-agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=5005

rem echo Some message here ...
"%JAVA_EXE%" %JAVA_OPTS% %LOG_OPTS% -classpath %CP% com.edifecs.support.log.Tool %*
GOTO end

:end

::exit
