#!/bin/sh

. ./logs-load.sh $1 templates/logstash/etl.rb
