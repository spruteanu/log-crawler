#!/bin/sh

. ./logs-load.sh $1 templates/logstash/TMLogger.cfg.rb
