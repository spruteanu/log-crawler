@echo off
@start cmd /c call elasticsearch/bin/elasticsearch.bat
@start cmd /c call kibana/bin/kibana.bat
