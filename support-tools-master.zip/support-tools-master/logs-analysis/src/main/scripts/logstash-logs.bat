@echo off

if "%1"=="" goto ERROR
if "%2"=="" goto ERROR

SET CURRENT_FOLDER=%cd%
SET FOLDER=%1

echo Loading '%FOLDER%' using '%2%'

call logstash/bin/logstash.bat -f %2
goto DONE

:ERROR
echo Folder or logstash config is not provided.

:DONE
