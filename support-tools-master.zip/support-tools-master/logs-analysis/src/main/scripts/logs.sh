#!/bin/bash

start() {
  java_home_check
}

java_home_check() {
  if [ ! -z "$JAVA_HOME" ];
  then
    java_exe_check
  else
    echo ERROR: Please, specify the JAVA_HOME variable in Environment Variables
    end
  fi
}

java_exe_check() {
  JAVA_EXE="$JAVA_HOME/bin/java"
  JAVA_VERSION="$("$JAVA_EXE" -version 2>&1)"
  if [ "$JAVA_VERSION" != *"command not found"* ] && [ "$JAVA_VERSION" != *"No such file or directory"* ];
  then
    execute
  else
    echo ERROR: java.exe could not be found. Please make sure to have JDK installed.
    exit
  fi
}

execute() {
  if [ -f $JAVA_HOME/bin/java ] ; then
    JAVA_EXE=$JAVA_HOME/bin/java
  else
    JAVA_EXE=java
  fi

  CONF="."
  LIB="lib/*"
  CP="$CONF:$LIB"
  JAVA_OPTS="-Xms256M -Xmx800M"
  LOG_OPTS=-Dlog4j.configurationFile="conf/log4j2.xml"

  $JAVA_EXE $JAVA_OPTS $LOG_OPTS -classpath $CP com.edifecs.support.log.Tool $@
  end
}

end() {
 :
#  read -p "Press any key to close the window..."
}

start
