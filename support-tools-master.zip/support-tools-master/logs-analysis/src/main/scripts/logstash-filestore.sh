#!/bin/sh

. ./logs-load.sh $1 templates/logstash/filestore-trace.rb
