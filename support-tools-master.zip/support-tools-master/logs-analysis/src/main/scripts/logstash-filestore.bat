@echo off

call logs-load.bat %1 templates/logstash/filestore-trace.rb
