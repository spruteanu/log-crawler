#!/bin/sh

if [ "$1" = "" ] ; then
PV=$packetbeat.version
MV=$metricbeat.version
FV=$filebeat.version
else
PV=$1
MV=$1
FV=$1
fi

wget https://artifacts.elastic.co/downloads/beats/packetbeat/packetbeat-$PV-linux-x86_64.tar.gz -O packetbeat.tar.gz
echo Unpacking PacketBeat...
tar xvf ./packetbeat.tar.gz -C ./.. >> install.log
mv ../packetbeat* ../packetbeat
rm ./packetbeat.tar.gz >> install.log

wget https://artifacts.elastic.co/downloads/beats/metricbeat/metricbeat-$MV-linux-x86_64.tar.gz -O metricbeat.tar.gz
echo Unpacking MetricBeat...
tar xvf ./metricbeat.tar.gz -C ./.. >> install.log
mv ../metricbeat* ../metricbeat
rm ./metricbeat.tar.gz >> install.log

wget https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-$FV-linux-x86_64.tar.gz -O filebeat.tar.gz
echo Unpacking FileBeat...
tar xvf ./filebeat.tar.gz -C ./.. >> install.log
mv ../filebeat* ../filebeat
rm ./filebeat.tar.gz >> install.log

echo Staring Elastic and Kibana to load metrics dashboards.
. ../servers-start.sh
read -p "Press [Enter] to continue once Elastic and Kibana are started."

echo Importing PacketBeat dashboards...
. ../packetbeat/scripts/import_dashboards.sh >> install.log
echo Importing MetricBeat dashboards...
. ../metricbeat/scripts/import_dashboards.sh >> install.log
echo Importing FileBeat dashboards...
. ../filebeat/scripts/import_dashboards.sh >> install.log
