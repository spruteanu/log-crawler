#!/bin/sh

echo Staring Elastic and Kibana to load metrics dashboards.
. ../servers-start.sh
read -p "Press [Enter] to continue once Elastic and Kibana are started."

rem TODO implement kibana templates load shell script like in this example: https://github.com/rocknsm/rock-dashboards/blob/master/load.sh
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/index-pattern/tm-logs*" -d @../templates/kibana/tm-index-pattern.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/search/tm-action-list" -d @../templates/kibana/tm-action-list.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-bar" -d @../templates/kibana/tm-fs-exec-bar.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-graph" -d @../templates/kibana/tm-fs-exec-graph.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-pivot" -d @../templates/kibana/tm-fs-exec-pivot.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-time" -d @../templates/kibana/tm-fs-exec-time.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/dashboard/fs-dashboard" -d @../templates/kibana/tm-fs-dashboard.json >> install.log
