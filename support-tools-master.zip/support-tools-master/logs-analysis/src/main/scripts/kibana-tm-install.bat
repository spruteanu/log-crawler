@echo off

echo Staring Elastic and Kibana to load metrics dashboards.
@start cmd /c call ..\elasticsearch/bin/elasticsearch.bat
@start cmd /c call ..\kibana/bin/kibana.bat
echo Continue once Elastic and Kibana are started.
pause

echo Importing TM dashboards...
rem TODO implement kibana templates load shell script like in this example: https://github.com/rocknsm/rock-dashboards/blob/master/load.sh
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/index-pattern/logs-tm*" -d @../templates/kibana/tm-index-pattern.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/search/tm-actions-list" -d @../templates/kibana/tm-action-search.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-bar" -d @../templates/kibana/tm-fs-exec-bar.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-graph" -d @../templates/kibana/tm-fs-exec-graph.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-pivot" -d @../templates/kibana/tm-fs-exec-pivot.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/visualization/tm-fs-exec-time" -d @../templates/kibana/tm-fs-exec-time.json >> install.log
curl -XPUT -H "Content-Type: application/json" "localhost:9200/.kibana/dashboard/fs-dashboard" -d @../templates/kibana/tm-fs-dashboard.json >> install.log
