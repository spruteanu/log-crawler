@echo off

call logs-load.bat %1 templates/logstash/TMLogger.cfg.rb
