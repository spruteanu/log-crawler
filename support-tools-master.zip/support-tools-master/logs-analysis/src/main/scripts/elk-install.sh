#!/bin/sh

if [ "$1" = "" ] ; then
EV=$elastic.version
KV=$kibana.version
LV=$logstash.version
else
EV=$1
KV=$1
LV=$1
fi

wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-$EV-linux-x86_64.tar.gz -O elasticsearch.tar.gz
echo Unpacking Elastic Search...
tar xvf ./elasticsearch.tar.gz -C ./.. >> install.log
mv ../elasticsearch* ../elasticsearch
rm ./elasticsearch.tar.gz >> install.log

wget https://artifacts.elastic.co/downloads/kibana/kibana-$KV-linux-x86_64.tar.gz -O kibana.tar.gz
echo Unpacking Kibana...
tar xvf ./kibana.tar.gz -C ./.. >> install.log
mv ../kibana* ../kibana
rm ./kibana.tar.gz >> install.log

wget https://artifacts.elastic.co/downloads/logstash/logstash-$LV-linux-x86_64.tar.gz -O logstash.tar.gz
echo Unpacking Logstash...
tar xvf ./logstash.tar.gz -C ./.. >> install.log
mv ../logstash* ../logstash
rm ./logstash.tar.gz >> install.log

echo Finished ELK installation, check install.log for details.
