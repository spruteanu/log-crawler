#!/bin/sh
# waiting till kibana is up, otherwise import fails
sleep 5;
curl -XPUT "192.168.99.100:9200/_template/tm-elastic-index" -d @/opt/tm-logs-analysis/index/tm-elastic-index.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/index-pattern/tm-logs*" -d @/opt/tm-logs-analysis/kibana/tm-index-pattern.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/search/tm-action-list" -d @/opt/tm-logs-analysis/kibana/tm-action-search.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/visualization/tm-fs-exec-bar" -d @/opt/tm-logs-analysis/kibana/tm-fs-exec-bar.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/visualization/tm-fs-exec-graph" -d @/opt/tm-logs-analysis/kibana/tm-fs-exec-graph.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/visualization/tm-fs-exec-pivot" -d @/opt/tm-logs-analysis/kibana/tm-fs-exec-pivot.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/visualization/tm-fs-exec-time" -d @/opt/tm-logs-analysis/kibana/tm-fs-exec-time.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
curl -XPUT -H "Content-Type: application/json" "192.168.99.100:9200/.kibana/dashboard/fs-dashboard" -d @/opt/tm-logs-analysis/kibana/tm-fs-dashboard.json >> /var/log/elasticsearch/curl.log && echo \ >> /var/log/elasticsearch/curl.log
