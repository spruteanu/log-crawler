@echo off

if "%1"=="" (
set EV=$elastic.version
set KV=$kibana.version
set LV=$logstash.version
) else (
set EV=%1
set KV=%1
set LV=%1
)

wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-%EV%-windows-x86_64.zip -O elasticsearch.zip
echo Unpacking Elastic Search...
unzip -o elasticsearch.zip -d .. >> install.log
move ..\elasticsearch* ..\elasticsearch
del elasticsearch.zip >> install.log

wget https://artifacts.elastic.co/downloads/kibana/kibana-%KV%-windows-x86_64.zip -O kibana.zip
echo Unpacking Kibana...
unzip -o kibana.zip -d .. >> install.log
move ..\kibana* ..\kibana
del kibana.zip >> install.log

wget https://artifacts.elastic.co/downloads/logstash/logstash-%LV%-windows-x86_64.zip -O logstash.zip
echo Unpacking Logstash...
unzip -o logstash.zip -d .. >> install.log
move ..\logstash* ..\logstash
del logstash.zip >> install.log

echo Finished ELK installation, check install.log for details.
