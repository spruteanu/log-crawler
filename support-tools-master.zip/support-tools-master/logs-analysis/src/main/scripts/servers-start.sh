#!/bin/sh
nohup ./elasticsearch/bin/elasticsearch.sh &
nohup ./kibana/bin/kibana.sh &
