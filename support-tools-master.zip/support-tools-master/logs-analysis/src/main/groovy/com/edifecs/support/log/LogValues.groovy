package com.edifecs.support.log

import com.edifecs.support.core.GroovyUtil
import groovy.transform.CompileStatic

import java.text.SimpleDateFormat
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class LogValues extends Expando {
    private static final Map<Object, SimpleDateFormat> dateFormatMap = new ConcurrentHashMap<>()

    Map<String, Object> values

    LogValues(Map<String, Object> values) {
        this.values = values
    }

    @Override
    String toString() {
        return values
    }

    LogValues values(Map<String, Object> values) {
        this.values = values
        return this
    }

    LogValues put(String entryKey, Object value) {
        values.put(entryKey, value)
        return this
    }

    LogValues put(MapEntry... entries) {
        if (entries) {
            for (MapEntry entry : entries) {
                values.put(entry.key.toString(), entry.value)
            }
        }
        return this
    }

    LogValues putAll(Map<String, ?> values) {
        this.values.putAll(values)
        return this
    }

    boolean match(String entryKey, Pattern pattern, @DelegatesTo(LogValues) Closure closure = null) {
        final line = get(entryKey)
        if (!line) {
            return false
        }
        final map = RegexConsumer.toMap(pattern, line.toString())
        putAll map
        final matched = map.size() > 0
        if (matched && closure) {
            GroovyUtil.closureCall(closure, this)
        }
        return matched
    }

    String get(String entryKey) {
        return values.get(entryKey)
    }

    Object _get(String entryKey) {
        return values.get(entryKey)
    }

    LogValues remove(String... keys) {
        if (keys) {
            for (String key : keys) {
                values.remove(key)
            }
        }
        return this
    }

    boolean isEmpty() {
        return values.isEmpty()
    }

    Integer putInteger(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Integer var = null
        if (value) {
            var = value as Integer
            values.put(target, var)
        }
        return var
    }

    Long putLong(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Long var = null
        if (value) {
            var = value as Long
            values.put(target, var)
        }
        return var
    }

    Short putShort(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Short var = null
        if (value) {
            var = value as Short
            values.put(target, var)
        }
        return var
    }

    Byte putByte(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Byte var = null
        if (value) {
            var = value as Byte
            values.put(target, var)
        }
        return var
    }

    Float putFloat(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Float var = null
        if (value) {
            var = value as Float
            values.put(target, var)
        }
        return var
    }

    Double putDouble(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Double var = null
        if (value) {
            var = value as Double
            values.put(target, var)
        }
        return var
    }

    BigDecimal putBigDecimal(String entryKey, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        BigDecimal var = null
        if (value) {
            var = value as BigDecimal
            values.put(target, var)
        }
        return var
    }

    Date putDate(String entryKey, SimpleDateFormat dateFormat, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Date var = null
        if (value) {
            var = dateFormat.parse(value.toString())
            values.put(target, var)
        }
        return var
    }

    Date putDate(String entryKey, String dateFormat, String targetEntry = null) {
        final target = targetEntry ?: entryKey
        final value = values.get(entryKey)
        Date var = null
        if (value) {
            if (!dateFormatMap.containsKey(entryKey)) {
                dateFormatMap.put(entryKey, new SimpleDateFormat(dateFormat))
            }
            var = dateFormatMap.get(entryKey).parse(value.toString())
            values.put(target, var)
        }
        return var
    }

    def propertyMissing(String entryKey) {
        return values.get(entryKey)
    }

    void setProperty(String entryKey, Object value) {
        values.put(entryKey, value)
    }

    Object getAt(String property) {
        return values.get(property)
    }

    void putAt(String key, Object value) {
        values.put(key, value)
    }

}
