package com.edifecs.support.log

import com.edifecs.support.SupportRuntimeException
import com.edifecs.support.core.GroovyUtil
import com.edifecs.support.core.Patterns
import com.edifecs.support.core.ToolHelper
import groovy.transform.CompileStatic
import groovy.util.logging.Log4j2
import org.apache.commons.lang.time.DurationFormatUtils
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger

import java.text.MessageFormat

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
@Log4j2
class Tool {
    protected static final String LOG4J_OPTION = '-log4j'
    protected static final String REGEX_OPTION = '-regex'
    protected static final String SOURCE_OPTION = "source"
    protected static final String DESTINATION_OPTION = "destination"
    private static final Set<String> configTypes = [LOG4J_OPTION, REGEX_OPTION, SOURCE_OPTION, DESTINATION_OPTION] as Set

    protected static final String FAILURE_MSG = "Internal error. Please see logs for more details..."

    private static Logger clLogger

    private static void usage() {
        println """
Crawls files/folder based on logging consumer rules

Usage:
logCrawler [$LOG4J_OPTION/$REGEX_OPTION option] [sourceFiles/sourceFolders...] [<builder script>.groovy]

WHERE:
    [$LOG4J_OPTION/$REGEX_OPTION option]
        Logging configuration option; option is required before file/folder definition.
        '$LOG4J_OPTION option' can be either a log4j config file (applied ONLY for folder) OR a log4j conversion pattern.
        '$REGEX_OPTION option' regular expression string used to match logging entry line
    [<builder script>.groovy]
        Logging crawler builder Groovy configuration script.
"""
    }

    static ToolHelper parseToolArguments(String... args) {
        return ToolHelper.Builder.of("support")
                .withHeader(Arrays.asList(
                        "Edifecs Support Tools Version 0.1 (STL).",
                        MessageFormat.format("Copyright (c) Edifecs, Inc {0}", Calendar.getInstance().get(Calendar.YEAR)),
                        "\n"
                )).withUsage(Arrays.asList(
                "Usage:",
                "       logs [-source <source folder>] [-destination <results destination>] [-verbose] [-debug] [-help]"
        ))
                .usingConsoleLogger("ConsoleAppender", "com.edifecs")
                .usingFileLogger("com.edifecs")
                .addOption(SOURCE_OPTION, "source folder", true, true)
                .addOption(DESTINATION_OPTION, "results destination", true, true)
                .addOption(LOG4J_OPTION, "can be either a log4j config file (applied ONLY for folder) OR a log4j conversion pattern.", true, true)
                .addOption(REGEX_OPTION, "regular expression string used to match logging entry line", false, true)
                .build(args)
    }

    static boolean shouldShowUsage(ToolHelper toolHelper) {
        return toolHelper.hasArgument(ToolHelper.HELP)
    }

    private static void handleLog4jOption(LogsBuilder builder, String configValue, File file) {
        final boolean configFile = !Log4jConsumer.isConversionPattern(configValue)
        if (file == null) {
            if (configFile) {
                builder.log4jConfig(configValue)
            } else {
                builder.log4jPattern(configValue)
            }
            return
        }
        if (file.isDirectory()) {
            if (configFile) {
                builder.log4jSource(file, configValue)
            } else {
                builder.log4jPattern(file, configValue)
            }
        } else {
            if (configFile) {
                builder.log4jSource(file, configValue)
            } else {
                final sourceEntry = Utils.newLogSource(new LogEntry(source: file), file.path)
                builder.register(sourceEntry, builder.log4jPattern(configValue), configValue)
            }
        }
    }
    private static void handleRegexOption(LogsBuilder builder, String configValue, File file) {
        if (file == null) {
            builder.regex(configValue)
            return
        }
        if (file.isDirectory()) {
            builder.regex(file, Patterns.of(configValue))
        } else {
            final sourceEntry = Utils.newLogSource(new LogEntry(source: file), file.path)
            builder.register(sourceEntry, builder.regex(configValue), configValue)
        }
    }

    private static File lookupFile(String[] args, int i) {
        if (args.length <= i) {
            return null
        }
        final value = args[i]
        if (configTypes.contains(value.toLowerCase())) {
            return null
        }
        if (value.toLowerCase().endsWith('groovy')) {
            return null
        }
        return new File(value)
    }

    private static int handleOptionArguments(LogsBuilder builder, String[] args, int i) {
        final String configType = args[i]
        final String configValue = args[i + 1]
        final File file = lookupFile(args, i + 2)
        switch (configType) {
            case LOG4J_OPTION:
                handleLog4jOption(builder, configValue, file)
                i = file == null ? i + 1 : i + 2
                break
            case REGEX_OPTION:
                handleRegexOption(builder, configValue, file)
                i = file == null ? i + 1 : i + 2
                break
            case SOURCE_OPTION:
                builder.source(new File(configValue))
                i = i + 1
                break
            case DESTINATION_OPTION:
                builder.toDestination(configValue)
                i = i + 1
                break;
        }
        return i
    }

    static <B extends LogsBuilder> B init(B builder, String... args) {
        if (!args) {
            return builder
        }
        final Collection<String> scripts = []
        for (int i = 0; i < args.length; i++) {
            final arg = args[i]
            if (configTypes.contains(arg.toLowerCase())) {
                i = handleOptionArguments(builder, args, i)
            } else {
                scripts.add(arg)
            }
        }
        for (final script : scripts) {
            GroovyUtil.parseScript(script, builder)
        }
        return builder
    }

    @SuppressWarnings("squid:S2221")
    static int doMain(String... args) {
        clLogger = LogManager.getLogger("ConsoleLine")
        int errorCode = 0
        try {
            final startTime = System.currentTimeMillis()
            System.setProperty("log4j.defaultInitOverride", "true")
            final ToolHelper toolHelper = parseToolArguments(args)
            toolHelper.logHeader()
            if (shouldShowUsage(toolHelper)) {
                errorCode = 2
                toolHelper.logUsage()
            }
            if (errorCode == 0) {
                final builder = Logs.builder(args)
                if (!toolHelper.hasArgument(DESTINATION_OPTION)) {
                    builder.resolveOutputConsumer()
                }
                builder.build().consume()
                log.info("Crawled using: '${args.join(', ')}'; Execution time: ${DurationFormatUtils.formatDurationWords(System.currentTimeMillis() - startTime, true, true)}")
            }
        } catch (IllegalArgumentException | UnsupportedOperationException ignore) {
            System.err.println(ignore)
            usage()
        } catch (SupportRuntimeException e) {
            log.debug(FAILURE_MSG, e)
            errorCode = 1
        } catch (Exception e) {
            log.debug(FAILURE_MSG, e)
            errorCode = -1
        }
        if (errorCode != 0) {
            clLogger.error("\n")
            clLogger.error(FAILURE_MSG)
            clLogger.error("\n")
        }
        return errorCode
    }

    static void main(String... args) {
        com.edifecs.support.core.Utils.disableIllegalReflectiveAccessWarning()
        System.exit(doMain(args))
    }

}
