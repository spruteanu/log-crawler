//file:noinspection unused
package com.edifecs.support.log

import com.edifecs.support.SupportRuntimeException
import com.edifecs.support.core.*
import groovy.transform.CompileStatic
import groovy.transform.PackageScope
import groovy.util.logging.Log4j2
import org.apache.commons.lang.StringUtils
import org.intellij.lang.annotations.Language

import javax.sql.DataSource
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.attribute.BasicFileAttributes
import java.text.SimpleDateFormat
import java.util.concurrent.ExecutorService
import java.util.concurrent.TimeUnit
import java.util.function.Predicate
import java.util.regex.Pattern
import java.util.stream.Collectors

/**
 * @author Serge Pruteanu
 */
@CompileStatic
@Log4j2
class LogsBuilder {

    static final Comparator<Path> CREATED_DT_COMPARATOR = { Path l, Path r ->
        final leftCreated = Files.readAttributes(l, BasicFileAttributes.class).creationTime()
        final rightCreated = Files.readAttributes(r, BasicFileAttributes.class).creationTime()
        return leftCreated.compareTo(rightCreated)
    } as Comparator<Path>

    protected ConsumerBuilderProvider provider = ConsumerBuilderProvider.of()

    protected Logs logs
    protected final Map<String, Object> sourceNameConsumerMap = [:]
    protected final Map<LogEntry, Object> sourceMap = [:]
    protected final List<ConsumerBuilder> builders = []

    protected final Map<String, ConsumerBuilder> registeredConsumerMethods = Collections.synchronizedMap(new LinkedHashMap<String, ConsumerBuilder>())
    protected MacroSubstitutionContentResolver variableResolver
    protected ContentResolver contentResolver = new FileResourceContentResolver()
    protected String destination

    LogsBuilder() {
        logs = new Logs()
    }

    ConsumerBuilderProvider getProvider() {
        return provider
    }
    LogsBuilder usingProvider(ConsumerBuilderProvider provider) {
        this.provider = provider
        return this
    }
    LogsBuilder usingContentResolver(ContentResolver contentResolver) {
        this.contentResolver = contentResolver
        return this
    }

    synchronized String resolveVariable(String path) {
        if (variableResolver == null) {
            variableResolver = Context.envSystemMacroResolver()
        }
        return variableResolver.resolve(path)
    }

    protected File resolveSourceFile(RegexConsumer.Builder builder) {
        return new File(resolveVariable(builder.source))
    }

    protected File resolveFile(String argFile) {
        return new File(resolveVariable(argFile))
    }

    LogConsumer getConsumer(Object consumerId, Object... args) {
        return provider.get(consumerId, args) as LogConsumer
    }
    @SuppressWarnings("GrUnnecessaryPublicModifier")
    public <T> T getRegisteredConsumer(String sourceName) {
        def result = sourceNameConsumerMap.get(sourceName) as T
        if (!result) {
            try {
                result = provider.get(sourceName)
            } catch (Exception ignore) { /*noop*/ }
        }
        return result
    }

    LogsBuilder parallel(int awaitTimeout = 0, TimeUnit unit = TimeUnit.MILLISECONDS) {
        builders.add(AsynchronousJobs.builder(logs).withExecutorService(awaitTimeout, unit))
        return this
    }

    LogsBuilder parallel(ExecutorService executorService, int awaitTimeout = 0, TimeUnit unit = TimeUnit.MILLISECONDS) {
        builders.add(AsynchronousJobs.builder(logs).withExecutorService(executorService, awaitTimeout, unit))
        return this
    }

    LogsBuilder provider(ConsumerBuilderProvider provider) {
        this.provider = provider
        return this
    }

    LogsBuilder using(LogConsumer consumer) {
        builders.add(new ConsumerBuilder().using(consumer))
        return this
    }
    LogsBuilder using(String consumer, String... consumers) {
        Objects.requireNonNull(consumer, 'Consumer name must not be null')
        for (final c : consumer.split(',')) {
            using(getConsumer(c))
        }
        if (consumers) {
            for (final c : consumers) {
                using(c)
            }
        }
        return this
    }

    LogsBuilder logEntry(@DelegatesTo(LogEntry) Closure logEntryClosure) {
        return using(new LogEntryClosureConsumer(logEntryClosure))
    }

    LogsBuilder filter(Predicate<LogEntry> predicate, LogConsumer consumer, LogConsumer... consumers) {
        def cs = consumers ? ContainerConsumer.of(consumer).addAll(consumers) : consumer
        return using(new PredicateConsumer(predicate, cs))
    }

    LogsBuilder filter(@DelegatesTo(LogEntry) Closure<Boolean> predicate, @DelegatesTo(LogEntry) Closure consumer, @DelegatesTo(LogEntry) Closure... consumers) {
        def cs = consumers ? ContainerConsumer.of(consumer).addAll(consumers) : new LogEntryClosureConsumer(consumer)
        return filter(new LogEntryClosurePredicate(predicate), cs)
    }

    protected void addSource(LogEntry logEntry) {
        sourceMap.put(logEntry, null)
    }

    LogsBuilder source(RandomAccessFile rf, String sourceName = null) {
        addSource(Utils.newLogSource(rf, sourceName))
        return this
    }

    LogsBuilder source(InputStream inputStream, String sourceName = null) {
        addSource(Utils.newLogSource(inputStream, sourceName))
        return this
    }

    LogsBuilder source(Reader reader, String sourceName = null) {
        addSource(Utils.newLogSource(reader, sourceName))
        return this
    }

    LogsBuilder sourceContent(String content, String sourceName = null) {
        addSource(Utils.newLogSource(content, sourceName))
        return this
    }

    def lookupSourceConsumer(String name) {
        for (Map.Entry<String, Object> entry : sourceNameConsumerMap.entrySet()) {
            if (Patterns.of(Directories.toFileWildcardRegex(entry.key), Pattern.CASE_INSENSITIVE).matcher(name).matches()) {
                return entry.value
            }
        }
        return null
    }

    boolean hasRegisteredConsumers() {
        return !sourceNameConsumerMap.isEmpty()
    }

    LogsBuilder source(File file, String fileFilter = '*', Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        if (!hasRegisteredConsumers()) {
            throw new IllegalStateException("Logger configurations not found. Call source methods after logging configurations are defined.")
        }
        // todo: add zip support
        if (file.isDirectory() && file.exists()) {
            for (final File f : listFiles(file, fileFilter, fileSorter)) {
                final name = f.getName()
                def builder = getRegisteredConsumer(name)
                if (!builder) {
                    builder = lookupSourceConsumer(name)
                }
                if (builder) {
                    log.debug("Found consumer for '$f': '$builder'")
                    source(f, builder)
                }
                if (!builder) {
                    log.warn("Consumer not found for '$f'")
                }
            }
        } else {
            addSource(Utils.newLogSource(file, file.name))
        }
        return this
    }

    LogsBuilder source(String file) {
        return source(new File(file))
    }

    protected static List<File> listFiles(File folder, String fileFilter = '*', Comparator<Path> fileSorter = LogsBuilder.CREATED_DT_COMPARATOR) {
        assert folder.exists() && folder.isDirectory(), "Folder: '$folder.path' doesn't exists"
        log.debug("Scanning '$folder.path' for logging sources using: '$fileFilter' filter")
        final results = Directories.filesStream(folder.toPath(), Directories.toFileWildcardPredicate(fileFilter))
                .sorted(fileSorter).map({ it.toFile() }).collect(Collectors.toList())
        if (results) {
            log.debug("Found '${results.size()}' files in '$folder.path'")
        } else {
            log.debug("No files found in '$folder.path' using '$fileFilter' filter")
        }
        return results
    }

    protected void register(LogEntry sourceEntry, Object sourceConsumer, String sourceName = null) {
        sourceMap.put(sourceEntry, sourceConsumer)
        if (sourceName) {
            sourceNameConsumerMap.put(sourceName, sourceConsumer)
        }
    }

    protected void source(File file, def builder, String sourceName = null, String fileFilter = null) {
        final logEntry = Utils.newLogSource(new LogEntry(source: file), file.path)
        register(logEntry, builder, sourceName)
        register(logEntry, builder, fileFilter)
    }

    protected void source(File folder, ConsumerBuilder builder, String sourceName, String fileFilter, Comparator<Path> fileSorter) {
        final files = listFiles(folder, fileFilter, fileSorter)
        for (File file : files) {
            source(file, builder, sourceName, fileFilter)
        }
    }

    LogsBuilder source(String path, LogConsumer consumer, Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        path = resolveVariable(path)
        int idx = Utils.indexOfFileFilter(path)
        String fileFilter = null
        if (idx >= 0) {
            fileFilter = path.substring(idx, path.length())
            path = path.substring(0, idx)
        }
        fileFilter = Utils.defaultFolderFilter(path, fileFilter, '*')

        final folder = new File(path)
        final files = listFiles(folder, fileFilter, fileSorter)
        final builder = using(consumer)
        for (File file : files) {
            register(Utils.newLogSource(new LogEntry(source: folder), file.path), builder)
        }
        return builder
    }

    Log4jConsumer.Builder log4jPattern(File file, String conversionPattern, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null,
                                       String fileFilter = '*', Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        final builder = GroovyUtil.closureCall(closure, Log4jConsumer.Builder.class,
                { new Log4jConsumer.Builder(this, Log4jConsumer.of(conversionPattern)) })
        builder.file = fileFilter
        if (file.isDirectory()) {
            source(file, builder, conversionPattern, fileFilter, fileSorter)
        } else {
            if (file.exists()) {
                source(file, builder, file.name, builder.fileFilter)
            } else {
                sourceConsumer(builder.source(file.path), conversionPattern)
            }
        }
        return builder
    }

    Log4jConsumer.Builder log4jPattern(String path, String conversionPattern, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null,
                                       String fileFilter = '*', Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        return log4jPattern(new File(path), conversionPattern, closure, fileFilter, fileSorter)
    }

    LogsBuilder log4jSource(File file, String log4jConfig, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null,
                            Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        final log4jConsumerProperties = Log4jConsumer.extractLog4jConsumerProperties(GroovyUtil.lookupText(log4jConfig).readLines())
        if (log4jConsumerProperties.isEmpty()) {
            throw new IllegalArgumentException("Either empty or there are no file loggers defined in '$log4jConfig'")
        }
        final filterConversionMap = Log4jConsumer.toLog4jFileConversionPattern(log4jConsumerProperties)
        for (Map.Entry<String, String> entry : filterConversionMap.entrySet()) {
            log4jPattern(file, entry.value, closure, entry.key, fileSorter)
        }
        for (Map.Entry<String, Map<String, String>> entry : log4jConsumerProperties.entrySet()) {
            final loggerName = entry.key
            final loggerProperties = entry.value
            final builder = getLog4jConsumer(loggerProperties.get(Log4jConsumer.APPENDER_CONVERSION_PATTERN_PROPERTY))
            if (builder) {
                builder.name = loggerName
                builder.file = loggerProperties.get(Log4jConsumer.APPENDER_FILE_PROPERTY)
                GroovyUtil.closureCall(closure, builder)
                register(builder)
            }
        }
        return this
    }

    LogsBuilder source(String filePath, String log4jConfig, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null,
                       Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        return log4jSource(resolveFile(filePath), log4jConfig, closure, fileSorter)
    }

    Log4jConsumer.Builder log4jPattern(String conversionPattern, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, Log4jConsumer.Builder.class,
                { new Log4jConsumer.Builder(this, Log4jConsumer.of(conversionPattern)) })
        if (builder.source) {
            source(resolveSourceFile(builder), builder, conversionPattern, builder.fileFilter, builder.fileSorter)
        } else {
            sourceConsumer(builder, conversionPattern)
        }
        return builder
    }

    protected void register(Log4jConsumer.Builder builder) {
        if (builder.name) {
            sourceNameConsumerMap.put(builder.name, builder)
        }
        if (builder.pattern) {
            sourceNameConsumerMap.put(builder.pattern, builder)
        }
        if (builder.file) {
            sourceNameConsumerMap.put(builder.file, builder)
        }
    }

    LogsBuilder log4jConfig(String log4jConfig, @DelegatesTo(Log4jConsumer.Builder) Closure closure = null) {
        final log4jConsumerProperties = Log4jConsumer.extractLog4jConsumerProperties(GroovyUtil.lookupText(log4jConfig).readLines())
        if (log4jConsumerProperties.isEmpty()) {
            throw new IllegalArgumentException("Either empty or there are no file loggers defined in '$log4jConfig'")
        }
        for (Map.Entry<String, Map<String, String>> entry : log4jConsumerProperties.entrySet()) {
            final loggerName = entry.key
            final loggerProperties = entry.value
            final conversionPattern = loggerProperties.get(Log4jConsumer.APPENDER_CONVERSION_PATTERN_PROPERTY)
            final appenderFile = loggerProperties.get(Log4jConsumer.APPENDER_FILE_PROPERTY)
            if (conversionPattern == null || appenderFile == null) {
                continue
            }
            final builder = new Log4jConsumer.Builder(this, Log4jConsumer.of(conversionPattern))
            builder.name = loggerName
            builder.file = appenderFile
            GroovyUtil.closureCall(closure, builder)
            register(builder)
        }
        return this
    }

    protected LogsBuilder sourceConsumer(Object sourceConsumer, String sourceName = null) {
        for (LogEntry sourceEntry : sourceMap.keySet()) {
            final sc = sourceMap.get(sourceEntry)
            if (sc == null) {
                register(sourceEntry, sourceConsumer, sourceName)
            }
        }
        return this
    }

    RegexConsumer.Builder regex(Pattern pattern, @DelegatesTo(RegexConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, RegexConsumer.Builder.class, { new RegexConsumer.Builder(this, RegexConsumer.of(pattern)) })
        if (builder.source) {
            source(resolveSourceFile(builder), builder, pattern.pattern(), builder.fileFilter, builder.fileSorter)
        } else {
            builders.add(builder)
        }
        return builder
    }

    RegexConsumer.Builder regex(String regEx, int flags = 0,
                                @DelegatesTo(RegexConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, RegexConsumer.Builder.class,
                { new RegexConsumer.Builder(this, RegexConsumer.of(regEx, flags)) })
        if (builder.source) {
            source(resolveSourceFile(builder), builder, regEx, builder.fileFilter, builder.fileSorter)
        } else {
            builders.add(builder)
        }
        return builder
    }

    RegexConsumer.Builder regex(@DelegatesTo(RegexConsumer.Builder) Closure closure) {
        final builder = GroovyUtil.closureCall(closure, RegexConsumer.Builder.class,
                { new RegexConsumer.Builder(this, new RegexConsumer()) })
        if (!builder.pattern) {
            throw new IllegalArgumentException('Regex pattern must be defined, please set it in configuration')
        }
        if (builder.source) {
            source(resolveSourceFile(builder), builder, builder.pattern, builder.fileFilter, builder.fileSorter)
        } else {
            builders.add(builder)
        }
        return builder
    }

    RegexConsumer.Builder regex(File folder, Pattern pattern,
                                String fileFilter = '*', Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        final builder = new RegexConsumer.Builder(this, RegexConsumer.of(pattern))
        source(folder, builder, pattern.pattern(), fileFilter, fileSorter)
        return builder
    }

    RegexConsumer.Builder getRegexConsumer(String regex) {
        return (RegexConsumer.Builder)getRegisteredConsumer(regex)
    }

    Log4jConsumer.Builder getLog4jConsumer(String sourceName) {
        return (Log4jConsumer.Builder)getRegisteredConsumer(sourceName)
    }

    LogsBuilder toDestination(String destination) {
        this.destination = destination
        return this
    }

    LogsBuilder toDate(SimpleDateFormat dateFormat, String group = DateConsumer.DATE) {
        return using(DateConsumer.of(dateFormat, group))
    }

    LogsBuilder toDate(String dateFormat, String group = DateConsumer.DATE) {
        return using(DateConsumer.of(dateFormat, group))
    }
    LogsBuilder toDate(@DelegatesTo(DateConsumer) Closure closure) {
        final consumer = new DateConsumer()
        GroovyUtil.closureCall(closure, consumer)
        return using(consumer)
    }

    LogsBuilder toException(ExceptionConsumer consumer) {
        return using(consumer)
    }
    LogsBuilder toException(@DelegatesTo(ExceptionConsumer) Closure closure) {
        final consumer = new ExceptionConsumer()
        GroovyUtil.closureCall(closure, consumer)
        return using(consumer)
    }
    LogsBuilder collectExceptions(Map<String, List<LogEntry>> exceptionMap) {
        toException(new ExceptionConsumer())
        return using(ExceptionConsumer.exceptionsCollector(exceptionMap))
    }

    TableBatchConsumer.Builder toDb(DataSource dataSource, @DelegatesTo(TableBatchConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, TableBatchConsumer.Builder.class,
                { new TableBatchConsumer.Builder(this, TableBatchConsumer.of(dataSource, 'LogEntry')) })
        builders.add(builder)
        return builder
    }

    LogsBuilder toCsv(Writer writer, String... columns) {
        return using(CsvWriterConsumer.of(writer, columns))
    }

    LogsBuilder toCsv(File writer, String... columns) {
        return using(CsvWriterConsumer.of(writer, columns))
    }

    CsvWriterConsumer.Builder toCsv(File file, @DelegatesTo(CsvWriterConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, CsvWriterConsumer.Builder.class,
                { new CsvWriterConsumer.Builder(this, CsvWriterConsumer.of(file)) })
        builders.add(builder)
        return builder
    }

    LogsBuilder toCsv(String writer, String... columns) {
        return using(CsvWriterConsumer.of(resolveVariable(writer), columns))
    }

    CsvWriterConsumer.Builder toCsv(String filePath, @DelegatesTo(CsvWriterConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, CsvWriterConsumer.Builder.class,
                { new CsvWriterConsumer.Builder(this, CsvWriterConsumer.of(resolveVariable(filePath))) })
        builders.add(builder)
        return builder
    }

    JSonWriterConsumer.Builder toJson(Writer writer, @DelegatesTo(JSonWriterConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, JSonWriterConsumer.Builder.class,
                { new JSonWriterConsumer.Builder(this, CsvWriterConsumer.of(writer)) })
        builders.add(builder)
        return builder
    }

    JSonWriterConsumer.Builder toJson(File file, @DelegatesTo(JSonWriterConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, JSonWriterConsumer.Builder.class,
                { new JSonWriterConsumer.Builder(this, CsvWriterConsumer.of(file)) })
        builders.add(builder)
        return builder
    }

    JSonWriterConsumer.Builder toJson(String filePath, @DelegatesTo(JSonWriterConsumer.Builder) Closure closure = null) {
        final builder = GroovyUtil.closureCall(closure, JSonWriterConsumer.Builder.class,
                { new JSonWriterConsumer.Builder(this, JSonWriterConsumer.of(resolveVariable(filePath))) })
        builders.add(builder)
        return builder
    }

    LogsBuilder log4j(@DelegatesTo(Log4jConsumer.Builder) Closure closure) {
        final builder = GroovyUtil.closureCall(closure, Log4jConsumer.Builder.class,
                { new Log4jConsumer.Builder(this, new Log4jConsumer()) })
        if (!builder.pattern) {
            throw new IllegalArgumentException('Either conversion pattern or log4j config file must be defined, please set it in configuration')
        }
        if (builder.source && resolveFile(builder.pattern).exists()) {
            log4jSource(resolveSourceFile(builder), resolveVariable(builder.pattern), closure, builder.fileSorter)
        } else {
            if (builder.source) {
                source(resolveSourceFile(builder), builder, builder.pattern, builder.fileFilter, builder.fileSorter)
            } else {
                sourceConsumer(builder, builder.pattern)
            }
        }
        return this
    }

    @SuppressWarnings("unchecked")
    def include(String groovyScript) {
        Object result
        try {
            result = parseScript(groovyScript, this, new Binding([] as String[]))
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to include script: '%s'", groovyScript), e)
        }
        return result
    }

    @PackageScope
    Object parseScript(String groovyScript, Object context, Binding binding) {
        return parseScript(groovyScript, context, binding, contentResolver)
    }

    @PackageScope
    Object parseScript(String groovyScript, Object context, Binding binding, ContentResolver contentResolver) {
        return GroovyUtil.parseScript(resolveVariable(groovyScript), context, binding, contentResolver)
    }

    def include(String groovyScript, Object parent, Binding binding) {
        Object result
        try {
            final LogsBuilder context
            if (parent == null) {
                context = this
            } else {
                context = GroovyUtil.lookupDelegate(parent, LogsBuilder.class, { this })
            }
            result = parseScript(groovyScript, context, binding != null ? binding : new Binding([] as String[]), contentResolver)
        } catch (SupportRuntimeException e) {
            throw e
        } catch (Exception e) {
            throw new SupportRuntimeException(String.format("Failed to include script: '%s'", groovyScript), e)
        }
        return result
    }

    def include(String groovyScript, Object parent, Map<String, Object> vars) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(vars))
    }

    def include(String groovyScript, Script parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args))
    }

    def include(String groovyScript, Closure parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args))
    }

    def include(String groovyScript, Object parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args))
    }

    def include(String groovyScript, Map<String, Object> vars) {
        return include(groovyScript, this, vars)
    }

    def include(String groovyScript, String... args) {
        return include(groovyScript, this, GroovyUtil.lookupBinder(args))
    }

    def include(String groovyScript, Script parent) {
        return include(groovyScript, parent, (Binding) null)
    }

    def include(String groovyScript, Closure parent) {
        return include(groovyScript, parent, (Binding) null)
    }

    def include(String groovyScript, Object parent) {
        return include(groovyScript, parent, (Binding) null)
    }

    def includeScript(@Language("groovy") String groovyScript) {
        return include(groovyScript, null, (Binding) null)
    }

    def includeScript(@Language("groovy") String groovyScript, Object parent, Map<String, Object> vars) {
        return include(groovyScript, parent, vars)
    }

    def includeScript(@Language("groovy") String groovyScript, Object parent, String... args) {
        return include(groovyScript, parent, GroovyUtil.lookupBinder(args))
    }

    def includeScript(@Language("groovy") String groovyScript, Object parent) {
        return include(groovyScript, parent, (Binding) null)
    }

    @PackageScope
    void buildSources() {
        final List<String> sourceNames = new ArrayList<>()
        final Map<Object, LogConsumer> consumers = [:]
        for (Map.Entry<LogEntry, Object> entry : sourceMap.entrySet()) {
            final value = entry.value
            LogConsumer source = null
            if (value instanceof ConsumerBuilder) {
                if (consumers.containsKey(value)) {
                    source = consumers.get(value)
                } else {
                    source = value.build()
                    consumers.put(value, source)
                }
            }
            if (source) {
                final logEntry = entry.key
                logs.source(logEntry, new LineReaderConsumer(logs, source))
                final sourceName = Utils.getSourceName(logEntry)
                if (sourceName) {
                    sourceNames.add(sourceName)
                }
            }
        }
        for (Map.Entry<LogEntry, Object> entry : sourceMap.entrySet()) {
            final value = entry.value
            LogConsumer source = null
            if (value instanceof LogConsumer) {
                source = value as LogConsumer
            }
            if (source) {
                final logEntry = entry.key
                logs.source(logEntry, new LineReaderConsumer(logs, source))
                final sourceName = Utils.getSourceName(logEntry)
                if (sourceName) {
                    sourceNames.add(sourceName)
                }
            }
        }
        int difference = StringUtils.indexOfDifference(sourceNames.toArray() as String[])
        if (difference > 0) {
            for (LogEntry logEntry : sourceMap.keySet()) {
                final sourceName = Utils.getSourceName(logEntry)
                if (sourceName) {
                    int idx = indexOfLastFolderSeparator(sourceName)
                    difference = Math.min(difference, indexOfLastFolderSeparator(sourceName, difference))
                    Utils.addSourceName(logEntry, sourceName.substring(Math.min(idx, difference)))
                }
            }
        }
    }

    protected static int indexOfLastFolderSeparator(String sourceName, int sidx = -1) {
        if (sidx < 0) {
            sidx = sourceName.length()
        }
        def ch = '\\'
        int idx = sourceName.lastIndexOf(ch, sidx)
        if (idx < 0) {
            ch = '/'
            idx = sourceName.lastIndexOf(ch, sidx)
        }
        return idx < 0 ? sidx : idx + 1
    }

    protected LogsBuilder resolveOutputConsumer() {
        ConsumerOutput consumerOutput = null
        for (final builder : builders) {
            final consumer = builder.getConsumer()
            if (consumer instanceof ConsumerOutput) {
                consumerOutput = consumer
                break
            }
        }
        if (consumerOutput == null) {
            File file
            if (destination == null) {
                file = com.edifecs.support.core.Utils.checkTimeSuffixedPath(Paths.get(""), "logs-", "json").toFile()
            } else {
                file = new File(destination)
                if (file.isDirectory()) {
                    file = com.edifecs.support.core.Utils.checkTimeSuffixedPath(file.toPath(), "logs-", "json").toFile()
                }
            }
            final fName = file.getName().toLowerCase()
            if (fName.endsWith('csv')) {
                toCsv(file, Log4jConsumer.DATE, Log4jConsumer.PRIORITY, Log4jConsumer.EVENT_CATEGORY, Log4jConsumer.MESSAGE)
            } else {
                toJson(file)
            }
        }
        return this
    }

    @PackageScope
    void buildConsumers() {
        for (ConsumerBuilder builder : builders) {
            final logConsumer = builder.build()
            if (logConsumer) {
                logs.using(logConsumer)
            }
        }
    }

    Logs build() {
        buildSources()
        buildConsumers()
        sourceMap.clear()
        sourceNameConsumerMap.clear()
        builders.clear()
        return logs
    }

    private void checkRegisteredMethodsLoaded() {
        if (registeredConsumerMethods.isEmpty()) {
            synchronized (registeredConsumerMethods) {
                final builders = provider.getRegisteredBuilders()
                for (final builder : builders) {
                    for (final method : builder.getClass().methods) {
                        registeredConsumerMethods.put(method.name, builder)
                    }
                }
            }
        }
    }

    def methodMissing(String name, args) {
        checkRegisteredMethodsLoaded()
        if (registeredConsumerMethods.containsKey(name)) {
            final consumerBuilder = registeredConsumerMethods.get(name)
            consumerBuilder.invokeMethod(name, args)
            builders.add(consumerBuilder)
        } else {
            throw new UnsupportedOperationException("There are no such method: $name defined with arguments: $args")
        }
    }
}
