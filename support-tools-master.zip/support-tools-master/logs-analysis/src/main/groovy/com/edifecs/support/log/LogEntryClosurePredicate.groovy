package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.util.function.Predicate

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class LogEntryClosurePredicate implements Predicate<LogEntry> {
    final Closure<Boolean> closure

    LogEntryClosurePredicate(@DelegatesTo(LogEntry) Closure<Boolean> closure) {
        this.closure = closure
    }

    @Override
    boolean test(LogEntry logEntry) {
        return logEntry.with(closure)
    }
}
