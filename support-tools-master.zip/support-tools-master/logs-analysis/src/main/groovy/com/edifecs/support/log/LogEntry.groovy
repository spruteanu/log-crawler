package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.util.concurrent.ConcurrentHashMap

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class LogEntry extends LogValues implements Cloneable {
    static final String SOURCE_INFO = 'Source'

    String line
    Object source
    int row

    LogEntry() {
        super(new ConcurrentHashMap<String, Object>())
    }

    LogEntry(String line) {
        this(null, line, 0)
    }

    LogEntry(String line, int row) {
        this(null, line, row)
    }

    LogEntry(Object source, String line, int row) {
        super(new ConcurrentHashMap<String, Object>())
        this.source = source
        this.line = line
        this.row = row
    }

    LogEntry source(Object source) {
        this.source = source
        return this
    }

    LogEntry sourceInfo(String value) {
        put(SOURCE_INFO, value)
        return this
    }
    String getSourceInfo() {
        return get(SOURCE_INFO)
    }

    LogEntry values(Map<String, Object> values) {
        super.values(values)
        return this
    }

    @Override
    String toString() {
        return line ? line : (source ? source : values)
    }

}
