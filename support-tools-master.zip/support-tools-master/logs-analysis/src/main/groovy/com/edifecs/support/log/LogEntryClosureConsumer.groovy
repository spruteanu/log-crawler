package com.edifecs.support.log

import groovy.transform.CompileStatic
import groovy.transform.PackageScope

/**
 * @author Serge Pruteanu
 */
@CompileStatic
@PackageScope
class LogEntryClosureConsumer implements LogConsumer {
    private final Closure closure

    LogEntryClosureConsumer(@DelegatesTo(LogEntry) Closure closure) {
        this.closure = closure
    }

    @Override
    void consume(LogEntry entry) {
        entry.with closure
    }

}
