package com.edifecs.support.log

import com.edifecs.support.core.DatePredicate
import com.edifecs.support.core.GroovyUtil
import groovy.transform.CompileStatic

import java.text.SimpleDateFormat
import java.util.function.Predicate
import java.util.function.Supplier

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class DateConsumer implements LogConsumer {
    static final String DATE = 'Date'

    String group = DATE
    String target
    Supplier<SimpleDateFormat> dateFormat

    DateConsumer() {
    }

    DateConsumer(Supplier<SimpleDateFormat> dateFormat, String group = DATE, String target = null) {
        this.target = target
        this.dateFormat = dateFormat
        this.group = group
    }

    protected String lookupDateField() {
        String dateField = target
        if (!dateField) {
            dateField = group
        }
        return dateField
    }

    protected synchronized Date parse(String dateString) {
        return dateFormat.get().parse(dateString)
    }

    @Override
    void consume(LogEntry entry) {
        if (entry.values.containsKey(group)) {
            final dateObj = entry._get(group)
            if (dateObj instanceof String) {
                entry.put(lookupDateField(), parse(dateObj))
            }
        }
    }

    static DatePredicate datePredicate(@DelegatesTo(DatePredicate) Closure closure) {
        final predicate = new DatePredicate()
        GroovyUtil.closureCall(closure, predicate)
        return predicate
    }

    static LogEntryDatePredicate logDatePredicate(@DelegatesTo(LogEntryDatePredicate) Closure closure, String dateField = DATE) {
        final predicate = new LogEntryDatePredicate().dateField(dateField)
        GroovyUtil.closureCall(closure, predicate)
        return predicate
    }
    static LogEntryDatePredicate logDatePredicate(DatePredicate predicate, String dateField = DATE) {
        return new LogEntryDatePredicate().dateField(dateField).datePredicate(predicate)
    }

    static DateConsumer of(Supplier<SimpleDateFormat> dateFormat, String target = DATE) {
        return new DateConsumer(dateFormat, DATE, target)
    }
    static DateConsumer of(SimpleDateFormat dateFormat, String target = DATE) {
        return new DateConsumer({ dateFormat }, DATE, target)
    }

    static DateConsumer of(String dateFormat, String target = DATE) {
        return of(new SimpleDateFormat(dateFormat), target)
    }

    @CompileStatic
    static class LogEntryDatePredicate implements Predicate<LogEntry> {
        private Supplier<String> dateField
        private DatePredicate datePredicate

        void setDateField(Supplier<String> dateField) {
            this.dateField = dateField
        }

        LogEntryDatePredicate dateField(Supplier<String> dateField) {
            setDateField(dateField)
            return this
        }

        LogEntryDatePredicate dateField(final String dateField) {
            setDateField({ dateField })
            return this
        }

        void setDatePredicate(DatePredicate datePredicate) {
            this.datePredicate = datePredicate
        }

        LogEntryDatePredicate datePredicate(DatePredicate datePredicate) {
            setDatePredicate(datePredicate)
            return this
        }

        LogEntryDatePredicate datePredicate(@DelegatesTo(LogEntryDatePredicate) Closure closure) {
            setDatePredicate(new DatePredicate())
            GroovyUtil.closureCall(closure, datePredicate)
            return this
        }

        @Override
        boolean test(LogEntry entry) {
            boolean result = false
            def dateObj = entry._get(dateField.get())
            if (!(dateObj instanceof Date)) {
                return false
            }
            final date = dateObj as Date
            if (!date) {
                return result
            }
            return datePredicate.test(date)
        }
    }
}
