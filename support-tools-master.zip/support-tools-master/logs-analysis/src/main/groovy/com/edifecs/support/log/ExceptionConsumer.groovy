package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.util.function.Predicate
import java.util.regex.Pattern

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class ExceptionConsumer implements LogConsumer {
    protected static final String EXCEPTION_REGEX = '^.+Exception[^\\r\\n]++(?:\\s+at .++)+'

    private static final Pattern EXCEPTION_PATTERN = ~/(?ms)(${EXCEPTION_REGEX})/
    private static final Pattern MESSAGE_WITH_EXCEPTION_PATTERN = ~/(?ms)([^\r\n]+)[\r\n]+(${EXCEPTION_REGEX})/
    private static final Pattern EXCEPTION_CLASS_MESSAGE_PATTERN = ~/^(.+Exception):([^\r\n]+)*/
    private static final Pattern TRACE_CLASS_METHOD_SOURCE_PATTERN = ~/^\s*at\s(.+)\((.+):(\d+)\)/

    static final String LOG_ERROR_MESSAGE = 'LogErrorMessage'
    static final String EXCEPTION = 'Exception'
    static final String EXCEPTION_MESSAGE = 'ExceptionMessage'
    static final String EXCEPTION_CLASS = 'ExceptionClass'
    static final String EXCEPTION_TRACES = 'ExceptionTraces'
    static final String CALLER_CLASS_METHOD = 'CallerClassMethod'
    static final String SOURCE_NAME = 'SourceName'
    static final String SOURCE_LINE = 'SourceLine'
    public static final String CAUSED_BY_PREFIX = 'Caused by:'

    String group
    boolean includeTraces

    ExceptionConsumer(String group = 'Message') {
        this.group = group
    }

    ExceptionConsumer includeTraces() {
        includeTraces = true
        return this
    }
    ExceptionConsumer noTraces() {
        includeTraces = false
        return this
    }

    protected void processExceptionClass(LogEntry entry, List<String> lines) {
        final List exceptions = new ArrayList<>()
        for (String line : lines) {
            final map = RegexConsumer.toMap(EXCEPTION_CLASS_MESSAGE_PATTERN, line, [(EXCEPTION_CLASS): 1, (EXCEPTION_MESSAGE): 2])
            if (map) {
                def exceptionClass = map.get(EXCEPTION_CLASS)
                if (exceptionClass) {
                    exceptionClass = exceptionClass.toString().trim()
                    if (exceptionClass.startsWith(CAUSED_BY_PREFIX)) {
                        map.put(EXCEPTION_CLASS, exceptionClass.substring(CAUSED_BY_PREFIX.length()).trim())
                    }
                }
                exceptions.add(map)
            }
        }
        if (exceptions) {
            entry.put(EXCEPTION_CLASS, exceptions)
        }
    }
    protected void processTraces(LogEntry entry, List<String> lines) {
        final List traces = new ArrayList<>()
        for (String traceLine : lines.subList(1, lines.size())) {
            final map = RegexConsumer.toMap(TRACE_CLASS_METHOD_SOURCE_PATTERN, traceLine, [(CALLER_CLASS_METHOD): 1, (SOURCE_NAME): 2, (SOURCE_LINE): 3])
            if (map) {
                traces.add(map)
            }
        }
        if (traces) {
            entry.put(EXCEPTION_TRACES, traces)
        }
    }
    @Override
    void consume(LogEntry entry) {
        final value = entry.get(group)
        if (value && EXCEPTION_PATTERN.matcher(value.toString()).matches()) {
            entry.values.putAll(RegexConsumer.toMap(MESSAGE_WITH_EXCEPTION_PATTERN, value.toString(), [(LOG_ERROR_MESSAGE): 1, (EXCEPTION): 2]))
            if (entry.values.containsKey(EXCEPTION)) {
                final exception = entry.get(EXCEPTION).toString()
                final lines = exception.split('\r\n|\r|\n').toList()
                processExceptionClass(entry, lines)
                if (includeTraces) {
                    processTraces(entry, lines)
                }
            }
        }
    }

    static ExceptionConsumer of(String group = 'Message') {
        return new ExceptionConsumer(group)
    }

    static boolean containsException(LogEntry entry) {
        return null != entry.get(ExceptionConsumer.EXCEPTION)
    }
    static boolean containsException(LogEntry entry, String exceptionText) {
        boolean result = false
        final exception = entry.get(EXCEPTION)
        if (exception) {
            result = exception.toLowerCase().contains(exceptionText.toLowerCase())
        }
        return result
    }

    @SuppressWarnings(['GrUnnecessaryPublicModifier', 'ChangeToOperator'])
    public static <T extends Throwable> boolean ofType(Class<T> aClass, LogEntry entry) {
        boolean result = false
        final exceptions = getExceptions(entry)
        for (int i = 0; i < exceptions.size() && !result; i++) {
            final map = exceptions.get(i)
            final exceptionClassName = map.get(EXCEPTION_CLASS)
            if (exceptionClassName == null) {
                return false
            }
            result = aClass.getName().equals(exceptionClassName)
        }
        return result
    }

    @SuppressWarnings('GrUnnecessaryPublicModifier')
    public static <T extends Throwable> boolean assignable(Class<T> aClass, LogEntry entry) {
        for (final Map<String, String> map : getExceptions(entry)) {
            final exceptionClassName = map.get(EXCEPTION_CLASS)
            if (exceptionClassName == null) {
                return false
            }
            try {
                return aClass.isAssignableFrom(Class.forName(exceptionClassName))
            } catch (Exception ignore) {
                return false
            }
        }
    }

    @SuppressWarnings('ChangeToOperator')
    static boolean ofType(String className, LogEntry entry) {
        return getExceptions(entry).stream().filter { className.equals(it.get(EXCEPTION_CLASS)) }.findAny()
    }

    static List<Map<String, String>> getExceptions(LogEntry entry) {
        def value = entry._get(EXCEPTION_CLASS)
        if (value instanceof List) {
            return value as List
        }
        return Collections.emptyList()
    }

    protected static Map<String, String> getException(LogEntry entry, int index) {
        final list = getExceptions(entry)
        def value = null
        if (list) {
            value = index < 0 ? list.last() : list[index]
        }
        if (value instanceof Map) {
            return value
        }
        return null
    }
    static Map<String, String> getException(LogEntry entry) {
        return getException(entry, 0)
    }
    static Map<String, String> getRootException(LogEntry entry) {
        return getException(entry, -1)
    }
    static String getExceptionClass(LogEntry entry) {
        return getException(entry).get(EXCEPTION_CLASS)
    }

    static ExceptionsCollector exceptionsCollector(Map<String, List<LogEntry>> entries) {
        return new ExceptionsCollector(entries)
    }
    static ExceptionsCollector exceptionsCollector() {
        return exceptionsCollector(new LinkedHashMap<String, List<LogEntry>>(1024))
    }

    @CompileStatic
    static class ExceptionsCollector implements LogConsumer {
        final Map<String, List<LogEntry>> entries
        private boolean flattenAll = true
        private Predicate<String> exceptionFilter = { true }

        ExceptionsCollector(int size = 1024) {
            this(new LinkedHashMap<String, List<LogEntry>>(size))
        }

        ExceptionsCollector(Map<String, List<LogEntry>> entries) {
            this.entries = entries
        }

        ExceptionsCollector flattenAll() {
            this.flattenAll = true
            return this
        }
        ExceptionsCollector originalOnly() {
            this.flattenAll = false
            return this
        }

        ExceptionsCollector exceptionFilter(Predicate<String> exceptionFilter) {
            this.exceptionFilter = exceptionFilter
            return this
        }

        @Override
        void consume(LogEntry entry) {
            if (!containsException(entry)) {
                return
            }
            final eEntries
            if (flattenAll) {
                eEntries = getExceptions(entry)
            } else {
                eEntries = Collections.singletonList(getException(entry))
            }
            for (final map : eEntries) {
                final eClass = map.get(EXCEPTION_CLASS)
                if (exceptionFilter.test(eClass)) {
                    def list = entries.get(eClass)
                    if (list == null) {
                        list = new ArrayList<LogEntry>(32)
                        entries.put(eClass, list)
                    }
                    list.add(entry)
                }
            }
        }
    }
}
