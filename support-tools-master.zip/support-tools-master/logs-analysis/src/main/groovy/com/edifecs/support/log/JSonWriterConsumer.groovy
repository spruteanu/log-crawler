package com.edifecs.support.log

import com.edifecs.support.core.JsonWriter
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class JSonWriterConsumer extends JsonWriter implements ConsumerOutput {
    JSonWriterConsumer() {
        super()
    }

    JSonWriterConsumer(Writer writer) {
        super(writer)
    }

    @Override
    void consume(LogEntry entry) {
        write(entry.getValues())
    }

    static JSonWriterConsumer of(Writer writer) {
        return new JSonWriterConsumer(writer: writer)
    }

    static JSonWriterConsumer of(File file) {
        return new JSonWriterConsumer(writer: new BufferedWriter(new FileWriter(file)))
    }

    static JSonWriterConsumer of(String filePath) {
        return of(new File(filePath))
    }

    @CompileStatic
    static class Builder extends ConsumerBuilder<JSonWriterConsumer> {
        Builder() {
        }

        Builder(LogsBuilder contextBuilder, Object consumer, Object... args) {
            super(contextBuilder, consumer, args)
        }

        Builder writer(Writer writer) {
            getConsumer().writer = writer
            return this
        }

        Builder flushAt(int flushAt = 100) {
            getConsumer().flushAt(flushAt)
            return this
        }
    }
}
