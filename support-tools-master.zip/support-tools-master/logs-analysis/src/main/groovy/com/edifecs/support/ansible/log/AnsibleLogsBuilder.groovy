package com.edifecs.support.ansible.log

import com.edifecs.support.SupportRuntimeException
import com.edifecs.support.log.LogsBuilder
import groovy.transform.CompileStatic

import java.nio.file.Path

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class AnsibleLogsBuilder extends LogsBuilder {
    private AnsibleLogs ansibleLogs

    AnsibleLogsBuilder() {
        logs = ansibleLogs = new AnsibleLogs()
    }

    AnsibleLogsBuilder source(File file, String fileFilter = '*', Comparator<Path> fileSorter = CREATED_DT_COMPARATOR) {
        if (file.exists() && file.isDirectory()) {
            ansibleLogs.jobEvents(file.getAbsolutePath())
        } else {
            // todo: add zip support
            throw new SupportRuntimeException("Only an existing execution directory is supported; provided: '$file'")
        }
        return this
    }

    AnsibleLogsBuilder jobEvents(@DelegatesTo(JobEvents) Closure closure) {
        ansibleLogs.jobEvents(closure)
        return this
    }

    @Override
    AnsibleLogs build() {
        return super.build() as AnsibleLogs
    }
}
