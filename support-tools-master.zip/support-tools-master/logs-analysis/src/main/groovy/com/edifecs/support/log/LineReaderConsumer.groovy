package com.edifecs.support.log

import groovy.transform.CompileStatic
import groovy.transform.PackageScope

@CompileStatic
@PackageScope
class LineReaderConsumer implements LogConsumer {
    final Logs logs
    final LogConsumer sourceConsumer

    LineReaderConsumer(Logs logs, LogConsumer sourceConsumer) {
        this.sourceConsumer = sourceConsumer
        this.logs = logs
    }

    LogConsumer getSourceConsumer() {
        return sourceConsumer
    }

    @Override
    void consume(LogEntry entry) {
        logs.consume(LineReaderInput.of(entry), Utils.getSourceName(entry), sourceConsumer)
    }
}
