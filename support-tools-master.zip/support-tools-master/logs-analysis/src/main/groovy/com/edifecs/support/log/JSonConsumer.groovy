package com.edifecs.support.log

import groovy.json.JsonSlurper
import groovy.transform.CompileDynamic
import groovy.transform.CompileStatic
import org.intellij.lang.annotations.Language

import java.nio.file.Path
import java.nio.file.Paths

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class JSonConsumer implements LogConsumer {
    LogValuesConsumer valuesConsumer = new LogValuesConsumer()

    Map<String, String> getFields() {
        return valuesConsumer.getFields()
    }

    JSonConsumer fields(Map<String, String> fields) {
        valuesConsumer.fields = fields
        return this
    }

    JSonConsumer add(Map<String, String> fields) {
        valuesConsumer.fields.putAll(fields)
        return this
    }

    JSonConsumer all() {
        valuesConsumer.all = true
        return this
    }

    JSonConsumer trimEmpty() {
        valuesConsumer.trimEmpty = true
        return this
    }

    static def readText(@Language("JSON") String text) {
        return new JsonSlurper().parseText(text)
    }

    static def read(Path path) {
        return new JsonSlurper().parse(path.toFile())
    }

    static def read(Reader reader) {
        return new JsonSlurper().parse(reader)
    }

    static def read(InputStream inputStream) {
        return new JsonSlurper().parse(inputStream)
    }

    def textToMap(@Language("JSON") String text) {
        def obj = readText(text)
        if (obj instanceof Map) {
            def rObj = valuesConsumer.toMap(obj)
            if (rObj.size() == 1) {
                obj = rObj.get(rObj.entrySet().iterator().next().getKey())
            } else {
                obj = rObj
            }
        }
        return obj
    }

    Map<String, Object> toMap(Path path) {
        return valuesConsumer.toMap(read(path) as Map)
    }

    Map<String, Object> toMap(Reader reader) {
        return valuesConsumer.toMap(read(reader) as Map)
    }

    Map<String, Object> toMap(InputStream inputStream) {
        return valuesConsumer.toMap(read(inputStream) as Map)
    }

    Map<String, Object> toMap(String path) {
        return toMap(Paths.get(path))
    }

    @Override
    @CompileDynamic
    void consume(LogEntry entry) {
        entry.values = toMap(entry.source)
    }

    static JSonConsumer of() {
        return new JSonConsumer()
    }

    static JSonConsumer of(Map<String, String> fields) {
        return new JSonConsumer().fields(fields)
    }

    static JSonConsumer of(List<String> fields) {
        return new JSonConsumer().fields(Utils.toFieldMap(fields))
    }

    static JSonConsumer of(String fields) {
        return new JSonConsumer().fields(Utils.toFieldMap(fields))
    }
}
