package com.edifecs.support.ansible.log

import com.edifecs.support.core.GroovyUtil
import com.edifecs.support.log.*
import groovy.transform.CompileDynamic
import groovy.transform.CompileStatic

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.function.Consumer
import java.util.function.Predicate
import java.util.stream.Stream

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class JobEvents implements LogConsumer {
    static final String BODY_PROPERTY = "event_data.res.invocation.module_args.body"
    static final String HOST = 'host'
    static final String REMOTE_HOST = 'remoteHost'
    static final String TASK = 'task'
    static final String CREATED = 'created'
    static final String START = 'start'
    static final String END = 'end'
    static final String DURATION = 'duration'
    static final String ELAPSED = 'elapsed'
    static final String EIM_EVENT = 'EIM event'
    static final String UUID = 'uuid'
    static final String PARENT_UUID = 'parentUuid'
    static final String PLAY_UUID = 'playUuid'
    static final String TASK_NAME = 'taskName'
    static final String SCRIPT = 'script'
    static final String TASK_CATEGORY = 'category'
    static final String PLAY_PATTERN = 'playId'
    static final String OUTPUT = 'output'

    static final Map<String, String> DEFAULT_FIELDS = [
            'event_data.host'        : HOST,
            'event_data.remote_addr' : REMOTE_HOST,
            'event_data.task'        : TASK,
            'created'                : CREATED,
            'event_data.start'       : START,
            'event_data.end'         : END,
            'event_data.duration'    : DURATION,
            'event_data.res.start'   : START,
            'event_data.res.end'     : END,
            'event_data.res.delta'   : ELAPSED,
            (BODY_PROPERTY)          : EIM_EVENT,
            'event_data.name'        : TASK_NAME,
            'event_data.play_pattern': PLAY_PATTERN,
            'event_data.task_path'   : SCRIPT,
            'event_data.task_action' : TASK_CATEGORY,
            'stdout'                 : OUTPUT,
            'uuid'                   : UUID,
            'parent_uuid'            : PARENT_UUID,
            'event_data.play_uuid'   : PLAY_UUID,
    ]

    AnsibleLogs logs
    JobEventsConsumer consumer = new JobEventsConsumer()

    protected JobEvents() {
        this(new AnsibleLogs())
    }

    protected JobEvents(AnsibleLogs logs) {
        this.logs(logs)
    }

    protected JobEventsConsumer newConsumer() {
        return new JobEventsConsumer()
    }

    JobEvents add(Map<String, String> fields) {
        consumer.add(fields)
        return this
    }

    JobEvents all() {
        consumer.all()
        return this
    }

    JobEvents trimEmpty() {
        consumer.trimEmpty()
        return this
    }

    protected JobEvents logs(AnsibleLogs logs) {
        this.logs = logs
        this.consumer = newConsumer()
        consumer.trimEmpty()
        return this
    }

    JobEvents defaultFields() {
        consumer.fields(new LinkedHashMap<>(DEFAULT_FIELDS))
        return this
    }

    JobEvents fields(Map<String, String> fields) {
        consumer.fields(fields)
        return this
    }

    JobEvents fieldValues(@DelegatesTo(LogValuesConsumer) Closure closure) {
        GroovyUtil.closureCall(closure, consumer.valuesConsumer)
        return this
    }

    protected JobsEventInput toConsumerInput(Path path, LogEntry entry) {
        return new JobsEventInput(stream(path))
    }

    protected JobsEventInput toConsumerInput(String path, LogEntry entry) {
        return toConsumerInput(Paths.get(path), entry)
    }

    protected JobsEventInput toConsumerInput(File file, LogEntry entry) {
        return toConsumerInput(file.toPath(), entry)
    }

    @SuppressWarnings("GroovyAssignabilityCheck")
    @CompileDynamic
    JobsEventInput toConsumerInput(LogEntry entry) {
        if (consumer.fields.isEmpty()) {
            defaultFields()
        }
        return toConsumerInput(entry.source, entry)
    }

    @Override
    void consume(LogEntry entry) {
        logs.consume(toConsumerInput(entry), Utils.getSourceName(entry), consumer)
    }

    static boolean containsException(String message) {
        return message.contains("Exception:")
    }

    static Predicate<Map<String, Object>> durationPredicate(final double maxDuration) {
        return { final Map<String, Object> map ->
            final val = map.get(DURATION)
            boolean result = false
            if (val != null) {
                result = Double.parseDouble(val.toString()) > maxDuration
            }
            return result
        }
    }

    static Predicate<Map<String, Object>> consoleExceptionPredicate(final String stdErr, final String stdOut) {
        return { Map<String, Object> map ->
            def val = map.get(stdErr)
            def result = val != null && containsException(val.toString())
            if (!result) {
                val = map.get(stdOut)
                result = val != null && containsException(val.toString())
            }
            return result
        }
    }

    static Predicate<Map<String, Object>> nonZeroResultCodePredicate(final String rcField) {
        return { Map<String, Object> map ->
            def val = map.get(rcField)
            return val != null && '0' != val.toString()
        }
    }

    protected Stream<Path> stream(Path path) {
        def execPath = path
        if (Files.isDirectory(execPath)) {
            final fileName = execPath.getFileName().toString().toLowerCase()
            if (!Utils.isJson(fileName) || !fileName.endsWith(AnsibleLogs.JOB_EVENTS_FOLDER)) {
                execPath = logs.resolveJobEventsPath(execPath)
            }
        }
        if (Files.isDirectory(execPath)) {
            return Files.list(execPath).filter(Utils.&isJson).sorted(JobEvents.&compareJobEventPath)
        } else {
            if (!Utils.isJson(execPath) || !Files.exists(execPath)) {
                throw new IllegalArgumentException("An existing JSON file or '${AnsibleLogs.JOB_EVENTS_FOLDER}' folder is expected; provided: '$execPath'")
            }
            return Stream.of(execPath)
        }
    }

    Stream<Map<String, Object>> mapStream(Stream<Path> stream) {
        return stream.map(consumer.&toMap)
    }
    Stream<Map<String, Object>> mapStream(Path path) {
        return mapStream(stream(path))
    }

    Stream<Map<String, Object>> mapStream(String path) {
        return mapStream(Paths.get(path))
    }

    Stream<LogEntry> logEntryStream(Path path) {
        return stream(path).map(consumer.&toLogEntry)
    }

    Stream<LogEntry> logEntryStream(String path) {
        return logEntryStream(Paths.get(path))
    }

    static int extractIndex(Path path) {
        String string = path.getFileName().toString()
        int idx = string.indexOf('-')
        if (idx != -1) {
            idx = Integer.parseInt(string.substring(0, idx))
        }
        return idx
    }

    static int compareJobEventPath(Path it1, Path it2) {
        return extractIndex(it1) <=> extractIndex(it2)
    }

    static JobEvents of() {
        return new JobEvents()
    }

    static JobEvents of(Map<String, String> fields) {
        return new JobEvents().fields(fields)
    }

    static JobEvents of(List<String> fields) {
        return new JobEvents().fields(Utils.toFieldMap(fields))
    }

    static JobEvents of(String fields) {
        return new JobEvents().fields(Utils.toFieldMap(fields))
    }

    @CompileStatic
    protected static class JobsEventInput implements ConsumerInput {
        final Stream<Path> stream
        private final Iterator<Path> entryIterator

        JobsEventInput(Stream<Path> stream) {
            this.stream = stream
            entryIterator = stream.iterator()
        }

        @Override
        LogEntry next(Object source) {
            return entryIterator.hasNext() ? new LogEntry(entryIterator.next(), null, 0) : null
        }

        @Override
        void close() throws IOException {
            stream.close()
        }
    }

    @CompileStatic
    private static class JobEventsConsumer extends JSonConsumer {
        JobEventsConsumer defaultFields() {
            fields(new LinkedHashMap<>(DEFAULT_FIELDS))
            return this
        }

        JobEventsConsumer fields(Map<String, String> fields) {
            if (fields == null) {
                defaultFields()
            } else {
                super.fields(fields)
            }
            return this
        }

        LogEntry toLogEntry(LogEntry entry, Path path) {
            final jMap = read(path) as Map
            final values = valuesConsumer.toMap(jMap)
            entry.row = Optional.ofNullable(jMap.get('counter') as Integer).orElse(0)
            entry.putAll(values)
            return entry
        }

        protected LogEntry consume(LogEntry entry, Path path) {
            return toLogEntry(entry, path)
        }

        protected LogEntry consume(LogEntry entry, File file) {
            return consume(entry, file.toPath())
        }

        protected LogEntry consume(LogEntry entry, String path) {
            return consume(entry, Path.of(path))
        }

        void lookupEventDetails(Map<String, Object> map) {
            final Object val = map.get(EIM_EVENT)
            if (val != null) {
                map.put("EIM event details", textToMap(val.toString()))
            }
        }

        @Override
        @CompileDynamic
        void consume(LogEntry entry) {
            consume(entry, entry.source)
            lookupEventDetails(entry.values)
        }
    }

    static Consumer<Map<String, Object>> eventDetailsConsumer(String... fields) {
        if (fields == null) {
            return new EventDetailsConsumer(of(["componentId", "executionId", "marker"]).trimEmpty())
        } else {
            return new EventDetailsConsumer(of(Arrays.asList(fields)).trimEmpty())
        }
    }
    private static class EventDetailsConsumer implements Consumer<Map<String, Object>> {
        private final JobEvents events

        EventDetailsConsumer(JobEvents events) {
            this.events = events
        }

        @Override
        void accept(Map<String, Object> map) {
            final Object val = map.get(EIM_EVENT)
            if (val != null) {
                map.put("EIM event details", events.consumer.textToMap(val.toString()))
            }
        }
    }
}
