package com.edifecs.support.ansible.log

import com.edifecs.support.SupportRuntimeException
import com.edifecs.support.core.GroovyUtil
import com.edifecs.support.core.ToolHelper
import com.edifecs.support.core.ZipContentResolver
import com.edifecs.support.core.ZipWalker
import com.edifecs.support.log.*
import groovy.transform.CompileStatic
import org.apache.commons.lang.StringUtils
import org.apache.commons.lang.time.DurationFormatUtils
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.yaml.snakeyaml.Yaml

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeParseException
import java.util.concurrent.atomic.AtomicReference
import java.util.function.Consumer
import java.util.function.Predicate
import java.util.stream.Collectors
import java.util.stream.Stream
import java.time.ZonedDateTime

import static com.edifecs.support.log.Reports.*

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class AnsibleLogs extends Logs {
    private static Logger logger

    static final String DEFAULT_ID = 'id000'
    static final String ARTIFACTS_FOLDER = 'artifacts'
    static final String VARS_FOLDER = 'vars'
    static final String JOB_EVENTS_FOLDER = "job_events"
    static final String INVENTORY_FOLDER = 'inventory'
    static final String GROUP_VARS_FOLDER = 'group_vars'
    static final String STATUS_FILE = 'status'
    static final String STDOUT_FILE = 'stdout'

    static final String ERROR = 'ERROR'
    static final String CANCELED_STATUS = 'Canceled'
    static final String UNKNOWN_STATUS = 'Unknown'
    static final String FATAL_STATUS = 'fatal'
    static final String FAILED_STATUS = 'Failed'
    static final String CHANGED_STATUS = 'changed'
    static final String OK_STATUS = 'ok'
    static final String DONE_STATUS = 'successful'

    String executionPath
    String artifactId = DEFAULT_ID
    String status

    protected JobEvents events = new JobEvents(this)
    private Yaml yaml
    private ZipWalker zipWalker

    Map<String, Map<String, Object>> variables = Collections.synchronizedMap(new LinkedHashMap<String, Map<String, Object>>(Short.MAX_VALUE))

    AnsibleLogs executionPath(String executionPath) {
        this.executionPath = executionPath
        return this
    }

    AnsibleLogs jobEvents(String executionPath) {
        this.executionPath(executionPath)
        final entry = new LogEntry(executionPath, null, 0)
        source(entry, events)
        return this
    }

    AnsibleLogs jobEvents(@DelegatesTo(JobEvents) Closure closure) {
        GroovyUtil.closureCall(closure, events)
        return this
    }

    Path resolveExecutionPath() {
        return Paths.get(executionPath)
    }

    Path resolveJobEventsPath(Path executionDir) {
        return resolveArtifactsPath(executionDir).resolve(JOB_EVENTS_FOLDER)
    }

    Path resolveArtifactsPath(Path executionDir) {
        return executionDir.resolve(ARTIFACTS_FOLDER).resolve(artifactId)
    }

    Path resolveJobEventsPath() {
        return resolveJobEventsPath(resolveExecutionPath())
    }

    Path resolveArtifactsPath() {
        return resolveArtifactsPath(resolveExecutionPath())
    }

    Path resolveInventoryPath() {
        return resolveExecutionPath().resolve(INVENTORY_FOLDER)
    }

    protected Path resolveVariablesPath(String id) {
        return Paths.get(executionPath).resolve(VARS_FOLDER).resolve(id + Utils.YML_EXT)
    }

    protected synchronized Yaml checkYamlCreated() {
        if (!yaml) {
            yaml = YamlSerializer.newKebabCaseYaml()
        }
        return yaml
    }

    protected void readVariables(String id, Path path) {
        if (path.toFile().exists()) {
            variables.put(id, YamlSerializer.read(checkYamlCreated(), path) as Map<String, Object>)
        }
    }

    synchronized Map<String, Object> resolveVariables(String id) {
        if (!variables.containsKey(id)) {
            readVariables(id, resolveVariablesPath(id))
        }
        return variables.get(id)
    }

    protected AnsibleLogs readGroupVariables() {
        Files.list(resolveInventoryPath().resolve(GROUP_VARS_FOLDER)).filter(Utils.&isYml).forEach {
            String id = it.getFileName().toString()
            id = id.substring(0, id.length() - Utils.YML_EXT.length())
            readVariables(id, it)
        }
        return this
    }

    static Path toArtifactsInternPath(Path source, String artifactId) {
        return source.resolve(ARTIFACTS_FOLDER).resolve(artifactId)
    }
    static Path toArtifactsInternPath(Path source) {
        return toArtifactsInternPath(source, DEFAULT_ID)
    }
    Path resolveArtifactsInternPath() {
        return toArtifactsInternPath(resolveExecutionPath(), DEFAULT_ID)
    }

    protected static void checkStatus(DeploymentReport dr, Path source, String artifactId) {
        final Path statusPath = toArtifactsInternPath(source, artifactId).resolve(STATUS_FILE)
        if (Files.exists(statusPath)) {
            try {
                final String status = Files.readString(statusPath).trim()
                if (!status.isEmpty()) {
                    dr.setStatus(status)
                }
            } catch (IOException e) {
                logger.debug("Failed to read artifacts status file", e)
            }
            if (dr.getStatus() == null) {
                dr.setStatus(UNKNOWN_STATUS)
            }
        } else {
            dr.setStatus(CANCELED_STATUS)
        }
    }

    protected void checkZippedStatus(DeploymentReport dr, String source) {
        if (!zipWalker) {
            zipWalker = ZipWalker.of(source)
        }
        final optional = zipWalker.listAll().stream().filter { it.endsWith(STATUS_FILE) }.findAny()
        if (optional.isPresent()) {
            def status = zipWalker.text(optional.get())
            if (!status) {
                status = UNKNOWN_STATUS
            }
            dr.setStatus(status)
        } else {
            dr.setStatus(CANCELED_STATUS)
        }
    }

    protected DeploymentReport checkStatus(DeploymentReport dr) {
        final source = dr.source
        if (ZipWalker.isZip(source)) {
            checkZippedStatus(dr, source)
        } else {
            checkStatus(dr, Paths.get(dr.source), artifactId)
        }
        return dr
    }

    protected String readStatus() {
        this.status = checkStatus(new DeploymentReport().source(executionPath)).status
        return this.status
    }

    protected void checkExecutionPathDefined() {
        if (!executionPath) {
            throw new SupportRuntimeException("Execution directory is not defined")
        }
    }

    @Override
    protected ConsumerInput lookupConsumerInput(LogEntry entry, LogConsumer sourceConsumer) {
        if (sourceConsumer instanceof JobEvents) {
            return sourceConsumer.toConsumerInput(entry)
        }
        return super.lookupConsumerInput(entry, sourceConsumer)
    }

    @Override
    protected Tuple toIteratorSource(LogEntry entry, LogConsumer consumer) {
        if ((consumer instanceof JobEvents)) {
            final tuple = new Tuple(lookupConsumerInput(entry, consumer), Utils.getSourceName(entry), events.consumer)
            final status = readStatus()
            entry.put('Status', status)
            toConsumers(entry)
            return tuple
        } else {
            return super.toIteratorSource(entry, consumer)
        }
    }

    @Override
    void consume() {
        checkExecutionPathDefined()
        super.consume()
    }

    static AnsibleLogsBuilder builder(String... args) {
        return Tool.init(new AnsibleLogsBuilder(), args)
    }

    static AnsibleLogs execution(@DelegatesTo(AnsibleLogsBuilder) Closure closure, String... args) {
        return builder(closure, args).build()
    }

    static AnsibleLogsBuilder builder(@DelegatesTo(AnsibleLogsBuilder) Closure closure, String... args) {
        return GroovyUtil.closureCall(closure, AnsibleLogsBuilder.class, { builder(args) })
    }

    static JobEvents jobEvents(Map<String, String> fields) {
        return JobEvents.of().fields(fields).trimEmpty()
    }

    static Stream<Map<String, Object>> toEventStream(Path source, Map<String, String> fields) {
        return jobEvents(fields).mapStream(source)
    }

    static Stream<Map<String, Object>> toEventStream(String source, Map<String, String> fields) {
        return toEventStream(Paths.get(source), fields)
    }

    static Stream<LogEntry> toStdoutStream(Path source) {
        return StdoutConsumerInput.of(source.toFile()).stream()
    }
    static Stream<LogEntry> toStdoutStream(File source) {
        return StdoutConsumerInput.of(source).stream()
    }
    static Stream<LogEntry> toStdoutStream(String source) {
        return StdoutConsumerInput.of(source).stream()
    }
    static String toStdoutText(String source) {
        return ZipWalker.isArchivedSource(source) ? ZipContentResolver.text(source) : Files.readString(Paths.get(source))
    }
    static Collection<LogEntry> toStdoutErrors(String source) {
        return toStdoutStream(source).filter {it._get(ERROR) != null}.collect(Collectors.toList())
    }
    static Collection<LogEntry> toStdoutErrors(String source, final Predicate<LogEntry> predicate) {
        return toStdoutStream(source).filter(predicate).collect(Collectors.toList())
    }

    static Stream<Map<String, Object>> toEventStream(String source, String... fields) {
        return toEventStream(Paths.get(source), toFieldMap(fields))
    }

    static JobEvents jobEvents(String... fields) {
        return JobEvents.of(toFieldMap(fields))
    }

    @SuppressWarnings("resource")
    static CsvReportingConsumer csvConsumer(Path csvPath, Map<String, String> fields) throws IOException {
        return CsvReportingConsumer.of(csvPath).hasHeader().fields(fields.values())
    }

    static CsvReportingConsumer csvConsumer(String csvPath, Map<String, String> fields) throws IOException {
        return csvConsumer(Paths.get(csvPath), fields)
    }

    static CsvReportingConsumer csvConsumer(String csvPath, String... fields) throws IOException {
        return csvConsumer(Paths.get(csvPath), toFieldMap(fields))
    }

    static Consumer<Map<String, Object>> eventDetailsConsumer(String... fields) {
        return JobEvents.eventDetailsConsumer(fields)
    }

    static void checkAddEventDetails(CsvReportable reportable, Map<String, String> fields) {
        if (fields.containsKey(JobEvents.BODY_PROPERTY)) {
            reportable.add(eventDetailsConsumer())
        }
    }

    static CsvReportingConsumer toCsvConsumer(CsvReportable reportable, Path csvPath, Map<String, String> fields) throws IOException {
        checkAddEventDetails(reportable, fields)
        return csvConsumer(csvPath, fields)
    }

    void csvReport(Path source, Path destination, Map<String, String> fields) throws IOException {
        if (!Files.exists(source)) {
            throw new IllegalArgumentException(String.format("Ansible source execution directory: '%s' doesn't exists", source))
        }
        logger.info("Generating CSV report from: '{}' ...", source)
        final DeploymentReport dr = new DeploymentReport().source(source.toString())
        checkStatus(dr, source, artifactId)
        logger.info("{}", dr)

        final Path csvPath = com.edifecs.support.core.Utils.checkTimeSuffixedPath(destination, "ans-job-events", "csv")
        try (final CsvReportable r = new CsvReportable().mapStream(toEventStream(source, fields))) {
            r.add(toCsvConsumer(r, csvPath, fields)).ingest()
            logger.info("Finished CSV report generation into: {}", csvPath)
        }
    }

    static Map<String, String> toFieldMap(List<String> fields) {
        return fields != null ? Reports.toFieldMap(fields) : JobEvents.DEFAULT_FIELDS
    }

    static Map<String, String> toFieldMap(String... fields) {
        return fields != null && fields.length > 0 ? Reports.toFieldMap(Arrays.asList(fields)) : JobEvents.DEFAULT_FIELDS
    }

    void csvReport(Path source, Path destination, List<String> fields) throws IOException {
        csvReport(source, destination, toFieldMap(fields))
    }

    private static int compareJobIndexes(String f1, String f2) {
        int f1i = f1.indexOf('-')
        int f2i = f2.indexOf('-')
        final f1s = f1.substring(0, f1i)
        final f2s = f2.substring(0, f2i)
        final f1d = StringUtils.isNumeric(f1s)
        final f2d = StringUtils.isNumeric(f2s)
        if (!f1d || !f2d) {
            return !f1d && !f2d ? f1s.compareTo(f2s) : f1d ? -1 : 1
        }
        return Integer.compare(Integer.valueOf(f1s), Integer.valueOf(f2s))
    }

    protected Path resolveStdoutPath() {
        return resolveArtifactsInternPath().resolve(STDOUT_FILE)
    }

    protected static Date parseAnsibleDate(def created) {
        try {
            // Use ZonedDateTime instead of LocalDateTime to properly handle timezone information
            return Date.from(ZonedDateTime.parse(created.toString()).toInstant())
        } catch (DateTimeParseException ignore) {
            return Date.from(LocalDateTime.parse(created.toString()).atZone(ZoneId.systemDefault()).toInstant())
        }
    }

    DeploymentReport deploymentReport() throws IOException {
        final dr = new DeploymentReport().source(executionPath).logs(this)
        checkStatus(dr)
        final lastEntry = new AtomicReference<LogEntry>()
        dr.errors(toStdoutErrors(resolveStdoutPath().toString(), {LogEntry it ->
            lastEntry.set(it)
            return it._get(ERROR) != null
        } as Predicate<LogEntry>))
        if (dr.isFailed() && dr.getErrors().isEmpty() && lastEntry.get() != null) {
            dr.errors(Collections.singletonList(lastEntry.get()))
        }
        final jobEventsPath = resolveJobEventsPath()
        final fileList = jobEventsPath.toFile().list()
        if (fileList) {
            // calculate stat time and duration
            final List<Path> files = new ArrayList<>()
            Arrays.sort(fileList, AnsibleLogs.&compareJobIndexes)
            for (int i = 0; i < fileList.length && files.size() < 4; i++) {
                final file = fileList[i]
                if (file.toLowerCase().endsWith('.json')) {
                    files.add(jobEventsPath.resolve(file))
                }
            }
            final List<Path> tailFiles = new ArrayList<>(4)
            for (int i = fileList.length - 1; i >= 0 && tailFiles.size() < 4; i--) {
                final file = fileList[i]
                if (file.toLowerCase().endsWith('.json')) {
                    tailFiles.add(jobEventsPath.resolve(file))
                }
            }
            files.addAll(tailFiles.reverse())
            Date start = null
            Date end = null
            JobEvents.of().logs(this).all().mapStream(files.stream()).forEach  {
                def created = it.get('created')
                if (created) {
                    final d = parseAnsibleDate(created)
                    if (!start || d.before(start)) {
                        start = d
                    }
                    if (!end) {
                        end = d
                    }
                    if (d.after(end)) {
                        end = d
                    }
                }
            }
            if (start) {
                dr.setStartTime(LocalDateTime.ofInstant(start.toInstant(), ZoneId.systemDefault()).toString())
                if (!end) {
                    end = start
                }
                dr.setDuration(DurationFormatUtils.formatDurationHMS(end.getTime() - start.getTime()))
            }
        }
        return dr
    }

    protected DeploymentReport deploymentReport(Path source, List<String> fields, String groovyScript, CsvReportable reportable, String[] args) {
        final DeploymentReport dr
        if (reportable.hasStream()) {
            dr = new DeploymentReport()
            final String ss = reportable.getSource()
            if (ss != null) {
                dr.source(ss)
                final Path sSource = Paths.get(ss)
                checkStatus(dr, sSource, artifactId)
                logger.info("Generating CSV report from: '{}' ...", sSource)
            } else {
                logger.warn("Unknown source for script call: {}, args: {}", groovyScript, (args != null ? Arrays.asList(args) : Collections.emptyList()))
                dr.setStatus("Unknown")
            }
        } else {
            dr = new DeploymentReport().source(source.toString())
            checkStatus(dr, source, artifactId)
            if (!Files.exists(source)) {
                throw new IllegalArgumentException(String.format("Ansible source execution directory: '%s' doesn't exists", source))
            }
            reportable.mapStream(jobEvents(toFieldMap(fields)).mapStream(source))
            logger.info("Generating CSV report from: '{}' ...", source)
        }
        return dr
    }

    void csvReport(Path source, Path destination, List<String> fields, String groovyScript, String... args) throws IOException {
        final CsvReportable reportable = new CsvReportable()
        GroovyUtil.include(groovyScript, reportable, args)
        final DeploymentReport dr = deploymentReport(source, fields, groovyScript, reportable, args)
        if (!reportable.hasCsvConsumer()) {
            final Path csvPath = com.edifecs.support.core.Utils.checkTimeSuffixedPath(destination, "ans-job-events", "csv")
            reportable.add(toCsvConsumer(reportable, csvPath, toFieldMap(fields)))
        }
        logger.info("{}", dr)
        try (final CsvReportable r = reportable) {
            r.ingest()
            logger.info("Finished CSV report generation")
        }
    }

    void csvReport(Path source, Path destination) throws IOException {
        csvReport(source, destination, (Map<String, String>) null)
    }

    static Consumer<Map<String, Object>> summaryConsumer(final CsvReportable reportable) {
        return { Map<String, Object> map ->
            if (!reportable.hasStart()) {
                final Object value = map.get(JobEvents.START)
                if (value != null) {
                    reportable.setStart(value.toString())
                }
            }
            if (!reportable.hasEnd()) {
                final Object value = map.get(JobEvents.END)
                if (value != null) {
                    reportable.setEnd(value.toString())
                }
            }
        }
    }

    @SuppressWarnings("rawtypes")
    static CsvReportable toCsvReportable(@DelegatesTo(CsvReportable.class) Closure closure) {
        final CsvReportable reportable = GroovyUtil.lookupDelegate(closure, CsvReportable.class, CsvReportable::new)
        reportable.add(summaryConsumer(reportable))
        GroovyUtil.closureCall(closure, reportable)
        return reportable
    }

    static boolean isFailed(String status) {
        return FATAL_STATUS.equalsIgnoreCase(status) || FAILED_STATUS.equalsIgnoreCase(status)
    }
    static boolean isDone(String status) {
        return DONE_STATUS.equalsIgnoreCase(status) || OK_STATUS.equalsIgnoreCase(status)
    }

    static AnsibleLogs of(String executionPath) {
        return new AnsibleLogs().executionPath(executionPath)
    }

    static final String SOURCE_OPTION = "source"
    static final String DESTINATION_OPTION = "destination"
    static final String CSV_REPORT_OPTION = "csv"
    static final String CSV_FIELDS_OPTION = "fields"
    static final String ALL_FIELDS_OPTION = "allFields"
    static final String FAILURE_MSG = "Internal error. Please see logs for more details..."

    static ToolHelper parseToolArguments(String... args) {
        final ToolHelper helper = ToolHelper.Builder.of("ansible-deployment-logs")
                .withHeader(Arrays.asList(
                        "Edifecs Support Tools Version " + ToolHelper.getVersion() + " (ST).",
                        "Copyright (c) Edifecs, Inc " + Calendar.getInstance().get(Calendar.YEAR),
                        "\n"
                )).withUsage(Arrays.asList(
                "Usage:",
                "       ansible-deployment-logs [-csv <-fields >] [-source <ansible executions folder>] [-destination <destination report file name>] [-all] [-verbose] [-debug] [-help]"
        ))
                .usingConsoleLogger("ConsoleAppender", "com.edifecs")
                .usingFileLogger("com.edifecs")
                .addOption(SOURCE_OPTION, "deployment executions folder", true, true)
                .addOption(DESTINATION_OPTION, "deployment logs destination", true, true)
                .addOption(CSV_REPORT_OPTION, "generate resulting deployment CSV report", false, true)
                .addOption(CSV_FIELDS_OPTION, "CSV fields and names to be generated, e.g. [pid, event_data.task:taskName, event_data.res.rc:resultCode, event_data.res.stdout:consoleOutput, event_data.start:startTime, event_data.end:endTime, event_data.duration:duration]", true, true)
                .addOption(ALL_FIELDS_OPTION, "extract all job fields", false, true)
                .build(args)
        logger = LogManager.getLogger(AnsibleLogs.class)
        return helper
    }

    static String checkGroovyScript(ToolHelper toolHelper) {
        String groovyFound = null
        for (String arg : toolHelper.getUnknownArguments()) {
            if (arg.toLowerCase().endsWith(".groovy")) {
                groovyFound = arg
                break
            }
        }
        return groovyFound
    }

    static int execute(ToolHelper toolHelper) throws IOException {
        final AnsibleLogs logs = new AnsibleLogs()
        final String source = Optional.ofNullable(toolHelper.getOptionValue(SOURCE_OPTION)).orElse(".")
        final String destination = Optional.ofNullable(toolHelper.getOptionValue(DESTINATION_OPTION)).orElse(".")
        List<String> fields = null
        if (toolHelper.hasArgument(CSV_FIELDS_OPTION)) {
            fields = toFields(toolHelper.getOptionValue(DESTINATION_OPTION))
        }
        final Path sPath = Paths.get(source)
        final Path dPath = Paths.get(destination)
        if (toolHelper.getUnknownArguments().isEmpty()) {
            logs.csvReport(sPath, dPath, fields)
        } else {
            final String groovyScript = checkGroovyScript(toolHelper)
            final Set<String> args = new LinkedHashSet<>(toolHelper.getUnknownArguments())
            args.remove(groovyScript)
            logs.csvReport(sPath, dPath, fields, groovyScript, args.isEmpty() ? null : args.toArray(new String[0]) as String[])
        }
        return 0
    }

    static boolean shouldShowUsage(ToolHelper toolHelper) {
        return toolHelper.shouldShowUsage() && checkGroovyScript(toolHelper) == null
    }

    @SuppressWarnings("squid:S2221")
    static int doMain(String... args) {
        int errorCode = 0
        try {
            System.setProperty("log4j.defaultInitOverride", "true")
            final ToolHelper toolHelper = parseToolArguments(args)
            toolHelper.logHeader()
            if (shouldShowUsage(toolHelper)) {
                errorCode = 2
                toolHelper.logUsage()
            }
            if (errorCode == 0) {
                errorCode = execute(toolHelper)
            }
        } catch (SupportRuntimeException e) {
            logger.debug(FAILURE_MSG, e)
            errorCode = 1
        } catch (Exception e) {
            logger.debug(FAILURE_MSG, e)
            errorCode = -1
        }
        if (errorCode != 0) {
            logger.error(FAILURE_MSG)
            logger.error("")
        }
        return errorCode
    }

    static void main(String... args) {
        com.edifecs.support.core.Utils.disableIllegalReflectiveAccessWarning()
        System.exit(doMain(args))
    }
}
