package com.edifecs.support.ansible.log

import com.edifecs.support.core.Patterns
import com.edifecs.support.log.ConsumerInput
import com.edifecs.support.log.LineReaderInput
import com.edifecs.support.log.LogEntry
import com.edifecs.support.log.Utils
import groovy.transform.CompileDynamic
import groovy.transform.CompileStatic
import org.yaml.snakeyaml.Yaml

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.regex.Matcher
import java.util.regex.Pattern
import java.util.stream.Stream
import java.util.stream.StreamSupport

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class StdoutConsumerInput implements ConsumerInput {
    private static final Pattern playNamePattern = Patterns.of('(PLAY|TASK)\\s+(.+)\\s+\\*+')
    private static final Pattern playOutputPattern = Patterns.of('(\\e\\[\\d+;\\d+m)(.+)(\\e\\[\\d+m)')
    private static final Pattern playAnsiCodesPattern = Patterns.of('\\e\\[(?:\\d+;)*\\d+m')

    static final String TYPE = 'type'
    static final String NAME = 'name'
    static final String OUTPUT = 'output'
    static final String MESSAGE = 'message'

    private static final String OBJECT_ID = "=>"
    private static final String KEY_ID = ':'

    LineReaderInput consumerInput
    private String source
    private String previousLine
    static private Yaml yaml

    StdoutConsumerInput() {
    }

    StdoutConsumerInput(LineReaderInput consumerInput) {
        this.consumerInput = consumerInput
    }

    String getSource() {
        return source
    }

    void setSource(String source) {
        this.source = source
    }
    StdoutConsumerInput source(String source) {
        setSource(source)
        return this
    }

    @CompileDynamic
    protected static LineReaderInput createLineReader(def source) {
        return LineReaderInput.of(source)
    }

    protected static void handleNameMatching(Matcher matcher, LogEntry logEntry) {
        if (matcher.hasGroup() || matcher.find()) {
            logEntry.put(TYPE, matcher.group(1))
            logEntry.put(NAME, matcher.group(2))
        }
    }

    protected static void handleOutputMatching(Matcher matcher, LogEntry logEntry) {
        if (!matcher.hasGroup()/* || !matcher.find()*/) {
            return
        }
        String message = logEntry._get(MESSAGE) as String ?: ''
        String m = playAnsiCodesPattern.matcher(matcher.group(2)).replaceAll('')
        if (m.toLowerCase().endsWith('...ignoring')) {
            logEntry.remove(AnsibleLogs.ERROR)
        }
        message += m
        logEntry.put(MESSAGE, message)
        int idx = m.indexOf(KEY_ID)
        if (idx < 0) {
            return
        }
        String key = m.substring(0, idx).trim()
        String value = m.substring(idx + 1).trim()
        if (AnsibleLogs.DONE_STATUS.equals(key) || AnsibleLogs.CHANGED_STATUS.equals(key) || AnsibleLogs.FATAL_STATUS.equals(key)) {
            String temp = key
            key = value
            value = temp
        }
        if (!value.equals(AnsibleLogs.FATAL_STATUS)) {
            logEntry.put(key, value)
            return
        }
        logEntry.put(AnsibleLogs.ERROR, true)
        idx = key.indexOf(OBJECT_ID)
        if (idx < 0) {
            logEntry.put(key, value)
            return
        }
        int i = key.indexOf(KEY_ID)
        if (i < 0) {
            logEntry.put(key, value)
            return
        }
        String t = key
        key = key.substring(0, i).trim()
        value = t.substring(i + 1).trim()
        Map map = new LinkedHashMap()
        map.put(TYPE, AnsibleLogs.FATAL_STATUS)
        idx = value.indexOf(OBJECT_ID)
        value = value.substring(idx + 1)
        if (!yaml) {
            yaml = new Yaml()
        }
        final val = yaml.load(new StringReader(value.substring(1, value.length())))
        if (val instanceof Map) {
            map.putAll(val)
            logEntry.put(key, map)
        } else {
            logEntry.put(key, value)
        }
    }

    protected void handlePlayOutput(LogEntry entry, StringBuilder sb,
                                    String line, Matcher matcher) {
        entry.setRow(consumerInput.currentRow)
        sb.append(line).append(System.lineSeparator())
        handleNameMatching(matcher, entry)
        final StringBuilder sbo = new StringBuilder()
        while (line) {
            line = consumerInput.readLine()
            if (line) {
                matcher = playOutputPattern.matcher(line)
                if (matcher.matches() || matcher.find()) {
                    handleOutputMatching(matcher, entry)
                    sb.append(line).append(System.lineSeparator())
                    sbo.append(line).append(System.lineSeparator())
                    previousLine = null
                } else {
                    if (playNamePattern.matcher(line).matches()) {
                        previousLine = line
                        break
                    } else {
                        previousLine = null
                        sb.append(line).append(System.lineSeparator())
                        sbo.append(line).append(System.lineSeparator())
                    }
                }
            }
        }
        if (sbo.toString()) {
            entry.put(OUTPUT, sbo.toString())
        }
    }

    protected LogEntry doNext() {
        final entry = new LogEntry().source(source)
        final sb = new StringBuilder()
        String line
        while (true) {
            line = previousLine
            if (!line) {
                line = consumerInput.readLine()
            }
            if (line) {
                def matcher = playNamePattern.matcher(line)
                if (matcher.matches()) {
                    handlePlayOutput(entry, sb, line, matcher)
                    break
                } else {
                    previousLine = null
                }
            }
            if (line == null) {
                break
            }
        }
        if (sb.isEmpty()) {
            return null
        }
        entry.setLine(sb.toString())
        return entry
    }

    @CompileDynamic
    protected StdoutConsumerInput newConsumerInput(source) {
        consumerInput = createLineReader(source)
        return this
    }

    @Override
    LogEntry next(Object source) {
        if (!consumerInput) {
            newConsumerInput(source)
        }
        return doNext()
    }

    @Override
    void close() throws IOException {
        consumerInput?.close()
        consumerInput = null
        previousLine = null
    }

    protected Iterator<LogEntry> iterator() {
        return new LogEntryIterator()
    }

    Stream<LogEntry> stream() {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterator(), 0), false)
    }

    @CompileDynamic
    protected static StdoutConsumerInput of(def source) {
        return new StdoutConsumerInput().newConsumerInput(source)
    }

    @SuppressWarnings("GroovyAssignabilityCheck")
    static StdoutConsumerInput of(LogEntry source) {
        return new StdoutConsumerInput().source(source.getSource()?.toString()).newConsumerInput(source)
    }

    static StdoutConsumerInput of(InputStream inputStream) {
        return new StdoutConsumerInput().newConsumerInput(inputStream)
    }

    static StdoutConsumerInput of(Reader reader) {
        return new StdoutConsumerInput().newConsumerInput(reader)
    }

    static StdoutConsumerInput of(File file) {
        return new StdoutConsumerInput().source(file.getAbsolutePath()).newConsumerInput(file)
    }

    static StdoutConsumerInput of(String content) {
        return new StdoutConsumerInput().source(content).newConsumerInput(content)
    }

    @CompileStatic
    private class LogEntryIterator implements Iterator<LogEntry> {
        private final AtomicReference<LogEntry> lastEntry = new AtomicReference<>()
        private AtomicBoolean eof = new AtomicBoolean()

        private int nEntries
        private int totalEntries

        protected void closeInput() {
            lastEntry.set(null)
            Utils.closeQuietly(StdoutConsumerInput.this)
            eof.set(true)
            nEntries = 0
        }

        @Override
        boolean hasNext() {
            boolean result = lastEntry.get() != null
            if (!result && !eof.get()) {
                lastEntry.set(StdoutConsumerInput.this.doNext())
            }
            result = lastEntry.get() != null
            if (!result) {
                closeInput()
            }
            return result
        }

        protected LogEntry doNext() {
            LogEntry result = lastEntry.get()
            if (result == null) {
                result = StdoutConsumerInput.this.doNext()
            } else {
                lastEntry.set(null)
            }
            if (result) {
                nEntries += 1
                totalEntries += 1
            } else {
                eof.set(true)
            }
            if (eof.get()) {
                closeInput()
            }
            return result
        }

        @Override
        LogEntry next() {
            LogEntry entry = null
            while (entry == null && !eof.get()) {
                entry = doNext()
            }
            return entry
        }
    }
}
