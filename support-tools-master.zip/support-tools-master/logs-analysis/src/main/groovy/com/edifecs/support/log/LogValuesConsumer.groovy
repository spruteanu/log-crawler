package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.util.function.Function
import java.util.regex.Pattern

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class LogValuesConsumer implements LogConsumer {
    static final Pattern KEY_SPLITTER = Pattern.compile("\\.")

    Map<String, String> fields = new LinkedHashMap<>()
    Map<String, Function> converters = new LinkedHashMap<>()
    boolean all
    boolean trimEmpty

    LogValuesConsumer all() {
        this.all = true
        return this
    }

    LogValuesConsumer trimEmpty() {
        this.trimEmpty = true
        return this
    }

    LogValuesConsumer converters(Map<String, Function> converters) {
        this.converters = converters
        return this
    }

    LogValuesConsumer fields(Map<String, String> fields) {
        this.fields = fields
        return this
    }

    LogValuesConsumer field(String field, String caption) {
        if (caption) {
            fields.put(field, caption)
        }
        return this
    }

    LogValuesConsumer field(String field, Function converter) {
        if (converter) {
            converters.put(field, converter)
        }
        return this
    }

    LogValuesConsumer field(String field, String caption, Function converter) {
        this.field(field, caption)
        this.field(field, converter)
        return this
    }

    static Object lookupValue(Map object, String key) {
        final keys = KEY_SPLITTER.split(key)
        Object result = null
        Map rom = object
        for (String k : keys) {
            final obj = rom.get(k)
            if (obj instanceof Map) {
                rom = obj
            } else {
                result = obj
                break
            }
        }
        return result
    }

    static Map<String, Object> toMapAll(Map object, Map<String, Object> result, String path, String suffix) {
        object.each {
            final key = it.key
            final value = it.value
            final String fPath = path + suffix + key
            if (value instanceof Map) {
                toMapAll(value as Map, result, fPath, '.')
            } else {
                result.put(fPath, value)
            }
        }
        return result
    }

    protected Map<String, Object> toMapAll(Map object) {
        return toMapAll(object, [:], '', '')
    }

    protected Map<String, Object> fieldsToMap(Map object) {
        return fieldsToMap(object, new LinkedHashMap<String, Object>(fields.size()))
    }
    protected Object checkConvert(String key, String name, Object value) {
        if (converters.containsKey(key)) {
            value = converters.get(key).apply(value)
        }
        if (key != name && converters.containsKey(name)) {
            value = converters.get(name).apply(value)
        }
        return value
    }

    protected Map<String, Object> fieldsToMap(Map object, Map<String, Object> result) {
        for (final Map.Entry<String, String> entry : fields.entrySet()) {
            final key = entry.key
            final name = entry.value
            try {
                final value = lookupValue(object, key)
                if (!trimEmpty || value) {
                    result.put(name, checkConvert(key, name, value))
                }
            } catch (Exception ignore) { }
        }
        return result
    }

    Map<String, Object> toMap(Map object) {
        return all ? toMapAll(object) : fieldsToMap(object)
    }

    @Override
    void consume(LogEntry entry) {
        toMap(entry.values)
    }
}
