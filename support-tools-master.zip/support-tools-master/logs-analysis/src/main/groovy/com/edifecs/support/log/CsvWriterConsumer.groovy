package com.edifecs.support.log

import com.edifecs.support.core.CsvWriter
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class CsvWriterConsumer extends CsvWriter implements ConsumerOutput {
    CsvWriterConsumer() {
        super()
    }

    CsvWriterConsumer(Writer writer, List<String> columns) {
        super(writer, columns)
    }

    @Override
    void consume(LogEntry entry) {
        final values = new ArrayList(columns.size())
        final logValueMap = entry.values
        for (String column : columns) {
            values.add(Objects.toString(logValueMap.get(column)?.toString(), ''))
        }
        if (allValues) {
            final notIncludedColumns = new LinkedHashSet(logValueMap.keySet())
            notIncludedColumns.removeAll(columns)
            if (notIncludedColumns) {
                values.addAll(logValueMap.subMap(notIncludedColumns).values())
            }
        }
        doWrite(values)
    }

    static CsvWriterConsumer of(Writer writer, String... columns) {
        return new CsvWriterConsumer(writer: writer, columns: Arrays.asList(columns))
    }

    static CsvWriterConsumer of(File file, String... columns) {
        return new CsvWriterConsumer(writer: new BufferedWriter(new FileWriter(file)), columns: Arrays.asList(columns))
    }

    static CsvWriterConsumer of(String filePath, String... columns) {
        return of(new File(filePath), columns)
    }

    @CompileStatic
    static class Builder extends ConsumerBuilder<CsvWriterConsumer> {
        Builder() {
        }

        Builder(LogsBuilder contextBuilder, Object consumer, Object... args) {
            super(contextBuilder, consumer, args)
        }

        Builder writer(Writer writer) {
            getConsumer().writer = writer
            return this
        }

        Builder columns(String... columns) {
            getConsumer().columns = columns.toList()
            return this
        }

        Builder columns(List<String> columns) {
            getConsumer().columns = columns
            return this
        }

        Builder separators(String separator, String fieldSeparator = '') {
            getConsumer().withSeparators(separator, fieldSeparator)
            return this
        }

        Builder fieldSeparator(String fieldSeparator) {
            getConsumer().fieldSeparator = fieldSeparator
            return this
        }

        Builder flushAt(int flushAt = 100) {
            getConsumer().flushAt(flushAt)
            return this
        }
    }
}
