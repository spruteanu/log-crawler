package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.nio.file.Path
import java.util.stream.Collectors

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class Utils {

    static final String YML_EXT = '.yml'

    static closeQuietly(Closeable inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close()
            } catch (IOException ignore) { }
        }
    }

    static closeQuietly(AutoCloseable inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close()
            } catch (IOException ignore) { }
        }
    }

    static int indexOfFileFilter(String path) {
        int idx = -1
        if (path.matches('.+[\\*\\?]')) {// todo Serge: fix to consider matching sub-folders
            idx = path.lastIndexOf('/')
            if (idx < 0) {
                idx = path.lastIndexOf('\\')
            }
            if (idx < 0) {
                idx = 0
            } else {
                idx++
            }
        }
        return idx
    }

    static String defaultFolderFilter(String path, String fileFilter, String defaultFilter = '*') {
        return new File(path).isDirectory() && !fileFilter ? fileFilter = defaultFilter : fileFilter
    }

    @SafeVarargs
    static <O> List<O> toList(O obj, O... objs) {
        final List<O> csList = new ArrayList<>()
        csList.add(obj)
        if (objs != null) {
            csList.addAll(Arrays.asList(objs))
        }
        return csList
    }

    static List<String> toFields(String fields) {
        return Arrays.stream(fields.split(",")).map(String.&trim).filter({ s -> !s.isEmpty() }).collect(Collectors.toList())
    }

    static <T> T leftMerger(T l, T r) {
        return l
    }

    static Map<String, String> toFieldMap(List<String> fields) {
        return fields != null ? fields.stream().map({ s ->
            if (!s.contains(":")) {
                s = s + ":" + s
            }
            return s.trim().split(":")
        }).collect(Collectors.toMap({ String[] pair -> pair[0] }, { String[] pair -> pair[1] },
                Utils.&leftMerger, { new LinkedHashMap() })) : null
    }

    static Map<String, String> toFieldMap(String fields) {
        return toFieldMap(toFields(fields))
    }

    static boolean isJson(String fileName) {
        return fileName.endsWith('.json')
    }

    static boolean isJson(Path path) {
        return isJson(path.toString().toLowerCase())
    }

    static boolean isYml(String fileName) {
        return fileName.endsWith(YML_EXT)
    }

    static boolean isYml(Path path) {
        return isYml(path.toString().toLowerCase())
    }

    static LogEntry newLogSource(Object source, String sourceName) {
        return addSourceName(new LogEntry(source: source), sourceName)
    }

    static LogEntry addSourceName(LogEntry entry, String sourceName) {
        entry.put('SourceName', sourceName)
        return entry
    }

    static String getSourceName(LogEntry entry) {
        return entry.get('SourceName')
    }
}
