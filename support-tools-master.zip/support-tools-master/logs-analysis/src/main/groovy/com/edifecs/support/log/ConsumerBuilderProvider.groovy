package com.edifecs.support.log

import com.edifecs.support.core.Provider
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class ConsumerBuilderProvider {
    Provider provider

    ConsumerBuilderProvider() {
        provider = Provider.instance()
    }

    ConsumerBuilderProvider(Provider provider) {
        this.provider = provider
    }

    @SuppressWarnings('GrUnnecessaryPublicModifier')
    public <T> T get(Object objectId, Object... args) {
        return provider.get(objectId.toString(), args)
    }

    Collection<ConsumerBuilder> getRegisteredBuilders() {
        return provider.getAll(ConsumerBuilder)
    }

    static ConsumerBuilderProvider of() {
        return new ConsumerBuilderProvider()
    }
    static ConsumerBuilderProvider of(Provider provider) {
        return new ConsumerBuilderProvider(provider)
    }
    static ConsumerBuilderProvider of(Properties properties) {
        return new ConsumerBuilderProvider(Provider.instance(properties))
    }
}
