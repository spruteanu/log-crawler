package com.edifecs.support.log

import com.edifecs.support.core.DatePredicate
import com.edifecs.support.core.GroovyUtil
import groovy.transform.CompileStatic
import groovy.util.logging.Log4j2

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.function.Predicate
import java.util.stream.Stream
import java.util.stream.StreamSupport

/**
 * @author Serge Pruteanu
 */
@CompileStatic
@Log4j2
class Logs implements Iterable<LogEntry> {

    protected Map<LogEntry, LogConsumer> sourceConsumerMap = [:]
    protected List<LogConsumer> consumers = new ArrayList<LogConsumer>()
    protected CloseableContainer closeableContainer = new CloseableContainer()

    AtomicBoolean processContext = new AtomicBoolean(true)

    protected Logs() {
    }

    Logs source(LogEntry source, LogConsumer sourceConsumer) {
        sourceConsumerMap.put(source, sourceConsumer)
        return this
    }

    @SuppressWarnings("GroovySynchronizationOnNonFinalField")
    Logs stop() {
        processContext.set(false)
        return this
    }

    protected void checkCloseable(Object object) {
        if (object instanceof Closeable) {
            if (object instanceof CloseableContainer) {
                ((CloseableContainer) object).addAll(closeableContainer)
                closeableContainer = object as CloseableContainer
            } else {
                closeableContainer.add(object as Closeable)
            }
        }
    }

    Logs using(LogConsumer consumer) {
        consumers.add(consumer)
        checkCloseable(consumer)
        if (consumer instanceof CsvWriterConsumer) {
            final csvOutputConsumer = (CsvWriterConsumer) consumer
            if (!csvOutputConsumer.columns) {
                final columns = new LinkedHashSet<String>()
                for (LogConsumer sourceConsumer : sourceConsumerMap.values()) {
                    sourceConsumer = lookupSourceConsumer(sourceConsumer)
                    if (sourceConsumer instanceof RegexConsumer) {
                        columns.addAll(((RegexConsumer) sourceConsumer).groupIndexMap.keySet().toList())
                    }
                }
                if (!columns) {
                    throw new RuntimeException('Columns are not defined for CsvOutputConsumer')
                }
                csvOutputConsumer.columns = columns.toList()
            }
        }
        return this
    }

    protected static void lookupLogDateConsumers(String target, final Collection<LogConsumer> collection) {
        for (final consumer : collection) {
            LogConsumer c = consumer
            if (c instanceof LineReaderConsumer) {
                c = ((LineReaderConsumer) c).getSourceConsumer()
            }
            if (c instanceof Log4jConsumer) {
                c.toDate(target)
            }
        }
    }

    Logs logToDate(String target = DateConsumer.DATE) {
        lookupLogDateConsumers(target, consumers)
        lookupLogDateConsumers(target, sourceConsumerMap.values())
        return this
    }

    Logs filter(Predicate<LogEntry> predicate, LogConsumer consumer, LogConsumer... consumers) {
        def cs = consumers ? ContainerConsumer.of(consumer).addAll(consumers) : consumer
        return using(new PredicateConsumer(predicate, cs))
    }

    Logs filter(@DelegatesTo(LogEntry) Closure<Boolean> predicate, @DelegatesTo(LogEntry) Closure consumer, @DelegatesTo(LogEntry) Closure... consumers) {
        def cs = consumers ? ContainerConsumer.of(consumer).addAll(consumers) : new LogEntryClosureConsumer(consumer)
        return filter(new LogEntryClosurePredicate(predicate), cs)
    }

    protected void toConsumers(LogEntry logEntry) {
        for (LogConsumer consumer : consumers) {
            consumer.consume(logEntry)
        }
    }

    protected void consume(LogEntry logEntry, LogConsumer sourceConsumer) {
        if (logEntry) {
            logEntry.sourceInfo("${Objects.toString(logEntry.source, '')}:($logEntry.row)".toString())
            sourceConsumer.consume(logEntry)
            toConsumers(logEntry)
        }
    }

    protected LogEntry consume(ConsumerInput input, Object source, LogConsumer sourceConsumer,
                               AtomicReference<LogEntry> aLastEntry, AtomicBoolean eof,
                               boolean onlyOne = false) {
        int nEntries = 0
        LogEntry lastEntry = aLastEntry.get()
        LogEntry logEntry
        while ((logEntry = input.next(source)) != null) {
            // todo: add a possibility to filter log entries at read time?
            sourceConsumer.consume(logEntry)
            if (logEntry.isEmpty()) {
                final line = logEntry.line
                if (lastEntry && line != null) {
                    lastEntry.line += ConsumerInput.LINE_BREAK + line
                }
                continue
            }
            lastEntry = logEntry
            if (!lastEntry.is(aLastEntry.get())) {
                if (aLastEntry.get() == null) {
                    aLastEntry.set(lastEntry)
                    continue
                }
                nEntries++
                final result = aLastEntry.get()
                consume(result, sourceConsumer)
                aLastEntry.set(lastEntry)
                if (onlyOne) {
                    return result
                }
            }
        }
        if (!logEntry) {
            eof.set(true)
        }
        if ((!logEntry || !onlyOne) && lastEntry) {
            nEntries++
            consume(lastEntry, sourceConsumer)
        }
        if (!onlyOne) {
            lastEntry = new LogEntry(source, null, nEntries)
        }
        return lastEntry
    }

    void consume(ConsumerInput input, Object source, LogConsumer sourceConsumer) {
        try {
            log.info("Consuming '$source'")
            final sourceStatEntry = consume(input, source, sourceConsumer, new AtomicReference<LogEntry>(null), new AtomicBoolean())
            if (sourceStatEntry) {
                log.info("Done consuming '$source'. Consumed '${sourceStatEntry.row}' entries")
            } else {
                log.info("Done consuming '$source'.")
            }
        } finally {
            Utils.closeQuietly(input)
        }
    }

    protected void close() {
        closeableContainer.close()
    }

    void consume(LogEntry logEntry) {
        for (LogConsumer consumer : consumers) {
            consumer.consume(logEntry)
        }
    }

    void consume() {
        for (final entry : sourceConsumerMap.entrySet()) {
            entry.value.consume(entry.key)
        }
        close()
    }

    protected void checkConsumersDefined() {
        if (sourceConsumerMap.isEmpty()) {
            throw new RuntimeException('No sources defined to iterate thru')
        }
    }

    @Override
    Iterator<LogEntry> iterator() {
        checkConsumersDefined()
        return new LogEntryIterator()
    }

    Stream<LogEntry> stream() { // todo add parallel logs processing support
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterator(), 0), false)
    }

    Stream<LogEntry> stream(Predicate<LogEntry> predicate) {
        return stream().filter(predicate)
    }

    Stream<LogEntry> dateStream(Date from = null, Date to = null, String target = DateConsumer.DATE) {
        logToDate(target)
        return stream(DateConsumer.logDatePredicate(DatePredicate.of(from, to), target))
    }

    @SuppressWarnings(['unused', 'GrMethodMayBeStatic'])
    protected ConsumerInput lookupConsumerInput(LogEntry entry, LogConsumer sourceConsumer) {
        return LineReaderInput.of(entry)
    }

    @SuppressWarnings(['unused', 'GrMethodMayBeStatic'])
    protected LogConsumer lookupSourceConsumer(LogConsumer consumer) {
        if (consumer instanceof AsynchronousJobs.AsynchronousJobConsumer) {
            consumer = ((AsynchronousJobs.AsynchronousJobConsumer) consumer).consumer
        }
        if (consumer instanceof LineReaderConsumer) {
            consumer = ((LineReaderConsumer) consumer).sourceConsumer
        }
        return consumer
    }

    protected Tuple toIteratorSource(LogEntry entry, LogConsumer consumer) {
        return new Tuple(lookupConsumerInput(entry, consumer), Utils.getSourceName(entry), consumer)
    }

    protected class LogEntryIterator implements Iterator<LogEntry> {
        private Queue<Tuple> sources = new LinkedList<>()

        private ConsumerInput input
        private LogConsumer sourceConsumer
        private Object source

        private final AtomicReference<LogEntry> lastEntry = new AtomicReference<>()
        private AtomicBoolean eof = new AtomicBoolean()

        private int nEntries
        private int totalEntries

        LogEntryIterator() {
            for (Map.Entry<LogEntry, LogConsumer> entry : sourceConsumerMap.entrySet()) {
                final key = entry.key
                final LogConsumer sourceConsumer = lookupSourceConsumer(entry.value)
                sources.add(toIteratorSource(key, sourceConsumer))
            }
        }

        protected void closeInput() {
            lastEntry.set(null)
            if (input) {
                Utils.closeQuietly(input)
            }
            input = null
            nEntries = 0
        }

        protected void nextSource() {
            closeInput()
            if (sources.size()) {
                final tuple = sources.poll()
                input = tuple.get(0) as ConsumerInput
                source = tuple.get(1)
                sourceConsumer = tuple.get(2) as LogConsumer
                nEntries = 0
                eof.set(false)
                log.info("Consuming '$source'")
            }
        }

        protected boolean hasNextSource() {
            return processContext && sources.size() > 0
        }
        protected boolean hasInput() {
            return processContext && input != null && !eof.get()
        }
        protected boolean hasInputOrSources() {
            return processContext && (hasInput() || hasNextSource())
        }
        protected boolean shouldChangeSource() {
            return hasNextSource() && (lastEntry.get() == null || (input != null && eof.get()))
        }

        @Override
        boolean hasNext() {
            if (shouldChangeSource()) {
                nextSource()
            }
            boolean result = hasInput()
            if (!result) {
                closeInput()
                Logs.this.close()
            }
            return result
        }

        protected LogEntry doNext() {
            final result = consume(input, source, sourceConsumer, lastEntry, eof, true)
            if (result) {
                nEntries += 1
                totalEntries += 1
            }
            if (eof.get()) {
                log.info("Done consuming '$source'. Consumed '$nEntries' entries")
                closeInput()
            }
            return result
        }

        @Override
        LogEntry next() {
            LogEntry entry = null
            while(entry == null && hasInputOrSources()) {
                entry = doNext()
                if (entry == null && !hasInput() && hasNextSource()) {
                    nextSource()
                }
            }
            return entry
        }
    }

    protected static LogsBuilder builder(String... args) {
        return Tool.init(new LogsBuilder(), args)
    }

    static LogsBuilder log4j(LogsBuilder builder, Closure closure) {
        builder.log4j(closure)
        return builder
    }

    static LogsBuilder log4j(@DelegatesTo(Log4jConsumer.Builder) Closure closure, String... args) {
        final builder = builder(args)
        return log4j(builder, closure)
    }

    static LogsBuilder builder(@DelegatesTo(LogsBuilder) Closure closure, String... args) {
        return GroovyUtil.closureCall(closure, LogsBuilder.class, { builder(args) })
    }
}
