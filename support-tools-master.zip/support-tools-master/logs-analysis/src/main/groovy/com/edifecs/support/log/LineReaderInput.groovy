package com.edifecs.support.log

import com.edifecs.support.core.ZipContentResolver
import com.edifecs.support.core.ZipWalker
import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu
 */
abstract class LineReaderInput implements ConsumerInput {
    abstract String readLine()
    int currentRow = 0

    @Override
    LogEntry next(Object source) {
        final line = readLine()
        LogEntry entry = null
        if (line != null) {
            entry = new LogEntry(source, line, currentRow)
        }
        return entry
    }

    @SuppressWarnings("GroovyAssignabilityCheck")
    static LineReaderInput of(LogEntry entry) {
        return of(entry.source)
    }

    @CompileStatic
    static LineReaderInput of(RandomAccessFile rf) {
        return new RandomAccessFileLineReader(rf)
    }

    @CompileStatic
    static List<RandomAccessFileLineReader> partitionReaders(String filePath) {
        return partitionReaders(filePath, 1)
    }

    @CompileStatic
    private static RandomAccessFile createRaf(String filePath) {
        return new RandomAccessFile(filePath, 'r')
    }

    @CompileStatic
    static List<RandomAccessFileLineReader> partitionReaders(String filePath, long nParts) {
        final List<RandomAccessFileLineReader> results = new ArrayList<>()
        RandomAccessFile raf = createRaf(filePath)
        long endPos = raf.length()
        long step = endPos / nParts as long
        while (nParts--) {
            raf = createRaf(filePath)
            results.add(new RandomAccessFileLineReader(raf, endPos))
            long startPos = endPos - step
            if (startPos) {
                raf.seek(startPos)
                raf.readLine()
                endPos = raf.filePointer
            }
        }
        return results
    }

    @CompileStatic
    static LineReaderInput of(InputStream inputStream) {
        return new IoLineReader(new BufferedReader(new InputStreamReader(inputStream)))
    }

    @CompileStatic
    static LineReaderInput of(Reader reader) {
        return new IoLineReader(reader instanceof BufferedReader ? reader : new BufferedReader(reader))
    }

    @CompileStatic
    static LineReaderInput of(File file) {
        return new IoLineReader(new BufferedReader(new FileReader(file)))
    }

    @CompileStatic
    static LineReaderInput of(String content) {
        if (content.length() < 1024) {
            if (ZipWalker.isArchivedSource(content)) {
                return of(ZipContentResolver.stream(content))
            } else {
                final file = new File(content)
                if (file.exists()) {
                    return of(file)
                }
            }
        }
        return new IoLineReader(new StringReader(content))
    }

    @CompileStatic
    private static class IoLineReader extends LineReaderInput {
        final Reader reader

        IoLineReader(Reader reader) {
            this.reader = reader
        }

        @Override
        String readLine() {
            final line = reader.readLine()
            if (line != null) {
                currentRow = currentRow + 1
            }
            return line
        }

        @Override
        void close() throws IOException {
            reader.close()
        }
    }

    @CompileStatic
    private static class RandomAccessFileLineReader extends LineReaderInput {
        final RandomAccessFile raf
        final long endPosition

        RandomAccessFileLineReader(RandomAccessFile raf) {
            this(raf, raf.length())
        }

        RandomAccessFileLineReader(RandomAccessFile raf, long endPosition) {
            this.raf = raf
            this.endPosition = endPosition
        }

        @Override
        String readLine() {
            final filePointer = raf.getFilePointer()
            final line = filePointer < endPosition ? raf.readLine() : null
            if (line != null) {
                currentRow = currentRow + 1
            }
            return line
        }

        @Override
        void close() throws IOException {
            raf.close()
        }
    }

}
