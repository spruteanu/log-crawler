package com.edifecs.support.log

import groovy.transform.CompileStatic

import java.util.function.Predicate

/**
 * @author Serge Pruteanu
 */
@CompileStatic
class PredicateConsumer implements LogConsumer {
    final LogConsumer consumer
    final Predicate<LogEntry> filter

    PredicateConsumer(@DelegatesTo(LogEntry) Closure<Boolean> filter, @DelegatesTo(LogEntry) Closure consumer) {
        this(new LogEntryClosurePredicate(filter), new LogEntryClosureConsumer(consumer))
    }

    PredicateConsumer(@DelegatesTo(LogEntry) Closure<Boolean> filter, LogConsumer consumer) {
        this(new LogEntryClosurePredicate(filter), consumer)
    }

    PredicateConsumer(Predicate<LogEntry> filter, LogConsumer consumer) {
        this.consumer = consumer
        this.filter = filter
    }

    @Override
    void consume(LogEntry entry) {
        if (filter.test(entry)) {
            consumer.consume(entry)
        }
    }

    static PredicateConsumer of(@DelegatesTo(LogEntry) Closure<Boolean> filter, @DelegatesTo(LogEntry) Closure consumer) {
        return new PredicateConsumer(new LogEntryClosurePredicate(filter), new LogEntryClosureConsumer(consumer))
    }

    static PredicateConsumer of(@DelegatesTo(LogEntry) Closure<Boolean> filter, LogConsumer consumer) {
        return new PredicateConsumer(new LogEntryClosurePredicate(filter), consumer)
    }

    static PredicateConsumer of(Predicate<LogEntry> filter, LogConsumer consumer) {
        return new PredicateConsumer(filter, consumer)
    }
}
