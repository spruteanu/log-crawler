package com.edifecs.support.ansible.log

import com.edifecs.support.core.Patterns
import com.edifecs.support.log.LogConsumer
import com.edifecs.support.log.LogEntry
import groovy.transform.CompileStatic
import org.apache.logging.log4j.LogManager

import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.regex.Pattern

/**
 * Format: <task start timestamp> <length of previous task> <current elapsed playbook execution time>
 * https://docs.ansible.com/ansible/latest/collections/ansible/posix/profile_tasks_callback.html
 *
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class ProfileTasksConsumer implements LogConsumer {
    private static final Pattern STATS_PATTERN = Patterns.of('\\((\\w+:\\w+:\\w+.\\w+)\\)\\s+(\\w+:\\w+:\\w+.\\w+)\\s+\\*+')
    public static final DateTimeFormatter TIME_DURATION_FORMATTER = DateTimeFormatter.ofPattern('H:mm[:ss[.SSS]]')

    protected LocalTime parseDuration(String durationString) {
        return LocalTime.parse(durationString, TIME_DURATION_FORMATTER)
    }

    Double parseProfileStats(LogEntry entry, String profileStatStr) {
        final matcher = STATS_PATTERN.matcher(profileStatStr)
        if (!matcher.find()) {
            return null
        }
        if (!entry.get(JobEvents.ELAPSED)) {
            final elapsed = matcher.group(2)
            if (elapsed) {
                entry.put(JobEvents.ELAPSED, elapsed)
            }
        }
        if (!entry.get(JobEvents.DURATION)) {
            final durationString = matcher.group(1)
            try {
                final time = parseDuration(durationString)
                final Double duration = time.toNanoOfDay() / 1_000_000_000.0d
                entry.put(JobEvents.DURATION, duration)
                return duration
            } catch(Exception ignore) {
                LogManager.getLogger(this.class).debug("Failed to parse duration: '$durationString'; Error message '${ignore.getMessage()}'")
            }
        }
        return null
    }

    @Override
    void consume(LogEntry entry) {
        final output = entry.get(JobEvents.OUTPUT)
        if (output && output.trim().endsWith('*')) {
            parseProfileStats(entry, output)
        }
    }
}
