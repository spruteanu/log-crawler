import com.edifecs.support.ansible.log.AnsibleLogs
import com.edifecs.support.ansible.log.JobEvents

final String source = args[0]
final String dest = args[1]

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
AnsibleLogs.toCsvReportable {
    setSource(source)
    def events = AnsibleLogs.jobEvents().defaultFields().add([
            "event_data.res.stderr": 'consoleError',
            "event_data.res.stdout": 'consoleOut',
            'event_data.res.rc'    : 'resultCode',
    ])
    mapStream events.mapStream(source).filter(
            JobEvents.consoleExceptionPredicate('consoleError', 'consoleOut').or(JobEvents.nonZeroResultCodePredicate('resultCode'))
    )
    add AnsibleLogs.csvConsumer(dest)
}
