import com.edifecs.support.ansible.log.AnsibleLogs

final String src = args[0]
final String dest = args[1]

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
AnsibleLogs.toCsvReportable {
    source(src)
    mapStream AnsibleLogs.toEventStream(src)
    add AnsibleLogs.csvConsumer(dest)
}
