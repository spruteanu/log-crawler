package com.edifecs.support.ansible.log

import com.edifecs.support.Util
import com.edifecs.support.core.ZipWalker
import com.edifecs.support.log.LogEntry
import spock.lang.Specification

import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class StdoutConsumerInputTest extends Specification {

    void 'verify handling play output'() {
        final entry = new LogEntry()
        def matcher = StdoutConsumerInput.playNamePattern.matcher('''PLAY [all] *********************************************************************''')
        matcher.matches()
        StdoutConsumerInput.handleNameMatching(matcher, entry)
        expect:
        entry._get(StdoutConsumerInput.TYPE)
        entry._get(StdoutConsumerInput.NAME)

        and: 'verify output matching'
        null != (matcher = StdoutConsumerInput.playOutputPattern.matcher('''\u001B[1;35m[WARNING]: Platform linux on host imlinux98 is using the discovered Python\u001B[0m'''))
        matcher.matches()
        StdoutConsumerInput.handleOutputMatching(matcher, entry)
        entry._get(StdoutConsumerInput.MESSAGE)

        and: 'verify recap output'
        entry.values.clear()
        null != (matcher = StdoutConsumerInput.playOutputPattern.matcher('''\u001B[0;33mimlinux98\u001B[0m                  : \u001B[0;32mok=34  \u001B[0m \u001B[0;33mchanged=11  \u001B[0m unreachable=0    failed=0    \u001B[0;36mskipped=6   \u001B[0m rescued=0    ignored=0   '''))
        matcher.matches() || matcher.find()
        StdoutConsumerInput.handleOutputMatching(matcher, entry)
        entry._get(StdoutConsumerInput.MESSAGE)
    }

    void 'verify stdout stream'() {
        final domainPath = Util.protectionDomainPath()
        def e002Path = new File(domainPath, 'executions/e002/artifacts/id000/stdout')

        expect:
        StdoutConsumerInput.of(e002Path).stream().collect(Collectors.toList())

        and: 'verify stdout stream from a zip'
        StdoutConsumerInput.of(ZipWalker.relativePath(
                new File(domainPath, 'executions/failed-e001.zip').getAbsolutePath(), 'e001/artifacts/id000/stdout')
        ).stream().collect(Collectors.toList())

        and: 'verify stdout stream from a zip with more details'
        StdoutConsumerInput.of(ZipWalker.relativePath(
                new File(domainPath, 'executions/failed-e0011.zip').getAbsolutePath(), 'e0011/artifacts/id000/stdout')
        ).stream().collect(Collectors.toList())

//        and: 'verify stdout stream with more facts'
//        StdoutConsumerInput.of(ZipWalker.relativePath(
//                new File(domainPath, 'executions/e0022.zip').getAbsolutePath(), 'e0022/artifacts/id000/stdout')
//        ).stream().collect(Collectors.toList())
    }
}
