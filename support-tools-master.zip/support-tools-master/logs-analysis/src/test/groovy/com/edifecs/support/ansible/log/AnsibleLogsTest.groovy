package com.edifecs.support.ansible.log

import com.edifecs.support.Util
import com.edifecs.support.log.LogEntry
import spock.lang.Specification
import spock.lang.Unroll

import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class AnsibleLogsTest extends Specification {

    protected static File executionsFile() {
        return new File(new File(Util.protectionDomainPath()).getParentFile(), 'test-classes/executions/e002')
    }

    protected static String executionsPath() {
        return executionsFile().absolutePath
    }

    void 'verify status'() {
        final ansibleLogs = new AnsibleLogs()
        ansibleLogs.jobEvents(executionsPath())

        expect:
        'successful' == ansibleLogs.readStatus()

        and:
        'Canceled' == ansibleLogs.jobEvents(Util.protectionDomainPath()).readStatus()
    }

    void 'verify read variables'() {
        final ansibleLogs = new AnsibleLogs()
        ansibleLogs.jobEvents(executionsPath())

        expect:
        ansibleLogs.readGroupVariables().variables.size()
        ansibleLogs.resolveVariables('all')

        and:
        ansibleLogs.resolveVariables('xecId_xecId_patch_host_imlinux98_id')
    }

    void 'verify log entries from one/multiple source(s)'() {
        given:
        def logs = AnsibleLogs.builder().source(executionsPath()).build()
        expect:
        final list = logs.stream().collect(Collectors.toList())
        list
    }

    void 'verify parse output duration'() {
        given:
        final consumer = new ProfileTasksConsumer()
        final output = 'Monday 28 August 2023  10:19:49 -0700 (0:00:00.900)       0:51:56.034 *********'
        final entry = new LogEntry()
        entry.(JobEvents.OUTPUT) = output

        expect:
        consumer.parseProfileStats(entry, output)
        entry._get(JobEvents.DURATION)
        entry.(JobEvents.DURATION)
        entry.(JobEvents.ELAPSED)
    }

    void 'verify deployment report'() {
        given:
        final logs = AnsibleLogs.of(executionsPath())
        def report = logs.deploymentReport()
        expect:
        report.isDone()
        report.startTime
        report.duration
        !report.getErrors()
    }

    @Unroll
    def "should correctly parse datetime with timezone: #timestamp"() {
        when: "parsing the timestamp"
        Date result = AnsibleLogs.parseAnsibleDate(timestamp)

        then: "the parsed date should match expected"
        result == expectedDate

        where:
        timestamp << [
                '2025-04-29T13:26:18.008636+00:00',      // UTC timezone
                '2025-04-29T13:26:18.008636-05:00',      // EST timezone
                '2025-04-29T13:26:18.008636+05:30',      // IST timezone
                '2025-04-29T13:26:18.008636Z',           // Zulu/UTC
                '2025-04-29T13:26:18+00:00',             // Without microseconds
                '2023-06-01T19:09:30.662415',
        ]
        expectedDate << [
                Date.from(ZonedDateTime.parse('2025-04-29T13:26:18.008636+00:00').toInstant()),
                Date.from(ZonedDateTime.parse('2025-04-29T13:26:18.008636-05:00').toInstant()),
                Date.from(ZonedDateTime.parse('2025-04-29T13:26:18.008636+05:30').toInstant()),
                Date.from(ZonedDateTime.parse('2025-04-29T13:26:18.008636Z').toInstant()),
                Date.from(ZonedDateTime.parse('2025-04-29T13:26:18+00:00').toInstant()),
                Date.from(LocalDateTime.parse('2023-06-01T19:09:30.662415').atZone(ZoneId.systemDefault()).toInstant()),
        ]
    }
}
