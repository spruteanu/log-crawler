/*
 * Log crawler, tool that allows to extract/crawl log files for further analysis
 *
 * Copyright (c) 2015, Sergiu Prutean. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3.0 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.
 */

package com.edifecs.support.log

import com.edifecs.support.core.Provider
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import spock.lang.Specification

/**
 * @author Serge Pruteanu
 */
class ConsumerBuilderProviderTest extends Specification {

    void 'verify default object provider'() {
        expect:
        Provider.isClassName(ConsumerBuilderProviderTest.class.name)
        null != ConsumerBuilderProvider.of().get(CsvWriterConsumer.name)
        null != ConsumerBuilderProvider.of().get(CsvWriterConsumer.name, new StringWriter(), ['col1', 'col2', 'col3',])
    }

    void 'verify spring object provider'() {
        // todo: add test case that will validate same ObjectId get methods under different profiles.
        final provider = ConsumerBuilderProvider.of()
        expect:
        null != provider.get(CsvWriterConsumer.name)
        null != provider.get(CsvWriterConsumer.name, new StringWriter(), ['col1', 'col2', 'col3',])
        null != provider.get('mumu')
        try {
            null == provider.get('cucu')
            throw new RuntimeException('An exception should be thrown, unknown class')
        } catch (Exception ignore) { }
    }

    @Configuration
    static class SpringConfig {
        @Bean(name = 'mumu')
        CsvWriterConsumer csvBean() {
            return new CsvWriterConsumer()
        }
    }
}
