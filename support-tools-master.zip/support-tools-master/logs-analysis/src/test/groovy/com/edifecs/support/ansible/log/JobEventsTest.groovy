package com.edifecs.support.ansible.log

import com.edifecs.support.Util
import spock.lang.Specification

import java.util.stream.Collectors

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class JobEventsTest extends Specification {

    void 'read job events'() {
        final je = new JobEvents()
        final jec = je.newConsumer()
        final result = jec.readText("""{"uuid": "12cc0352-e29d-4e91-99af-ceb96930a1bb", "counter": 9, "stdout": "", "start_line": 9, "end_line": 9, "runner_ident": "id000", "event": "runner_on_start", "pid": 524930, "created": "2022-10-26T16:56:55.423264", "parent_uuid": "0050568d-0dbd-1854-c18e-000000000009", "event_data": {"playbook": "main.yml", "playbook_uuid": "a444a156-45dc-4629-a7cf-fbcd190b78d3", "play": "localhost", "play_uuid": "0050568d-0dbd-1854-c18e-000000000007", "play_pattern": "localhost", "task": "Eid={{_EXECUTION_ID_}}: Execution marker=BEGIN_DEPLOYMENT", "task_uuid": "0050568d-0dbd-1854-c18e-000000000009", "task_action": "uri", "resolved_action": "uri", "task_args": "", "task_path": "/home/admin/IM/IM_DATA/environment/current/executions/e018/project/main.yml:4", "host": "localhost", "uuid": "12cc0352-e29d-4e91-99af-ceb96930a1bb"}}""")

        expect:
        result != null
        jec.defaultFields().valuesConsumer.fieldsToMap(result as Map).host == 'localhost'
        jec.defaultFields().defaultFields().valuesConsumer.toMap(result as Map).get("host") == 'localhost'
        jec.valuesConsumer.toMapAll(result as Map).get("event_data.host") == 'localhost'
    }

    void 'verify jobs map stream'() {
        final events = new JobEvents().all().trimEmpty()
        def e002Path = new File(Util.protectionDomainPath(), 'executions/e002')
        expect:
        events.mapStream(e002Path.toPath()).collect(Collectors.toList())
    }
}
