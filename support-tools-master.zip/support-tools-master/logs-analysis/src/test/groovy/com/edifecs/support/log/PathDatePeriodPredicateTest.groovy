package com.edifecs.support.log

import com.edifecs.support.Util
import spock.lang.Specification

import java.text.SimpleDateFormat

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
class PathDatePeriodPredicateTest extends Specification {
    private static final dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm")

    void 'verify logged date predicate with file'() {
        given:
        def testFile = new File(Util.protectionDomainFile(), "test-predicate.log")
        testFile.text = "2023-12-31 21:59:00\n2023-12-31 22:59:00\n2023-12-31 23:59:00"
        final predicate = PathDatePeriodPredicate.of('2023-12-31...2024-01-31 23:59',
                { String it -> dateFormat.parse(it) })
        expect:
        predicate.test(testFile.toPath())
    }

    void 'verify logged date predicate with log4j style file'() {
        given:
        def testFile = new File(Util.protectionDomainFile(), "tm-filter.log")
        testFile.text = """2023-05-12 17:26:52,860 INFO ETL.Logger - ETL processor 'DataIndexerProcessor Thread17' started to process the transmission 4670D311-CA0E-4295-9C31-CDFF76486153.dat (d7115133-1504-4c83-a8c5-01043200d323)
2023-05-12 17:26:52,861 INFO ETL.Logger - ETL processor 'DataIndexerProcessor Thread15' started to process the transmission ACK_4237C642-6C33-4A87-9BE0-353A99B8C864.dat (298BAD14-8030-44E0-88DB-A403357C5981-0000000)
2023-05-12 17:26:52,863 INFO ETL.Logger - [servicemanager_JMSETLProcessor4] JMSEtlProcessor Thread4 finished to process the file ACK_4237C642-6C33-4A87-9BE0-353A99B8C864.dat (298BAD14-8030-44E0-88DB-A403357C5981-0000000) in 0 hour(s) 0 minute(s) 0.123 second(s). Loaded: 6 business items, 0 errors, 0 validation events.
2023-05-12 17:26:52,863 INFO ETL.Logger - [servicemanager_JMSETLProcessor12] JMSEtlProcessor Thread12 finished to process the file 4670D311-CA0E-4295-9C31-CDFF76486153.dat (d7115133-1504-4c83-a8c5-01043200d323) in 0 hour(s) 0 minute(s) 0.113 second(s). Loaded: 6 business items, 0 errors, 0 validation events."""

        final predicate = PathDatePeriodPredicate.of('%d%m%n', '2023-04-01...2024-01-31 23:59')
        expect:
        predicate.test(testFile.toPath())
    }
}
