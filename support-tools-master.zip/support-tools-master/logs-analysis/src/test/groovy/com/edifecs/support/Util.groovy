package com.edifecs.support

import groovy.transform.CompileStatic

/**
 * @author Serge Pruteanu (sergep@edifecs.com)
 */
@CompileStatic
class Util {
    static File protectionDomainFile() {
        new File(Util.protectionDomain.codeSource.location.file)
    }

    static String protectionDomainPath() {
        return protectionDomainFile().absolutePath
    }
    static String getProtectionDomainPath() {
        return protectionDomainFile().absolutePath
    }

    static String protectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }
    static String getProtectionDomainPath(Class clazz) {
        return clazz.protectionDomain.codeSource.location.file
    }
}
