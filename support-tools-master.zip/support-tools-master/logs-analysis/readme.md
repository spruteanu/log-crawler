**TM logs analysis tool**

The tool contains a set of shell/logstash scripts that will help in logs analysis using ELK stack.

Package structure:
   * install<br/>
     folder with scripts (applications) for servers installation
   * templates<br/>
     folders with various templates for ELK stack
     * index<br/>
       folder with elasticsearch indexes, used from logstash scripts
     * kibana<br/>
       folder with elasticsearch indexes, used from logstash scripts
     * logstash<br/>
       folder with logstash scripts, used for logs parsing and load
   * root folder<br/>
      Contains various scripts for server(s) start, logs load
      ```*-start.bat, *-start.sh```<br/>
        scripts that start servers/agents. After servers start, kibana is accessible under [Kibana localhost](http://localhost:5601) <br/>
      ```*-load.bat, *-load.sh```<br/>
        scripts that parses/loads logs into elasticsearch or resulting file<br/>. Most of the scripts take as argument folder were logs are located (with one subfolder level)<br/>
      *Examples*:<br/>
      Load ETL logs with execution time, useful to analyze ETL throughput
        ```
        etl-logs-load.bat c:\temp\etl-slow
        ```
      Load traces logs to analyze Filestore operations
        ```
        tracer-logs-load.bat c:\temp\filestore-traces
        ```
      Load ALL TM logs, analyze ETL/Filestore executions too
        ```
        tm-logs-load.bat c:\temp\tm-logs
        ```

Useful links:<br/>
   * ElasticSearch Head Web front end<br/>
     [ElasticSearch Head GitHub](https://github.com/mobz/elasticsearch-head)
   * ElasticSearch Head Chrome extension<br/>
     [ElasticSearch Head Chrome Extension](https://chrome.google.com/webstore/detail/elasticsearch-head/ffmkiejjmecolpfloofpjologoblkegm?utm_source=chrome-app-launcher-info-dialog)
