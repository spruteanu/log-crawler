package com.edifecs.support.filelocker;

import com.edifecs.support.core.Utils;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @author victtern
 * Created: 10 2023
 */
public class Main {

    private static final Logger LOG = LogManager.getLogger(Main.class);

    private static final long DEFAULT_DURATION = 10;
    private static final HelpFormatter HELP_FORMATTER = new HelpFormatter();
    private static final Options OPTIONS = getOptions();

    public static void main(String[] args) {
        final Optional<CommandLine> cmdOpt = Utils.checkForValidArgumentsOrHelp(args, OPTIONS, v -> usage());

        try {
            if (cmdOpt.isPresent()) {
                final CommandLine cmd = cmdOpt.get();
                if (cmd.hasOption("help")) {
                    usage();
                } else {
                    lockFile(cmd.getOptionValue("file"), lockMode(cmd.getOptionValue("lockMode")), parseDuration(cmd.getOptionValue("duration")));
                }
            }
        } catch (Exception e) {
            LOG.error("Tool failed", e);
        }
    }

    private static long parseDuration(String duration) {
        if (duration != null && !duration.isEmpty()) {
            try {
                return Integer.parseInt(duration);
            } catch(NumberFormatException e) {
                throw new IllegalArgumentException("Invalid duration: " + duration, e);
            }
        }
        return DEFAULT_DURATION;
    }

    private static String lockMode(String lockMode) {
        if (lockMode != null && !lockMode.isBlank()) {
            return lockMode;
        }
        return "r";
    }

    private static void lockFile(String file, String lockMode, long duration) {
        final File fileToLock = new File(file);
        if (!fileToLock.exists()) {
            throw new IllegalArgumentException(String.format("The file %s does not exist", file));
        }
        LOG.info("Locking file {}", file);
        FileLock localFileLock = null;
        try (RandomAccessFile randomAccessFile = new RandomAccessFile(fileToLock, lockMode);
             FileChannel localFileChannel = randomAccessFile.getChannel()) {
            if (!"r".equals(lockMode)) {
                localFileLock = localFileChannel.lock();
            } else {
                localFileLock = localFileChannel.lock(0, Long.MAX_VALUE, true);
            }
            LOG.info("File {} locked", file);
            Thread.sleep(TimeUnit.MINUTES.toMillis(duration));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException(String.format("The file %s does not exist", file));
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Failed to lock the file %s", file));
        } finally {
            if (localFileLock != null) {
                try {
                    localFileLock.close();
                } catch (IOException ex) {
                    LOG.error("Failed to close lock for file: {}", file, ex);
                }
            }
        }
        LOG.info("File {} un-locked", file);
    }

    private static Options getOptions() {
        return new Options()
                .addOption(Option.builder("file").desc("File path to lock").required().hasArg().build())
                .addOption(Option.builder("lockMode").desc("Lock mode: 'r', 'rw', 'rws' or 'rwd' ('r' default)").required(false).hasArg().build())
                .addOption(Option.builder("duration").desc("Lock the file for provided duration (in minutes)").required(false).hasArg().build())
                .addOption(Option.builder("help").hasArg(false).desc("print help message").build());
    }

    private static void usage() {
        HELP_FORMATTER.printHelp("tm-lock-file.bat -file <filePath> [-lockMode <lockMode> | -duration <lockForDuration> | -help]", OPTIONS);
    }
}
