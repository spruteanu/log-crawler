@echo off
set JAVA_EXE=%JAVA_HOME%\bin\java.exe
IF EXIST "%JAVA_EXE%" goto start
set JAVA_EXE=java.exe
:start

set JAVA_OPTS=-Xmx10M
set JAVA_OPTS=%JAVA_OPTS% -DJAVA_EXE="%JAVA_EXE%"

set CLASSPATH=.
set CLASSPATH=%CLASSPATH%;%CLASSPATH%/*;file-locker-1.0-SNAPSHOT-jar-with-dependencies.jar;

"%JAVA_EXE%" %JAVA_OPTS% com.edifecs.support.filelocker.Main %*
