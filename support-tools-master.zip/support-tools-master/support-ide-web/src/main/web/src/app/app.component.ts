/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, OnInit, TemplateRef, ViewChild, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ScriptService } from './features/scripts/services/script.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Support IDE';
  serverName = '';
  isAdmin = false;
  isMenuOpen = false;
  currentUsername: string = '';

  localSystemInfo: Record<string, string> | null = null;
  isLoadingLocalInfo = false;
  @ViewChild('systemInfoDialog') systemInfoDialog?: TemplateRef<any>;

  constructor(private scriptService: ScriptService, private dialog: MatDialog, private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.loadServerName();
    this.loadMe();
  }

  ngOnDestroy(): void {}

  private loadServerName(): void {
    this.scriptService.getServerName().subscribe({
      next: (name) => {
        this.serverName = name;
      },
      error: (error) => {
        console.error('Failed to load server name:', error);
        this.serverName = 'Unknown';
      }
    });
  }

  private loadMe(): void {
    this.http.get<any>('api/users/me', { withCredentials: true }).subscribe({
      next: (me) => {
        const roles: string[] = me?.roles || [];
        this.isAdmin = roles.includes('ROLE_ADMIN') || roles.includes('ADMIN');
        this.currentUsername = me?.username || '';
      },
      error: (err) => {
        if (err?.status === 401) {
          window.location.href = 'login';
          return;
        }
        console.warn('Failed to load current user', err);
        this.isAdmin = false;
        this.currentUsername = '';
      }
    });
  }

  openLocalSystemInfo(): void {
    this.isLoadingLocalInfo = true;
    this.localSystemInfo = null;
    const ref = this.dialog.open(this.systemInfoDialog!, { width: '600px' });
    this.scriptService.getLocalSystemInfo().subscribe({
      next: (info) => {
        this.localSystemInfo = info;
        this.isLoadingLocalInfo = false;
      },
      error: (err) => {
        console.error('Failed to load local system info', err);
        this.localSystemInfo = { error: 'Failed to load local system info' } as any;
        this.isLoadingLocalInfo = false;
      }
    });
  }

  toggleMenu(): void {
    this.isMenuOpen = !this.isMenuOpen;
  }

  closeMenu(): void {
    this.isMenuOpen = false;
  }

  openCurrentUserEdit(): void {
    const username = this.currentUsername || 'me';
    this.router.navigate(['/users'], { queryParams: { edit: username } });
  }

  logout(): void {
    this.http.post('api/logout', {}, { withCredentials: true }).subscribe({
      next: () => window.location.href = 'login',
      error: () => window.location.href = 'login'
    });
  }
}
