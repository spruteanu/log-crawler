import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Cluster, AuthMode } from '../../models/cluster.model';

export interface DialogData {
    cluster: Cluster | null;
}

@Component({
    selector: 'app-cluster-dialog',
    templateUrl: './cluster-dialog.component.html',
    styleUrls: ['./cluster-dialog.component.scss']
})
export class ClusterDialogComponent {
    clusterForm: FormGroup;
    isEditMode: boolean;
    authModes = AuthMode;

    constructor(
        public dialogRef: MatDialogRef<ClusterDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: DialogData,
        private fb: FormBuilder
    ) {
        this.isEditMode = !!data.cluster;
        this.clusterForm = this.createForm();

        this.clusterForm.get('authMode')?.valueChanges.subscribe(mode => {
            this.updateValidators(mode);
        });

        this.updateValidators(this.clusterForm.get('authMode')?.value);
    }

    private createForm(): FormGroup {
        const cluster = this.data.cluster;
        return this.fb.group({
            name: [cluster?.name || '', [Validators.required]],
            description: [cluster?.description || ''],
            active: [cluster?.active !== false],
            awsRegion: [cluster?.awsRegion || '', [Validators.required]],
            clusterName: [cluster?.clusterName || '', [Validators.required]],
            authMode: [cluster?.authMode || AuthMode.PROFILE],
            awsProfile: [cluster?.awsProfile || ''],
            awsAccessKeyId: [cluster?.awsAccessKeyId || ''],
            awsSecretAccessKey: [cluster?.awsSecretAccessKey || ''],
            awsSessionToken: [cluster?.awsSessionToken || '']
        });
    }

    private updateValidators(authMode: AuthMode): void {
        const awsProfileControl = this.clusterForm.get('awsProfile');
        const awsAccessKeyIdControl = this.clusterForm.get('awsAccessKeyId');
        const awsSecretAccessKeyControl = this.clusterForm.get('awsSecretAccessKey');

        awsProfileControl?.clearValidators();
        awsAccessKeyIdControl?.clearValidators();
        awsSecretAccessKeyControl?.clearValidators();

        if (authMode === AuthMode.PROFILE) {
            awsProfileControl?.setValidators([Validators.required]);
        } else if (authMode === AuthMode.STATIC) {
            awsAccessKeyIdControl?.setValidators([Validators.required]);
            awsSecretAccessKeyControl?.setValidators([Validators.required]);
        }

        awsProfileControl?.updateValueAndValidity();
        awsAccessKeyIdControl?.updateValueAndValidity();
        awsSecretAccessKeyControl?.updateValueAndValidity();
    }

    onCancel(): void {
        this.dialogRef.close();
    }

    onSave(): void {
        if (this.clusterForm.valid) {
            const formValue = this.clusterForm.value;
            const cluster: Cluster = {
                id: this.data.cluster?.id || '',
                name: formValue.name,
                description: formValue.description,
                active: formValue.active,
                awsRegion: formValue.awsRegion,
                clusterName: formValue.clusterName,
                authMode: formValue.authMode,
                awsProfile: formValue.authMode === AuthMode.PROFILE ? formValue.awsProfile : undefined,
                awsAccessKeyId: formValue.authMode === AuthMode.STATIC ? formValue.awsAccessKeyId : undefined,
                awsSecretAccessKey: formValue.authMode === AuthMode.STATIC ? formValue.awsSecretAccessKey : undefined,
                awsSessionToken: formValue.authMode === AuthMode.STATIC ? formValue.awsSessionToken : undefined,
                createdAt: this.data.cluster?.createdAt || new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            this.dialogRef.close(cluster);
        }
    }

    getAuthModeKeys(): string[] {
        return Object.keys(this.authModes);
    }

    getAuthModeDisplay(mode: string): string {
        switch (mode) {
            case 'PROFILE':
                return 'AWS Profile';
            case 'STATIC':
                return 'Static credentials';
            default:
                return mode;
        }
    }
}
