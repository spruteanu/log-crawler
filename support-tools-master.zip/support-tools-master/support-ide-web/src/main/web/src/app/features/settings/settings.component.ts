import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  form = this.fb.group({
    exampleOption: ['']
  });

  roles: string[] = [];
  newRole = '';
  editingIndex: number | null = null;
  editingValue = '';
  isLoadingRoles = false;

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient, private snack: MatSnackBar) {}

  ngOnInit(): void {
    this.loadRoles();
  }

  navigateToScripts(): void {
    this.router.navigate(['']);
  }

  save(): void {
    // Demo save handler — extend to call backend as needed
    alert('Saved (demo)');
  }

  private api<T>(path: string, options?: any) {
    return this.http.request<T>(options?.method || 'GET', path, {
      withCredentials: true,
      headers: { 'Content-Type': 'application/json' },
      body: options?.body
    });
  }

  loadRoles(): void {
    this.isLoadingRoles = true;
    this.http.get<string[]>('api/roles', { withCredentials: true }).subscribe({
      next: (list) => { this.roles = list || []; this.isLoadingRoles = false; },
      error: () => { this.snack.open('Failed to load roles', 'Close', { duration: 3000 }); this.isLoadingRoles = false; }
    });
  }

  addRole(): void {
    const name = (this.newRole || '').trim();
    if (!name) return;
    this.api('api/roles', { method: 'POST', body: { name } }).subscribe({
      next: () => { this.snack.open('Role added', 'Close', { duration: 2000 }); this.newRole = ''; this.loadRoles(); },
      error: (err) => { const msg = err?.error?.error || 'Error'; this.snack.open('Failed to add role: ' + msg, 'Close', { duration: 3000 }); }
    });
  }

  startEdit(i: number): void {
    this.editingIndex = i;
    this.editingValue = this.roles[i] || '';
  }

  saveEdit(i: number): void {
    const oldName = this.roles[i];
    const newName = (this.editingValue || '').trim();
    if (!oldName || !newName || oldName === newName) { this.cancelEdit(); return; }
    this.api('api/roles/' + encodeURIComponent(oldName), { method: 'PUT', body: { newName } }).subscribe({
      next: () => { this.snack.open('Role renamed', 'Close', { duration: 2000 }); this.cancelEdit(); this.loadRoles(); },
      error: (err) => { const msg = err?.error?.error || 'Error'; this.snack.open('Failed to rename role: ' + msg, 'Close', { duration: 3000 }); }
    });
  }

  cancelEdit(): void { this.editingIndex = null; this.editingValue = ''; }

  deleteRole(i: number): void {
    const name = this.roles[i];
    if (!name) return;
    if (!confirm('Delete role "' + name + '"?')) return;
    this.api('api/roles/' + encodeURIComponent(name), { method: 'DELETE' }).subscribe({
      next: () => { this.snack.open('Role deleted', 'Close', { duration: 2000 }); this.loadRoles(); },
      error: (err) => { const msg = err?.error?.error || 'Error'; this.snack.open('Failed to delete role: ' + msg, 'Close', { duration: 3000 }); }
    });
  }
}
