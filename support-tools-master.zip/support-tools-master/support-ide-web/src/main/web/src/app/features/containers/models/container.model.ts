/*
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Container {
  id?: string;
  name: string;
  image?: string;
  namespace?: string;
  podName?: string;
  containerName?: string;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}
