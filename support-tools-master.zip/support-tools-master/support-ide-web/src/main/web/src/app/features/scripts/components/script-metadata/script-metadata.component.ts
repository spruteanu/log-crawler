/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Script } from '../../models/script.model';
import { ScriptService } from '../../services/script.service';

@Component({
  selector: 'app-script-metadata',
  templateUrl: './script-metadata.component.html',
  styleUrls: ['./script-metadata.component.scss']
})
export class ScriptMetadataComponent implements OnChanges {
  @Input() script: Script | null = null;
  scriptContent: string = '';
  isLoadingContent: boolean = false;

  constructor(private scriptService: ScriptService) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['script'] && this.script) {
      this.loadScriptContent();
    }
  }

  /**
   * Load the content of the selected script.
   */
  loadScriptContent(): void {
    if (!this.script) {
      return;
    }

    this.isLoadingContent = true;
    this.scriptService.getScriptContent(this.script.name).subscribe(
      (content) => {
        this.scriptContent = content;
        this.isLoadingContent = false;
      },
      (error) => {
        console.error('Error loading script content:', error);
        this.scriptContent = 'Failed to load script content: ' + error.message;
        this.isLoadingContent = false;
      }
    );
  }
}
