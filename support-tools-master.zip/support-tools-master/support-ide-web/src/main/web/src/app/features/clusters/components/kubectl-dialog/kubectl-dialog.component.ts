import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Cluster, KubectlResult } from '../../models/cluster.model';

export interface KubectlDialogData {
    cluster: Cluster;
    result?: KubectlResult;
    args?: string[];
}

@Component({
    selector: 'app-kubectl-dialog',
    templateUrl: './kubectl-dialog.component.html',
    styleUrls: ['./kubectl-dialog.component.scss']
})
export class KubectlDialogComponent implements OnInit {
    kubectlForm: FormGroup;
    isResultMode: boolean = false;
    commonCommands = [
        { name: 'List k8s pods', command: 'get pods' },
        { name: 'List services', command: 'get services' },
        { name: 'List namespaces', command: 'get namespaces' },
        { name: 'List deployments', command: 'get deployments' },
        { name: 'List nodes', command: 'get nodes' },
        { name: 'Cluster information', command: 'cluster-info' },
        { name: 'kubectl version', command: 'version' }
    ];

    constructor(
        public dialogRef: MatDialogRef<KubectlDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: KubectlDialogData,
        private fb: FormBuilder
    ) {
        this.isResultMode = !!data.result;
        this.kubectlForm = this.createForm();
    }

    ngOnInit(): void {
        if (this.data.args) {
            this.kubectlForm.get('command')?.setValue(this.data.args.join(' '));
        }
    }

    private createForm(): FormGroup {
        return this.fb.group({
            command: ['', [Validators.required]]
        });
    }

    onCancel(): void {
        this.dialogRef.close();
    }

    onExecute(): void {
        if (this.kubectlForm.valid) {
            const command = this.kubectlForm.get('command')?.value.trim();
            if (command) {
                const args = command.split(/\s+/).filter((arg: string) => arg.length > 0);
                this.dialogRef.close({ args });
            }
        }
    }

    selectCommonCommand(command: string): void {
        this.kubectlForm.get('command')?.setValue(command);
    }

    downloadResult(): void {
        if (this.data.result?.destination) {
            console.log('Download result from:', this.data.result.destination);
        }
    }

    getFormattedOutput(): string {
        if (!this.data.result?.output) {
            return '';
        }

        try {
            const parsed = JSON.parse(this.data.result.output);
            return JSON.stringify(parsed, null, 2);
        } catch {
            return this.data.result.output;
        }
    }

    isJsonOutput(): boolean {
        if (!this.data.result?.output) {
            return false;
        }

        try {
            JSON.parse(this.data.result.output);
            return true;
        } catch {
            return false;
        }
    }
}
