import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Cluster } from '../../models/cluster.model';

@Component({
    selector: 'app-cluster-list',
    templateUrl: './cluster-list.component.html',
    styleUrls: ['./cluster-list.component.scss']
})
export class ClusterListComponent {
    @Input() clusters: Cluster[] = [];
    @Output() edit = new EventEmitter<Cluster>();
    @Output() delete = new EventEmitter<Cluster>();
    @Output() testConnection = new EventEmitter<Cluster>();
    @Output() kubectl = new EventEmitter<Cluster>();

    displayedColumns: string[] = ['name', 'region', 'clusterName', 'authMode', 'status', 'actions'];

    onEdit(cluster: Cluster): void {
        this.edit.emit(cluster);
    }

    onDelete(cluster: Cluster): void {
        this.delete.emit(cluster);
    }

    onTestConnection(cluster: Cluster, event: Event): void {
        event.stopPropagation();
        this.testConnection.emit(cluster);
    }

    onKubectl(cluster: Cluster, event: Event): void {
        event.stopPropagation();
        this.kubectl.emit(cluster);
    }

    getAuthModeDisplay(authMode: string): string {
        switch (authMode) {
            case 'PROFILE':
                return 'AWS Profile';
            case 'STATIC':
                return 'Static credentials';
            default:
                return authMode;
        }
    }
}
