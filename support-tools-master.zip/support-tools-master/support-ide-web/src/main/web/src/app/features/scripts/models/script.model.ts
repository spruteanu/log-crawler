/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

/**
 * Interface representing a script metadata.
 * This corresponds to the Metadata class in the backend.
 */
export interface Script {
  name: string;
  type: string;
  path: string;
  description?: string;
  usage?: string;
  author?: string;
  arguments?: ScriptArgument[];
  libraryScript?: boolean;
  group?: string; // Group name for grouping in UI
}

/**
 * Interface representing a script argument.
 */
export interface ScriptArgument {
  name: string;
  type?: string;
  description?: string;
  required?: boolean;
  defaultValue?: any;
}

/**
 * Interface representing a script execution result.
 */
export interface ScriptExecutionResult {
  scriptName: string;
  scriptPath: string;
  success: boolean;
  output?: string;
  result?: any; // Changed from string to any to support complex objects
  error?: string;
  stackTrace?: string[];
  destination?: string; // Added for download functionality
  
  // Remote execution properties
  server?: string; // Server name
  hostname?: string; // Server hostname
}
