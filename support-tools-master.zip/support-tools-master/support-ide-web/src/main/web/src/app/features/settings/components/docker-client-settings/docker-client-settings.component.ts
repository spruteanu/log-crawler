/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface DockerClientConfig {
  host: string;
  port: number;
  tls: boolean;
  certPath?: string;
  keyPath?: string;
  caPath?: string;
}

@Component({
  selector: 'app-docker-client-settings',
  templateUrl: './docker-client-settings.component.html',
  styleUrls: ['./docker-client-settings.component.scss']
})
export class DockerClientSettingsComponent implements OnInit {
  @Output() saved = new EventEmitter<DockerClientConfig>();

  form: FormGroup;
  loading = false;

  constructor(private fb: FormBuilder, private http: HttpClient, private snack: MatSnackBar) {
    this.form = this.fb.group({
      host: ['localhost', Validators.required],
      port: [2375, [Validators.required, Validators.min(1)]],
      tls: [false],
      certPath: [''],
      keyPath: [''],
      caPath: ['']
    });
  }

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.http.get<DockerClientConfig>('api/docker/config', { withCredentials: true }).subscribe({
      next: cfg => { if (cfg) this.form.patchValue(cfg); this.loading = false; },
      error: () => { this.loading = false; /* silently ignore if endpoint not present */ }
    });
  }

  save(): void {
    if (this.form.invalid) return;
    const cfg = this.form.value as DockerClientConfig;
    this.http.post('api/docker/config', cfg, { withCredentials: true }).subscribe({
      next: () => { this.snack.open('Docker client settings saved', 'Close', { duration: 2000 }); this.saved.emit(cfg); },
      error: () => { this.snack.open('Failed to save Docker client settings', 'Close', { duration: 3000 }); }
    });
  }
}
