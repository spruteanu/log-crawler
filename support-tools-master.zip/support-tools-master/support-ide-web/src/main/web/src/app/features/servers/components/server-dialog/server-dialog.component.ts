/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Server } from '../../models/server.model';
import { ServerService } from '../../services/server.service';

export interface DialogData {
  server: Server | null;
}

@Component({
  selector: 'app-server-dialog',
  templateUrl: './server-dialog.component.html',
  styleUrls: ['./server-dialog.component.scss']
})
export class ServerDialogComponent {
  serverForm: FormGroup;
  isEditMode: boolean;
  grpcToken: string | null = null; // mirror of form control for convenience
  isDownloading = false;
  isGenerating = false;
  isDeploying = false;
  isGrpcTesting = false;

  constructor(
    public dialogRef: MatDialogRef<ServerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private fb: FormBuilder,
    private serverService: ServerService,
    private snackBar: MatSnackBar
  ) {
    this.isEditMode = !!data.server;
    this.serverForm = this.createForm();
  }

  private createForm(): FormGroup {
    const server = this.data.server;
    return this.fb.group({
      name: [server?.name || '', [Validators.required]],
      hostname: [server?.hostname || '', [Validators.required]],
      port: [server?.port || 22, [Validators.required, Validators.min(1), Validators.max(65535)]],
      username: [server?.username || '', [Validators.required]],
      password: [''],
      description: [server?.description || ''],
      grpcPort: [server?.grpcPort || 9090, [Validators.required, Validators.min(1), Validators.max(65535)]],
      toolLocation: [server?.toolLocation || '/tmp', [Validators.required]],
      grpcToken: [server?.grpcToken || '']
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.serverForm.valid) {
      const formValue = this.serverForm.value;
      const server: Server = {
        id: this.data.server?.id || '',
        name: formValue.name,
        hostname: formValue.hostname,
        port: formValue.port,
        username: formValue.username,
        password: formValue.password,
        description: formValue.description,
        grpcPort: formValue.grpcPort,
        toolLocation: formValue.toolLocation,
        grpcToken: formValue.grpcToken,
        active: this.data.server?.active || true,
        createdAt: this.data.server?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      this.dialogRef.close(server);
    }
  }

  generateGrpcToken(): void {
    const hostname = this.serverForm.get('hostname')?.value;
    if (!hostname) {
      this.snackBar.open('Please enter a hostname first', 'Close', { duration: 3000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
      return;
    }
    this.isGenerating = true;
    this.serverService.generateGrpcTokenForHostname(hostname).subscribe({
      next: (res) => {
        this.grpcToken = res.token;
        this.serverForm.get('grpcToken')?.setValue(res.token);
        this.isGenerating = false;
        this.snackBar.open('gRPC token generated from hostname', 'Close', { duration: 3000, panelClass: ['success-snackbar'], verticalPosition: 'top' });
      },
      error: (err) => {
        console.error('Failed to generate token', err);
        this.isGenerating = false;
        this.snackBar.open('Failed to generate gRPC token', 'Close', { duration: 6000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
      }
    });
  }

  copyToken(input: HTMLInputElement): void {
    const val = this.serverForm.get('grpcToken')?.value || '';
    if (val) {
      input.select();
      document.execCommand('copy');
      this.snackBar.open('Token copied to clipboard', 'Close', { duration: 2000, verticalPosition: 'top' });
    }
  }

  deployGrpcAgent(): void {
    if (!this.isEditMode || !this.data.server?.id) {
      this.snackBar.open('Save the server first to enable deployment', 'Close', { duration: 4000, verticalPosition: 'top' });
      return;
    }
    const hostname = this.serverForm.get('hostname')?.value;
    const toolLocation = this.serverForm.get('toolLocation')?.value;
    if (!hostname || !toolLocation) {
      this.snackBar.open('Hostname and tool location are required before deploying', 'Close', { duration: 4000, verticalPosition: 'top' });
      return;
    }

    const confirmed = window.confirm(`Deploy gRPC agent to ${hostname} at ${toolLocation}?`);
    if (!confirmed) return;

    this.isDeploying = true;
    // Build a full server override object based on current form values
    const formValue = this.serverForm.value;
    const override: Server = {
      id: this.data.server.id,
      name: formValue.name,
      hostname: formValue.hostname,
      port: formValue.port,
      username: formValue.username,
      password: formValue.password || '',
      description: formValue.description,
      grpcPort: formValue.grpcPort,
      toolLocation: formValue.toolLocation,
      grpcToken: formValue.grpcToken,
      active: this.data.server?.active ?? true,
      createdAt: this.data.server?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.serverService.deployGrpcAgent(this.data.server.id, override).subscribe({
      next: (res) => {
        this.isDeploying = false;
        const msg = res && res.success ? 'gRPC agent deployed successfully' : 'Deployment finished';
        this.snackBar.open(msg, 'Close', { duration: 4000, panelClass: ['success-snackbar'], verticalPosition: 'top' });
        // Optionally surface unzip output
        if (res && res.unzipOutput) {
          console.log('Unzip output:', res.unzipOutput);
        }
      },
      error: (err) => {
        this.isDeploying = false;
        let message = 'Failed to deploy gRPC agent';
        if (err && err.error) {
          if (typeof err.error === 'string') {
            message = err.error;
          } else if (err.error.message) {
            message = `${message}: ${err.error.message}`;
          }
        }
        console.error('Deployment error', err);
        this.snackBar.open(message, 'Close', { duration: 7000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
      }
    });
  }

  testGrpcConnection(): void {
    if (!this.isEditMode || !this.data.server?.id) {
      this.snackBar.open('Save the server first to test gRPC connection', 'Close', { duration: 4000, verticalPosition: 'top' });
      return;
    }
    this.isGrpcTesting = true;
    this.serverService.testGrpcConnection(this.data.server.id).subscribe({
      next: (res) => {
        this.isGrpcTesting = false;
        if (res && res.success) {
          this.snackBar.open(res.message || 'gRPC connection successful', 'Close', { duration: 3000, panelClass: ['success-snackbar'], verticalPosition: 'top' });
        } else {
          this.snackBar.open((res && res.message) || 'gRPC connection failed', 'Close', { duration: 7000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
        }
      },
      error: (err) => {
        this.isGrpcTesting = false;
        let message = 'Failed to test gRPC connection';
        if (err && err.error) {
          if (typeof err.error === 'string') message = err.error;
          else if (err.error.message) message = err.error.message;
        }
        this.snackBar.open(message, 'Close', { duration: 7000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
      }
    });
  }

  downloadGrpcAgent(): void {
    if (!this.isEditMode || !this.data.server?.id) {
      this.snackBar.open('Save the server first to enable host-specific download', 'Close', { duration: 4000, verticalPosition: 'top' });
      return;
    }
    this.isDownloading = true;
    const id = this.data.server.id;
    const hostname = this.serverForm.get('hostname')?.value || 'server';
    this.serverService.downloadGrpcAgentBundleForServer(id).subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `grpc-agent-${hostname}.zip`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        this.isDownloading = false;
        this.snackBar.open('Host-specific gRPC agent downloaded', 'Close', { duration: 3000, panelClass: ['success-snackbar'], verticalPosition: 'top' });
      },
      error: (err) => {
        console.error('Download failed', err);
        this.isDownloading = false;
        this.snackBar.open('Failed to download host-specific gRPC agent', 'Close', { duration: 6000, panelClass: ['error-snackbar'], verticalPosition: 'top' });
      }
    });
  }
}
