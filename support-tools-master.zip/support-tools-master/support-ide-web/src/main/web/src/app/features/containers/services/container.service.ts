/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Container } from '../models/container.model';

@Injectable({ providedIn: 'root' })
export class ContainerService {
  private readonly apiUrl = 'api/containers';

  constructor(private http: HttpClient) {}

  list(): Observable<Container[]> {
    return this.http.get<Container[]>(this.apiUrl, { withCredentials: true });
  }

  create(container: Container): Observable<Container> {
    return this.http.post<Container>(this.apiUrl, container, { withCredentials: true });
  }

  update(id: string, container: Container): Observable<Container> {
    return this.http.put<Container>(`${this.apiUrl}/${encodeURIComponent(id)}`, container, { withCredentials: true });
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${encodeURIComponent(id)}`, { withCredentials: true });
  }

  // Execute a registered script in Kubernetes for this container
  executeScript(id: string, scriptName: string, args: string[] = []): Observable<{ output?: string; error?: string; exitCode?: number; }>{
    const params = new HttpParams()
      .set('script', scriptName)
      .set('args', args.join(' '));
    return this.http.post<{ output?: string; error?: string; exitCode?: number; }>(`${this.apiUrl}/${encodeURIComponent(id)}/k8s/exec`, null, { params, withCredentials: true });
  }
}
