/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

/**
 * Interface representing a server configuration for remote script execution.
 */
export interface Server {
  id: string;
  name: string;
  hostname: string;
  port: number;
  username: string;
  password?: string; // Only used for input, not stored
  description?: string;
  grpcPort: number; // gRPC server port, defaults to 9090
  toolLocation?: string; // Location where support-tool will be copied, defaults to /tmp
  grpcToken?: string; // Token used by gRPC agent for authentication
  active: boolean;
  createdAt: string;
  updatedAt: string;
  downloadProgress?: {
    isDownloading: boolean;
    percentage: number;
    message: string;
  };
  deployProgress?: {
    isDeploying: boolean;
    percentage: number;
    message: string;
  };
}

/**
 * Interface representing a server connection test result.
 */
export interface ConnectionTestResult {
  success: boolean;
  message: string;
}
