import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { ClustersRoutingModule } from './clusters-routing.module';
import { ClustersComponent } from './clusters.component';
import { ClusterDialogComponent } from './components/cluster-dialog/cluster-dialog.component';
import { ClusterListComponent } from './components/cluster-list/cluster-list.component';
import { KubectlDialogComponent } from './components/kubectl-dialog/kubectl-dialog.component';

// Angular Material Modules
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';

@NgModule({
    declarations: [
        ClustersComponent,
        ClusterDialogComponent,
        ClusterListComponent,
        KubectlDialogComponent
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        ClustersRoutingModule,

        // Angular Material
        MatDialogModule,
        MatSnackBarModule,
        MatButtonModule,
        MatIconModule,
        MatTableModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        MatTabsModule,
        MatTooltipModule,
        MatRadioModule,
        MatSlideToggleModule,
        MatCardModule,
        MatExpansionModule,
        MatDividerModule
    ]
})
export class ClustersModule { }
