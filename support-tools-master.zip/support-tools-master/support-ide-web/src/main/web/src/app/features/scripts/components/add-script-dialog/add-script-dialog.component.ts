/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Script } from '../../models/script.model';
import { ScriptService } from '../../services/script.service';

export interface AddScriptDialogData {
  scripts: Script[];
}

export interface NewScriptData {
  name: string;
  description: string;
  author: string;
  selectedScripts?: Script[];
  scriptContent?: string;
}

@Component({
  selector: 'app-add-script-dialog',
  templateUrl: './add-script-dialog.component.html',
  styleUrls: ['./add-script-dialog.component.scss']
})
export class AddScriptDialogComponent implements OnInit {
  addScriptForm: FormGroup;
  isAdvancedMode = false;
  selectedScript: Script | null = null;
  selectedScripts: Script[] = [];
  scriptContent = '';
  
  constructor(
    private fb: FormBuilder,
    private scriptService: ScriptService,
    public dialogRef: MatDialogRef<AddScriptDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddScriptDialogData
  ) {
    this.addScriptForm = this.fb.group({
      // Mandatory fields
      name: ['', Validators.required],
      description: ['', Validators.required],
      author: ['', Validators.required],
      // Mode-specific fields
      selectedScriptPaths: [[]],
      scriptContent: ['']
    });
  }

  ngOnInit(): void {
    // Initialize form based on mode
    this.updateFormValidation();
  }

  /**
   * Toggle between simple dropdown mode and advanced editor mode
   */
  toggleMode(): void {
    this.isAdvancedMode = !this.isAdvancedMode;
    this.updateFormValidation();
    this.addScriptForm.reset();
    this.selectedScript = null;
    this.scriptContent = '';
  }

  /**
   * Update form validation based on current mode
   */
  private updateFormValidation(): void {
    if (this.isAdvancedMode) {
      // In advanced mode, script name and content are required
      // Other script information fields are not shown, so they're not required
      this.addScriptForm.get('name')?.setValidators([Validators.required]);
      this.addScriptForm.get('description')?.clearValidators();
      this.addScriptForm.get('author')?.clearValidators();
      this.addScriptForm.get('scriptContent')?.setValidators([Validators.required]);
      this.addScriptForm.get('selectedScriptPaths')?.clearValidators();
    } else {
      // In simple mode, script information fields and at least one script are required
      this.addScriptForm.get('name')?.setValidators([Validators.required]);
      this.addScriptForm.get('description')?.setValidators([Validators.required]);
      this.addScriptForm.get('author')?.setValidators([Validators.required]);
      this.addScriptForm.get('selectedScriptPaths')?.setValidators([this.atLeastOneScriptValidator]);
      this.addScriptForm.get('scriptContent')?.clearValidators();
    }
    this.addScriptForm.updateValueAndValidity();
  }

  /**
   * Custom validator to ensure at least one script is selected
   */
  private atLeastOneScriptValidator(control: any) {
    const value = control.value;
    return value && value.length > 0 ? null : { atLeastOneScript: true };
  }

  /**
   * Handle script selection from multi-select dropdown
   */
  onScriptsSelected(selectedPaths: string[]): void {
    this.selectedScripts = this.data.scripts.filter(script => 
      selectedPaths.includes(script.path)
    );
    
    this.addScriptForm.get('selectedScriptPaths')?.setValue(selectedPaths);
    
    // Load content for all selected scripts for preview
    if (this.selectedScripts.length > 0) {
      this.loadSelectedScriptsContent();
    }
  }

  /**
   * Load content for all selected scripts
   */
  private loadSelectedScriptsContent(): void {
    this.scriptContent = '';
    this.selectedScripts.forEach((script, index) => {
      this.scriptService.getScriptContent(script.name).subscribe(
        content => {
          this.scriptContent += `// === ${script.name} ===\n${content}\n\n`;
        },
        error => {
          console.error(`Error loading script content for ${script.name}:`, error);
          this.scriptContent += `// === ${script.name} ===\n// Failed to load script content\n\n`;
        }
      );
    });
  }

  /**
   * Handle script content change in editor
   */
  onScriptContentChange(content: string): void {
    this.addScriptForm.get('scriptContent')?.setValue(content);
  }

  /**
   * Add the script
   */
  addScript(): void {
    if (this.addScriptForm.valid) {
      const result: NewScriptData = {
        name: this.addScriptForm.get('name')?.value,
        description: this.isAdvancedMode ? 'Created in Advanced Mode' : this.addScriptForm.get('description')?.value,
        author: this.isAdvancedMode ? 'Advanced Mode User' : this.addScriptForm.get('author')?.value,
        selectedScripts: this.isAdvancedMode ? undefined : this.selectedScripts,
        scriptContent: this.isAdvancedMode ? this.addScriptForm.get('scriptContent')?.value : undefined
      };
      
      this.dialogRef.close(result);
    }
  }

  /**
   * Cancel and close dialog
   */
  cancel(): void {
    this.dialogRef.close();
  }
}
