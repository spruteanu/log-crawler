import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cluster, ConnectionTestResult, KubectlResult } from '../models/cluster.model';

@Injectable({
    providedIn: 'root'
})
export class ClusterService {
    private apiUrl = '/support-ide/api/clusters';

    constructor(private http: HttpClient) { }

    /**
     * Gets all clusters.
     */
    getAllClusters(): Observable<Cluster[]> {
        return this.http.get<Cluster[]>(this.apiUrl);
    }

    /**
     * Gets active clusters.
     */
    getActiveClusters(): Observable<Cluster[]> {
        return this.http.get<Cluster[]>(`${this.apiUrl}/active`);
    }

    /**
     * Gets a specific cluster by ID.
     * @param id The cluster ID
     */
    getCluster(id: string): Observable<Cluster> {
        return this.http.get<Cluster>(`${this.apiUrl}/${id}`);
    }

    /**
     * Creates a new cluster.
     * @param cluster The cluster to create
     */
    createCluster(cluster: Cluster): Observable<Cluster> {
        return this.http.post<Cluster>(this.apiUrl, cluster);
    }

    /**
     * Updates an existing cluster.
     * @param id The cluster ID
     * @param cluster The updated cluster
     */
    updateCluster(id: string, cluster: Cluster): Observable<Cluster> {
        return this.http.put<Cluster>(`${this.apiUrl}/${id}`, cluster);
    }

    /**
     * Deletes a cluster.
     * @param id The cluster ID
     */
    deleteCluster(id: string): Observable<void> {
        return this.http.delete<void>(`${this.apiUrl}/${id}`);
    }

    /**
     * Tests connection to a cluster.
     * @param id The cluster ID
     */
    testConnection(id: string): Observable<ConnectionTestResult> {
        return this.http.post<ConnectionTestResult>(`${this.apiUrl}/${id}/test-connection`, {});
    }

    /**
     * Executes a kubectl command on a cluster.
     * @param id The cluster ID
     * @param args The kubectl command arguments
     */
    executeKubectl(id: string, args: string[]): Observable<KubectlResult> {
        let params = new HttpParams();
        if (args && args.length > 0) {
            args.forEach(arg => {
                params = params.append('args', arg);
            });
        }
        return this.http.post<KubectlResult>(`${this.apiUrl}/${id}/kubectl`, null, { params });
    }
}
