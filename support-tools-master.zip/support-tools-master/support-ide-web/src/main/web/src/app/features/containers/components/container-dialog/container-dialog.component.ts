/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Container } from '../../models/container.model';

export interface ContainerDialogData {
  mode: 'create' | 'edit';
  container?: Container;
}

@Component({
  selector: 'app-container-dialog',
  templateUrl: './container-dialog.component.html',
  styleUrls: ['./container-dialog.component.scss']
})
export class ContainerDialogComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<ContainerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ContainerDialogData
  ) {
    this.form = this.fb.group({
      name: [data.container?.name || '', [Validators.required]],
      image: [data.container?.image || ''],
      namespace: [data.container?.namespace || ''],
      podName: [data.container?.podName || ''],
      containerName: [data.container?.containerName || ''],
      active: [!!data.container?.active]
    });
  }

  save(): void {
    if (this.form.invalid) return;
    this.dialogRef.close(this.form.value as Container);
  }
}
