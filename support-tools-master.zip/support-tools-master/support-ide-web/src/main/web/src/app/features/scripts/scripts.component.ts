/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ExecuteOnContainerDialogComponent, ExecuteOnContainerResult } from './components/execute-on-container-dialog/execute-on-container-dialog.component';
import { ContainerService } from '../containers/services/container.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ScriptService } from './services/script.service';
import { Script } from './models/script.model';
import { AddScriptDialogComponent, NewScriptData } from './components/add-script-dialog/add-script-dialog.component';
import { HistoryDialogComponent, ContextHistory } from './components/history-dialog/history-dialog.component';
import { Subject, of } from 'rxjs';
import { takeUntil, catchError, tap } from 'rxjs/operators';

@Component({
  selector: 'app-scripts',
  templateUrl: './scripts.component.html',
  styleUrls: ['./scripts.component.scss']
})
export class ScriptsComponent implements OnInit, OnDestroy {
  scripts: Script[] = [];
  selectedScript: Script | null = null;
  executionResult: any = null;
  isExecuting = false;
  isRefreshing = false;
  isLoading = false;

  private destroy$ = new Subject<void>();

  constructor(
    private scriptService: ScriptService,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private router: Router,
    private containerService: ContainerService
  ) { }

  ngOnInit(): void {
    this.loadScripts();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadScripts(): void {
    this.isLoading = true;
    this.scriptService.getAllScripts().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error loading scripts:', error);
        this.isLoading = false;
        return of([]);
      })
    ).subscribe(scripts => {
      this.scripts = scripts;
      this.isLoading = false;
      this.cdr.detectChanges(); // Force change detection
    });
  }

  onScriptSelected(script: Script): void {
    this.selectedScript = script;
    this.executionResult = null;
  }

  onExecuteScript(data: { args: string[], serverId?: string }): void {
    if (!this.selectedScript) {
      return;
    }

    this.isExecuting = true;
    this.executionResult = null;

    const { args, serverId } = data;
    
    // Log execution details
    console.log(`Executing script: ${this.selectedScript.name}`);
    console.log(`Arguments: ${args.length > 0 ? args.join(', ') : 'none'}`);
    console.log(`Server: ${serverId ? serverId : 'local'}`);

    this.scriptService.executeScript(this.selectedScript.name, args, serverId).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error executing script:', error);
        this.executionResult = {
          success: false,
          error: 'Failed to execute script: ' + error.message
        };
        this.isExecuting = false;
        return of(this.executionResult); // Return the error result
      })
    ).subscribe(result => {
      this.executionResult = result;
      this.isExecuting = false;
      
      // Log server information if present in the result
      if (result.server && result.hostname) {
        console.log(`Script executed on server: ${result.server} (${result.hostname})`);
      }
    });
  }

  refreshScripts(): void {
    this.isRefreshing = true;
    this.scriptService.refreshScripts().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error refreshing scripts:', error);
        this.isRefreshing = false;
        return of([]);
      })
    ).subscribe(scripts => {
      this.scripts = scripts;
      this.isRefreshing = false;
      this.cdr.detectChanges();
    });
  }

  openAddScriptDialog(): void {
    const dialogRef = this.dialog.open(AddScriptDialogComponent, {
      width: '800px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      data: { scripts: this.scripts },
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result: NewScriptData) => {
      if (result) {
        console.log('Script data received:', result);
        
        // Call backend to create the new script and get refreshed list
        this.scriptService.createScript(result).pipe(
          takeUntil(this.destroy$),
          catchError(error => {
            console.error('Error creating script:', error);
            
            // Extract error message from ApiError response
            let errorMessage = 'Script creation failed';
            if (error && error.error) {
              // If we have a structured error response
              if (error.error.message) {
                errorMessage = error.error.message;
              } else if (typeof error.error === 'string') {
                errorMessage = error.error;
              }
            }
            
            // Show error message in snackbar popup
            this.snackBar.open(errorMessage, 'Close', {
              duration: 8000, // 8 seconds
              panelClass: ['error-snackbar'],
              verticalPosition: 'top'
            });
            
            return of(null);
          })
        ).subscribe(refreshedScripts => {
          if (refreshedScripts) {
            console.log('Script created successfully, received refreshed scripts list:', refreshedScripts.length + ' scripts');
            // Update the scripts list directly with the refreshed list
            this.scripts = refreshedScripts;
            this.cdr.detectChanges();
            
            // Show success message
            this.snackBar.open('Script created successfully', 'Close', {
              duration: 3000, // 3 seconds
              panelClass: ['success-snackbar'],
              verticalPosition: 'top'
            });
          }
        });
      }
    });
  }

  openHistoryDialog(): void {
    const dialogRef = this.dialog.open(HistoryDialogComponent, {
      width: '800px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      data: {},
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((selectedHistory: ContextHistory) => {
      if (selectedHistory) {
        console.log('History selected:', selectedHistory);
        
        // Update script execution section with selected context history
        this.updateScriptExecutionFromHistory(selectedHistory);
        
        // Find associated scripts and mark as selected
        this.findAndSelectAssociatedScripts(selectedHistory);
      }
    });
  }

  navigateToServers(): void {
    this.router.navigate(['/servers']);
  }

  navigateToClusters(): void {
     this.router.navigate(['/clusters']);
  }

  navigateToContainers(): void {
     this.router.navigate(['/containers']);
  }

  private updateScriptExecutionFromHistory(history: ContextHistory): void {
    // Clear current execution result
    this.executionResult = null;
    
    // If there are scripts in the history, try to select the first one
    if (history.scripts && history.scripts.length > 0) {
      const firstScriptPath = history.scripts[0];
      const matchingScript = this.scripts.find(script => 
        script.path === firstScriptPath || script.name === this.getScriptNameFromPath(firstScriptPath)
      );
      
      if (matchingScript) {
        this.selectedScript = matchingScript;
        console.log('Selected script from history:', matchingScript);
      }
    }
  }

  private findAndSelectAssociatedScripts(history: ContextHistory): void {
    if (history.scripts && history.scripts.length > 0) {
      this.scriptService.findScriptsByPaths(history.scripts).pipe(
        takeUntil(this.destroy$),
        catchError(error => {
          console.error('Error finding associated scripts:', error);
          return of([]);
        })
      ).subscribe(associatedScripts => {
        console.log('Found associated scripts:', associatedScripts);
        
        // Mark the first associated script as selected if found
        if (associatedScripts.length > 0) {
          this.selectedScript = associatedScripts[0];
          console.log('Marked script as selected:', associatedScripts[0]);
        }
      });
    }
  }


  private getScriptNameFromPath(scriptPath: string): string {
    if (!scriptPath) return '';
    
    // Extract script name from path
    const parts = scriptPath.split(/[/\\]/);
    const fileName = parts[parts.length - 1];
    
    // Remove file extension if present
    return fileName.replace(/\.[^/.]+$/, '');
  }
}
