/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Server } from '../../models/server.model';

@Component({
  selector: 'app-server-list',
  templateUrl: './server-list.component.html',
  styleUrls: ['./server-list.component.scss']
})
export class ServerListComponent {
  @Input() servers: Server[] = [];
  @Output() edit = new EventEmitter<Server>();
  @Output() delete = new EventEmitter<Server>();
  @Output() testConnection = new EventEmitter<Server>();

  displayedColumns: string[] = ['name', 'hostname', 'port', 'username', 'status', 'actions'];

  onEdit(server: Server): void {
    this.edit.emit(server);
  }

  onDelete(server: Server): void {
    this.delete.emit(server);
  }

  onTestConnection(server: Server, event: Event): void {
    event.stopPropagation();
    this.testConnection.emit(server);
  }
}
