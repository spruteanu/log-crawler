/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./features/scripts/scripts.module').then(m => m.ScriptsModule)
  },
  {
    path: 'servers',
    loadChildren: () => import('./features/servers/servers.module').then(m => m.ServersModule)
  },
  {
    path: 'clusters',
    loadChildren: () => import('./features/clusters/clusters.module').then(m => m.ClustersModule)
  },
  {
    path: 'containers',
    loadChildren: () => import('./features/containers/containers.module').then(m => m.ContainersModule)
  },
  {
    path: 'users',
    loadChildren: () => import('./features/users/users.module').then(m => m.UsersModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./features/settings/settings.module').then(m => m.SettingsModule)
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
