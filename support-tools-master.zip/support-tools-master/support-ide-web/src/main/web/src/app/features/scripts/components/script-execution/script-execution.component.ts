/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Script, ScriptExecutionResult } from '../../models/script.model';
import { ScriptService } from '../../services/script.service';
import { HistoryDialogComponent, ContextHistory } from '../history-dialog/history-dialog.component';
import { ScriptMetadataDialogComponent } from '../script-metadata-dialog/script-metadata-dialog.component';
import { Subject, of } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';
import { ServerService } from '../../../servers/services/server.service';
import { Server } from '../../../servers/models/server.model';

@Component({
  selector: 'app-script-execution',
  templateUrl: './script-execution.component.html',
  styleUrls: ['./script-execution.component.scss']
})
export class ScriptExecutionComponent implements OnInit, OnChanges, OnDestroy {
  @Input() script: Script | null = null;
  @Input() isExecuting = false;
  @Input() executionResult: ScriptExecutionResult | null = null;
  @Output() execute = new EventEmitter<{ args: string[], serverId?: string }>();

  executionForm: FormGroup;
  
  // Server-related properties
  servers: Server[] = [];
  isLoadingServers = false;
  
  // Download-related properties
  isDownloading = false;
  downloadError: string | null = null;
  downloadingDestination: string | null = null;
  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder, 
    private scriptService: ScriptService, 
    private serverService: ServerService,
    private dialog: MatDialog
  ) {
    this.executionForm = this.fb.group({
      arguments: this.fb.array([]),
      serverId: ['']
    });
  }

  ngOnInit(): void {
    this.loadActiveServers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['script'] && this.script) {
      this.resetForm();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
  
  /**
   * Load active servers for remote execution.
   */
  loadActiveServers(): void {
    this.isLoadingServers = true;
    this.serverService.getActiveServers().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error loading servers:', error);
        this.isLoadingServers = false;
        return of([]);
      })
    ).subscribe(servers => {
      this.servers = servers;
      this.isLoadingServers = false;
    });
  }

  /**
   * Reset the form and initialize it with the script arguments.
   */
  resetForm(): void {
    // Clear the arguments form array
    while (this.argumentsFormArray.length !== 0) {
      this.argumentsFormArray.removeAt(0);
    }

    // Add form controls for each script argument
    if (this.script && this.script.arguments && this.script.arguments.length > 0) {
      this.script.arguments.forEach(arg => {
        this.argumentsFormArray.push(this.fb.control(arg.defaultValue || ''));
      });
    } else {
      // Add a single empty argument field if no arguments are defined
      this.addArgument();
    }
  }

  /**
   * Get the arguments form array.
   */
  get argumentsFormArray(): FormArray {
    return this.executionForm.get('arguments') as FormArray;
  }

  /**
   * Add a new argument field.
   */
  addArgument(): void {
    this.argumentsFormArray.push(this.fb.control(''));
  }

  /**
   * Remove an argument field.
   * @param index The index of the argument to remove
   */
  removeArgument(index: number): void {
    this.argumentsFormArray.removeAt(index);
  }

  /**
   * Execute the script with the provided arguments and optional server.
   */
  executeScript(): void {
    if (!this.script) {
      return;
    }

    // Get the argument values, filtering out empty ones
    const args = this.argumentsFormArray.controls
      .map(control => control.value)
      .filter(value => value !== null && value !== '');
    
    // Get the selected server ID
    const serverId = this.executionForm.get('serverId')?.value;
    
    // Emit the execution event with args and serverId
    this.execute.emit({ args, serverId: serverId || undefined });
  }

  /**
   * Check if the execution result is successful.
   */
  isSuccessful(): boolean {
    return this.executionResult?.success === true;
  }

  /**
   * Check if the execution result is an error.
   */
  isError(): boolean {
    return this.executionResult?.success === false;
  }

  /**
   * Check if the result is a complex object (not a simple string).
   */
  isComplexResult(): boolean {
    return this.executionResult?.result && 
           typeof this.executionResult.result === 'object' && 
           this.executionResult.result !== null;
  }

  /**
   * Check if the result is a simple string.
   */
  isSimpleResult(): boolean {
    return this.executionResult?.result && 
           typeof this.executionResult.result === 'string';
  }

  /**
   * Get the result as a formatted JSON string for display.
   */
  getFormattedResult(): string {
    if (!this.executionResult?.result) {
      return '';
    }
    
    if (typeof this.executionResult.result === 'string') {
      // Try to parse as JSON first, in case it's a JSON string
      try {
        const parsed = JSON.parse(this.executionResult.result);
        return JSON.stringify(parsed, null, 2);
      } catch {
        // If not JSON, return as is
        return this.executionResult.result;
      }
    }
    
    // For objects, stringify with proper formatting
    return JSON.stringify(this.executionResult.result, null, 2);
  }

  /**
   * Get object keys for iteration in template.
   */
  getObjectKeys(obj: any): string[] {
    return obj ? Object.keys(obj) : [];
  }

  /**
   * Get the value of an object property.
   */
  getObjectValue(obj: any, key: string): any {
    return obj ? obj[key] : null;
  }

  /**
   * Check if a value is an object (for nested display).
   */
  isObject(value: any): boolean {
    return value && typeof value === 'object' && value !== null && !Array.isArray(value);
  }

  /**
   * Check if a value is an array.
   */
  isArray(value: any): boolean {
    return Array.isArray(value);
  }

  /**
   * Format a value for display.
   */
  formatValue(value: any): string {
    if (value === null || value === undefined) {
      return 'null';
    }
    if (typeof value === 'string') {
      return value;
    }
    if (typeof value === 'boolean' || typeof value === 'number') {
      return String(value);
    }
    if (this.isArray(value)) {
      return `Array (${value.length} items)`;
    }
    if (this.isObject(value)) {
      const keys = Object.keys(value);
      return `Object (${keys.length} properties)`;
    }
    return JSON.stringify(value);
  }

  /**
   * Open the script details dialog.
   */
  openScriptDetailsDialog(): void {
    if (!this.script) {
      return;
    }

    this.dialog.open(ScriptMetadataDialogComponent, {
      width: '600px',
      data: { script: this.script },
      hasBackdrop: false,
      disableClose: true,
      position: { top: '100px' },
      panelClass: 'moveable-dialog'
    });
  }

  /**
   * Open the filtered history dialog for this script.
   */
  openFilteredHistoryDialog(): void {
    if (!this.script) {
      return;
    }

    const dialogRef = this.dialog.open(HistoryDialogComponent, {
      width: '800px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      data: { 
        filterScript: this.script.name,
        filterScriptPath: this.script.path 
      },
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((selectedHistory: ContextHistory) => {
      if (selectedHistory) {
        console.log('Filtered history selected:', selectedHistory);
        // Note: The parent component (scripts.component) handles the history selection logic
        // This component is focused on script execution, so we just log the selection
      }
    });
  }

  /**
   * Get a shortened version of the destination path for display.
   */
  getShortDestination(destination: string): string {
    if (!destination) {
      return '';
    }
    
    // If the path is too long, show only the filename
    const maxLength = 50;
    if (destination.length <= maxLength) {
      return destination;
    }
    
    // Extract filename from path
    const parts = destination.split(/[/\\]/);
    const filename = parts[parts.length - 1];
    
    // If filename is still too long, truncate it
    if (filename.length > maxLength) {
      return '...' + filename.substring(filename.length - maxLength + 3);
    }
    
    return '.../' + filename;
  }

  /**
   * Download a file from the given destination.
   */
  downloadFile(destination: string, event: Event): void {
    if (!destination) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    this.isDownloading = true;
    this.downloadError = null;
    this.downloadingDestination = destination;

    this.scriptService.downloadFile(destination, this.executionResult?.server).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error downloading file:', error);
        this.downloadError = error.message || 'Failed to download file';
        this.isDownloading = false;
        return of(null);
      })
    ).subscribe(response => {
      if (response) {
        // Handle successful download
        this.isDownloading = false;
        this.downloadingDestination = null;
        
        // Create a blob and download link
        const blob = new Blob([response], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = this.getShortDestination(destination);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }
    });
  }

  /**
   * Retry downloading the file.
   */
  retryDownload(): void {
    if (this.downloadingDestination) {
      this.downloadError = null;
      this.downloadFile(this.downloadingDestination, new Event('click'));
    }
  }
}
