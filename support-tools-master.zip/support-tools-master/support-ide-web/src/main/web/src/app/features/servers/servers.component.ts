/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ServerService } from './services/server.service';
import { Server } from './models/server.model';
import { ServerDialogComponent } from './components/server-dialog/server-dialog.component';
import { Subject, of } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.scss']
})
export class ServersComponent implements OnInit, OnDestroy {
  servers: Server[] = [];
  isLoading = false;
  isRefreshing = false;

  private destroy$ = new Subject<void>();

  constructor(
    private serverService: ServerService,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadServers();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadServers(): void {
    this.isLoading = true;
    this.serverService.getAllServers().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error loading servers:', error);
        this.isLoading = false;
        return of([]);
      })
    ).subscribe(servers => {
      this.servers = servers;
      this.isLoading = false;
      this.cdr.detectChanges(); // Force change detection
    });
  }

  navigateToScripts(): void {
    this.router.navigate(['']);
  }

  navigateToClusters(): void {
    this.router.navigate(['/clusters']);
  }

  openAddServerDialog(): void {
    const dialogRef = this.dialog.open(ServerDialogComponent, {
      width: '600px',
      data: { server: null },
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result: Server) => {
      if (result) {
        this.serverService.createServer(result).pipe(
          takeUntil(this.destroy$),
          catchError(error => {
            console.error('Error creating server:', error);
            
            // Extract error message from ApiError response
            let errorMessage = 'Server creation failed';
            if (error && error.error) {
              // If we have a structured error response
              if (error.error.message) {
                errorMessage = error.error.message;
              } else if (typeof error.error === 'string') {
                errorMessage = error.error;
              }
            }
            
            // Show error message in snackbar popup
            this.snackBar.open(errorMessage, 'Close', {
              duration: 8000, // 8 seconds
              panelClass: ['error-snackbar'],
              verticalPosition: 'top'
            });
            
            return of(null);
          })
        ).subscribe(server => {
          if (server) {
            // Add the new server to the list and trigger table change detection by changing array reference
            this.servers.push(server);
            this.servers = [...this.servers];
            this.cdr.detectChanges();
            
            // Show success message
            this.snackBar.open('Server created successfully', 'Close', {
              duration: 3000, // 3 seconds
              panelClass: ['success-snackbar'],
              verticalPosition: 'top'
            });
          }
        });
      }
    });
  }

  openEditServerDialog(server: Server): void {
    const dialogRef = this.dialog.open(ServerDialogComponent, {
      width: '600px',
      data: { server: { ...server } },
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result: Server) => {
      if (result) {
        this.serverService.updateServer(server.id, result).pipe(
          takeUntil(this.destroy$),
          catchError(error => {
            console.error('Error updating server:', error);
            
            // Extract error message from ApiError response
            let errorMessage = 'Server update failed';
            if (error && error.error) {
              // If we have a structured error response
              if (error.error.message) {
                errorMessage = error.error.message;
              } else if (typeof error.error === 'string') {
                errorMessage = error.error;
              }
            }
            
            // Show error message in snackbar popup
            this.snackBar.open(errorMessage, 'Close', {
              duration: 8000, // 8 seconds
              panelClass: ['error-snackbar'],
              verticalPosition: 'top'
            });
            
            return of(null);
          })
        ).subscribe(updatedServer => {
          if (updatedServer) {
            // Update the server in the list
            const index = this.servers.findIndex(s => s.id === updatedServer.id);
            if (index !== -1) {
              this.servers[index] = updatedServer;
              // Reassign array to new reference so MatTable updates properly
              this.servers = [...this.servers];
              this.cdr.detectChanges();
            }
            
            // Show success message
            this.snackBar.open('Server updated successfully', 'Close', {
              duration: 3000, // 3 seconds
              panelClass: ['success-snackbar'],
              verticalPosition: 'top'
            });
          }
        });
      }
    });
  }

  deleteServer(server: Server): void {
    if (confirm(`Are you sure you want to delete the server "${server.name}"?`)) {
      this.serverService.deleteServer(server.id).pipe(
        takeUntil(this.destroy$),
        catchError(error => {
          console.error('Error deleting server:', error);
          
          // Extract error message from ApiError response
          let errorMessage = 'Server deletion failed';
          if (error && error.error) {
            // If we have a structured error response
            if (error.error.message) {
              errorMessage = error.error.message;
            } else if (typeof error.error === 'string') {
              errorMessage = error.error;
            }
          }
          
          // Show error message in snackbar popup
          this.snackBar.open(errorMessage, 'Close', {
            duration: 8000, // 8 seconds
            panelClass: ['error-snackbar'],
            verticalPosition: 'top'
          });
          
          return of(false);
        })
      ).subscribe(success => {
        if (success !== false) {
          // Remove the server from the list
          this.servers = this.servers.filter(s => s.id !== server.id);
          this.cdr.detectChanges();
          
          // Show success message
          this.snackBar.open('Server deleted successfully', 'Close', {
            duration: 3000, // 3 seconds
            panelClass: ['success-snackbar'],
            verticalPosition: 'top'
          });
        }
      });
    }
  }

  testConnection(server: Server): void {
    this.serverService.testGrpcConnection(server.id).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error testing connection:', error);
        
        // Extract error message from ApiError response
        let errorMessage = 'Connection test failed';
        if (error && error.error) {
          // If we have a structured error response
          if (error.error.message) {
            errorMessage = error.error.message;
          } else if (typeof error.error === 'string') {
            errorMessage = error.error;
          }
        }
        
        // Show error message in snackbar popup
        this.snackBar.open(errorMessage, 'Close', {
          duration: 8000, // 8 seconds
          panelClass: ['error-snackbar'],
          verticalPosition: 'top'
        });
        
        return of({ success: false, message: errorMessage });
      })
    ).subscribe(result => {
      if (result.success) {
        // Show success message
        this.snackBar.open(result.message || 'Connection successful', 'Close', {
          duration: 3000, // 3 seconds
          panelClass: ['success-snackbar'],
          verticalPosition: 'top'
        });
      } else {
        // Show error message
        this.snackBar.open(result.message || 'Connection failed', 'Close', {
          duration: 8000, // 8 seconds
          panelClass: ['error-snackbar'],
          verticalPosition: 'top'
        });
      }
    });
  }

  downloadGrpcAgentBundle(): void {
    this.serverService.downloadGrpcAgentBundle().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error downloading gRPC agent bundle:', error);
        
        // Show error message in snackbar popup
        this.snackBar.open('Failed to download gRPC agent bundle', 'Close', {
          duration: 8000, // 8 seconds
          panelClass: ['error-snackbar'],
          verticalPosition: 'top'
        });
        
        return of(null);
      })
    ).subscribe(blob => {
      if (blob) {
        // Create download link
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'support-tools.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        // Show success message
        this.snackBar.open('gRPC agent bundle downloaded successfully', 'Close', {
          duration: 3000, // 3 seconds
          panelClass: ['success-snackbar'],
          verticalPosition: 'top'
        });
      }
    });
  }

  downloadGrpcAgentBundleForServer(server: Server): void {
    // Generate unique session ID for progress tracking
    const sessionId = `download_${server.id}_${Date.now()}`;
    
    // Initialize progress tracking
    server.downloadProgress = {
      isDownloading: true,
      percentage: 0,
      message: 'Initializing download...'
    };
    
    // Establish SSE connection for progress updates
    const eventSource = this.serverService.getDownloadProgress(sessionId);

    // Unified handler for both named 'progress' SSE events and default ones
    const handleDownloadProgressEvent = (event: MessageEvent) => {
      try {
        const progressData = JSON.parse(event.data);
        server.downloadProgress = {
          isDownloading: progressData.status !== 'completed',
          percentage: typeof progressData.percentage === 'number' ? progressData.percentage : server.downloadProgress?.percentage || 0,
          message: progressData.message || server.downloadProgress?.message || ''
        };

        // Trigger change detection
        this.cdr.detectChanges();

        if (progressData.status === 'completed') {
          eventSource.close();
        }
      } catch (e) {
        console.error('Error parsing progress data:', e);
      }
    };

    // Listen to explicitly named 'progress' events (backend emits named events)
    eventSource.addEventListener('progress', handleDownloadProgressEvent as any);
    // Fallback in case server sends unnamed events
    eventSource.onmessage = handleDownloadProgressEvent;
    
    eventSource.onerror = (error) => {
      console.error('SSE connection error:', error);
      eventSource.close();
      server.downloadProgress = { isDownloading: false, percentage: 0, message: '' };
      this.cdr.detectChanges();
    };
    
    // Start the actual download with session ID
    this.serverService.downloadGrpcAgentBundleForServer(server.id, sessionId).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error downloading gRPC agent bundle for server:', error);
        eventSource.close();
        server.downloadProgress = { isDownloading: false, percentage: 0, message: '' };
        this.cdr.detectChanges();
        
        this.snackBar.open('Failed to download agent bundle for server', 'Close', {
          duration: 8000,
          panelClass: ['error-snackbar'],
          verticalPosition: 'top'
        });
        return of(null);
      })
    ).subscribe(blob => {
      if (blob) {
        eventSource.close();
        server.downloadProgress = { isDownloading: false, percentage: 100, message: 'Download completed!' };
        
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${server.hostname}-support-tools.zip`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        this.snackBar.open('Agent bundle downloaded', 'Close', {
          duration: 3000,
          panelClass: ['success-snackbar'],
          verticalPosition: 'top'
        });
        
        // Clear progress after a delay
        setTimeout(() => {
          server.downloadProgress = { isDownloading: false, percentage: 0, message: '' };
          this.cdr.detectChanges();
        }, 2000);
      }
    });
  }

  deployGrpcAgent(server: Server): void {
    // Generate unique session ID for progress tracking
    const sessionId = `deploy_${server.id}_${Date.now()}`;
    
    // Initialize progress tracking
    server.deployProgress = {
      isDeploying: true,
      percentage: 0,
      message: 'Initializing deployment...'
    };
    
    // Establish SSE connection for progress updates
    const eventSource = this.serverService.getDeployProgress(sessionId);

    // Unified handler for both named 'progress' SSE events and default ones
    const handleDeployProgressEvent = (event: MessageEvent) => {
      try {
        const progressData = JSON.parse(event.data);
        server.deployProgress = {
          isDeploying: progressData.status !== 'completed',
          percentage: typeof progressData.percentage === 'number' ? progressData.percentage : server.deployProgress?.percentage || 0,
          message: progressData.message || server.deployProgress?.message || ''
        };

        // Trigger change detection
        this.cdr.detectChanges();

        if (progressData.status === 'completed') {
          eventSource.close();
        }
      } catch (e) {
        console.error('Error parsing progress data:', e);
      }
    };

    // Listen to explicitly named 'progress' events (backend emits named events)
    eventSource.addEventListener('progress', handleDeployProgressEvent as any);
    // Fallback in case server sends unnamed events
    eventSource.onmessage = handleDeployProgressEvent;
    
    eventSource.onerror = (error) => {
      console.error('SSE connection error:', error);
      eventSource.close();
      server.deployProgress = { isDeploying: false, percentage: 0, message: '' };
      this.cdr.detectChanges();
    };
    
    // Start the actual deployment with session ID
    this.serverService.deployGrpcAgent(server.id, undefined, sessionId).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error deploying gRPC agent:', error);
        eventSource.close();
        server.deployProgress = { isDeploying: false, percentage: 0, message: '' };
        this.cdr.detectChanges();
        
        let errorMessage = 'Failed to deploy gRPC agent';
        if (error && error.error) {
          if (error.error.message) {
            errorMessage = error.error.message;
          } else if (typeof error.error === 'string') {
            errorMessage = error.error;
          }
        }
        this.snackBar.open(errorMessage, 'Close', {
          duration: 8000,
          panelClass: ['error-snackbar'],
          verticalPosition: 'top'
        });
        return of(null);
      })
    ).subscribe(result => {
      if (result) {
        eventSource.close();
        server.deployProgress = { isDeploying: false, percentage: 100, message: 'Deployment completed!' };
        
        this.snackBar.open('gRPC agent deployed successfully', 'Close', {
          duration: 3000,
          panelClass: ['success-snackbar'],
          verticalPosition: 'top'
        });
        
        // Clear progress after a delay
        setTimeout(() => {
          server.deployProgress = { isDeploying: false, percentage: 0, message: '' };
          this.cdr.detectChanges();
        }, 2000);
      }
    });
  }
}
