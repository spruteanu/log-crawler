/**
 * Enum for auths AWS modes.
 */
export enum AuthMode {
    PROFILE = 'PROFILE',
    STATIC = 'STATIC'
}

/**
 * K8s cluster config interface
 */
export interface Cluster {
    id: string;
    name: string;
    description?: string;
    active: boolean;

    awsRegion: string;
    clusterName: string;

    authMode: AuthMode;
    awsProfile?: string;

    awsAccessKeyId?: string;
    awsSecretAccessKey?: string;
    awsSessionToken?: string;

    createdAt: string;
    updatedAt: string;

    testProgress?: {
        isTesting: boolean;
        message: string;
    };
}

/**
 * Interface representing the result of a connection test.
 */
export interface ConnectionTestResult {
    success: boolean;
    message: string;
    output?: string;
    error?: string;
}

/**
 * Interface representing the result of a kubectl command.
 */
export interface KubectlResult {
    success: boolean;
    output?: string;
    error?: string;
    destination?: string;
}
