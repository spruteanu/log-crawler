import { Component, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface UserDialogData {
  user?: { username: string; roles: string[]; firstName?: string; lastName?: string; selectedRole?: string } | null;
  availableRoles: string[];
}

@Component({
  selector: 'app-users-edit-dialog',
  templateUrl: './users-edit-dialog.component.html',
  styleUrls: ['./users-edit-dialog.component.scss']
})
export class UsersEditDialogComponent {
  title = this.data?.user ? 'Edit User' : 'Add User';
  hidePassword = true;

  form = this.fb.group({
    username: [{ value: this.data?.user?.username || '', disabled: !!this.data?.user }, [Validators.required]],
    password: [''],
    firstName: [this.data?.user?.firstName || ''],
    lastName: [this.data?.user?.lastName || ''],
    roles: [this.data?.user?.roles || []],
    selectedRole: [this.data?.user?.selectedRole || '']
  });

  availableRoles: string[] = [];
  newRole = '';

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<UsersEditDialogComponent, any>,
    @Inject(MAT_DIALOG_DATA) public data: UserDialogData
  ) {
    const uniq = Array.from(new Set(data?.availableRoles || []));
    this.availableRoles = (uniq.length ? uniq : ['ADMIN']).sort((a, b) => a.localeCompare(b));
    // Initialize selectedRole if not provided but roles exist
    const currentSelected = (this.form.get('selectedRole')?.value || '').trim();
    const roles: string[] = this.form.get('roles')?.value || [];
    if (!currentSelected && roles && roles.length > 0) {
      this.form.get('selectedRole')?.setValue(roles[0]);
    }
  }

  addRole(): void {
    const r = (this.newRole || '').trim();
    if (!r) return;
    const set = new Set<string>([...this.availableRoles, r]);
    this.availableRoles = Array.from(set).sort((a, b) => a.localeCompare(b));
    const current = new Set<string>(this.form.get('roles')?.value || []);
    current.add(r);
    this.form.get('roles')?.setValue(Array.from(current));
    // set the selectedRole to the newly added role
    this.form.get('selectedRole')?.setValue(r);
    this.newRole = '';
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.dialogRef.close({
      username: (v.username || '').trim(),
      password: (v.password || '').trim(),
      firstName: (v.firstName || '').trim(),
      lastName: (v.lastName || '').trim(),
      roles: (v.roles || []) as string[],
      selectedRole: (v.selectedRole || '').trim()
    });
  }

  cancel(): void {
    this.dialogRef.close(null);
  }
}
