/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ScriptService } from '../../services/script.service';
import { Subject } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

export interface ContextHistory {
  scripts: string[];
  destination: string;
  dateTime: string;
  source: string;
  server?: string; // server name
}

export interface HistoryDialogData {
  filterScript?: string;
  filterScriptPath?: string;
}

@Component({
  selector: 'app-history-dialog',
  templateUrl: './history-dialog.component.html',
  styleUrls: ['./history-dialog.component.scss']
})
export class HistoryDialogComponent implements OnInit, OnDestroy {
  historyEntries: ContextHistory[] = [];
  selectedEntry: ContextHistory | null = null;
  isLoading = false;
  errorMessage: string | null = null;
  showAllScripts: { [key: string]: boolean } = {};
  isDownloading = false;
  downloadingDestination: string | null = null;
  downloadingServer: string | null = null;
  downloadError: string | null = null;

  private destroy$ = new Subject<void>();

  constructor(
    public dialogRef: MatDialogRef<HistoryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: HistoryDialogData,
    private scriptService: ScriptService
  ) { }

  ngOnInit(): void {
    this.loadHistory();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadHistory(): void {
    this.isLoading = true;
    this.errorMessage = null;

    this.scriptService.getContextHistory().pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Error loading context history:', error);
        this.errorMessage = 'Failed to load execution history: ' + error.message;
        this.isLoading = false;
        return of([]);
      })
    ).subscribe(history => {
      // Apply filtering if filter parameters are provided
      if (this.data.filterScript || this.data.filterScriptPath) {
        this.historyEntries = this.filterHistoryByScript(history);
      } else {
        this.historyEntries = history;
      }
      this.isLoading = false;
    });
  }

  private filterHistoryByScript(history: ContextHistory[]): ContextHistory[] {
    if (!this.data.filterScript && !this.data.filterScriptPath) {
      return history;
    }

    return history.filter(entry => {
      if (!entry.scripts || entry.scripts.length === 0) {
        return false;
      }

      // Check if any script in the entry matches the filter criteria
      return entry.scripts.some(scriptPath => {
        // Extract script name from path for comparison
        const scriptName = this.getScriptName(scriptPath);
        
        // Match by script name or full path
        return (this.data.filterScript && scriptName === this.data.filterScript) ||
               (this.data.filterScriptPath && scriptPath === this.data.filterScriptPath) ||
               (this.data.filterScript && scriptPath.includes(this.data.filterScript));
      });
    });
  }

  selectEntry(entry: ContextHistory): void {
    this.selectedEntry = entry;
  }

  toggleShowAllScripts(source: string, event: Event): void {
    // Prevent the click from selecting the table row
    event.stopPropagation();
    this.showAllScripts[source] = !this.showAllScripts[source];
  }

  trackByEntry(index: number, entry: ContextHistory): string {
    return entry.source || index.toString();
  }

  formatDate(dateTime: string): string {
    try {
      const date = new Date(dateTime);
      return date.toLocaleString();
    } catch (error) {
      return dateTime;
    }
  }

  getShortDestination(destination: string): string {
    if (!destination) return '';
    
    // Extract filename from path
    const parts = destination.split(/[/\\]/);
    return parts[parts.length - 1] || destination;
  }

  getScriptName(scriptPath: string): string {
    if (!scriptPath) return '';
    
    // Extract script name from path
    const parts = scriptPath.split(/[/\\]/);
    const fileName = parts[parts.length - 1];
    
    // Remove file extension if present
    return fileName.replace(/\.[^/.]+$/, '');
  }

  getEntryName(entry: ContextHistory): string {
    if (!entry.scripts || entry.scripts.length === 0) {
      return 'Execution Entry';
    }
    
    // Use the first script name as the entry name
    const firstScriptName = this.getScriptName(entry.scripts[0]);
    
    // If there are multiple scripts, indicate that
    if (entry.scripts.length > 1) {
      return `${firstScriptName} (+${entry.scripts.length - 1} more)`;
    }
    
    return firstScriptName;
  }

  getPrimaryScript(entry: ContextHistory): string {
    if (!entry.scripts || entry.scripts.length === 0) {
      return 'No script';
    }
    
    return this.getScriptName(entry.scripts[0]);
  }


  downloadFile(destination: string, event: Event, server?: string): void {
    // Prevent the click from selecting the list item
    event.stopPropagation();
    
    if (!destination) {
      console.error('No destination path provided for download');
      return;
    }

    // Prevent multiple simultaneous downloads
    if (this.isDownloading) {
      return;
    }

    // Reset any previous error and set download progress state
    this.downloadError = null;
    this.isDownloading = true;
    this.downloadingDestination = destination;
    this.downloadingServer = server ?? this.selectedEntry?.server ?? null;

    // Use the new service method that can handle errors
    this.scriptService.downloadFile(destination, this.downloadingServer ?? undefined).pipe(
      takeUntil(this.destroy$),
      catchError(error => {
        console.error('Download error:', error);
        
        // Set appropriate error message based on HTTP status
        if (error.status === 400) {
          this.downloadError = 'Invalid file path provided for download.';
        } else if (error.status === 404) {
          this.downloadError = 'File not found or access denied. The file may have been moved or deleted.';
        } else if (error.status === 500) {
          this.downloadError = 'Server error occurred while preparing the download. Please try again later.';
        } else {
          this.downloadError = 'An unexpected error occurred during download. Please try again.';
        }
        
        // Reset download state
        this.isDownloading = false;
        this.downloadingDestination = null;
        this.downloadingServer = null;
        
        return of(null); // Return null to complete the observable
      })
    ).subscribe(blob => {
      // Reset download state
      this.isDownloading = false;
      this.downloadingDestination = null;
      this.downloadingServer = null;
      
      // If blob is null (error case), don't proceed with download
      if (!blob) {
        return;
      }
      
      // Create blob URL and trigger download
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = this.getShortDestination(destination);
      link.style.display = 'none';
      
      // Add to DOM, click, and remove
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up the blob URL
      window.URL.revokeObjectURL(url);
    });
  }

  selectHistory(): void {
    if (this.selectedEntry) {
      this.dialogRef.close(this.selectedEntry);
    }
  }

  retryDownload(): void {
    if (this.downloadingDestination) {
      // Create a dummy event object for the downloadFile method
      const dummyEvent = new Event('click');
      this.downloadFile(this.downloadingDestination, dummyEvent, this.downloadingServer ?? undefined);
    }
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
