/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Container } from '../../../containers/models/container.model';
import { ContainerService } from '../../../containers/services/container.service';

export interface ExecuteOnContainerDialogData {
  scriptName: string;
}

export interface ExecuteOnContainerResult {
  containerId: string;
  args: string[];
}

@Component({
  selector: 'app-execute-on-container-dialog',
  templateUrl: './execute-on-container-dialog.component.html',
  styleUrls: ['./execute-on-container-dialog.component.scss']
})
export class ExecuteOnContainerDialogComponent implements OnInit {
  form: FormGroup;
  containers: Container[] = [];
  loading = false;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<ExecuteOnContainerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ExecuteOnContainerDialogData,
    private containerService: ContainerService
  ) {
    this.form = this.fb.group({
      containerId: ['', Validators.required],
      args: ['']
    });
  }

  ngOnInit(): void {
    this.loading = true;
    this.containerService.list().subscribe({
      next: list => { this.containers = (list || []).filter(c => c.active); this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  save(): void {
    if (this.form.invalid) return;
    const args = (this.form.value.args as string || '').trim();
    const result: ExecuteOnContainerResult = {
      containerId: this.form.value.containerId,
      args: args ? args.split(/\s+/) : []
    };
    this.dialogRef.close(result);
  }
}
