/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Script, ScriptExecutionResult } from '../models/script.model';
import { ContextHistory } from '../components/history-dialog/history-dialog.component';
import { NewScriptData } from '../components/add-script-dialog/add-script-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class ScriptService {
  private apiUrl = '/support-ide/api/scripts';

  constructor(private http: HttpClient) { }

  /**
   * Get all available scripts.
   */
  getAllScripts(): Observable<Script[]> {
    return this.http.get<Script[]>(this.apiUrl);
  }

  /**
   * Get details of a specific script.
   * @param scriptPath The path of the script
   */
  getScript(scriptPath: string): Observable<Script> {
    return this.http.get<Script>(`${this.apiUrl}/${encodeURIComponent(scriptPath)}`);
  }

  /**
   * Get the content of a specific script.
   * @param scriptPath The path of the script
   */
  getScriptContent(scriptPath: string): Observable<string> {
    return this.http.get(`${this.apiUrl}/${encodeURIComponent(scriptPath)}/content`, { responseType: 'text' });
  }

  /**
   * Execute a script.
   * @param scriptPath The path of the script
   * @param args The script arguments
   * @param serverId The ID of the server to execute the script on (optional)
   */
  executeScript(scriptPath: string, args: string[] = [], serverId?: string): Observable<ScriptExecutionResult> {
    let params = new HttpParams();
    if (args && args.length > 0) {
      args.forEach(arg => {
        params = params.append('args', arg);
      });
    }
    
    if (serverId) {
      params = params.append('serverId', serverId);
    }
    
    return this.http.post<ScriptExecutionResult>(
      `${this.apiUrl}/${encodeURIComponent(scriptPath)}/execute`, 
      null, 
      { params }
    );
  }

  /**
   * Refresh the script cache.
   */
  refreshScripts(): Observable<Script[]> {
    return this.http.post<Script[]>(`${this.apiUrl}/refresh`, null);
  }

  /**
   * Get the server name.
   */
  getServerName(): Observable<string> {
    return this.http.get(`${this.apiUrl}/server-name`, { responseType: 'text' });
  }

  /**
   * Get context history list.
   */
  getContextHistory(): Observable<ContextHistory[]> {
    return this.http.get<ContextHistory[]>(`${this.apiUrl}/history`);
  }

  /**
   * Find scripts by their paths.
   * @param scriptPaths Array of script paths
   */
  findScriptsByPaths(scriptPaths: string[]): Observable<Script[]> {
    const scripts = scriptPaths.join(',');
    let params = new HttpParams().set('scripts', scripts);
    return this.http.get<Script[]>(`${this.apiUrl}/find-by-scripts`, { params });
  }

  /**
   * Get download URL for a file from script execution results.
   * @param filePath The path to the file to download
   */
  getDownloadUrl(filePath: string, server?: string): string {
    const encodedPath = encodeURIComponent(filePath);
    const serverParam = server ? `&server=${encodeURIComponent(server)}` : '';
    return `${this.apiUrl}/download?path=${encodedPath}${serverParam}`;
  }

  /**
   * Download a file from script execution results with proper error handling.
   * @param filePath The path to the file to download
   */
  downloadFile(filePath: string, server?: string): Observable<Blob> {
    const encodedPath = encodeURIComponent(filePath);
    const serverParam = server ? `&server=${encodeURIComponent(server)}` : '';
    return this.http.get(`${this.apiUrl}/download?path=${encodedPath}${serverParam}`, { 
      responseType: 'blob',
      observe: 'body'
    });
  }

  /**
   * Create a new script with the provided data and return a refreshed list of all scripts.
   * @param scriptData The new script data including name, description, author, and either selectedScripts or scriptContent
   * @returns A refreshed list of all scripts including the newly created script
   */
  createScript(scriptData: NewScriptData): Observable<Script[]> {
    return this.http.post<Script[]>(`${this.apiUrl}/create`, scriptData);
  }

  /**
   * Get local system info of the machine running backend.
   */
  getLocalSystemInfo(): Observable<Record<string, string>> {
    return this.http.get<Record<string, string>>(`/support-ide/api/servers/local-system-info`);
  }
}
