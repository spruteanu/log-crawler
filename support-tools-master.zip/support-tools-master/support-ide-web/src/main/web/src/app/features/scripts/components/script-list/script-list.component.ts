/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Script } from '../../models/script.model';
import { MatAccordion } from '@angular/material/expansion';
import { ScriptMetadataDialogComponent } from '../script-metadata-dialog/script-metadata-dialog.component';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-script-list',
  templateUrl: './script-list.component.html',
  styleUrls: ['./script-list.component.scss']
})
export class ScriptListComponent implements OnChanges {
  @ViewChild(MatAccordion) accordion?: MatAccordion;
  @Input() scripts: Script[] = [];
  @Input() selectedScript: Script | null = null;
  @Output() scriptSelected = new EventEmitter<Script>();

  filterText: string = '';
  filteredScripts: Script[] = [];

  // Grouped view data
  ungroupedScripts: Script[] = [];
  groupedScripts: { name: string, scripts: Script[] }[] = [];
  private initialExpansionDone: boolean = false;

  constructor(private dialog: MatDialog, private sanitizer: DomSanitizer) {}

  /**
   * Initialize filtered scripts when input scripts change
   */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['scripts']) {
      this.updateFilteredScripts();
    }
  }

  /**
   * Handle filter text changes
   */
  onFilterChange(): void {
    this.updateFilteredScripts();
  }

  /**
   * Clear the filter
   */
  clearFilter(): void {
    this.filterText = '';
    this.updateFilteredScripts();
  }

  /**
   * Update the filtered scripts based on the filter text
   */
  private updateFilteredScripts(): void {
    if (!this.filterText || this.filterText.length < 2) {
      // If filter text is empty or has less than 2 characters, show all scripts
      this.filteredScripts = [...this.scripts];
    } else {
      // Filter scripts based on the filter text (case-insensitive)
      const filterTextLower = this.filterText.toLowerCase();
      
      // First try to filter by name only
      let nameMatches = this.scripts.filter(script => 
        script.name.toLowerCase().includes(filterTextLower)
      );
      
      // If no name matches found, then filter by description
      if (nameMatches.length === 0) {
        nameMatches = this.scripts.filter(script => 
          script.description && script.description.toLowerCase().includes(filterTextLower)
        );
      }
      
      this.filteredScripts = nameMatches;
    }
    this.updateGroupedView();
  }

  /**
   * Build grouped view arrays from filteredScripts
   */
  private updateGroupedView(): void {
    const groupsMap: { [key: string]: Script[] } = {};
    const ungrouped: Script[] = [];

    for (const s of this.filteredScripts) {
      const g = (s as any).group && (s as any).group!.trim() ? (s as any).group!.trim() : '';
      if (!g) {
        ungrouped.push(s);
      } else {
        if (!groupsMap[g]) groupsMap[g] = [];
        groupsMap[g].push(s);
      }
    }

    // Sort scripts by name within each group
    Object.keys(groupsMap).forEach(k => groupsMap[k].sort((a, b) => a.name.localeCompare(b.name)));
    ungrouped.sort((a, b) => a.name.localeCompare(b.name));

    // Build grouped array sorted by group name
    const groupedArr = Object.keys(groupsMap)
      .sort((a, b) => a.localeCompare(b))
      .map(name => ({ name, scripts: groupsMap[name] }));

    this.ungroupedScripts = ungrouped;
    this.groupedScripts = groupedArr;

    // Expand all groups on initial load (no filter) once; collapse after filtering
    // Use setTimeout to run after the view updates with new panels
    setTimeout(() => {
      // Expand all groups on initial load and when a filter is applied
      if (!this.initialExpansionDone && (!this.filterText || this.filterText.trim().length === 0)) {
        this.accordion?.openAll();
        this.initialExpansionDone = true;
      } else if (this.filterText && this.filterText.trim().length > 0) {
        this.accordion?.openAll();
      }
    }, 0);
  }
  
  /**
   * Highlights the matching text in a string
   * @param text The text to highlight
   * @returns SafeHtml with highlighted text
   */
  highlightText(text: string): SafeHtml {
    if (!text || !this.filterText || this.filterText.length < 2) {
      return this.sanitizer.bypassSecurityTrustHtml(text);
    }
    
    const filterTextLower = this.filterText.toLowerCase();
    const textLower = text.toLowerCase();
    
    if (!textLower.includes(filterTextLower)) {
      return this.sanitizer.bypassSecurityTrustHtml(text);
    }
    
    const startIndex = textLower.indexOf(filterTextLower);
    const endIndex = startIndex + this.filterText.length;
    
    const beforeMatch = text.substring(0, startIndex);
    const match = text.substring(startIndex, endIndex);
    const afterMatch = text.substring(endIndex);
    
    const highlightedText = `${beforeMatch}<span class="highlight-text">${match}</span>${afterMatch}`;
    return this.sanitizer.bypassSecurityTrustHtml(highlightedText);
  }

  /**
   * Select a script from the list.
   * @param script The script to select
   */
  selectScript(script: Script): void {
    this.scriptSelected.emit(script);
  }

  /**
   * Check if a script is the currently selected script.
   * @param script The script to check
   * @returns True if the script is selected, false otherwise
   */
  isSelected(script: Script): boolean {
    return this.selectedScript?.path === script.path;
  }

  /**
   * Show script metadata in a non-modal dialog.
   * @param script The script to show metadata for
   */
  showScriptMetadata(script: Script): void {
    this.dialog.open(ScriptMetadataDialogComponent, {
      width: '600px',
      data: { script },
      hasBackdrop: false,
      disableClose: true,
      position: { top: '100px' },
      panelClass: 'moveable-dialog'
    });
  }

  /**
   * Get material icon name based on script type
   */
  getScriptIconName(script: Script): string {
    const t = (script.type || '').toLowerCase();
    if (t.includes('collect')) return 'format_list_bulleted'; // list icon for collect
    if (t.includes('fixture')) return 'build'; // wrench/build-like for fixture
    if (t.includes('valid')) return 'check_circle'; // validation icon (more widely supported)
    return 'description';
  }

  /**
   * Get CSS class for icon color based on script type
   */
  getScriptIconClass(script: Script): string {
    const t = (script.type || '').toLowerCase();
    if (t.includes('collect')) return 'icon-collect';
    if (t.includes('fixture')) return 'icon-fixture';
    if (t.includes('valid')) return 'icon-validation';
    return 'icon-default';
  }
}
