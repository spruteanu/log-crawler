import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersEditDialogComponent } from './users-edit-dialog.component';

interface UserDto {
  username: string;
  roles: string[];
  firstName?: string;
  lastName?: string;
  selectedRole?: string;
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  displayedColumns = ['username', 'roles', 'actions'];
  users: UserDto[] = [];
  isLoading = false;
  editingUser: UserDto | null = null;
  private pendingEditUsername: string | null = null;
  private availableRolesCache: string[] = [];

  form = this.fb.group({
    username: ['', [Validators.required]],
    password: [''],
    isAdmin: [false]
  });

  constructor(private http: HttpClient, private fb: FormBuilder, private snack: MatSnackBar, private dialog: MatDialog, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.pendingEditUsername = this.route.snapshot.queryParamMap.get('edit');
    this.loadUsers();
    // Load available roles from backend for dialogs
    this.http.get<string[]>('api/roles', { withCredentials: true }).subscribe({
      next: (list) => { this.availableRolesCache = (list || []).slice().sort(); },
      error: () => { /* ignore, fallback in getAvailableRoles */ }
    });
  }

  private api<T>(path: string, options?: any) {
    return this.http.request<T>(options?.method || 'GET', path, {
      withCredentials: true,
      headers: { 'Content-Type': 'application/json' },
      body: options?.body
    });
  }

  loadUsers(): void {
    this.isLoading = true;
    this.http.get<UserDto[]>('api/users', { withCredentials: true }).subscribe({
      next: (list) => {
        this.users = list || [];
        this.isLoading = false;
        // If there is a pending edit request from query params, handle it now
        if (this.pendingEditUsername) {
          this.handlePendingEdit();
        }
      },
      error: (err) => {
        console.error(err);
        this.snack.open('Failed to load users', 'Close', { duration: 3000 });
        this.isLoading = false;
        // Even if users list failed to load, try to handle pending edit for current user
        if (this.pendingEditUsername) {
          this.handlePendingEdit(true);
        }
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    if (this.editingUser) {
      this.updateUser();
    } else {
      this.createUser();
    }
  }

  private createUser(): void {
    const username = (this.form.value.username || '').trim();
    const password = this.form.value.password || '';
    const roles = this.form.value.isAdmin ? ['ADMIN'] : [];
    if (!username || !password) {
      this.snack.open('Username and password are required', 'Close', { duration: 3000 });
      return;
    }
    this.api('api/users', { method: 'POST', body: { username, password, roles } }).subscribe({
      next: () => {
        this.snack.open('User created', 'Close', { duration: 2000 });
        this.resetForm();
        this.loadUsers();
      },
      error: (err) => {
        console.error(err);
        const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
        this.snack.open('Failed to create user: ' + msg, 'Close', { duration: 4000 });
      }
    });
  }

  startEdit(user: UserDto): void {
    this.editingUser = user;
    this.form.patchValue({
      username: user.username,
      password: '',
      isAdmin: (user.roles || []).includes('ADMIN')
    });
    this.form.get('username')?.disable();
  }

  cancelEdit(): void {
    this.editingUser = null;
    this.resetForm();
  }

  private updateUser(): void {
    const username = this.editingUser!.username;
    const roles = this.form.value.isAdmin ? ['ADMIN'] : [];
    const body: any = { roles };
    this.api(`api/users/${encodeURIComponent(username)}`, { method: 'PUT', body }).subscribe({
      next: () => {
        const pwd = (this.form.value.password || '').trim();
        if (pwd) {
          this.api(`api/users/${encodeURIComponent(username)}/password`, { method: 'POST', body: { password: pwd } }).subscribe({
            next: () => {
              this.snack.open('User updated', 'Close', { duration: 2000 });
              this.cancelEdit();
              this.loadUsers();
            },
            error: (err) => {
              console.error(err);
              const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
              this.snack.open('Updated roles but failed to update password: ' + msg, 'Close', { duration: 4000 });
              this.cancelEdit();
              this.loadUsers();
            }
          });
        } else {
          this.snack.open('User updated', 'Close', { duration: 2000 });
          this.cancelEdit();
          this.loadUsers();
        }
      },
      error: (err) => {
        console.error(err);
        const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
        this.snack.open('Failed to update user: ' + msg, 'Close', { duration: 4000 });
      }
    });
  }

  private resetForm(): void {
    this.form.reset({ username: '', password: '', isAdmin: false });
    this.form.get('username')?.enable();
  }

  deleteUser(username: string): void {
    if (!confirm(`Delete user ${username}?`)) return;
    this.api(`api/users/${encodeURIComponent(username)}`, { method: 'DELETE' }).subscribe({
      next: () => {
        this.snack.open('User deleted', 'Close', { duration: 2000 });
        this.loadUsers();
      },
      error: (err) => {
        console.error(err);
        const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
        this.snack.open('Failed to delete user: ' + msg, 'Close', { duration: 4000 });
      }
    });
  }

  resetPassword(username: string): void {
    const user = this.users.find(u => u.username === username);
    if (user) {
      this.openEditDialog(user);
      return;
    }
    // Fallback if user list is not loaded
    this.openEditDialog({ username, roles: [] });
  }

  private getAvailableRoles(): string[] {
    const list = this.availableRolesCache && this.availableRolesCache.length > 0 ? this.availableRolesCache : null;
    if (list) return list;
    const set = new Set<string>();
    this.users.forEach(u => (u.roles || []).forEach(r => set.add(r)));
    // ensure ADMIN is present as default option
    set.add('ADMIN');
    return Array.from(set).sort();
  }

  private handlePendingEdit(skipListLookup = false): void {
    const username = (this.pendingEditUsername || '').trim();
    if (!username) return;

    const clearParam = () => {
      // Remove the query param from URL
      this.router.navigate([], { relativeTo: this.route, queryParams: { edit: null }, queryParamsHandling: 'merge', replaceUrl: true });
      this.pendingEditUsername = null;
    };

    if (!skipListLookup) {
      const found = this.users.find(u => u.username === username);
      if (found) {
        this.openEditDialog(found);
        clearParam();
        return;
      }
    }

    // Fallback: try current user endpoint
    this.http.get<any>('api/users/me', { withCredentials: true }).subscribe({
      next: (me) => {
        const u: UserDto = { username: me?.username || username, roles: me?.roles || [] };
        // Only open if it is the same user as requested or if request was for 'me'
        if (u.username === username || username.toLowerCase() === 'me') {
          this.openEditDialog(u);
        }
        clearParam();
      },
      error: () => {
        clearParam();
      }
    });
  }

  openAddDialog(): void {
    const ref = this.dialog.open(UsersEditDialogComponent, {
      width: '480px',
      data: { user: null, availableRoles: this.getAvailableRoles() }
    });
    ref.afterClosed().subscribe(res => {
      if (!res) return;
      const username = (res.username || '').trim();
      const password = (res.password || '').trim();
      const firstName = (res.firstName || '').trim();
      const lastName = (res.lastName || '').trim();
      const roles: string[] = Array.isArray(res.roles) ? res.roles : [];
      const selectedRole = (res.selectedRole || '').trim();
      if (!username || !password) {
        this.snack.open('Username and password are required', 'Close', { duration: 3000 });
        return;
      }
      this.api('api/users', { method: 'POST', body: { username, password, roles, firstName, lastName, selectedRole } }).subscribe({
        next: () => {
          this.snack.open('User created', 'Close', { duration: 2000 });
          this.loadUsers();
        },
        error: (err) => {
          console.error(err);
          const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
          this.snack.open('Failed to create user: ' + msg, 'Close', { duration: 4000 });
        }
      });
    });
  }

  openEditDialog(user: UserDto): void {
    const ref = this.dialog.open(UsersEditDialogComponent, {
      width: '480px',
      data: { user, availableRoles: this.getAvailableRoles() }
    });
    ref.afterClosed().subscribe(res => {
      if (!res) return;
      const username = user.username;
      const roles: string[] = Array.isArray(res.roles) ? res.roles : [];
      const firstName = (res.firstName || '').trim();
      const lastName = (res.lastName || '').trim();
      const selectedRole = (res.selectedRole || '').trim();
      this.api(`api/users/${encodeURIComponent(username)}`, { method: 'PUT', body: { roles, firstName, lastName, selectedRole } }).subscribe({
        next: () => {
          const pwd = (res.password || '').trim();
          if (pwd) {
            this.api(`api/users/${encodeURIComponent(username)}/password`, { method: 'POST', body: { password: pwd } }).subscribe({
              next: () => {
                this.snack.open('User updated', 'Close', { duration: 2000 });
                this.loadUsers();
              },
              error: (err) => {
                console.error(err);
                const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
                this.snack.open('Updated roles but failed to update password: ' + msg, 'Close', { duration: 4000 });
                this.loadUsers();
              }
            });
          } else {
            this.snack.open('User updated', 'Close', { duration: 2000 });
            this.loadUsers();
          }
        },
        error: (err) => {
          console.error(err);
          const msg = err?.error ? (typeof err.error === 'string' ? err.error : JSON.stringify(err.error)) : 'Error';
          this.snack.open('Failed to update user: ' + msg, 'Close', { duration: 4000 });
        }
      });
    });
  }

  navigateToScripts(): void {
    this.router.navigate(['']);
  }
}
