/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Script } from '../../models/script.model';
import { ScriptService } from '../../services/script.service';

@Component({
  selector: 'app-script-metadata-dialog',
  templateUrl: './script-metadata-dialog.component.html',
  styleUrls: ['./script-metadata-dialog.component.scss']
})
export class ScriptMetadataDialogComponent {
  script: Script;
  scriptContent: string = '';
  isLoadingContent: boolean = false;
  isContentExpanded: boolean = false;

  constructor(
    private scriptService: ScriptService,
    public dialogRef: MatDialogRef<ScriptMetadataDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { script: Script }
  ) {
    this.script = data.script;
  }

  /**
   * Close the dialog.
   */
  close(): void {
    this.dialogRef.close();
  }

  /**
   * Toggle the script content section.
   */
  toggleContent(): void {
    this.isContentExpanded = !this.isContentExpanded;
    
    if (this.isContentExpanded && !this.scriptContent) {
      this.loadScriptContent();
    }
  }

  /**
   * Load the content of the script.
   */
  private loadScriptContent(): void {
    if (!this.script) {
      return;
    }

    this.isLoadingContent = true;
    this.scriptService.getScriptContent(this.script.name).subscribe(
      (content) => {
        this.scriptContent = content;
        this.isLoadingContent = false;
      },
      (error) => {
        console.error('Error loading script content:', error);
        this.scriptContent = 'Failed to load script content: ' + error.message;
        this.isLoadingContent = false;
      }
    );
  }
}
