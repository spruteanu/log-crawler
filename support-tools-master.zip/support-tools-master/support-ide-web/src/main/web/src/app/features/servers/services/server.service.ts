/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { Server, ConnectionTestResult } from '../models/server.model';

@Injectable({
  providedIn: 'root'
})
export class ServerService {
  private apiUrl = '/support-ide/api/servers';
  private encryptionKey: string | null = null;

  constructor(private http: HttpClient) { }

  /**
   * Get all servers.
   */
  getAllServers(): Observable<Server[]> {
    return this.http.get<Server[]>(this.apiUrl);
  }

  /**
   * Get active servers.
   */
  getActiveServers(): Observable<Server[]> {
    return this.http.get<Server[]>(`${this.apiUrl}/active`);
  }

  /**
   * Get a specific server by ID.
   * @param id The server ID
   */
  getServer(id: string): Observable<Server> {
    return this.http.get<Server>(`${this.apiUrl}/${id}`);
  }

  /**
   * Create a new server.
   * @param server The server to create
   */
  createServer(server: Server): Observable<Server> {
    // Encrypt password if provided
    return this.encryptPasswordIfNeeded(server).pipe(
      switchMap(encryptedServer => this.http.post<Server>(this.apiUrl, encryptedServer))
    );
  }

  /**
   * Update an existing server.
   * @param id The server ID
   * @param server The updated server
   */
  updateServer(id: string, server: Server): Observable<Server> {
    // Encrypt password if provided
    return this.encryptPasswordIfNeeded(server).pipe(
      switchMap(encryptedServer => this.http.put<Server>(`${this.apiUrl}/${id}`, encryptedServer))
    );
  }

  /**
   * Delete a server.
   * @param id The server ID
   */
  deleteServer(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  /**
   * Test connection to a server (SSH).
   * @param id The server ID
   */
  testConnection(id: string): Observable<ConnectionTestResult> {
    return this.http.post<ConnectionTestResult>(`${this.apiUrl}/${id}/test-connection`, {});
  }

  /**
   * Test gRPC connection to the server's agent.
   * Calls backend endpoint which should try to reach the remote agent using hostname/token.
   */
  testGrpcConnection(id: string): Observable<ConnectionTestResult> {
    return this.http.post<ConnectionTestResult>(`${this.apiUrl}/${id}/grpc-test-connection`, {});
  }

  /**
   * Download gRPC agent bundle (legacy, generic bundle).
   */
  downloadGrpcAgentBundle(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/grpc-agent-bundle`, { 
      responseType: 'blob' 
    });
  }

  /**
   * Download a host-specific gRPC agent bundle for the given server ID.
   */
  downloadGrpcAgentBundleForServer(id: string, sessionId?: string): Observable<Blob> {
    const params: { [key: string]: string } = {};
    if (sessionId) {
      params['sessionId'] = sessionId;
    }
    return this.http.get(`${this.apiUrl}/${id}/grpc-agent-bundle`, {
      responseType: 'blob',
      params
    });
  }

  /**
   * Establish SSE connection for download progress tracking.
   */
  getDownloadProgress(sessionId: string): EventSource {
    return new EventSource(`${this.apiUrl}/download-progress/${sessionId}`);
  }

  /**
   * Establish SSE connection for deployment progress tracking.
   */
  getDeployProgress(sessionId: string): EventSource {
    return new EventSource(`${this.apiUrl}/deploy-progress/${sessionId}`);
  }

  /**
   * Deploy the gRPC agent to the remote server for the given server ID.
   * If a server override is provided, it will be sent (with password encrypted if present)
   * so that the backend can use current, unsaved values during deployment.
   */
  deployGrpcAgent(id: string, serverOverride?: Server, sessionId?: string): Observable<any> {
    const params: { [key: string]: string } = {};
    if (sessionId) {
      params['sessionId'] = sessionId;
    }

    if (serverOverride) {
      return this.encryptPasswordIfNeeded(serverOverride).pipe(
        switchMap(encrypted => this.http.post(`${this.apiUrl}/${id}/grpc-agent-deploy`, encrypted, { params }))
      );
    }
    return this.http.post(`${this.apiUrl}/${id}/grpc-agent-deploy`, {}, { params });
  }

  /**
   * Generate a gRPC token deterministically from the hostname.
   */
  generateGrpcTokenForHostname(hostname: string): Observable<{ token: string; hostname: string }> {
    return this.http.get<{ token: string; hostname: string }>(`${this.apiUrl}/generate-grpc-token/${encodeURIComponent(hostname)}`);
  }

  /**
   * Get encryption key for frontend use.
   */
  private getEncryptionKey(): Observable<string> {
    if (this.encryptionKey) {
      return new Observable<string>(observer => {
        observer.next(this.encryptionKey!);
        observer.complete();
      });
    }
    
    return this.http.get(`${this.apiUrl}/encryption-key`, { responseType: 'text' }).pipe(
      map(key => {
        this.encryptionKey = key;
        return key;
      })
    );
  }

  /**
   * Encrypt a password for frontend use.
   * @param password The password to encrypt
   * @param key The encryption key
   */
  private encryptPassword(password: string, key: string): string {
    // Simple XOR encryption with the key
    let result = '';
    for (let i = 0; i < password.length; i++) {
      result += String.fromCharCode(password.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return btoa(result); // Base64 encode
  }

  /**
   * Encrypt the password in a server object if needed.
   * @param server The server object
   */
  private encryptPasswordIfNeeded(server: Server): Observable<Server> {
    if (!server.password) {
      return new Observable<Server>(observer => {
        observer.next(server);
        observer.complete();
      });
    }
    
    return this.getEncryptionKey().pipe(
      map(key => {
        const encryptedServer = { ...server };
        encryptedServer.password = this.encryptPassword(server.password!, key);
        return encryptedServer;
      })
    );
  }
}
