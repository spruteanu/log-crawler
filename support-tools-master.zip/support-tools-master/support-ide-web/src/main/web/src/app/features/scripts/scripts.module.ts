/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The OpenSearch Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {ScriptsRoutingModule} from './scripts-routing.module';
import {ScriptsComponent} from './scripts.component';
import {ScriptListComponent} from './components/script-list/script-list.component';
import {ScriptMetadataComponent} from './components/script-metadata/script-metadata.component';
import {ScriptExecutionComponent} from './components/script-execution/script-execution.component';
import {ScriptMetadataDialogComponent} from './components/script-metadata-dialog/script-metadata-dialog.component';
import {AddScriptDialogComponent} from './components/add-script-dialog/add-script-dialog.component';
import {HistoryDialogComponent} from './components/history-dialog/history-dialog.component';
import { ExecuteOnContainerDialogComponent } from './components/execute-on-container-dialog/execute-on-container-dialog.component';

// Highlight.js Module
import {HIGHLIGHT_OPTIONS, HighlightModule} from 'ngx-highlightjs';

// Angular Material Modules
import {MatListModule} from '@angular/material/list';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatDividerModule} from '@angular/material/divider';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatChipsModule} from '@angular/material/chips';
import {DragDropModule} from '@angular/cdk/drag-drop';

@NgModule({
    declarations: [
        ScriptsComponent,
        ScriptListComponent,
        ScriptMetadataComponent,
        ScriptExecutionComponent,
        ScriptMetadataDialogComponent,
        AddScriptDialogComponent,
        HistoryDialogComponent,
        ExecuteOnContainerDialogComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ScriptsRoutingModule,
        HighlightModule,

        // Angular Material
        MatListModule,
        MatCardModule,
        MatButtonModule,
        MatIconModule,
        MatProgressBarModule,
        MatDividerModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatInputModule,
        MatSnackBarModule,
        MatDialogModule,
        MatSlideToggleModule,
        MatSelectModule,
        MatTooltipModule,
        MatProgressSpinnerModule,
        MatChipsModule,
        DragDropModule
    ],
    providers: [
        {
            provide: HIGHLIGHT_OPTIONS,
            useValue: {
                fullLibraryLoader: () => import('highlight.js')
            }
        }
    ]
})
export class ScriptsModule {
}
