import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ClusterService } from './services/cluster.service';
import { Cluster, KubectlResult } from './models/cluster.model';
import { ClusterDialogComponent } from './components/cluster-dialog/cluster-dialog.component';
import { KubectlDialogComponent } from './components/kubectl-dialog/kubectl-dialog.component';
import { Subject, of } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';

@Component({
    selector: 'app-clusters',
    templateUrl: './clusters.component.html',
    styleUrls: ['./clusters.component.scss']
})
export class ClustersComponent implements OnInit, OnDestroy {
    clusters: Cluster[] = [];
    isLoading = false;

    private destroy$ = new Subject<void>();

    constructor(
        private clusterService: ClusterService,
        private cdr: ChangeDetectorRef,
        private dialog: MatDialog,
        private snackBar: MatSnackBar,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.loadClusters();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    loadClusters(): void {
        this.isLoading = true;
        this.clusterService.getAllClusters().pipe(
            takeUntil(this.destroy$),
            catchError(error => {
                console.error('Error loading clusters:', error);
                this.isLoading = false;
                return of([]);
            })
        ).subscribe(clusters => {
            this.clusters = clusters;
            this.isLoading = false;
            this.cdr.detectChanges();
        });
    }

    navigateToScripts(): void {
        this.router.navigate(['']);
    }

    navigateToServers(): void {
        this.router.navigate(['/servers']);
    }

    openAddClusterDialog(): void {
        const dialogRef = this.dialog.open(ClusterDialogComponent, {
            width: '600px',
            data: { cluster: null },
            disableClose: false
        });

        dialogRef.afterClosed().subscribe((result: Cluster) => {
            if (result) {
                this.clusterService.createCluster(result).pipe(
                    takeUntil(this.destroy$),
                    catchError(error => {
                        console.error('Error creating cluster:', error);

                        let errorMessage = 'Cluster creation failed';
                        if (error && error.error) {
                            if (error.error.message) {
                                errorMessage = error.error.message;
                            } else if (typeof error.error === 'string') {
                                errorMessage = error.error;
                            }
                        }

                        this.snackBar.open(errorMessage, 'Închide', {
                            duration: 8000,
                            panelClass: ['error-snackbar'],
                            verticalPosition: 'top'
                        });

                        return of(null);
                    })
                ).subscribe(cluster => {
                    if (cluster) {
                        this.clusters.push(cluster);
                        this.clusters = [...this.clusters];
                        this.cdr.detectChanges();

                        this.snackBar.open('Cluster created successfully', 'Close', {
                            duration: 3000,
                            panelClass: ['success-snackbar'],
                            verticalPosition: 'top'
                        });
                    }
                });
            }
        });
    }

    openEditClusterDialog(cluster: Cluster): void {
        const dialogRef = this.dialog.open(ClusterDialogComponent, {
            width: '600px',
            data: { cluster: { ...cluster } },
            disableClose: false
        });

        dialogRef.afterClosed().subscribe((result: Cluster) => {
            if (result) {
                this.clusterService.updateCluster(cluster.id, result).pipe(
                    takeUntil(this.destroy$),
                    catchError(error => {
                        console.error('Error updating cluster:', error);

                        let errorMessage = 'Cluster update failed';
                        if (error && error.error) {
                            if (error.error.message) {
                                errorMessage = error.error.message;
                            } else if (typeof error.error === 'string') {
                                errorMessage = error.error;
                            }
                        }

                        this.snackBar.open(errorMessage, 'Close', {
                            duration: 8000,
                            panelClass: ['error-snackbar'],
                            verticalPosition: 'top'
                        });

                        return of(null);
                    })
                ).subscribe(updatedCluster => {
                    if (updatedCluster) {
                        const index = this.clusters.findIndex(c => c.id === updatedCluster.id);
                        if (index !== -1) {
                            this.clusters[index] = updatedCluster;
                            this.clusters = [...this.clusters];
                            this.cdr.detectChanges();
                        }

                        // Afișează mesaj de succes
                        this.snackBar.open('Cluster successfully updated', 'Close', {
                            duration: 3000,
                            panelClass: ['success-snackbar'],
                            verticalPosition: 'top'
                        });
                    }
                });
            }
        });
    }

    deleteCluster(cluster: Cluster): void {
        if (confirm(`Are you sure you want to delete the cluster "${cluster.name}"?`)) {
            this.clusterService.deleteCluster(cluster.id).pipe(
                takeUntil(this.destroy$),
                catchError(error => {
                    console.error('Error deleting cluster:', error);

                    let errorMessage = 'Cluster deletion failed';
                    if (error && error.error) {
                        if (error.error.message) {
                            errorMessage = error.error.message;
                        } else if (typeof error.error === 'string') {
                            errorMessage = error.error;
                        }
                    }

                    this.snackBar.open(errorMessage, 'Close', {
                        duration: 8000,
                        panelClass: ['error-snackbar'],
                        verticalPosition: 'top'
                    });

                    return of(false);
                })
            ).subscribe(success => {
                if (success !== false) {
                    this.clusters = this.clusters.filter(c => c.id !== cluster.id);
                    this.cdr.detectChanges();

                    this.snackBar.open('Cluster successfully deleted', 'Close', {
                        duration: 3000,
                        panelClass: ['success-snackbar'],
                        verticalPosition: 'top'
                    });
                }
            });
        }
    }

    testConnection(cluster: Cluster): void {
        cluster.testProgress = {
            isTesting: true,
            message: 'Test connection...'
        };

        this.clusterService.testConnection(cluster.id).pipe(
            takeUntil(this.destroy$),
            catchError(error => {
                console.error('Connection test error:', error);

                cluster.testProgress = undefined;
                this.cdr.detectChanges();

                let errorMessage = 'Connection test failed.';
                if (error && error.error) {
                    if (error.error.message) {
                        errorMessage = error.error.message;
                    } else if (typeof error.error === 'string') {
                        errorMessage = error.error;
                    }
                }

                this.snackBar.open(errorMessage, 'Close', {
                    duration: 8000,
                    panelClass: ['error-snackbar'],
                    verticalPosition: 'top'
                });

                return of({ success: false, message: errorMessage });
            })
        ).subscribe(result => {
            cluster.testProgress = undefined;
            this.cdr.detectChanges();

            if (result.success) {
                this.snackBar.open(result.message || 'Connection successful', 'Close', {
                    duration: 3000,
                    panelClass: ['success-snackbar'],
                    verticalPosition: 'top'
                });
            } else {
                this.snackBar.open(result.message || 'Connection failed', 'Close', {
                    duration: 8000,
                    panelClass: ['error-snackbar'],
                    verticalPosition: 'top'
                });
            }
        });
    }

    openKubectlDialog(cluster: Cluster): void {
        const dialogRef = this.dialog.open(KubectlDialogComponent, {
            width: '800px',
            data: { cluster },
            disableClose: false
        });

        dialogRef.afterClosed().subscribe((result: { args: string[] }) => {
            if (result && result.args && result.args.length > 0) {
                this.executeKubectl(cluster, result.args);
            }
        });
    }

    executeKubectl(cluster: Cluster, args: string[]): void {
        cluster.testProgress = {
            isTesting: true,
            message: 'Execution kubectl ' + args.join(' ') + '...'
        };

        this.clusterService.executeKubectl(cluster.id, args).pipe(
            takeUntil(this.destroy$),
            catchError(error => {
                console.error('Error executing kubectl:', error);

                cluster.testProgress = undefined;
                this.cdr.detectChanges();

                let errorMessage = 'kubectl command execution failed';
                if (error && error.error) {
                    if (error.error.message) {
                        errorMessage = error.error.message;
                    } else if (typeof error.error === 'string') {
                        errorMessage = error.error;
                    }
                }

                this.snackBar.open(errorMessage, 'Close', {
                    duration: 8000,
                    panelClass: ['error-snackbar'],
                    verticalPosition: 'top'
                });

                return of({ success: false, error: errorMessage });
            })
        ).subscribe((result: KubectlResult) => {
            cluster.testProgress = undefined;
            this.cdr.detectChanges();

            if (result.success) {
                this.dialog.open(KubectlDialogComponent, {
                    width: '800px',
                    data: {
                        cluster,
                        result,
                        args
                    },
                    disableClose: false
                });
            } else {
                this.snackBar.open(result.error || 'kubectl command execution failed', 'Close', {
                    duration: 8000,
                    panelClass: ['error-snackbar'],
                    verticalPosition: 'top'
                });
            }
        });
    }
}
