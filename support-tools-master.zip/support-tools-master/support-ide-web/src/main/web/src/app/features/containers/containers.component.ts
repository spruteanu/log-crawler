/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Container } from './models/container.model';
import { ContainerService } from './services/container.service';
import { ContainerDialogComponent } from './components/container-dialog/container-dialog.component';

@Component({
  selector: 'app-containers',
  templateUrl: './containers.component.html',
  styleUrls: ['./containers.component.scss']
})
export class ContainersComponent implements OnInit {
  displayedColumns = ['name', 'image', 'namespace', 'pod', 'container', 'active', 'actions'];
  data: Container[] = [];
  loading = false;

  constructor(private service: ContainerService, private dialog: MatDialog, private snack: MatSnackBar) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.loading = true;
    this.service.list().subscribe({
      next: d => { this.data = d || []; this.loading = false; },
      error: () => { this.loading = false; this.snack.open('Failed to load containers', 'Close', { duration: 3000 }); }
    });
  }

  openAdd(): void {
    const ref = this.dialog.open(ContainerDialogComponent, { width: '600px', data: { mode: 'create' } });
    ref.afterClosed().subscribe(result => { if (result) { this.service.create(result).subscribe(() => { this.snack.open('Container created', 'Close', { duration: 2000 }); this.refresh(); }); } });
  }

  openEdit(c: Container): void {
    const ref = this.dialog.open(ContainerDialogComponent, { width: '600px', data: { mode: 'edit', container: c } });
    ref.afterClosed().subscribe(result => { if (result) { this.service.update(c.id!, { ...c, ...result }).subscribe(() => { this.snack.open('Container updated', 'Close', { duration: 2000 }); this.refresh(); }); } });
  }

  delete(c: Container): void {
    if (!c.id) return;
    if (!confirm('Delete container "' + c.name + '"?')) return;
    this.service.delete(c.id).subscribe({ next: () => { this.snack.open('Deleted', 'Close', { duration: 1500 }); this.refresh(); }, error: () => this.snack.open('Failed to delete', 'Close', { duration: 3000 })});
  }
}
